 var _cur_year = new Date().getFullYear();
 var copyright="&copy; " + _cur_year + " JPMorgan Chase & Co.";  // copyright
 var copyright_fusa="&copy; " + _cur_year + " First USA"; // first usa copyright
 var copyright_fdic="&copy; " + _cur_year + " JPMorgan Chase Bank"; // member fdic copyright
 var copyright_fdic2="&copy; " + _cur_year + " JPMorgan Chase Bank, N.A. Member FDIC."; // member fdic copyright
 var copyright_year="&copy; " + _cur_year + ""; //year
 var copyright_bestbuy="&copy; " + _cur_year + " Best Buy Canada Ltd."; //bestbuy
 var copyright_bestbuyca="&copy; " + _cur_year + " Best Buy Canada Ltee"; //bestbuy

 try{
  document.getElementById("copyright").innerHTML = copyright;
 } catch(e){
 }