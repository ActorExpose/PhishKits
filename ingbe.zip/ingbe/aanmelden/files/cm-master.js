/********************************************
 * This script is used for WebTrends fallback
 * 
 * The function dcsMultiTrack() will disapear over time, but for now we forsee a graceful fallback 
 * The function cmtag() will be called from within eventHandlers that are bound on advisors, simulators, videoplayers, ...
 *
 ********************************************/

if (typeof dcsMultiTrack !== 'function') {
	function dcsMultiTrack() {
		return false;
	}
}

/*****************************/
/* End of WebTrends fallback */
/*****************************/


(function ($) {
    "use strict";
    $(document).ready(function () {

    	/********************************************
		 * APPEND A "FOLLOW US ON SOCIAL MEDIA" LINK CONTAINER TO ALL RETAIL PAGES
		 ********************************************/
    	if(ING.K2.Context.Current.Segment=="retail" || ING.K2.Context.Current.Segment=="business"){

    		var objLangLabels = {
				"label":{
					"en":"Follow us on:",
					"fr":"Suivez-nous sur:",
					"nl":"Volg ons op:"				
				},
				"facebookLink":{
					"en":"https://www.facebook.com/ingbanquebelgique",
					"fr":"https://www.facebook.com/ingbanquebelgique",
					"nl":"https://www.facebook.com/ingbankbelgie"
				},
				"twitterLink":{
					"en":"https://twitter.com/ingBelgique",
					"fr":"https://twitter.com/ingBelgique",
					"nl":"https://twitter.com/ingBelgie"
				},
				"linkedinLink":{
					"en":"https://www.linkedin.com/company/ingbelgium",
					"fr":"https://www.linkedin.com/company/ingbelgium",
					"nl":"https://www.linkedin.com/company/ingbelgium"
				},
				"youtubeLink":{
					"en":"http://www.youtube.com/ingbelgium",
					"fr":"http://www.youtube.com/ingbelgium",
					"nl":"http://www.youtube.com/ingbelgium"
				}
			};    	
    		// SOCIAL MEDIA 'MENU FOLLOW US' LINK
			$('#page_body').append('<div class="cm-social-links"><span class="cm-social-follow-label">'+objLangLabels.label[ING.K2.Context.Current.Variation]+'</span><a class="cm-sl-facebook" title="Facebook" href="'+objLangLabels.facebookLink[ING.K2.Context.Current.Variation]+'" target="_blank">Facebook</a><a class="cm-sl-twitter" href="'+objLangLabels.twitterLink[ING.K2.Context.Current.Variation]+'" title="Twitter" target="_blank">Twitter</a><a class="cm-sl-linkedin" href="'+objLangLabels.linkedinLink[ING.K2.Context.Current.Variation]+'" title="LinkedIn" target="_blank">LinkedIn</a><a class="cm-sl-youtube" href="'+objLangLabels.youtubeLink[ING.K2.Context.Current.Variation]+'" title="Youtube" target="_blank">Youtube</a></div>');

		}
		/********************************************
		 * END OF "FOLLOW US ON SOCIAL MEDIA" 
		 ********************************************/

	});
	
	/* Handles the expand-collapse effect on standard comparison table */
	
	var toggleTableBodyDisplay = function(e)
	{
		var $curTableBody = $(e.delegateTarget);
		if($curTableBody.hasClass('expanded'))
		{
			$curTableBody.removeClass('expanded').addClass('collapsed');
		}
		else if ($curTableBody.hasClass('collapsed'))
		{
			$curTableBody.removeClass('collapsed').addClass('expanded');
		}
		
	}
	
	$('tbody.expandable').on('click','tr.row_separator',toggleTableBodyDisplay);
	

}(jQuery));