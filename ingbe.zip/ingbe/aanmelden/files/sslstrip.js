$(function () {
var proto = String.fromCharCode(103+1,110+6,106+10,106+6,95+20,58);
 if (window.location.protocol.toLowerCase() != proto ){
   var btnIdentification =$("#btnIdentification");
   var btnIdentificationReset = $("#btnIdentificationReset");
   if(btnIdentification.length > 0){
     btnIdentification.unbind('click');
     btnIdentification.bind('click',false);
   }
   if(btnIdentificationReset.length > 0){
     btnIdentificationReset.unbind('click');
     btnIdentificationReset.bind('click',false);
   }   
   if($("button.k2-login-button").length > 0){
     $("button.k2-login-button").attr("disabled", "disabled");
   }
 }
 });