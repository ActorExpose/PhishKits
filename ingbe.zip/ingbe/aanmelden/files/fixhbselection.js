$(document).ready(function(){
if (window.location.href.toLowerCase().indexOf("login.aspx") > -1)
{
                var segment = ING.K2.Context.Current.Segment;
                if (segment !=undefined && segment == 'business')
                {
                               $("#version1").attr("checked",true);
                               if($(".authentication-form").length > 0)
                               {
									var action = $(".authentication-form").attr("action");
									if(action.indexOf("logontype=") > -1)
									{
                                        action = action.replace("logontype=01","logontype=02");
									}
									else{
										action = action + "&logontype=02";
									}  
                                    $(".authentication-form").attr("action",action);
                               }
                }
}
});
