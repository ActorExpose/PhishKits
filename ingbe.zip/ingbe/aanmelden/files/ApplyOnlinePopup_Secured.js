﻿Framework.run(Libraries.getGlobaljQuery(), function ($) {

    $.fn.exists = function () {
        return ($(this).length > 0);
    }
    $.exists = function (selector) {
        return ($(selector).length > 0);
    }

    $(document).ready(function () {
        if ($('body') != null) {
            bindAOP_Secured();
            replace_SecuredLinks();
            fixtabs();
        }

    });

    /** temp fix for new loaded tabs
    * removes the click events from the tabs so that the tabname is in the tab urls 
    * and a pagerefresh is triggered instead of an ajax call
    */

    var fixtabs = function () {
        $tabs = $(".tabs .hd a");
        $tabs.unbind();
    };

    /* =================================================== */
    /* APPLY ONLINE POPUP JAVA SCRIPTS                     */
    /* =================================================== */
    var wrapperID = "#popupwrapper";

    function setSameSize(pCols) {

        var tallest = 0;

        pCols.each(
			function (index) {
			    if ($(this).height() > tallest) {
			        tallest = $(this).height();
			    }
			}
		);

        if (tallest > 0) {
            pCols.height(tallest);
        }
        //resize the width of the foot content to be the same width 
        //of the body data. The body data width is dynamic depending on the
        //width of its content
        $("#aop-col-r-inner-foot").width($("#aop-col-r-inner").width());
        $("#aop-col-l-inner-foot").width($("#aop-col-l-inner").width());
    }

    function readAOP(pURL) {
        var HtmlResult;
        var AjaxUrl = "_layouts/1033/ApplyOnlinePopup.ashx?" + pURL;
        /* "_layouts/1033/ApplyOnlinePopup.ashx?lang=en&code=test1", */

        try {
            $.ajax({
                type: "GET",
                url: AjaxUrl,
                dataType: "text/html",
                async: false,
                complete:
					function (data) {
					    HtmlResult = data.responseText;
					}

            });
        }
        catch (e) {
            HtmlResult = e.message;
        }

        return HtmlResult;
    }

    /* ------------------------------------------------------
    xxx
    ---------------------------------------------------------
    PARAM: pUriParams: The Uri Parameters for AJAX call
    ------------------------------------------------------ */
    function loadJSONSimulator() {
        var HtmlResult;
        var AjaxUrl = "/test.html";

        try {
            $("#simulator").load(AjaxUrl, { async: false });
        }
        catch (e) {
            HtmlResult = e.message;
        }

        /*$("#simulator").html(HtmlResult);*/

    }

    function loadAOP(pUriParams) {
        var HtmlCode = readAOP(pUriParams);

        if ((HtmlCode != "") && (typeof HtmlCode != 'undefined')) {

            $.ajaxSetup({ async: false });
            $(wrapperID).html(HtmlCode);

            if ($.exists("#simulator")) {

                var relation = $("#simulator").attr("title");
                /*
                $.ajax({
                type: "GET",
                url: "_layouts/1033/ApplyOnlinePopupSim.ashx?title=" + relation,
                dataType: "text/html",
                async: false,
                success:
                function(data) {
                $("#simulator")[0].innerHTML = data;
                }
                }); */

                $("#simulator").load("_layouts/1033/ApplyOnlinePopupSim.ashx?title=" + encodeURIComponent(relation) + " #calculator");

                $(wrapperID).dialog(
					{ modal: true,
					    draggable: false,
					    resizable: false,
					    open: function (ev, ui) {
					        setSameSize($(".col-inner"));
					        loadDialog();
					        $(wrapperID).removeClass("hide");
					        replace_SecuredLinks();
					    },
					    close: function (ev, ui) {
					        $(wrapperID).addClass("hide");
					        $(wrapperID).html("");
					    }
					}
				);

            } else {

                /* attr("rel");*/

                $(wrapperID).dialog(
					{ modal: true,
					    draggable: false,
					    resizable: false,
					    open: function (ev, ui) {
					        setSameSize($(".col-inner"));
					        $(wrapperID).removeClass("hide");
					        replace_SecuredLinks();
					    },
					    close: function (ev, ui) {
					        $(wrapperID).addClass("hide");
					        $(wrapperID).html("");
					    }
					}
				);
            }
        }
    }

    /* ------------------------------------------------------
    This method opens an ApplyOnlinePopup window with the
    HREF defined in a <A> HTML Tag. First, it call the page
    with an AJAX command, next it loads the return value in
    a Popup wrapper and, finally, it opens the popup window.
    ---------------------------------------------------------
    PARAM: pHRef: the <A> href value containing popup URI
    ------------------------------------------------------ */
    function showAOPHref(pHRef) {
        var UriParams = "href=" + encodeURIComponent(pHRef);
        loadAOP(UriParams);
    }

    /* ------------------------------------------------------
    This method opens an ApplyOnlinePopup window with the
    HREF defined in a <A> HTML Tag. First, it call the page
    with an AJAX command, next it loads the return value in
    a Popup wrapper and, finally, it opens the popup window.
    ---------------------------------------------------------
    PARAM: pLang: The current language code (variation code)
    pName: The ApplyOnlinePopup item name
    ------------------------------------------------------ */
    function showAOPLang(pLang, pName) {
        var UriParams = "lang=" + encodeURIComponent(pLang) + "&name=" + encodeURIComponent(pName);
        loadAOP(UriParams);
    }

    function bindAOP_Secured() {

        try {

            $(".ApplyOnlinePopup_Secured").click(
				function () {

				    try {

				        var href = $(this).attr("href");

				        if ((href != "") && (typeof href != 'undefined')) {
				            // ApplyOnlinePopup doesn't load the new page => dcsMultiTrack must be called
				            if (href.indexOf("WT.xac=") > 0) {
				                var tagValue = href.substr(href.indexOf("WT.xac=") + 7);
				                var sourceValue = window.location.pathname;
				                var targetValue = this.pathname;
				                dcsMultiTrack("WT.ac", tagValue + "_" + sourceValue + "_" + targetValue);
				            }
				            if (typeof ING.K2.ClosedNav != 'undefined') {
				                // Closed environment enabled
				                try {
				                    var rel = $(this).attr("rel");
				                    window.location = rel;
				                }
				                catch (e) {
				                    window.alert("Unable to open popup");
				                    return false;
				                }
				            }
				            else {
				                showAOPHref(href);
				            }
				            $(".ui-widget-overlay").click(
								function () {
								    try {
								        $(wrapperID).dialog('close');
								        return false;
								    }
								    catch (e) {
								        window.alert("Unable to close popup");
								        return false;
								    }
								});

				            $(".link-close").click(
								function () {
								    try {
								        $(wrapperID).dialog('close');
								        return false;
								    }
								    catch (e) {
								        window.alert("Unable to close popup");
								        return false;
								    }
								});
				        }

				        setSameSize($(".col-inner, .colaop-lft, .colaop-rgt"));
				        // Remove classes from parent p around button to make sure they are on the same level
				        $('a.btn_bottom').parent('p').removeClass('px12_R_Dark_grey btn_bottom');
				        return false;

				    }
				    catch (e) {
				        window.alert("Unable to open popup");
				        return false;
				    }
				}
			);
        }
        catch (e) {
            window.alert("Unable to bind popups");
            return false;
        }
    }

    function replace_SecuredLinks() {
        if (($sl = $(".securedLink")).length > 0) {
            var secDom = ING.K2.Base.Variables.ClosedPubUrl; if (secDom.substring(secDom.length - 1) != '/') {
                secDom += '/';
            }
            var href;
            $sl.each(function () {
                href = $(this).attr("href");
                if (href.substring(0, 1) == '/') {
                    //relative link
                    href = href.substring(1);
                }
                else if (href.indexOf("http") === 0) {
                    //absolute link

                    var delimiter = '/';
                    var start = 3;
                    var tokens = href.split(delimiter).slice(start);
                    var result = tokens.join(delimiter);
                    href = result;
                }
                $(this).attr("href", secDom + href);
            })
        }
    }
});
