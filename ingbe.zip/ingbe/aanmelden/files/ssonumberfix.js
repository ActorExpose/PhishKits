$(function () {
$("input[id$=cardid], input[id$=ingid], input[id$=cardid1], input[id$=cardid2], input[id$=cardid3],input[id$=cardid4], input[id$=cardid5]").unbind("keydown");
  $("input[id$=cardid], input[id$=ingid], input[id$=cardid1], input[id$=cardid2], input[id$=cardid3],input[id$=cardid4], input[id$=cardid5]").keypress(function (e) {
		 var charCode = (e.which) ? e.which : e.keyCode;
        if (charCode == 46 || charCode == 8 || charCode == 9 || charCode == 27 || charCode == 13 ||
        ((charCode == 65 || charCode == 86 || charCode == 67 || charCode == 88) && e.ctrlKey === true) || charCode == 16) {
            return true;
        } else {
            if (!(charCode >= 48 && charCode <= 57)) {
                return false;
            }
        }
    });
});