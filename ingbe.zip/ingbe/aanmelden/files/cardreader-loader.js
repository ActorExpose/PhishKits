﻿(function($) {
    var logoutFileName = "logout.aspx",
        confVars = [],
        currentRevValue;


    var onInit = function() {
        createConfVars();
        if (loadCardreader()) {
            currentRevValue = getCurrentRevValue();
            if (confVars.CcrEwallEnabled === true && checkEwall()) {
                loadCcrScripts();
            } else {
                if (confVars.ScrEnabled === true) {
                    loadScrScripts();
                }
            }
        }
    };

    var loadCcrScripts = function() {
        loadScripts([
            confVars.CcrSconnectPath,
            confVars.CcrEnexPath,
            confVars.CcrJsonObjectPath,
            confVars.CcrJsPath + currentRevValue,
            confVars.ScrOverlayPath + currentRevValue
        ]);
    };

    var loadScrScripts = function() {
        loadScripts([
            confVars.ScrSconnectPath,
            confVars.ScrEnexPath,
            confVars.ScrJsonObjectPath,
            confVars.ScrJsPath + currentRevValue,
            confVars.ScrOverlayPath + currentRevValue
        ]);
    };

    var loadScripts = function(scripts) {
        scripts.forEach(function(script) {
            document.write("<script src=\"" + script + "\"></script>");
        });
    };

    var createConfVars = function() {
        var $ccrDialog = $(".ccr-dialog");
        confVars.CcrEnabled = $ccrDialog.data("ccrenabled");
        confVars.CcrEwallEnabled = $ccrDialog.data("ccrewallenabled");
        confVars.ScrEnabled = $ccrDialog.data("screnabled");
        confVars.CcrSconnectPath = $ccrDialog.data("ccrsconnectpath");
        confVars.CcrEnexPath = $ccrDialog.data("ccrenexpath");
        confVars.CcrJsonObjectPath = $ccrDialog.data("ccrjsonobjectpath");
        confVars.CcrJsPath = $ccrDialog.data("ccrjspath");
        confVars.ScrSconnectPath = $ccrDialog.data("scrsconnectpath");
        confVars.ScrEnexPath = $ccrDialog.data("screnexpath");
        confVars.ScrJsonObjectPath = $ccrDialog.data("scrjsonobjectpath");
        confVars.ScrJsPath = $ccrDialog.data("scrjspath");
        confVars.CcrIncludedUrls = $ccrDialog.data("ccrincludedurls");
        confVars.ScrOverlayPath = $ccrDialog.data("scroverlaypath");
    };

    var loadCardreader = function() {
        return confVars.CcrEnabled &&
        (typeof (ING.Session) !== "undefined" ||
            confVars.CcrIncludedUrls.toLowerCase().indexOf(logoutFileName) > -1 ||
            confVars.CcrIncludedUrls.toLowerCase().indexOf(getUrlFileName().toLowerCase()) > -1);
    };

    var getUrlFileName = function() {
        var urlParts = window.location.pathname.split("/");
        return urlParts.pop();
    };

    var getCurrentRevValue = function() {
        var $scripts = $("script"),
            $scriptSrc = $scripts[$scripts.length - 1].src;
        return $scriptSrc.substring($scriptSrc.indexOf("?rev="));
    };

    var checkEwall = function() {
        return window.navigator.userAgent.search(/E-WALL ([0-9,\- ]{0,16})/) > -1;
    };

    onInit();
})(Libraries.getGlobaljQuery());
