Framework.run(Libraries.getGlobaljQuery(), function ($) {

    "use strict";

    var ingId = "input.ingid",
        cardId = "input.cardid";

    /* - - - - - General - - - - - */

    var validateLogin = function () {
        var $ingid = $(ingId),
            $cardid = $(cardId),
            $password = $("input.password"),
            isCCR = $(".login-content").hasClass("ccr"),
            $identification = $(".txtIdentification");
        if (isCCR) {
            $ingid = null;
            $identification = null;
        }

        if (ING.SSO.validateLogin($ingid, $cardid, $password, $identification)) {
            var date = new Date();
            $(".login-container.UCR input[name='logonTimestamp']").val(ING.SSO.currentDateTime());
            $(".password-hidden").val(hex_sha1($password.val()).toUpperCase());
            if (!isCCR) {
                $(ingId + "-hidden").val(ING.SSO.cleanIngId($ingid));
            }
            $(cardId + "-hidden").val(ING.SSO.cleanCardId($cardid));
            $("input[name='URL']").val(ING.SSO.getQueryStringValue("URL"));
            ING.SSO.valueCheckedOrDefault($(".save-information:hidden"), $(".save-information:checkbox"));
            return true;
        } else {
            return false;
        }
    };

    var changeLogonType = function () {
        var $radioButton = $(this),
            $radioButtonValue = $radioButton.val(),
            $form = $radioButton.closest("[action]"),
            action = $form.attr("action");
        $(".logon-type").val($radioButton.val());
        if (action.indexOf("logontype=") > -1) {
            var actionVal = action.substring(0, action.length - 2) + $radioButtonValue;
        }
        else {
            var actionVal = action + "&logontype=" + $radioButtonValue;
        }
        $form.attr("action", actionVal);
    };


    var onInit = function () {

        ////////////////// ATTACH EVENTS /////////////////////

        var proto = String.fromCharCode(103 + 1, 110 + 6, 106 + 10, 106 + 6, 95 + 20, 58),
            httpsTrue = window.location.protocol.toLowerCase() === proto;

        $(".authentication-form").submit(function () {
            ING.SSO.disableSubmitButton();
            if (httpsTrue && validateLogin()) {
                ING.SSO.submitDiv();
            } else {
                return false;
            }
        });

        $(".version-wrapper")
                .on("change", "input.version", changeLogonType);

        
        if (!httpsTrue) {
            if ($("button.identification").length > 0) {
                $("button.identification").attr("disabled", "disabled");
            }
        }
    };

    onInit();
});