var lionAccountUrl = "/"+ING.K2.Context.Current.Variation + "/Retail/Pages/lionaccount-salesflow.aspx";
$('a[href$="free-and-online.aspx"]').attr("href",lionAccountUrl);
$('a[href$="free-ane-online.aspx?WT.xmenusource=LANGUAGE_NL"]').attr("href",lionAccountUrl);
