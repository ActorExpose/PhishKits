ING.K2.ApplyOnlinePopup = Framework.run(Libraries.getGlobaljQuery(), function ($) {

    var expose = {};

    var wrapperID = "#popupwrapper";

    var onLoad = function () {
        if ($('body') != null) {
            $('body').append('<div id="popupwrapper" class="hide"></div>');
            expose.bindAll();
        }
    };

    /* =================================================== */
    /* APPLY ONLINE POPUP JAVA SCRIPTS                     */
    /* =================================================== */


    var setSameSize = function (pCols) {
        var tallest = 0;
        pCols.each(
			function (index) {
			    if ($(this).height() > tallest) {
			        tallest = $(this).height();
			    }
			}
		);

        if (tallest > 0) {
            pCols.height(tallest);
        }
        //resize the width of the foot content to be the same width 
        //of the body data. The body data width is dynamic depending on the
        //width of its content
        $("#aop-col-r-inner-foot").width($("#aop-col-r-inner").width());
        $("#aop-col-l-inner-foot").width($("#aop-col-l-inner").width());
    };

    var readAOP = function (pURL) {
        var htmlResult;
        var ajaxUrl = "_layouts/1033/ApplyOnlinePopup.ashx?" + pURL;
        /* For authoring
        var localUrl = window.location.href.indexOf("/Pages") > 0 ? window.location.href.substring(0, window.location.href.indexOf("/Pages")) : window.location.href.substring(0, window.location.href.lastIndexOf("/"));
        var AjaxUrl = localUrl + "/_layouts/1033/ApplyOnlinePopup.ashx?" + pURL;*/
        try {
            $.ajax({
                type: "GET",
                url: ajaxUrl,
                dataType: "text/html",
                async: false,
                complete:
					function (data) {
					    htmlResult = data.responseText;
					}
            });
        }
        catch (e) {
            htmlResult = e.message;
        }
        return htmlResult;
    };

    /* ------------------------------------------------------
    xxx
    ---------------------------------------------------------
    PARAM: pUriParams: The Uri Parameters for AJAX call
    ------------------------------------------------------ */
    var loadJSONSimulator = function () {
        var HtmlResult;
        var AjaxUrl = "/test.html";

        try {
            $("#simulator").load(AjaxUrl, { async: false });
        }
        catch (e) {
            HtmlResult = e.message;
        }

    };

    var loadAOP = function (pUriParams) {
        var HtmlCode = readAOP(pUriParams);

        if ((HtmlCode != "") && (typeof HtmlCode != 'undefined')) {

            $.ajaxSetup({ async: false });
            $(wrapperID).html(HtmlCode);

            if ($("#simulator").length) {

                var relation = $("#simulator").attr("title");

                $("#simulator").load("_layouts/1033/ApplyOnlinePopupSim.ashx?title=" + encodeURIComponent(relation) + " #calculator");

                $(wrapperID).dialog(
					{ modal: true,
					    draggable: false,
					    resizable: false,
					    open: function (ev, ui) {
					        setSameSize($(".col-inner"));
					        loadDialog();
					        $(wrapperID).removeClass("hide");
					    },
					    close: function (ev, ui) {
					        $(wrapperID).addClass("hide");
					        $(wrapperID).html("");
					    }
					}
				);

            } else {

                $(wrapperID).dialog(
					{ modal: true,
					    draggable: false,
					    resizable: false,
					    open: function (ev, ui) {
					        setSameSize($(".col-inner"));
					        $(wrapperID).removeClass("hide");
					    },
					    close: function (ev, ui) {
					        $(wrapperID).addClass("hide");
					        $(wrapperID).html("");
					    }
					}
				);
            }
        }
    };

    /* ------------------------------------------------------
    This method opens an ApplyOnlinePopup window with the
    HREF defined in a <A> HTML Tag. First, it call the page
    with an AJAX command, next it loads the return value in
    a Popup wrapper and, finally, it opens the popup window.
    ---------------------------------------------------------
    PARAM: pHRef: the <A> href value containing popup URI
    ------------------------------------------------------ */
    var showAOPHref = function (pHRef) {
        var UriParams = "href=" + encodeURIComponent(pHRef);
        loadAOP(UriParams);
    };

    /* ------------------------------------------------------
    This method opens an ApplyOnlinePopup window with the
    HREF defined in a <A> HTML Tag. First, it call the page
    with an AJAX command, next it loads the return value in
    a Popup wrapper and, finally, it opens the popup window.
    ---------------------------------------------------------
    PARAM: pLang: The current language code (variation code)
    pName: The ApplyOnlinePopup item name
    ------------------------------------------------------ */
    var showAOPLang = function (pLang, pName) {
        var UriParams = "lang=" + encodeURIComponent(pLang) + "&name=" + encodeURIComponent(pName);
        loadAOP(UriParams);
    };

    expose.bindAll = function () {
        try {
            $(".ApplyOnlinePopup").click(
				function () {
				    try {
				        var href = $(this).attr("href");

				        if ((href != "") && (typeof href != 'undefined')) {
				            // ApplyOnlinePopup doesn't load the new page => dcsMultiTrack must be called
				            if (href.indexOf("WT.xac=") > 0) {
				                var tagValue = href.substr(href.indexOf("WT.xac=") + 7);
				                var sourceValue = window.location.pathname;
				                var targetValue = this.pathname;
				                dcsMultiTrack("WT.ac", tagValue + "_" + sourceValue + "_" + targetValue);
				            }
				            showAOPHref(href);
				            $(".ui-widget-overlay").click(
								function () {
								    try {
								        $(wrapperID).dialog('close');
								        return false;
								    }
								    catch (e) {
								        window.alert("Unable to close popup");
								        return false;
								    }
								});

				            $(".link-close").click(
								function () {
								    try {
								        $(wrapperID).dialog('close');
								        return false;
								    }
								    catch (e) {
								        window.alert("Unable to close popup");
								        return false;
								    }
								});
				        }

				        setSameSize($(".col-inner, .colaop-lft, .colaop-rgt"));
				        // Remove classes from parent p around button to make sure they are on the same level
				        $('a.btn_bottom').parent('p').removeClass('px12_R_Dark_grey btn_bottom');
				        return false;

				    }
				    catch (e) {
				        window.alert("Unable to open popup");
				        return false;
				    }
				}
			);
        }
        catch (e) {
            window.alert("Unable to bind popups");
            return false;
        }
    };

    $(onLoad);

    return expose;
});