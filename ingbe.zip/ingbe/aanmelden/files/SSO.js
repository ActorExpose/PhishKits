/*
	Masked Input plugin for jQuery
	Copyright (c) 2007-2013 Josh Bush (digitalbush.com)
	Licensed under the MIT license (http://digitalbush.com/projects/masked-input-plugin/#license)
	Version: 1.3.1
*/
(function($) {
	function getPasteEvent() {
    var el = document.createElement('input'),
        name = 'onpaste';
    el.setAttribute(name, '');
    return (typeof el[name] === 'function')?'paste':'input';             
}

var pasteEventName = getPasteEvent() + ".mask",
	ua = navigator.userAgent,
	iPhone = /iphone/i.test(ua),
	android=/android/i.test(ua),
	caretTimeoutId;

$.mask = {
	//Predefined character definitions
	definitions: {
		'9': "[0-9]",
		'a': "[A-Za-z]",
		'*': "[A-Za-z0-9]"
	},
	dataName: "rawMaskFn",
	placeholder: '_',
};

$.fn.extend({
	//Helper Function for Caret positioning
	caret: function(begin, end) {
		var range;

		if (this.length === 0 || this.is(":hidden")) {
			return;
		}

		if (typeof begin == 'number') {
			end = (typeof end === 'number') ? end : begin;
			return this.each(function() {
				if (this.setSelectionRange) {
					this.setSelectionRange(begin, end);
				} else if (this.createTextRange) {
					range = this.createTextRange();
					range.collapse(true);
					range.moveEnd('character', end);
					range.moveStart('character', begin);
					range.select();
				}
			});
		} else {
			if (this[0].setSelectionRange) {
				begin = this[0].selectionStart;
				end = this[0].selectionEnd;
			} else if (document.selection && document.selection.createRange) {
				range = document.selection.createRange();
				begin = 0 - range.duplicate().moveStart('character', -100000);
				end = begin + range.text.length;
			}
			return { begin: begin, end: end };
		}
	},
	unmask: function() {
		return this.trigger("unmask");
	},
	mask: function(mask, settings) {
		var input,
			defs,
			tests,
			partialPosition,
			firstNonMaskPos,
			len;

		if (!mask && this.length > 0) {
			input = $(this[0]);
			return input.data($.mask.dataName)();
		}
		settings = $.extend({
			placeholder: $.mask.placeholder, // Load default placeholder
			completed: null
		}, settings);


		defs = $.mask.definitions;
		tests = [];
		partialPosition = len = mask.length;
		firstNonMaskPos = null;

		$.each(mask.split(""), function(i, c) {
			if (c == '?') {
				len--;
				partialPosition = i;
			} else if (defs[c]) {
				tests.push(new RegExp(defs[c]));
				if (firstNonMaskPos === null) {
					firstNonMaskPos = tests.length - 1;
				}
			} else {
				tests.push(null);
			}
		});

		return this.trigger("unmask").each(function() {
			var input = $(this),
				buffer = initBuffer(),
				focusText = input.val();

			function seekNext(pos) {
				while (++pos < len && !tests[pos]);
				return pos;
			}

			function seekPrev(pos) {
				while (--pos >= 0 && !tests[pos]);
				return pos;
			}

			function shiftL(begin,end) {
				var i,
					j;

				if (begin<0) {
					return;
				}

				for (i = begin, j = seekNext(end); i < len; i++) {
					if (tests[i]) {
						if (j < len && tests[i].test(buffer[j])) {
							buffer[i] = buffer[j];
							buffer[j] = settings.placeholder;
						} else {
							break;
						}

						j = seekNext(j);
					}
				}
				writeBuffer();
				input.caret(Math.max(firstNonMaskPos, begin));
			}

			function shiftR(pos) {
				var i,
					c,
					j,
					t;

				for (i = pos, c = settings.placeholder; i < len; i++) {
					if (tests[i]) {
						j = seekNext(i);
						t = buffer[i];
						buffer[i] = c;
						if (j < len && tests[j].test(t)) {
							c = t;
						} else {
							break;
						}
					}
				}
			}

			function keydownEvent(e) {
				var k = e.which,
					pos,
					begin,
					end;

				//backspace, delete, and escape get special treatment
				if (k === 8 || k === 46 || (iPhone && k === 127)) {
					pos = input.caret();
					begin = pos.begin;
					end = pos.end;

					if (end - begin === 0) {
						begin=k!==46?seekPrev(begin):(end=seekNext(begin-1));
						end=k===46?seekNext(end):end;
					}
					clearBuffer(begin, end);
					shiftL(begin, end - 1);

					e.preventDefault();
				} else if (k == 27) {//escape
					input.val(focusText);
					input.caret(0, checkVal());
					e.preventDefault();
				}
			}

			function keypressEvent(e) {
				var k = e.which,
					pos = input.caret(),
					p,
					c,
					next;

				if (e.ctrlKey || e.altKey || e.metaKey || k < 32) {//Ignore
					return;
				} else if (k) {
					if (pos.end - pos.begin !== 0){
						clearBuffer(pos.begin, pos.end);
						shiftL(pos.begin, pos.end-1);
					}

					p = seekNext(pos.begin - 1);
					if (p < len) {
						c = String.fromCharCode(k);
						if (tests[p].test(c)) {
							shiftR(p);

							buffer[p] = c;
							writeBuffer();
							next = seekNext(p);

							if(android){
								setTimeout($.proxy($.fn.caret,input,next),0);
							}else{
								input.caret(next);
							}

							if (settings.completed && next >= len) {
								settings.completed.call(input);
							}
						}
					}
					e.preventDefault();
				}
			}

			function clearBuffer(start, end) {
				var i;
				for (i = start; i < end && i < len; i++) {
					if (tests[i]) {
						buffer[i] = settings.placeholder;
					}
				}
			}

			function writeBuffer() { input.val(buffer.join('')); }

			function checkVal(allow) {
				//try to place characters where they belong
				var test = input.val(),
					lastMatch = -1,
					i,
					c;

				for (i = 0, pos = 0; i < len; i++) {
					if (tests[i]) {
						buffer[i] = settings.placeholder;
						while (pos++ < test.length) {
							c = test.charAt(pos - 1);
							if (tests[i].test(c)) {
								buffer[i] = c;
								lastMatch = i;
								break;
							}
						}
						if (pos > test.length) {
							break;
						}
					} else if (buffer[i] === test.charAt(pos) && i !== partialPosition) {
						pos++;
						lastMatch = i;
					}
				}
				if (allow) {
					writeBuffer();
				}  else {
					writeBuffer();
					input.val(input.val().substring(0, lastMatch + 1));
				}
				return (partialPosition ? i : firstNonMaskPos);
			}

            function initBuffer(){
                return $.map(
				        mask.split(""),
				        function(c, i) {
					        if (c != '?') {
						        return defs[c] ? settings.placeholder : c;
					        }
				        });
            }

			input.data($.mask.dataName,function(){
				return $.map(buffer, function(c, i) {
					return tests[i]&&c!=settings.placeholder ? c : null;
				}).join('');
			});

			if (!input.attr("readonly"))
				input
				.one("unmask", function() {
					input
						.unbind(".mask")
						.removeData($.mask.dataName);
				})
				.bind("focus.mask", function() {
					clearTimeout(caretTimeoutId);
					var pos,
						moveCaret;

					focusText = input.val();
					pos = checkVal();
					
					caretTimeoutId = setTimeout(function(){
					/*	writeBuffer();
						if (pos == mask.length) {
							input.caret(0, pos);
						} else {
							input.caret(pos);
						}*/
					}, 10);
				})
				.bind("blur.mask", function() {
					checkVal();
					if (input.val() != focusText)
						input.change();
				})
                .bind("clear", function() {
                    buffer = initBuffer();
                    input.val("");
                    //input.trigger("unmask");
                })
				.bind("keydown.mask", keydownEvent)
				.bind("keypress.mask", keypressEvent)
				.bind(pasteEventName, function() {
					setTimeout(function() { 
						//var pos=checkVal(true);
						//input.caret(pos); 
						//if (settings.completed && pos == input.val().length)
						//	settings.completed.call(input);
					}, 0);
				});
			checkVal(); //Perform initial check for existing values
		});
	}
});


})(jQuery);

ING.SSO = Framework.run(Libraries.getGlobaljQuery(), function ($) {
    "use strict";

    var expose = {},
        cErrorClass = "c-error",
        flowPlaceholderClass = "flow-placeholder",
        profilesWrapper = ".profiles-wrapper",
        ingId = "input.ingid",
        cardId = "input.cardid",        
        $lastInput,
        submitButton = ".identification";
    

    //Validates the login data. When not validated, stop the submit.
    //when element is null, no validation is done
    expose.validateLogin = function ($ingId, $cardId, $password, $otp) {
        var ingIdValid = ING.SSO.validateIngId($ingId),
            cardIdValid = ING.SSO.validateCardID($cardId),
            passwordValid = ING.SSO.validatePassword($password),
            codeValid = ING.SSO.validateCode($otp);

        if ($ingId) {
            ingIdValid = ING.SSO.validateIngId($ingId);
        } else {
            ingIdValid = true;
        }

        //if crr no validation ing id and card id
        //set form data-attr to false if not valid, do this in validation function of ingid, cardid
        if (ingIdValid && cardIdValid && passwordValid && passwordValid && codeValid) {
            return true;
        } else {
            $(".default-error").show();
            expose.enableSubmitButton();
            return false;
        }
    };

    expose.validate = function ($ingId, $cardId, $otp) {
        var ingIdValid = ING.SSO.validateIngId($ingId),
            cardIdValid = ING.SSO.validateCardID($cardId),
            codeValid = ING.SSO.validateCode($otp);

        if (ingIdValid && cardIdValid && codeValid) {
            return true;
        } else {
            $(".default-error").show();
            expose.enableSubmitButton();
            return false;
        }
    };

    expose.validateIngId = function ($inputIngId) {
        if ($inputIngId) {
            var inputValue = $inputIngId.val().replace(/\s/g, "");

            if (inputValue) {
                var lastChar = inputValue.substr(inputValue.length - 2);
                inputValue = inputValue.substring(0, inputValue.length - 2);
                if (lastChar === "97") {
                    lastChar = 0;
                }
                if ((lastChar == (inputValue - (Math.floor(inputValue / 97)) * 97)) && $.isNumeric(inputValue)) {
                    $inputIngId.removeClass(cErrorClass);
                    return true;
                }
            }
            $inputIngId.addClass(cErrorClass);
            return false;
        } else {
            return true;
        }
    };

    expose.validateCardID = function ($cardId) {
        var isCardIdValid = true,
            $mainInputCardId = $(".cardid"),
            cardLength = $mainInputCardId.val().replace(/-/g, "").length;

        if (cardLength < 16 || cardLength > $mainInputCardId.attr("data-maxlength")) {
            $mainInputCardId.addClass(cErrorClass);
            isCardIdValid = false;
        } else {
            $mainInputCardId.removeClass(cErrorClass);
        }
        return isCardIdValid;
    };

    expose.validatePassword = function ($password) {
        if ($password.val().length > 0) {
            $password.removeClass(cErrorClass);
            return true;
        } else {
            $password.addClass(cErrorClass);
            return false;
        }
    };

    expose.validateCode = function ($txtCode) {
        if ($txtCode) {
            var code = $txtCode.val();
            if (!code || code.length < 4) {
                $txtCode.addClass(cErrorClass);
                return false;
            }
            $txtCode.removeClass(cErrorClass);
            return true;
        }        
        return true;
    };

    //only allows numbers + navigation keys on input
    expose.onlyAllowNumbers = function (e) {
        var charCode = (e.which) ? e.which : e.keyCode;

        if (charCode == 46 || charCode == 8 || charCode == 9 || charCode == 27 || charCode == 13 ||
        ((charCode == 65 || charCode == 86 || charCode == 67 || charCode == 88) && e.ctrlKey === true) || charCode == 16) {
            return true;
        } else {
            if (!(charCode >= 48 && charCode <= 57)) {
                return false;
            }
        }
    };

    expose.disableSubmitButton = function() {
        $(submitButton).prop("disabled", true);
    };

    expose.enableSubmitButton = function() {
        $(submitButton).removeAttr("disabled");
    };

    expose.jumpNext = function () {
        var $input = $(this);
        if ($input.val().replace(/[^0-9]/g, '').length === parseInt($input.attr("data-maxlength"))) {
            var $all = $(".auto-next"),
                index = $(".auto-next").index($input) + 1,
                $next = $all.get(index);
            if ($next) {
                $next.focus();
            }
        }
    };

    expose.currentDateTime = function () {
        var now = new Date(),
            year = now.getFullYear(),
            month = addZeroToLeft(now.getMonth() + 1, 2, "0"),
            day = addZeroToLeft(now.getDate(), 2, "0"),
            hour = addZeroToLeft(now.getHours(), 2, "0"),
            minute = addZeroToLeft(now.getMinutes(), 2, "0");
        return year + "/" + month + "/" + day + " " + hour + ":" + minute;

    };
    /* - - - - - CCR - - - - - */
    expose.hideUcrFields = function () {
        $(".login-content")
                .addClass("ccr")
                .trigger("hideUcrFields");
        $(ingId)
                .val("")
                .removeAttr("readonly")
                .mask("99999999 99")
                .focus();
        $(cardId)
            .removeClass("auto-next")
            .unmask()
            .prop("disabled", true);
        $(".profile-stored")
                        .removeClass("profile-stored");
        $(".profile-dropdown")
                        .hide();
    };

    expose.updateSecurityType = function (securityType) {
        $("input[name='securityType']").val(securityType);
    };

    expose.showUcrFields = function () {
        $(".login-content")
            .removeClass("ccr")
            .prop("disabled", false)
            .trigger("showUcrFields");
        $(ingId)
            .prop("disabled", false);
        $(cardId)
            .mask("9999-9999-9999-9999-9")
            .prop("disabled", false);
        $(".ingId-wrapper, .login-fieldset.otp, .save-information-wrapper").show();
        loadProfiles();
    };

    var addZeroToLeft = function (nr, n, str) { return Array(n - String(nr).length + 1).join(str || '0') + nr; }

    // PROFILES
    var showDropDown = function () {
        $(this).nextAll(profilesWrapper).show();
    };

    var toggleDropdown = function (e) {
        var $container = $(profilesWrapper)
        if ($container.is(":visible") && !$container.is(e.target) && $container.has(e.target).length === 0) {
            $container.hide();
        }
    };

    var showProfiles = function () {
        if ($(this).hasClass("ingid")) {
            $(".alternative-profile.ingid").show();
        } else {
            $(".alternative-profile.cardnr").show();
        }
        $(this).hide();
        $(this).nextAll("div.btn-hide").show();
    };

    var hideProfiles = function () {
        if ($(this).hasClass("ingid")) {
            $(".alternative-profile.ingid").hide();
        } else {
            $(".alternative-profile.cardnr").hide();
        }
        $(this).hide();
        $(this).prevAll("div.show-all").show();
    };

    var addProfile = function () {
        var $ingId = $(ingId);
        $ingId
                .val("")
                .removeAttr("readonly")
                .mask("99999999 99")
                .focus()
                .removeClass("profile-stored");
        $ingId.nextAll(".profile-dropdown").hide();
        $ingId.nextAll(".profiles-wrapper").hide();
        addCardId();
    };

    var loadCardNrProfiles = function () {
        var ingIdVal = $("input.ingid").val(),
            count = 0;
        $(".profiles-dropdown.ingid > ul > li").each(function () {
            var $this = $(this);
            if (padLeft($this.data("ingid"), 10) == ingIdVal) {
                count++;
                $(".profiles-dropdown.cardnr ul").empty().append($this[0].outerHTML);
            }
        });

        if (count <= 1) {
            $(".show-all.cardnr, btn-hide.cardnr").hide();
        }

        $(".profiles-dropdown.cardnr ul li:first").removeClass("alternative-profile");
        $(".profiles-dropdown.cardnr ul li").removeClass("ingid").addClass("cardnr");
    };

    //Clean values before submit
    expose.cleanIngId = function ($ingid) {
        return padLeft($ingid.val().replace(' ', ''), 10);
    };

    var padLeft = function (nr, n, str) {
        return Array(n - String(nr).length + 1).join(str || '0') + nr;
    };

    expose.cleanCardId = function ($cardid) {
        var cardidVal = $cardid.val();
        return cardidVal.replace(/-/g, '');
    };

    expose.valueCheckedOrDefault = function ($default, $value) {
        if ($value.is(":checked")) {
            $default.attr("disabled", true);;
        }
    };

    expose.getValueOrDefault = function($element, $value, $default) {
        if ($element != null) {
            return $value
        } else {
            return $default;
        }
    };

    expose.getQueryStringValue = function (name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)",
            regex = new RegExp(regexS),
            results = regex.exec(window.location.href);
        if (results == null)
            return "";
        else
            return results[1];
    };
                          
    /* - - - - - Profiles - - - - - */
    var loadProfiles = function () {
        if ($("#profileItem").length > 0 && $(".renderer-wrapper").hasClass("sharepoint-server")) {
            $.ajax({
                cache: 'false',
                type: 'POST',
                url: "/sso/ssohttphandler.ashx",
                contentType: "application/x-www-form-urlencoded;",
                data: { 'UserProfile': 'Yes' },
                responseType: "json",
                dataType: "json",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("Pragma", "no-cache");
                    xhr.setRequestHeader("cache-control", "no cache,  no-store");
                },
                success: function () { // code for the profile stuff 
                },
                error: function () { //need to see what we are going to do with exception 
                }
            }).done(function (data) {
                if (data) {
                    var ucr = getDecryptedValue(data, "UCR"),
                        lastUsedIngId = getDecryptedValue(data, "BBLLastUsedIngId"),
                        lastUsedCardNr = getDecryptedValue(data, "BBLLastUsedCardNr"),
                        $profilesIngId = $(".profiles-dropdown.ingid > ul");
                    if (ucr) {
                        $(ingId)
                            .addClass("profile-stored")
                            .attr("readonly", true)
                            .val(lastUsedIngId);
                        $(".profile-dropdown").show();
                        $(cardId)
                            .addClass("profile-stored")
                            .attr("readonly", true)
                            .val(lastUsedCardNr);
                        var lastUsedProfile = $("#lastUsedProfile").html(),
                            profileItem = $("#profileItem").html(),
                            profiles = ucr.split("+");
 
                        for (var i = 0; i < profiles.length - 1; i++) {
                            var profile = profiles[i].split("-");
                            $profilesIngId
                                .append(profileItem
                                            .replace(/{{ingid}}/g, profile[0])
                                            .replace(/{{cardid}}/g, profile[1]));
                        }
                        if ((profiles.length - 1) <= 1) {
                            $(".show-all.ingid, btn-hide.ingid").hide();
                        }
                        loadCardNrProfiles();
                        $(".profiles-dropdown.ingid ul li").slice(1).addClass("alternative-profile");
                        $(".profiles-footer")
                            .on("click", ".add-profile", addProfile);
                        $(".profiles-footer")
                            .on("click", ".add-cardId", addCardId);
                    }
                }
                setMasks();
            });
        } else {
            setMasks()
        }
        return false;
    };

    var getDecryptedValue = function (data,name) {
        var value = $.grep(data, function (cookie, i) {
            return cookie.Name == name;
        })[0].DecryptedValue;
        if(value){ return value }else{ return "" };
    };

    var enableProfiles = function () {
        $(".cardid,.ingid").addClass("profile-stored");
        $(".profile-dropdown").show();
    };

    var addCardId = function () {
        var $cardId = $(cardId);
        $cardId
            .removeAttr("readonly")
            .mask("9999-9999-9999-9999-9")
            .trigger("clear")
            .removeClass("profile-stored")
            .attr("value", "6703");
        $cardId.nextAll(".profile-dropdown").hide();
        $cardId.nextAll(".profiles-wrapper").hide();
        $(".save-information").attr("checked", true);
        return false;
    };

    var updateInputFields = function (e) {
        var $this = $(this),
            cardVal = $this.attr("data-cardId"),
            lastVal = cardVal.substring(16, 17);
        $(ingId).val($this.attr("data-ingId"));
        var cardInputVal = cardVal.substring(0, 4) + "-" + cardVal.substring(4, 8) + "-" + cardVal.substring(8, 12) + "-" + cardVal.substring(12, 16) + "-" + lastVal;
        $(cardId).attr("value", cardInputVal)
        $this.closest(profilesWrapper).hide();
        loadCardNrProfiles();
    };

   

    //fix for doing a submit of a div with an action
    expose.submitDiv = function () {
        if ($lastInput != null) {
            $(document).off("submit", "form", expose.submitDiv);
            var $pseudoForm = $lastInput.closest("div[action]"),
                action = ($pseudoForm.attr("action") ? $pseudoForm.attr("action") : ""),
                method = ($pseudoForm.attr("method") ? $pseudoForm.attr("method") : ""),
                $newForm = $("<form class=\"hidden-form\" name=\"hidden-form\" action=\"" + action + "\" method=\"" + method + "\"></form>");
            $pseudoForm.find(":input").clone().appendTo($newForm);
            $newForm.appendTo("body");
            document.forms["hidden-form"].submit();
            $lastInput = null;
            return false;
        }
    };

    // Overlays

    var closeOverlay = function () {
        $(".overlay-wrapper").hide();
        $(".overlay-hb").hide();
    };

    var setMasks = function () {
        var $ingId = $(ingId);
        if ($ingId.val() == "") {
            $ingId.mask("99999999 99");
            $(cardId).mask("9999-9999-9999-9999-9").attr("value", "6703");
        }
    };

    var onLoad = function () {
        loadProfiles();
        if (typeof infoBoxJson != "undefined") {
            $(".info-body-wrapper")
                    .append(infoBoxJson.Body)
                    .addClass(infoBoxJson.Class)
                    .show();
        }
        

        $(".info-icon").hover(
            function () {
                $(this).next(".info-msg").show();
            },
            function () {
                $(this).next(".info-msg").hide();
            });

        if ($("input.ingid").hasClass("profile-stored")) {
            loadCardNrProfiles();
        }

        $(document).on("keypress", "input.numbers", expose.onlyAllowNumbers);        

        // Profiles
        $(document).mouseup(function (e) { toggleDropdown(e) });
        $(profilesWrapper)
            .on("click", ".profile", updateInputFields);
        $(".c-controls")
            .on("click", ".profile-dropdown", showDropDown);        
        $("div.profiles-wrapper")
            .on("click", "div.show-all", showProfiles)
            .on("click", "div.btn-hide", hideProfiles);

        $(".back")
                .on("click", ".overlay-back", closeOverlay);

        $(".auto-next").bind("keyup", ING.SSO.jumpNext);

        // fix for no placeholder in older browsers
        if (!("placeholder" in document.createElement("input"))) {
            $("input[placeholder]").each(function () {
                var val = $(this).attr("placeholder"),
                input = $(this);
                if (this.value == "") {
                    input.addClass(flowPlaceholderClass);
                    this.value = val;
                }
                input.focus(function () {
                    if (this.value == val) {
                        input.removeClass(flowPlaceholderClass);
                        this.value = "";
                    }
                }).blur(function () {
                    if ($.trim(this.value) == "") {
                        input.addClass(flowPlaceholderClass);
                        this.value = val;
                    }
                });
            });
            $('form').submit(function () {
                $(this).find("input[placeholder]").each(function () {
                    var input = $(this);
                    if (this.value == input.attr("placeholder")) {
                        input.removeClass(flowPlaceholderClass);
                        this.value = "";
                    }
                });
            });
        }

        $("form div[action] input, form div[action] button")
            .click(function () {
                $lastInput = $(this);
            })
            .blur(function () {
                $lastInput = null;
            });
    };

    $(onLoad);

    return expose;
});


var hexcase = 0;  /* hex output format. 0 - lowercase; 1 - uppercase        */
var b64pad = ""; /* base-64 pad character. "=" for strict RFC compliance   */
var chrsz = 8;  /* bits per input character. 8 - ASCII; 16 - Unicode      */
/*   * These are the functions you'll usually want to call   
* They take string arguments and return either hex or base-64 encoded strings   
*/
function hex_sha1(s) { return binb2hex(core_sha1(str2binb(s), s.length * chrsz)); }
function b64_sha1(s) { return binb2b64(core_sha1(str2binb(s), s.length * chrsz)); }
function str_sha1(s) { return binb2str(core_sha1(str2binb(s), s.length * chrsz)); }
function hex_hmac_sha1(key, data) { return binb2hex(core_hmac_sha1(key, data)); }
function b64_hmac_sha1(key, data) { return binb2b64(core_hmac_sha1(key, data)); }
function str_hmac_sha1(key, data) { return binb2str(core_hmac_sha1(key, data)); }
/*   * Perform a simple self-test to see if the VM is working   */
function sha1_vm_test() { return hex_sha1("abc") == "a9993e364706816aba3e25717850c26c9cd0d89d"; }
function core_sha1(x, len) {
    /* append padding */
    x[len >> 5] |= 0x80 << (24 - len % 32);
    x[((len + 64 >> 9) << 4) + 15] = len;
    var w = Array(80);
    var a = 1732584193;
    var b = -271733879;
    var c = -1732584194;
    var d = 271733878;
    var e = -1009589776;
    for (var i = 0; i < x.length; i += 16) {
        var olda = a;
        var oldb = b;
        var oldc = c;
        var oldd = d;
        var olde = e;
        for (var j = 0; j < 80; j++) {
            if (j < 16) w[j] = x[i + j];
            else w[j] = rol(w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16], 1);
            var t = safe_add(safe_add(rol(a, 5), sha1_ft(j, b, c, d)),
							safe_add(safe_add(e, w[j]), sha1_kt(j)));
            e = d;
            d = c;
            c = rol(b, 30);
            b = a;
            a = t;
        }
        a = safe_add(a, olda);
        b = safe_add(b, oldb);
        c = safe_add(c, oldc);
        d = safe_add(d, oldd);
        e = safe_add(e, olde);
    } return Array(a, b, c, d, e);
}
/*   * Perform the appropriate triplet combination function for the current   * iteration   */
function sha1_ft(t, b, c, d) {
    if (t < 20) return (b & c) | ((~b) & d);
    if (t < 40) return b ^ c ^ d;
    if (t < 60) return (b & c) | (b & d) | (c & d);
    return b ^ c ^ d;
}
/*   * Determine the appropriate additive constant for the current iteration   */
function sha1_kt(t) {
    return (t < 20) ? 1518500249 : (t < 40) ? 1859775393 :
			   (t < 60) ? -1894007588 : -899497514;
}
/*   * Calculate the HMAC-SHA1 of a key and some data   */
function core_hmac_sha1(key, data) {
    var bkey = str2binb(key);
    if (bkey.length > 16) bkey = core_sha1(bkey, key.length * chrsz);
    var ipad = Array(16), opad = Array(16);
    for (var i = 0; i < 16; i++) {
        ipad[i] = bkey[i] ^ 0x36363636;
        opad[i] = bkey[i] ^ 0x5C5C5C5C;
    }
    var hash = core_sha1(ipad.concat(str2binb(data)), 512 + data.length * chrsz);
    return core_sha1(opad.concat(hash), 512 + 160);
}
/*   
* Add integers, wrapping at 2^32. This uses 16-bit operations internally   * to work around bugs in some JS interpreters.   */
function safe_add(x, y) {
    var lsw = (x & 0xFFFF) + (y & 0xFFFF);
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    return (msw << 16) | (lsw & 0xFFFF);
}
/*   
* Bitwise rotate a 32-bit number to the left.   
*/
function rol(num, cnt) {
    return (num << cnt) | (num >>> (32 - cnt));
}
/*   
* Convert an 8-bit or 16-bit string to an array of big-endian words   
* In 8-bit function, characters >255 have their hi-byte silently ignored.   
*/
function str2binb(str) {
    var bin = Array();
    var mask = (1 << chrsz) - 1;
    for (var i = 0; i < str.length * chrsz; i += chrsz)
        bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << (32 - chrsz - i % 32);
    return bin;
}
/*   
* Convert an array of big-endian words to a string   
*/
function binb2str(bin) {
    var str = "";
    var mask = (1 << chrsz) - 1;
    for (var i = 0; i < bin.length * 32; i += chrsz)
        str += String.fromCharCode((bin[i >> 5] >>> (32 - chrsz - i % 32)) & mask);
    return str;
}
/*   
* Convert an array of big-endian words to a hex string.   
*/
function binb2hex(binarray) {
    var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
    var str = "";
    for (var i = 0; i < binarray.length * 4; i++) {
        str += hex_tab.charAt((binarray[i >> 2] >> ((3 - i % 4) * 8 + 4)) & 0xF) +
				   hex_tab.charAt((binarray[i >> 2] >> ((3 - i % 4) * 8)) & 0xF);
    }
    return str;
}
/*   
* Convert an array of big-endian words to a base-64 string   
*/
function binb2b64(binarray) {
    var tab = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    var str = "";
    for (var i = 0; i < binarray.length * 4; i += 3) {
        var triplet = (((binarray[i >> 2] >> 8 * (3 - i % 4)) & 0xFF) << 16)
							| (((binarray[i + 1 >> 2] >> 8 * (3 - (i + 1) % 4)) & 0xFF) << 8)
							| ((binarray[i + 2 >> 2] >> 8 * (3 - (i + 2) % 4)) & 0xFF);
        for (var j = 0; j < 4; j++) {
            if (i * 8 + j * 6 > binarray.length * 32) str += b64pad;
            else str += tab.charAt((triplet >> 6 * (3 - j)) & 0x3F);
        }
    } return str;
} 	
Framework.ensure("ING");
ING.Hbforall = Framework.run(Libraries.getGlobaljQuery(), function ($) {
    var expose = {};
    var getQueryStringValue = function (name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(window.location.href);
        if (results == null)
            return "";
        else
            return results[1];
    }
    expose.updatek2activationflow = function () {
        if (getQueryStringValue("ERROR_CODE")) {
            $(".k2-activationflow").hide();
        }
    };
    return expose;
});
Framework.run(Libraries.getGlobaljQuery(), function ($) {
    "use strict";


    /* - - - - - Error processing - - - - - */

    var errorOccured = function () {
        var errorCode = urlParam("ERROR_CODE");
        if (urlParam("TAM_OP") && errorCode) {
            return errorCode;
        }
        return false;
    };

    var urlParam = function (name) {
        var results = new RegExp('[\?&amp;]' + name + '=([^&amp;#]*)').exec(window.location.href);
        if (results) {
            return results[1] || 0
        }
        return false;
    }

    var ShowMatchingElement = function (value, selector) {
        if (value === "true") {
            $(selector).show();
        }
    };

    var showMatchingError = function () {
        var error = "",
            errorCode = errorOccured();
        if (errorCode) {
            var data = ING.SSO["ssoErrorMapping" + ING.K2.Context.Current.Variation.toLowerCase() + ING.K2.Context.Current.Segment.toLowerCase()];
            var items = $.grep(data.SsoErrors.Errors, function (element, index) {
                return element.Code === errorCode;
            });
            if (items.length > 0) {
                error = items[0];
                if (error != "") {
                    if (error.DisplayError === "ErrorBlock") {
                        $(".default-error").show();
                    } else {
                        ShowMatchingElement(error.FindBranchButton, ".btn-branch");
                        ShowMatchingElement(error.MakeAnAppointmentButton, ".btn-appointment");
                        ShowMatchingElement(error.HomeBankMoreInfo, ".btn-homebank");
                        ShowMatchingElement(error.HomeBankPlusMoreInfo, ".btn-homebank-plus");
                        ShowMatchingElement(error.BackButton, ".btn-back");
                        $(".overlay-header > h2").text(error.Title);
                        $(".overlay-content > p").text(error.Description);
                        $(".overlay").show();
                    }
                }
            }            
        }
    };
   
    var onLoad = function () {
        showMatchingError();       
    };
    $(onLoad);
});
ING.SSO.ssoErrorMappingenbusiness = {
        "SsoErrors": {
            "Errors": [
              {
                  "Code": "101",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "102",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "201",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "202",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "203",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "301",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "302",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "303",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "304",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "305",
                  "Title": "Expired bank card",
                  "Description": "Your bank card has expired. Please use your new card if you have received it or make a request at your ING branch. If you have one, you can also connect to Home'Bank with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "306",
                  "Title": "Inactive bank card",
                  "Description": "Please call Home'Bank Helpdesk on 02 464 60 04 or go to your ING branch to have this card reactivated. If you have one, try with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "307",
                  "Title": "Inactive bank card",
                  "Description": "This ING bank card is no longer active and so no longer lets you access Home'Bank. Go to your ING branch to have this card reactivated or, if you have one, try with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "308",
                  "Title": "Blocked bank card",
                  "Description": "As a safety precaution, your card has been blocked. To remedy this situation call the Home'Bank Helpdesk immediately on 02 464 60 04.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "309",
                  "Title": "Inactive bank card",
                  "Description": "This ING bank card is no longer active and so no longer lets you access Home'Bank. Go to your ING branch to have this card reactivated or, if you have one, try with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "310",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "311",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "313",
                  "Title": "Log-in error",
                  "Description": "You are temporarily unable to access your Home'Bank because you have reset your previous password. For security reasons, you need to wait 24 hours before you can set up a new password. Afterwards, go to Home'Bank, click on \"New password\" and follow the steps.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "314",
                  "Title": "Log-in error",
                  "Description": "You are temporarily unable to access your Home'Bank because you have reset your previous password. For security reasons, you need to wait 24 hours before you can set up a new password. Afterwards, go to Home'Bank, click on \"New password\" and follow the steps.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "315",
                  "Title": "Log-in error",
                  "Description": "Your Home'Bank (Plus) subscription is blocked. Please contact Home'Bank Helpdesk on 02 464 60 04.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "316",
                  "Title": "Log-in error",
                  "Description": "Your Home'Bank (Plus) subscription has been cancelled. Go to your ING branch for more information.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "317",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "318",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "319",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "321",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "322",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "399",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38b9a4b0",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf0432",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf04c6",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf04d7",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf0427",
                  "DisplayError": "ErrorBlock"
              }
            ]
        }
    };
ING.SSO.ssoErrorMappingenretail = {
        "SsoErrors": {
            "Errors": [
              {
                  "Code": "101",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "102",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "201",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "202",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "203",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "301",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "302",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "303",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "304",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "305",
                  "Title": "Expired bank card",
                  "Description": "Your bank card has expired. Please use your new card if you have received it or make a request at your ING branch. If you have one, you can also connect to Home'Bank with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "306",
                  "Title": "Inactive bank card",
                  "Description": "Please call Home'Bank Helpdesk on 02 464 60 04 or go to your ING branch to have this card reactivated. If you have one, try with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "307",
                  "Title": "Inactive bank card",
                  "Description": "This ING bank card is no longer active and so no longer lets you access Home'Bank. Go to your ING branch to have this card reactivated or, if you have one, try with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "308",
                  "Title": "Blocked bank card",
                  "Description": "As a safety precaution, your card has been blocked. To remedy this situation call the Home'Bank Helpdesk immediately on 02 464 60 04.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "309",
                  "Title": "Inactive bank card",
                  "Description": "This ING bank card is no longer active and so no longer lets you access Home'Bank. Go to your ING branch to have this card reactivated or, if you have one, try with another ING bank card.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "310",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "311",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "313",
                  "Title": "Log-in error",
                  "Description": "You are temporarily unable to access your Home'Bank because you have reset your previous password. For security reasons, you need to wait 24 hours before you can set up a new password. Afterwards, go to Home'Bank, click on \"New password\" and follow the steps.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "314",
                  "Title": "Log-in error",
                  "Description": "You are temporarily unable to access your Home'Bank because you have reset your previous password. For security reasons, you need to wait 24 hours before you can set up a new password. Afterwards, go to Home'Bank, click on \"New password\" and follow the steps.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "315",
                  "Title": "Log-in error",
                  "Description": "Your Home'Bank (Plus) subscription is blocked. Please contact Home'Bank Helpdesk on 02 464 60 04.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "316",
                  "Title": "Log-in error",
                  "Description": "Your Home'Bank (Plus) subscription has been cancelled. Go to your ING branch for more information.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "317",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "318",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "319",
                  "Title": "Log-in error",
                  "Description": "You do not currently have a Home'Bank subscription, so logging in is impossible. If you have a Home'Bank subscription, check if you have selected the right service (Home'Bank or Home'Bank Plus) on the log-in page.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "321",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "322",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "399",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38b9a4b0",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf0432",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf04c6",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf04d7",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf0427",
                  "DisplayError": "ErrorBlock"
              }
            ]
        }
    };
ING.SSO.ssoErrorMappingfrbusiness = {
        "SsoErrors": {
            "Errors": [
              {
                  "Code": "101",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "102",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "201",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "202",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "203",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "301",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "302",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "303",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "304",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "305",
                  "Title": "Carte bancaire expirée",
                  "Description": "Votre carte bancaire est expirée. Utilisez votre nouvelle carte si vous l'avez reçue ou effectuez une demande dans votre agence ING. Vous pouvez également vous connecter à Home'Bank avec une autre carte bancaire ING si vous en possédez une.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "306",
                  "Title": "Carte bancaire inactive",
                  "Description": "Veuillez contacter le Support Home'Bank au 02 464 60 02 ou rendez-vous dans votre agence ING afin de faire réactiver cette carte. Essayez avec une autre carte bancaire ING si vous en possédez une.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "307",
                  "Title": "Carte bancaire inactive",
                  "Description": "Vous pouvez faire activer votre carte bancaire ING dans une agence ING pendant les heures d'ouverture.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "308",
                  "Title": "Carte bancaire bloquée",
                  "Description": "Par mesure de sécurité, votre carte a été bloquée. Pour remédier à cette situation, appelez immédiatement le Helpdesk Home'Bank au 02 464 60 02. ",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "309",
                  "Title": "Carte bancaire inactive",
                  "Description": "Vous pouvez faire activer votre carte bancaire ING dans une agence ING pendant les heures d'ouverture. ",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "310",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "311",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "313",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez temporairement pas accès à Home'Bank parce que vous avez réinitialisé votre mot de passe précédent. Par sécurité, il faut un délai de 24 heures avant de pouvoir créer un nouveau mot de passe. Ensuite, rendez-vous dans Home'Bank, cliquez sur \"Nouveau mot de passe\" et suivez les étapes.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "314",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez temporairement pas accès à Home'Bank parce que vous avez réinitialisé votre mot de passe précédent. Par sécurité, il faut un délai de 24 heures avant de pouvoir créer un nouveau mot de passe. Ensuite, rendez-vous dans Home'Bank, cliquez sur \"Nouveau mot de passe\" et suivez les étapes.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "315",
                  "Title": "Erreur de connexion",
                  "Description": "Votre abonnement Home'Bank (Plus) est bloqué. Veuillez contacter le Support Home'Bank au 02 464 60 02.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                    "Code": "316",
                    "Title": "Erreur de connexion",
                    "Description": "Votre abonnement Home'Bank (Plus) est révoqué. Veuillez vous rendre dans votre agence ING pour plus d'informations. ",
                    "DisplayError": "ErrorOverlay",
                    "FindBranchButton": "true",
                    "MakeAnAppointmentButton": "false",
                    "HomeBankMoreInfo": "false",
                    "HomeBankPlusMoreInfo": "false",
                    "BackButton": "true"
              },
              {
                    "Code": "317",
                    "Title": "Erreur de connexion",
                    "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                    "DisplayError": "ErrorOverlay",
                    "FindBranchButton": "false",
                    "MakeAnAppointmentButton": "false",
                    "HomeBankMoreInfo": "true",
                    "HomeBankPlusMoreInfo": "true",
                    "BackButton": "true"
              },
              {
                    "Code": "318",
                    "Title": "Erreur de connexion",
                    "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                    "DisplayError": "ErrorOverlay",
                    "FindBranchButton": "false",
                    "MakeAnAppointmentButton": "false",
                    "HomeBankMoreInfo": "true",
                    "HomeBankPlusMoreInfo": "true",
                    "BackButton": "true"
             },
             {
                    "Code": "319",
                    "Title": "Erreur de connexion",
                    "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                    "DisplayError": "ErrorOverlay",
                    "FindBranchButton": "false",
                    "MakeAnAppointmentButton": "false",
                    "HomeBankMoreInfo": "true",
                    "HomeBankPlusMoreInfo": "true",
                    "BackButton": "true"
              },
              {
                  "Code": "321",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "322",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "399",
                  "DisplayError": "ErrorBlock"
              },
              {
                   "Code": "0x38b9a4b0",
                   "DisplayError": "ErrorBlock"
              },
              {
                   "Code": "0x38cf0432",
                   "DisplayError": "ErrorBlock"
               },
               {
                   "Code": "0x38cf04c6",
                   "DisplayError": "ErrorBlock"
               },
               {
                   "Code": "0x38cf04d7",
                   "DisplayError": "ErrorBlock"
               },
               {
                   "Code": "0x38cf0427",
                   "DisplayError": "ErrorBlock"
                }]
        }
    };
ING.SSO.ssoErrorMappingfrretail = {
        "SsoErrors": {
            "Errors": [
              {
                  "Code": "101",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "102",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "201",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "202",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "203",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "301",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "302",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "303",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "304",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "305",
                  "Title": "Carte bancaire expirée",
                  "Description": "Votre carte bancaire est expirée. Utilisez votre nouvelle carte si vous l'avez reçue ou effectuez une demande dans votre agence ING. Vous pouvez également vous connecter à Home'Bank avec une autre carte bancaire ING si vous en possédez une.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "306",
                  "Title": "Carte bancaire inactive",
                  "Description": "Veuillez contacter le Support Home'Bank au 02 464 60 02 ou rendez-vous dans votre agence ING afin de faire réactiver cette carte. Essayez avec une autre carte bancaire ING si vous en possédez une.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "307",
                  "Title": "Carte bancaire inactive",
                  "Description": "Vous pouvez faire activer votre carte bancaire ING dans une agence ING pendant les heures d'ouverture.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "308",
                  "Title": "Carte bancaire bloquée",
                  "Description": "Par mesure de sécurité, votre carte a été bloquée. Pour remédier à cette situation, appelez immédiatement le Helpdesk Home'Bank au 02 464 60 02. ",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "309",
                  "Title": "Carte bancaire inactive",
                  "Description": "Vous pouvez faire activer votre carte bancaire ING dans une agence ING pendant les heures d'ouverture. ",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "true",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "310",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "311",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "313",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez temporairement pas accès à Home'Bank parce que vous avez réinitialisé votre mot de passe précédent. Par sécurité, il faut un délai de 24 heures avant de pouvoir créer un nouveau mot de passe. Ensuite, rendez-vous dans Home'Bank, cliquez sur \"Nouveau mot de passe \" et suivez les étapes.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "314",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez temporairement pas accès à Home'Bank parce que vous avez réinitialisé votre mot de passe précédent. Par sécurité, il faut un délai de 24 heures avant de pouvoir créer un nouveau mot de passe. Ensuite, rendez-vous dans Home'Bank, cliquez sur \"Nouveau mot de passe \" et suivez les étapes.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "315",
                  "Title": "Erreur de connexion",
                  "Description": "Votre abonnement Home'Bank (Plus) est bloqué. Veuillez contacter le Support Home'Bank au 02 464 60 02.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "316",
                  "Title": "Erreur de connexion",
                  "Description": "Votre abonnement Home'Bank (Plus) est révoqué. Veuillez vous rendre dans votre agence ING pour plus d'informations. ",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "true",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "false",
                  "HomeBankPlusMoreInfo": "false",
                  "BackButton": "true"
              },
              {
                  "Code": "317",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "318",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "319",
                  "Title": "Erreur de connexion",
                  "Description": "Vous n'avez actuellement pas d'abonnement Home'Bank, la connexion est donc impossible. Si vous avez un abonnement Home'Bank, vérifiez que vous avez sélectionné le bon service (Home'Bank ou Home'Bank Plus) sur la page de connexion.",
                  "DisplayError": "ErrorOverlay",
                  "FindBranchButton": "false",
                  "MakeAnAppointmentButton": "false",
                  "HomeBankMoreInfo": "true",
                  "HomeBankPlusMoreInfo": "true",
                  "BackButton": "true"
              },
              {
                  "Code": "321",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "322",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "399",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38b9a4b0",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf0432",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf04c6",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf04d7",
                  "DisplayError": "ErrorBlock"
              },
              {
                  "Code": "0x38cf0427",
                  "DisplayError": "ErrorBlock"
              }
            ]
        }
    };
ING.SSO.ssoErrorMappingnlretail = {
    "SsoErrors": {
        "Errors": [
          {
              "Code": "101",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "102",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "201",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "202",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "203",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "301",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "302",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "303",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "304",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "305",
              "Title": "Vervallen bankkaart",
              "Description": "Uw bankkaart is vervallen. Gebruik uw nieuwe kaart als u die hebt ontvangen of vraag er een aan in uw ING-kantoor. U kunt ook inloggen in Home'Bank met een andere ING-bankkaart als u er een hebt.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "306",
              "Title": "Inactieve bankkaart",
              "Description": "Gelieve Home'Bank Helpdesk te contacteren op het nummer 02 464 60 01 of ga naar uw ING-kantoor om de kaart opnieuw te laten activeren Probeer met een andere ING-bankkaart, als u er een hebt.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "307",
              "Title": "Inactieve bankkaart",
              "Description": "U kunt uw ING-bankkaart laten activeren in een ING-kantoor tijdens de openingsuren.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "308",
              "Title": "Geblokkeerde bankkaart",
              "Description": "Om veiligheidsredenen is uw kaart geblokkeerd. Neem onmiddellijk contact op met de Home'Bank-helpdesk op 02 464 60 01 om deze situatie op te lossen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "309",
              "Title": "Inactieve bankkaart",
              "Description": "Deze ING-bankkaart is niet langer actief waardoor u geen toegang meer hebt tot Home'Bank. Ga naar uw ING-kantoor om de kaart opnieuw te laten activeren of probeer met een andere ING-bankkaart, als u er een hebt.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "310",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "311",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "313",
              "Title": "Fout bij inloggen",
              "Description": "U kunt momenteel Home'Bank niet gebruiken omdat u uw vorige paswoord hebt verwijderd. Uit veiligheidsoverwegingen moet u 24 uur wachten voor u een nieuw paswoord kunt aanmaken. Ga daarna naar Home’Bank, klik op \“Nieuw paswoord\” en volg de stappen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "314",
              "Title": "Fout bij inloggen",
              "Description": "U kunt momenteel Home'Bank niet gebruiken omdat u uw vorige paswoord hebt verwijderd. Uit veiligheidsoverwegingen moet u 24 uur wachten voor u een nieuw paswoord kunt aanmaken. Ga daarna naar Home’Bank, klik op \“Nieuw paswoord\” en volg de stappen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "315",
              "Title": "Fout bij inloggen",
              "Description": "Uw Home'Bank (Plus)-abonnement is geblokkeerd. Gelieve Home'Bank Helpdesk te contacteren op 02 464 60 01.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "316",
              "Title": "Fout bij inloggen",
              "Description": "Uw Home'Bank (Plus)-abonnement is opgezegd. Ga naar uw ING-kantoor voor meer info.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "317",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "318",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "319",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "321",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "322",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "399",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38b9a4b0",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0432",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04c6",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04d7",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0427",
              "DisplayError": "ErrorBlock"
          }
        ]
    }
};

ING.SSO.ssoErrorMappingnlbusiness = {
    "SsoErrors": {
        "Errors": [
          {
              "Code": "101",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "102",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "201",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "202",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "203",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "301",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "302",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "303",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "304",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "305",
              "Title": "Vervallen bankkaart",
              "Description": "Uw bankkaart is vervallen. Gebruik uw nieuwe kaart als u die hebt ontvangen of vraag er een aan in uw ING-kantoor. U kunt ook inloggen in Home'Bank met een andere ING-bankkaart als u er een hebt.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "306",
              "Title": "Inactieve bankkaart",
              "Description": "Gelieve Home'Bank Helpdesk te contacteren op het nummer 02 464 60 01 of ga naar uw ING-kantoor om de kaart opnieuw te laten activeren Probeer met een andere ING-bankkaart, als u er een hebt.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "307",
              "Title": "Inactieve bankkaart",
              "Description": "U kunt uw ING-bankkaart laten activeren in een ING-kantoor tijdens de openingsuren.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "308",
              "Title": "Geblokkeerde bankkaart",
              "Description": "Om veiligheidsredenen is uw kaart geblokkeerd. Neem onmiddellijk contact op met de Home'Bank-helpdesk op 02 464 60 01 om deze situatie op te lossen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "309",
              "Title": "Inactieve bankkaart",
              "Description": "Deze ING-bankkaart is niet langer actief waardoor u geen toegang meer hebt tot Home'Bank. Ga naar uw ING-kantoor om de kaart opnieuw te laten activeren of probeer met een andere ING-bankkaart, als u er een hebt.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "310",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "311",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "313",
              "Title": "Fout bij inloggen",
              "Description": "U kunt momenteel Home'Bank niet gebruiken omdat u uw vorige paswoord hebt verwijderd. Uit veiligheidsoverwegingen moet u 24 uur wachten voor u een nieuw paswoord kunt aanmaken. Ga daarna naar Home’Bank, klik op \“Nieuw paswoord\” en volg de stappen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "314",
              "Title": "Fout bij inloggen",
              "Description": "U kunt momenteel Home'Bank niet gebruiken omdat u uw vorige paswoord hebt verwijderd. Uit veiligheidsoverwegingen moet u 24 uur wachten voor u een nieuw paswoord kunt aanmaken. Ga daarna naar Home’Bank, klik op \“Nieuw paswoord\” en volg de stappen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "315",
              "Title": "Fout bij inloggen",
              "Description": "Uw Home'Bank (Plus)-abonnement is geblokkeerd. Gelieve Home'Bank Helpdesk te contacteren op 02 464 60 01.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "316",
              "Title": "Fout bij inloggen",
              "Description": "Uw Home'Bank (Plus)-abonnement is opgezegd. Ga naar uw ING-kantoor voor meer info.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "317",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "318",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "319",
              "Title": "Fout bij inloggen",
              "Description": "U hebt momenteel geen Home'Bank-abonnement, inloggen is dus niet mogelijk. Als u een Home'Bank-abonnement hebt, controleer of u de juiste dienst hebt geselecteerd (Home'Bank of Home'Bank Plus) op de inlogpagina.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "321",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "322",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "399",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38b9a4b0",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0432",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04c6",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04d7",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0427",
              "DisplayError": "ErrorBlock"
          }
        ]
    }
};
ING.SSO.ssoErrorMappingderetail = {
    "SsoErrors": {
        "Errors": [
          {
              "Code": "101",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "102",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "201",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "202",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "203",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "301",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "302",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "303",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "304",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "305",
              "Title": "Bankkarte abgelaufen",
              "Description": "Bitte benutzen Sie Ihre neue Karte, falls Sie diese bereits erhalten haben, oder beantragen Sie sie in Ihrer ING Zweigstelle. Sie können sich bei Home'Bank auch mit einer anderen ING Bankkarte anmelden, falls Sie eine weitere besitzen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "306",
              "Title": "Bankkarte gesperrt",
              "Description": "Bitte rufen Sie Home'Bank Helpdesk unter Tel. 02 464 60 03 an oder lassen Sie sie in Ihrer ING Zweigstelle freischalten. Probieren Sie es mit einer anderen ING Karte, falls Sie eine weitere besitzen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "307",
              "Title": "Bankkarte gesperrt",
              "Description": "Sie können Ihre ING Bankkarte in Ihrer ING Zweigstelle während der Schalteröffnungszeiten freischalten lassen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "308",
              "Title": "Bankkarte gesperrt",
              "Description": "Ihre Bankkarte wurde aus Sicherheitsgründen gesperrt. Um Sie wieder freischalten zu lassen, rufen Sie umgehend das Home'Bank-Helpdesk unter 02 464 60 03 an.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "309",
              "Title": "Bankkarte gesperrt",
              "Description": "Diese ING Bankkarte ist gesperrt. Sie können damit nicht mehr auf Home'Bank zugreifen. Lassen Sie sie in Ihrer ING Zweigstelle freischalten oder probieren Sie es mit einer anderen ING Karte, falls Sie eine weitere besitzen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "310",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "311",
              "Title": "Anmeldefehler",
              "Description": "Sie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "313",
              "Title": "Anmeldefehler",
              "Description": "Sie haben momentan keinen Zugang zu Ihrem Home'Bank da Sie Ihr vorheriges Passwort zurückgesetzt haben. Aus Sicherheitsgründen kann ein neues Passwort erst nach 24 Stunden angelegt werden. Dann klicken Sie unter Home'Bank auf \"Neues Passwort\" und befolgen die nächsten Schritte.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "314",
              "Title": "Anmeldefehler",
              "Description": "Sie haben momentan keinen Zugang zu Ihrem Home'Bank da Sie Ihr vorheriges Passwort zurückgesetzt haben. Aus Sicherheitsgründen kann ein neues Passwort erst nach 24 Stunden angelegt werden. Dann klicken Sie unter Home'Bank auf \"Neues Passwort\" und befolgen die nächsten Schritte.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "315",
              "Title": "Anmeldefehler",
              "Description": "Ihr Home'Bank (Plus) Abonnement ist blockiert. Bitte nehmen Sie mit Home'Bank Helpdesk unter Tel. 02 464 60 03 Kontakt auf.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "316",
              "Title": "Anmeldefehler",
              "Description": "Ihr Home'Bank (Plus) Abonnement ist gekündigt. Besuchen Sie Ihre ING Zweigstelle für mehr Informationen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "317",
              "Title": "Anmeldefehler",
              "Description": "YouSie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "318",
              "Title": "Anmeldefehler",
              "Description": "Sie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "319",
              "Title": "Anmeldefehler",
              "Description": "Sie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "321",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "322",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "399",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38b9a4b0",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0432",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04c6",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04d7",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0427",
              "DisplayError": "ErrorBlock"
          }
        ]
    }
};

ING.SSO.ssoErrorMappingdebusiness = {
    "SsoErrors": {
        "Errors": [
          {
              "Code": "101",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "102",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "201",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "202",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "203",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "301",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "302",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "303",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "304",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "305",
              "Title": "Bankkarte abgelaufen",
              "Description": "Bitte benutzen Sie Ihre neue Karte, falls Sie diese bereits erhalten haben, oder beantragen Sie sie in Ihrer ING Zweigstelle. Sie können sich bei Home'Bank auch mit einer anderen ING Bankkarte anmelden, falls Sie eine weitere besitzen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "306",
              "Title": "Bankkarte gesperrt",
              "Description": "Bitte rufen Sie Home'Bank Helpdesk unter Tel. 02 464 60 03 an oder lassen Sie sie in Ihrer ING Zweigstelle freischalten. Probieren Sie es mit einer anderen ING Karte, falls Sie eine weitere besitzen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "307",
              "Title": "Bankkarte gesperrt",
              "Description": "Sie können Ihre ING Bankkarte in Ihrer ING Zweigstelle während der Schalteröffnungszeiten freischalten lassen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "308",
              "Title": "Bankkarte gesperrt",
              "Description": "Ihre Bankkarte wurde aus Sicherheitsgründen gesperrt. Um Sie wieder freischalten zu lassen, rufen Sie umgehend das Home'Bank-Helpdesk unter 02 464 60 03 an.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "309",
              "Title": "Bankkarte gesperrt",
              "Description": "Diese ING Bankkarte ist gesperrt. Sie können damit nicht mehr auf Home'Bank zugreifen. Lassen Sie sie in Ihrer ING Zweigstelle freischalten oder probieren Sie es mit einer anderen ING Karte, falls Sie eine weitere besitzen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "true",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "310",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "311",
              "Title": "Anmeldefehler",
              "Description": "Sie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "313",
              "Title": "Anmeldefehler",
              "Description": "Sie haben momentan keinen Zugang zu Ihrem Home'Bank da Sie Ihr vorheriges Passwort zurückgesetzt haben. Aus Sicherheitsgründen kann ein neues Passwort erst nach 24 Stunden angelegt werden. Dann klicken Sie unter Home'Bank auf \"Neues Passwort\" und befolgen die nächsten Schritte.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "314",
              "Title": "Anmeldefehler",
              "Description": "Sie haben momentan keinen Zugang zu Ihrem Home'Bank da Sie Ihr vorheriges Passwort zurückgesetzt haben. Aus Sicherheitsgründen kann ein neues Passwort erst nach 24 Stunden angelegt werden. Dann klicken Sie unter Home'Bank auf \"Neues Passwort\" und befolgen die nächsten Schritte.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "315",
              "Title": "Anmeldefehler",
              "Description": "Ihr Home'Bank (Plus) Abonnement ist blockiert. Bitte nehmen Sie mit Home'Bank Helpdesk unter Tel. 02 464 60 03 Kontakt auf.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "316",
              "Title": "Anmeldefehler",
              "Description": "Ihr Home'Bank (Plus) Abonnement ist gekündigt. Besuchen Sie Ihre ING Zweigstelle für mehr Informationen.",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "true",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "false",
              "HomeBankPlusMoreInfo": "false",
              "BackButton": "true"
          },
          {
              "Code": "317",
              "Title": "Anmeldefehler",
              "Description": "YouSie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "318",
              "Title": "Anmeldefehler",
              "Description": "Sie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "319",
              "Title": "Anmeldefehler",
              "Description": "Sie verfügen derzeit nicht über ein Home'Bank-Abonnement, daher können Sie sich nicht einloggen. Falls Sie ein Home'Bank-Abonnement haben, prüfen Sie, ob Sie bei der Anmeldung den richtigen Dienst gewählt haben (Home'Bank oder Home'Bank Plus).",
              "DisplayError": "ErrorOverlay",
              "FindBranchButton": "false",
              "MakeAnAppointmentButton": "false",
              "HomeBankMoreInfo": "true",
              "HomeBankPlusMoreInfo": "true",
              "BackButton": "true"
          },
          {
              "Code": "321",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "322",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "399",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38b9a4b0",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0432",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04c6",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf04d7",
              "DisplayError": "ErrorBlock"
          },
          {
              "Code": "0x38cf0427",
              "DisplayError": "ErrorBlock"
          }
        ]
    }
};
