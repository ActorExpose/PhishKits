﻿Framework.ensure("ING.K2");
Framework.ensure("ING.K2.Search");

ING.K2.Search.Autocomplete = Framework.run(Libraries.getGlobaljQuery(), function ($) {
    "use strict";

    var includeInSuggestionsThreshold,
        suggestionThreshold,
        suggestionsLimit,
        suggestionsUrlFormat,
        $searchBtn,
        init = function () {
            var deferred = $.Deferred();
            includeInSuggestionsThreshold = ING.Search.Run.configuration.SearchBox.IncludeInSuggestionsThreshold;
            suggestionsLimit = ING.Search.Run.configuration.SearchBox.NbAutoComplete;
            suggestionThreshold = ING.Search.Run.configuration.SearchBox.StartCompletionAfterCharacter;
            suggestionsUrlFormat = "/_vti_bin/services/search13?path=/_api/web/lists/getbytitle('User Queries')/items"
                            + "?$filter=((((SearchQueryCount gt '{0}')"
                            + " and (SearchLanguage eq '{1}'))"
                            + " and (SearchSegment eq '{2}'))"
                            + " and startswith(Title,'{3}'))&$orderby=Title";
            deferred.resolve();
            return deferred.promise();
        },
        onLoad = function () {
            $(".k2-search-section").each(function () {
                var $searchInput = $(":text", this);
                $searchInput.focus(onFocus).blur(onBlur);
            });
            init().then(function () {
                $(".k2-search-section").each(function () {
                    var $searchInput = $(":text", this);
                    $searchInput.keydown(evalFuncKey)
                                .keydown(evalKeypress)
                                .keyup(evalKeypress);
                    $(this).find(".k2-search-suggestions-container")
                        .on("mouseenter", function () {
                            $searchInput.off("blur", onBlur);
                        })
                        .on("mouseleave", function () {
                            $searchInput.on("blur", onBlur);
                        });
                });
            });
            $searchBtn = $(".k2-search-section-submit");
        },
        evalFuncKey = function (event) {
            var searchBox = event.target;
            if (event.which === 38) {
                goUp(searchBox);
            }
            if (event.which === 40) {
                goDown(searchBox);
            }
            if (event.which === 13) {
                var targetSuggestion = $(searchBox).parents(".k2-search-section").find(".k2-search-suggestions-container li.highlighted")[0];
                if (targetSuggestion !== null && targetSuggestion !== undefined) {
                    submitSearch(targetSuggestion, searchBox);
                }
            }

            //reject unauthorized char   
        },
        evalKeypress = function (event) {
            var theEvent = event || window.event;
            var key = theEvent.keyCode || theEvent.which;

            if (key == 37 || key == 38 || key == 39 || key == 40 || key == 8 || key == 9 || key == 46 || key == 13) { // Left / Up / Right / Down Arrow, Backspace, Tab, Delete, enter keys,
                //controls characters
            }
            else {
                var regex = new RegExp("[^a-zA-Z 0-9./s']");
                var str = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                if (regex.test(str)) {
                    event.preventDefault();
                    return false;
                }
            }

            var eventTarget = event.target;
            countChars(eventTarget);

        },
        onFocus = function () {
        },
        onBlur = function () {
            hideSuggestions(this);
        },
        gettingSuggestions = function (queryText) {

            var segment = ING.K2.Context.Current.Segment;
            var language = ING.K2.Context.Current.Variation;
            var getCookieForEB = function (name) { var re = new RegExp(name + "=([^;]+)"); var value = re.exec(document.cookie); return (value != null) ? unescape(value[1]) : null; }

            if (segment == "") {
                segment = getCookieForEB("SP_segment");
            };
            if (language == "") {
                language = getCookieForEB("SP_language");
            }

            var url = String.format(suggestionsUrlFormat, includeInSuggestionsThreshold, language, segment, queryText),
                promise = $.ajax({
                    url: url,
                    dataType: "json"
                });
            return promise;
        },
        goUp = function (eventTarget) {
            var $list = $(eventTarget).parents(".k2-search-section").find(".k2-search-suggestions-container ul"),
                $selectedItem = $list.find(".highlighted"),
                selectedIndex = $selectedItem.index();
            if (selectedIndex > 0) {
                $selectedItem.removeClass("highlighted");
                $selectedItem.prev().addClass("highlighted");
            }
        },
        goDown = function (eventTarget) {
            var $list = $(eventTarget).parents(".k2-search-section").find(".k2-search-suggestions-container ul"),
                $selectedItem = $list.find(".highlighted"),
                selectedIndex = $selectedItem.index(),
                totalItems = $list.find("li:visible").length;
            if (selectedIndex >= 0 && selectedIndex < totalItems - 1) {
                $selectedItem.removeClass("highlighted");
                $selectedItem.next().addClass("highlighted");
            }
            if (selectedIndex === -1 && totalItems > 0) {
                $list.find("li:first").addClass("highlighted");
                showSuggestions(eventTarget);
            }
        },
        countChars = function (eventTarget) {
            var queryText = $(eventTarget).val().toLowerCase();
            if (queryText.length >= suggestionThreshold) {
                if (queryText.substr(0, suggestionThreshold) !== $(eventTarget).data("querytext")) {
                    $(eventTarget).data("querytext", queryText.substr(0, suggestionThreshold));
                    gettingSuggestions(queryText).then(function (resultsData) {
                        if (resultsData !== null && resultsData.d.results.length > 0) {
                            buildSuggestionList(eventTarget, resultsData.d.results);
                            showSuggestions(eventTarget);
                        }
                    });

                }
                else {
                    showSuggestions(eventTarget);
                }
            }
            else {
                hideSuggestions(eventTarget);
            }
        },
        showSuggestions = function (searchBox) {
            var queryText = $(searchBox).val().toLowerCase(),
                $container = $(searchBox).parents(".k2-search-section").find(".k2-search-suggestions-container"),
                $visibleItems = $container.find("ul li")
                                .each(function () {
                                    $(this).hide()
                                        .removeClass("search-suggestion-firstrow")
                                        .removeClass("search-suggestion-lastrow");

                                })
                                .filter(function (index) {
                                    return $(this).text().toLowerCase().indexOf(queryText.toLowerCase()) === 0;
                                })
                                .slice(0, suggestionsLimit),
                 maxVisibleItems = $visibleItems.length > suggestionsLimit ? suggestionsLimit : $visibleItems.length;
            $visibleItems.eq(0).addClass("search-suggestion-firstrow");
            $visibleItems.eq(maxVisibleItems - 1).addClass("search-suggestion-lastrow");
            $visibleItems.show();
            $container.show();
        },
        hideSuggestions = function (searchBox) {
            var $container = $(searchBox).parents(".k2-search-section").find(".k2-search-suggestions-container"),
                $suggestionList = $container.find("ul");
            $container.hide();
            clearHighlightedSuggestions($suggestionList);
        },
        buildSuggestionList = function (searchBox, data) {
            var $ul = $(searchBox).parents(".k2-search-section").find(".k2-search-suggestions-container ul");
            $ul.empty();
            for (var i = 0; i < data.length; i++) {
                var $li = $("<li>" + data[i].Title + "</li>");
                $li.hide();
                $li.on("mouseenter", highlightSuggestion).on("mouseleave", unHighlightSuggestion).on("click", suggestionClicked);
                $ul.append($li);
            }
        },
        highlightSuggestion = function () {
            clearHighlightedSuggestions($(this).parent());
            $(this).addClass("highlighted");
        },
        unHighlightSuggestion = function () {
            $(this).removeClass("highlighted");
        },
        clearHighlightedSuggestions = function (suggestionList) {
            $(suggestionList).find("li.highlighted").removeClass("highlighted");
        },
        suggestionClicked = function () {
            var $input = $(this).parents(".k2-search-section").find("input:text")[0];
            $input.focus();
            submitSearch($(this), $input);
        },
        submitSearch = function (targetSuggestion, senderInput) {
            var queryText = $(targetSuggestion).text();
            queryText = queryText.replace(/[^a-zA-Z 0-9.]+/g, '').trim();
            $(senderInput).val(queryText);
            hideSuggestions(senderInput);
            // Chrome requires setting focus before clicking, in order to mimic exactly the human click of the button
            // btn.focus().click() doesn't guarantee that first focus is set and only after that the click executed
            // by using .one() we attach the event receiver for only one call, and that is exactly all we need
            $searchBtn.one("focus", function () {
                $(this).click();
            });
            $searchBtn.focus();
        };
    $(onLoad);
});
