// $ shortcut cannot be used here as it conflicts with MS cmssitemanager.js More info: chuvash.eu/2012/06/01/in-cmssitemanager-js-conflicts-with-in-jquery
//Fixed, in K2R3, now $ can be used.

Framework.run(Libraries.getGlobaljQuery(), function ($) {

	$(".k2-segment-tab-parent").mouseleave(function () {
		if ($(this).hasClass("k2-segment-tab-dropdown-open") == true) {
			$(this)
				.removeClass("k2-segment-tab k2-segment-tab-dropdown-open")
				.find(".k2-segment-choice")
				.fadeOut("fast").hide();
		}
	});

});