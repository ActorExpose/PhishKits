﻿Framework.ensure("ING.K2");

ING.K2.Search = Framework.run(Libraries.getGlobaljQuery(), function ($) {
    "use strict";

    var onLoad = function () {
        $(".k2-search-section").each(function () {
            var $searchInput = $(":text", this);

            var isDefaultText = function () {
                return $searchInput.val() === $searchInput.data("default");
            };
            var isEmpty = function () {
                return $searchInput.val().length == 0;
            };
            var $searchBtn = $(".k2-search-section-submit", this);
            $searchBtn.click(function () {
                $("form").attr("submitter", "SearchBtn");
            });
            $searchInput.keypress(function (event) {
                if (event.keyCode == 13) {
                    event.preventDefault();
                    $searchBtn.click();
                }
            });

            $searchInput
                .focus(function () {
                    $(this)
                        .removeClass("k2-input-disabled")
                    // Keep text previously entered by the user - Delete default text
                        .filter(isDefaultText).val("");
                })
                .blur(function () {
                    $(this)
                    // Show default text if textbox is left empty
                        .filter(isEmpty).addClass("k2-input-disabled").val($(this).data("default"));
                })
                .filter(isDefaultText).addClass("k2-input-disabled");

            $("form").submit(function (eventArgs) {
                if ($(eventArgs.currentTarget).attr("submitter") == "SearchBtn") {
                    $(eventArgs.currentTarget).attr("submitter", "");
                    // Check whether the input text contains keywords.
                    if (isDefaultText() || $searchInput.val().length == 0) {
                        return false;
                    }
                }
            });
        });
    };

    $(onLoad);
});