$(function(){
	var Click = false;
	var Uname = $('#gebruikersnaam input').val();

	// SUBMIT loginform
	$("#login").submit(function() {
		hide_tooltip();
		if (!$('#gebruikersnaam input').val() || !$('#wachtwoord input').val()){
			$("#wachtwoord .notification").removeClass("hide-element");
			$("#wachtwoord, #gebruikersnaam").addClass("validation-error");
			$("#wachtwoord .notification-message").html(Errortext1);
			$('#gebruikersnaam input').val(Uname);
			$('#wachtwoord input').val('');
			if(!Uname){$("#gebruikersnaam input").focus();}
			else{$("#wachtwoord input").focus();}
			return false;
		}
		else if ($('#gebruikersnaam input').val() && $('#wachtwoord input').val() && Click == false){
			Click = true;
			return true;
		}
	});
	
	//CAPSLOCK CHECK
	$('#wachtwoord input').keypress(function(e) { 
	    var s = String.fromCharCode( e.which );
	    if ( s.toUpperCase() === s && s.toLowerCase() !== s && !e.shiftKey && !('ontouchstart' in window)) {show_tooltip(this,Tooltiptitle1,Tooltiptext1);}
		else{hide_tooltip();}
	});
	$("#wachtwoord input").focusout(function(){hide_tooltip();});
	
});