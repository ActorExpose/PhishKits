var preloaderContent = {
	xhrUrls : [
		'ideal/betalen/inlog-annuleren/static/js/require.js',
        'ideal/betalen/inlog-annuleren/static/js/packages/jquery-ui-1.8.7-jquery-1.6.2.js',
        'ideal/betalen/inlog-annuleren/static/js/requirejs-plugins/domready.js',
        'ideal/betalen/inlog-annuleren/static/js/packages/forms-jquery-1.6.2.js',
        'ideal/betalen/inlog-annuleren/static/js/packages/validate-jquery-1.6.2.js',
		'ideal/betalen/inlog-annuleren/static/web/cms/riaf-init-1.0.0.js',
		'ideal/betalen/inlog-annuleren/static/js/packages/jquery-1.6.2.js',
        'ideal/betalen/inlog-annuleren/static/web/cms/riaf-bm-1.0.0.js',
		'ideal/betalen/inlog-annuleren/static/web/cms/riaf-home-1.0.0.js',
        'ideal/betalen/inlog-annuleren/static/js/packages/validate-jquery-1.6.2.js',
		'ideal/betalen/inlog-annuleren/static/web/cms/css/style-ideal-1.0.0.css',
		'ideal/betalen/inlog-annuleren/static/web/riaf/css/style-page-ideal-1.0.0.css',
		'ideal/betalen/inlog-annuleren/static/web/core/css/style-1.0.0.css',
		'ideal/betalen/inlog-annuleren/static/css/jquery-ui/jquery-ui-1.8.7.custom.css'
	],
	imgUrls : [
        'ideal/betalen/inlog-annuleren/static/images/ico_euro.gif',
        'ideal/betalen/inlog-annuleren/static/web/core/css/images/SOL_gradients_sprite.png',
        'ideal/betalen/inlog-annuleren/static/web/core/css/images/SOL_icon_sprite.png',
        'ideal/betalen/inlog-annuleren/static/web/core/css/images/SOL_buttons_sprite.png',
		'ideal/betalen/inlog-annuleren/static/contentimages/10492_logo_ideal.png',
		'ideal/betalen/inlog-annuleren/static/contentimages/10515_SOL_logo_ing.gif',
		'ideal/betalen/inlog-annuleren/static/images/favicon.ico',
		'ideal/betalen/inlog-annuleren/static/images/touch-icon.png'
	]
};