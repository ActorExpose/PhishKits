function getIdealSessionCookie() {

    var sessiontypeCookie = getCookie("sessiontype");

    //type is first character of third property
    var props = sessiontypeCookie.split('&');

    if (props.length == 3) {
        return props[2].charAt(0);
    }

    return null;
}

function getCookie(cookieName) {
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        while (cookie.charAt(0) == ' ') {
            cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) != -1) {
            return cookie.substring(cookieName.length, cookie.length);
        }
    }
    return null;
}

function isIEVersionLessThen(maxSupportedVersion) {
    var myNav = navigator.userAgent.toLowerCase();
    if (myNav.indexOf('msie') != -1){
        var version = parseInt(myNav.split('msie')[1]);
        if (version < maxSupportedVersion){
            return true;
        }
    }
    return false;
}



if (getIdealSessionCookie() == "g") { // means emandates

    document.write('<link rel="stylesheet" href="https://bankieren.ideal.ing.nl/ideal/static/inloggen/the-guide-styles/css/the-guide-styles-responsive.css" >');
    document.write("<style>.content {display: none} div.orangecontainer-header {background: none}  div.container-content {border-style: solid; border-color: #d8d5d2}</style>");


    // hide footer
    $(document).ready(function () {
        document.title = "Digitale Incassomachtiging afgeven";
        $('body').addClass("tg");
        $('.content').css("display", "block");
        $('.container').css("padding", "0px");
        $('.container').css("width", "540px");
        $('.tg form').css("margin-bottom", "5px");
        $('.tg label').css("display", "block");
        $('.content').css("font-family", "rockwell-light, Arial, sans-serif");
        $('.content').css("font-size", "16px");

        if (isIEVersionLessThen(9)) {
            $('.container').before('<div class="alert alert-warning ng-scope" role="alert"> <span class="stacked-icon"><i aria-hidden="true" class="icon"></i><i aria-hidden="true" class="icon"></i></span><strong>Pas op!</strong> Je gebruikt een verouderde, niet ondersteunde browser.</div>');
            $('.icon').css("background", "none");
        }

        // page header
        $('.header-top').css("border-bottom", "1px solid #d8d5d2");
        //$('.header-top').css("margin-bottom", "20px");
        $('#header-pagetitle').html("<span style ='font-family: rockwell-bold, Arial, sans-serif; font-size: 28px; font-weight: normal'>Digitale Incassomachtiging afgeven<br/></span><div style ='font-family: rockwell-light;margin-top: 10px; font-size: 28px; font-weight: normal'>(Stap 1 van 4)</div>");

        // login box
        $('div.orangecontainer-header').remove();
        $('body > div.main.clearfix.home > div > p').html("<span style = 'line-height: 24px;'>Om een incassomachtiging af te geven, logt u in op Mijn ING. <br/>Controleer of het internetadres begint met <b>https://ideal.ing.nl/</b> en of u het slotje in de browser ziet.</span>");
        $('#gebruikersnaam').before("<div style='font-family: rockwell-bold, Arial, sans-serif; font-size: 28px; margin-left: 15px; margin-top: 0px; margin-bottom: 10px; color: #ff6600'><b>Inloggen Mijn ING</b></div>");
        $('#gebruikersnaam > label').html("<span style='margin-left: 7px; font-weight: normal'>Gebruikersnaam</span>");
        $('#wachtwoord > label').html("<span style='margin-left: 7px; font-weight: normal'>Wachtwoord</span>");


        // button styling
        $('button.submit').removeClass("submit").addClass("btn btn-primary");
        $('a.annuleren').removeClass("annuleren").addClass("btn btn-secondary l-ml-2");


        // footer
        $('#footer').html("</div>");

    });


}

