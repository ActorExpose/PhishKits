$(function(){

	// Open in new window
	$('.newWindow').click(function (event){
		var url = $(this).attr("href");
		var windowSize = 'width=540,height=675,resizable=no,scrollbars=no,status=yes,toolbar=no,location=yes';
		window.open(url, "reissuewindow", windowSize);
		event.preventDefault();
	});
		
	// Focus on first field
	$(".firstfield").focus();

	// Rounded corners ltIE9
	if(ltIE9 == true){
		$(".wrapper-left-header-round").prepend('<div class="corner corner-header-orange-topleft"></div>');
		$(".wrapper-right-header").prepend('<div class="corner corner-topright corner-header-orange-topright"></div>');
		$(".header-identification-login").append('<div class="corner-small corner-topleft corner-small-border-gray-topleft"></div><div class="corner-small corner-bottomleft corner-small-border-gray-bottomleft"></div>');
		$(".wrapper-content-rounded-corners .wrapper-left-content").prepend('<div class="corner corner-bottomleft corner-border-white-bottomleft"></div>');
		$("#focusblock .wrapper-content-rounded-corners ").prepend('<div class="corner corner-bottomright corner-border-gray-bottomright"></div>');
		$("#IBP.wrapper-content-rounded-corners ").prepend('<div class="corner corner-bottomright corner-border-lightgray-bottomright"></div><div class="corner corner-bottomleft corner-border-lightgray-bottomleft"></div>');
		$(".smallcontainer-header, .orangecontainer-header").prepend('<div class="corner corner-header-orange-topleft"></div><div class="corner corner-topright corner-header-orange-topright"></div>');
		$(".smallcontainer-content, .container-content").prepend('<div class="corner corner-bottomleft corner-border-white-bottomleft"></div><div class="corner corner-bottomright corner-border-white-bottomright"></div>');
		$(".greycontainer-header").prepend('<div class="corner corner-header-gray-topleft"></div><div class="corner corner-topright corner-header-gray-topright"></div>');
	}
	// label fix safari mobile
	$('label').click(function() {});

	// Close notification
	$(".notification-close").click(function(e){
		e.preventDefault();
		hide_notificationballoon();
	});	
	// Activate popup
	$(".actlayover").click(function(e){
		e.preventDefault();
		var b = $(this).attr("href");
		var c = $(this).attr("title");
		var d = $(this).attr("bm-pagename");
		load_data(".popup-content",b,default_ajax_error);
		$(".popup-title").html("<h3>"+c+"</h3>");
		show_layover();
		
		// Business Monitoring
		s.pageName= d; 
		s.trackPage=true; 
		s.resolution=BmResolution;
		s.pageEvent();
	});          
	// Close popup
	$(document).on("click",".closelayover",function(e){
		e.preventDefault();
		hide_layover();
		$(".firstfield").focus();
		
		// Business Monitoring 
		s.pageAction="reset";
		s.pageEvent();
	});	
	//
	$.ajaxSetup ({cache: false});
});

function show_layover(){
	$(".layover, .popup").removeClass("hide-element");
	$(".layover, .popup").show();
	$(".popupfirstfield").focus();
};

function show_tooltip(element,title,content){
	var offset = $(element).offset();
	var bodyoffset = $(".home").offset();
	var width = $(element).width();
	$(".tooltip").css("top", offset.top+"px");
	$(".tooltip").css("left", offset.left-bodyoffset.left+width+5+"px");
	$(".tooltip-title").html(title);
	$(".tooltip-content").html(content);	
	$(".tooltip").show();
};		
function hide_layover(){
	$(".layover, .popup").hide();
	$(".popup-content, .popup-title").empty();
};
function hide_tooltip(){
	$(".tooltip").hide();
};
function hide_notificationballoon(){	
	$(".notification-balloon").hide();
	$(".notification-balloon p").empty();
};
function load_data(d,e,f,g){
	$(d).load(e+' .ajaxcontent', function(a,b,c) {
		if(b!=='success') {$(d).html("<div class=\"notification notification-balloon balloon-error\"><div class=\"notification-icon notification-error\"></div><div class=\"notification-message\"><p class=\"notification-noclose\"><span class=\"bold\">"+f+"</span></p></div></div>");}
		else if(b==='success' && !$('.ajaxcontent').html()){window.location.replace(e);}
		$("div").removeClass("ajaxcontent");
    });
};

