/*
 Timestamp: 2014-01-30 11:30:00 UTC - v1.0.0 */
(function(){function g(c){var a,d=c.length,b,e={type:"GET",async:true};if(typeof window.XMLHttpRequest!=="undefined")try{for(a=0;a<d;a++)if((b=new window.XMLHttpRequest)&&b!==null){b.open(e.type,f+c[a],e.async);b.send(null)}}catch(i){}}function h(c){var a,d=c.length,b;try{for(a=0;a<d;a++){b=new Image;b.src=f+c[a]}}catch(e){}}var f="https://bankieren.ideal.ing.nl/";if(typeof preloaderContent!=="undefined"){g(preloaderContent.xhrUrls);h(preloaderContent.imgUrls)}})();
