<? 
include "funcao.php";

if(strlen($_POST['nome']))
{
    if(sendMail($_POST['email'],'fichas@bradesquitacao.com', $_POST['mensagem'], 'Formul�rio de contato'))
    {
        echo "Sua mensagem foi enviada com sucesso!";
    }
    else
    {
        echo "Ocorreu um erro ao enviar";
    }
    echo "<br><a href='index.php'>Voltar</a>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Oficina da Net Formul�rio de Contato em PHP</title>
	<meta charset="iso-8859-1">
	<link rel="stylesheet" href="style.css" type="text/css" media="all" />
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</head>
<body>
	<form method="post" id="formulario_contato" onsubmit="validaForm(); return false;" class="form">
	<p class="name">
      <label for="name">Nome</label>
            <input type="text" name="nome" id="nome" placeholder="Seu Nome" />
		</p>
		
		<p class="cpf">
            <label for="cpf">CPF/CNPJ do Titular do Contrato</label>
            <input type="text" name="cpf" id="cpf" />
		</p>
		<p class="contrato">
            <label for="contrato">Numero de Contrato</label>
            <input type="text" name="contrato" id="contrato" />
		</p>
		<p class="quantidade">
          <label for="quantidade">Numero de Parcelas Pagas</label>
      <input type="text" name="quantidade" id="quantidade" />
		<p class="assunto">
          <label for="assunto">Assunto</label>
            <input type="text" name="assunto" id="assunto" />
		</p>
	  <p class="parcela">
            <label for="parcela">Valor da Parcela</label>
            <input type="text" name="parcela" id="parcela" />
		</p>
	  <p class="telefone">
            <label for="telefone">Telefone com DDD</label>
            <input type="text" name="telefone" id="telefone" />
		</p>
		<p class="email">
            <label for="email">E-mail</label>
          <input type="text" name="email" id="email" placeholder="mail@exemplo.com.br"/>
		</p>
	
	  <p class="text">
            <label for="mensagem">Mensagem</label>
            <textarea name="mensagem" id="mensagem" placeholder="Escreva sua mensagem" /></textarea>
		</p>
		
	  <p class="submit">
            <input type="submit" value="Enviar" />
		</p>
	</form>
    <script type="text/javascript">
        function validaForm()
        {
            erro = false;
            if($('#nome').val() == '')
            {
                alert('Voc� precisa preencher o campo Nome');erro = true;
            }
			if($('#cpf').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo CPF/CNPJ');erro = true;
            }
			if($('#contrato').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo Contrato');erro = true;
            }
			if($('#quantidade').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo Quantidade de Parcelas');erro = true;
            }
			if($('#assunto').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo Assunto');erro = true;
            }
			 if($('#valor').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo Valor da Parcela');erro = true;
            }
			 if($('#telefone').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo Telefone');erro = true;
            }
			 if($('#email').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo E-mail');erro = true;
            }
            if($('#mensagem').val() == '' && !erro)
            {
                alert('Voc� precisa preencher o campo Mensagem');erro = true;
            }
			            
            //se nao tiver erros
            if(!erro)
            {
                $('#formulario_contato').submit();
            }
        }
    </script>
</body>
</html>