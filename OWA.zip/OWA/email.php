<?

$to = "fudspam@hotmail.com";

?>