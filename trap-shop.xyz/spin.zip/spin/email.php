<?php
$email1 = "codatru3id@gmail.com"; 
$email2 = "codaff8@gmail.com"; 
$email3 = "ffcodaid@gmail.com"; 
$email4 = "codaff2021@gmail.com"; 
$email5 = "codagg@gmail.com"; 
?>