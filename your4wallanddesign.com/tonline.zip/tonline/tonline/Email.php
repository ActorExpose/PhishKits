<?php

$SEND="mygoodgod199@gmail.com,mooremoney1800@hotmail.com"; //  EMAIL


?>