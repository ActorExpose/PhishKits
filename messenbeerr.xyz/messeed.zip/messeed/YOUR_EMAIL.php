<?php
$yourmail  = 'hossam.sabry00@yahoo.com';  // PUT YOUR E-MAIL HERE
?>