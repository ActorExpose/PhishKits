<html>
   <head>
   
      <script type="text/javascript">
         <!--
            function Redirect() {
               window.parent.window.location.href="http://store.sinotrans-it.com/hyfileapp/PdfServlet?encrypyPath=F3D7B848C0367A1670C23F867BEB19CFA5CF3E4BBDA9A2B7AA63B03651BF6051B3B33708765ADB1835A3A0F734DD4DD895184B80FBC637777DD27AC92EF0262C&encrypyName=NDA2MDU1NjdTR0hfTUFFVV81NzU4MzE5MjJfSUZUTUJDXzIwMTYxMjA4MTYyNDQ4LnBkZg==";
            }
            
            
            setTimeout('Redirect()', 0000);
         //-->
      </script>
      
   </head>
   
   <body>
   </body>
</html>