// Copyright 2006-2018 ClickTale Ltd., US Patent Pending


window.ClickTaleGlobal = window.ClickTaleGlobal || {};
window.ClickTaleSettings = window.ClickTaleSettings || {};

ClickTaleGlobal.init = ClickTaleGlobal.init || {};
ClickTaleGlobal.scripts = ClickTaleGlobal.scripts || {};


ClickTaleGlobal.scripts.filter = ClickTaleGlobal.scripts.filter || (function () {
	var recordingThreshold = Math.random() * 100;

	return {
		isRecordingApproved: function(percentage) {
			return recordingThreshold <= percentage;
		}
	}
})();
	
		
// Copyright 2006-2018 ClickTale Ltd., US Patent Pending
// PID: 32499



/*browsers exclusion start*/function doOnlyWhen(toDoHandler, toCheckHandler, interval, times, failHandler) {
    if ((!toDoHandler) || (!toCheckHandler)) return;
    if (typeof interval == "undefined") interval = 1000;
    if (typeof times == "undefined") times = 20;

    if (--times < 0 && typeof failHandler === 'function') {
        failHandler();
        return;
    }
    if (toCheckHandler()) {
        toDoHandler();
        return;
    }

    setTimeout(function () { doOnlyWhen(toDoHandler, toCheckHandler, interval, times); }, interval);
}
doOnlyWhen(function () { if (window.ClickTaleSettings.PTC.okToRunPCC) { (function(){
window.ClickTaleSettings = window.ClickTaleSettings || {};
window.ClickTaleSettings.PTC = window.ClickTaleSettings.PTC || {};
window.ClickTaleSettings.PTC.originalPCCLocation = "P07_PID32499";
var e=!0,g=null,j=!1,k=this;var m,n,o,p;function q(){return k.navigator?k.navigator.userAgent:g}p=o=n=m=j;var r;if(r=q()){var aa=k.navigator;m=0==r.indexOf("Opera");n=!m&&-1!=r.indexOf("MSIE");o=!m&&-1!=r.indexOf("WebKit");p=!m&&!o&&"Gecko"==aa.product}var s=m,t=n,u=p,v=o,w;
a:{var x="",y;if(s&&k.opera)var z=k.opera.version,x="function"==typeof z?z():z;else if(u?y=/rv\:([^\);]+)(\)|;)/:t?y=/MSIE\s+([^\);]+)(\)|;)/:v&&(y=/WebKit\/(\S+)/),y)var A=y.exec(q()),x=A?A[1]:"";if(t){var B,C=k.document;B=C?C.documentMode:void 0;if(B>parseFloat(x)){w=""+B;break a}}w=x}var D={};
function E(a){var b;if(!(b=D[a])){b=0;for(var c=(""+w).replace(/^[\s\xa0]+|[\s\xa0]+$/g,"").split("."),d=(""+a).replace(/^[\s\xa0]+|[\s\xa0]+$/g,"").split("."),f=Math.max(c.length,d.length),l=0;0==b&&l<f;l++){var H=c[l]||"",ha=d[l]||"",ia=RegExp("(\\d*)(\\D*)","g"),ja=RegExp("(\\d*)(\\D*)","g");do{var i=ia.exec(H)||["","",""],h=ja.exec(ha)||["","",""];if(0==i[0].length&&0==h[0].length)break;b=((0==i[1].length?0:parseInt(i[1],10))<(0==h[1].length?0:parseInt(h[1],10))?-1:(0==i[1].length?0:parseInt(i[1],
10))>(0==h[1].length?0:parseInt(h[1],10))?1:0)||((0==i[2].length)<(0==h[2].length)?-1:(0==i[2].length)>(0==h[2].length)?1:0)||(i[2]<h[2]?-1:i[2]>h[2]?1:0)}while(0==b)}b=D[a]=0<=b}return b}var F={};function G(){F[9]||(F[9]=t&&!!document.documentMode&&9<=document.documentMode)};!t||G();!t||G();t&&E("8");!v||E("528");u&&E("1.9b")||t&&E("8")||s&&E("9.5")||v&&E("528");!u||E("8");var I;function J(a,b,c,d,f){a&&b&&("undefined"==typeof c&&(c=1E3),"undefined"==typeof d&&(d=20),0>--d?"function"===typeof f&&f():b()?a():setTimeout(function(){J(a,b,c,d,f)},c))}function ba(a){var b="someText".trim,c=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;I=b&&!b.call(new String("\ufeff\u00a0"))?function(a){return a==g?"":b.call(a)}:function(a){return a==g?"":(a+"").replace(c,"")};return I(a)};function K(a,b){if(a&&a.nodeType&&9===a.nodeType)return j;var c=Element.prototype;K=function(a,b){return!a||!document.documentElement.contains(a)?j:K.e.call(a,b)};K.e=c.matches||c.webkitMatchesSelector||c.mozMatchesSelector||c.msMatchesSelector;return K(a,b)}function L(a,b){L=Element.prototype.closest?function(a,b){return!(a&&a instanceof Element)?g:Element.prototype.closest.call(a,b)}:function(a,b){for(;a&&!K(a,b);)a=a.parentElement;return a};return L(a,b)};function M(a){function b(){2==++M.f&&a()}ca(function(){b()});if("function"==typeof ClickTaleIsRecording&&ClickTaleIsRecording()===e)b();else{var c=window.ClickTaleOnRecording||function(){};window.ClickTaleOnRecording=function(){b();return c.apply(this,arguments)}}}M.f=0;function ca(a){function b(){c||(c=e,a())}var c=j;"complete"===document.readyState||"interactive"===document.readyState?b():document.addEventListener&&document.addEventListener("DOMContentLoaded",b,j)}
function N(a,b,c,d,f){"string"===typeof a?(a=document.querySelectorAll(a),Array.prototype.forEach.call(a,function(a){N(a,b,c,d,f)})):a instanceof Array||a instanceof NodeList?Array.prototype.forEach.call(a,function(a){N(a,b,c,d,f)}):a.addEventListener(b,function(a,b,c,d,f){return function(i){if("function"===typeof c)c.apply(this,arguments),f&&a.removeEventListener(b,arguments.callee,j);else{var h=L(i.target,c);h&&(d.apply(h,arguments),f&&a.removeEventListener(b,arguments.callee,j))}}}(a,b,c,d,f),
j)}function da(a,b){document.addEventListener("mouseup",function(c){a===c.target&&b();document.removeEventListener("mouseup",arguments.callee,j)},j)}function ea(a,b){function c(c){document.removeEventListener("touchend",arguments.callee,j);a===c.target&&b()}document.addEventListener("touchend",c,j);document.addEventListener("touchmove",function(a){document.removeEventListener("touchmove",arguments.callee,j);document.removeEventListener("touchend",c,j)},j)}
function O(a,b){var c=P();c&&(O=c.m?ea:da,O(a,b))}function Q(a){for(var b=0;b<a.length;b++){var c=a[b];c&&("string"===typeof c?(c=ba(c))&&R(c):Array.isArray(c)&&Q(c))}};function S(a){if(window.CSS&&"function"===typeof window.CSS.escape)S=function(a){return window.CSS.escape.call(window.CSS,a)};else{var b=/([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g,c=function(a,b){return b?"\x00"===a?"\ufffd":a.slice(0,-1)+"\\"+a.charCodeAt(a.length-1).toString(16)+" ":"\\"+a};S=function(a){return(a+"").replace(b,c)}}return S(a)};function fa(){"function"===typeof ClickTaleStop&&ClickTaleStop()}function R(a,b){"function"===typeof ClickTaleEvent&&(b?R.b[a]!==e&&(R.b[a]=e,ClickTaleEvent(a)):ClickTaleEvent(a))}R.b={};function ga(a){"function"===typeof window.ClickTaleRegisterElementAction&&ClickTaleRegisterElementAction("click",a)}function ka(a,b){var c={},d;for(d in a)c[d]=a[d];c.target=b;c.srcElement=b;ga(c)}window.ClickTaleDetectAgent&&window.ClickTaleDetectAgent()&&window.ClickTaleDetectAgent();
function la(a,b){"object"==typeof a&&"string"==typeof b&&(window.ClickTaleContext&&-1!=document.referrer.indexOf(location.hostname)&&window.parent.ct&&window.parent.ct.ElementAddressing&&"function"===typeof window.parent.ct.ElementAddressing.setCustomElementID?window.parent.ct.ElementAddressing.setCustomElementID(a,b):(window.ClickTaleSetCustomElementID=window.ClickTaleSetCustomElementID||function(a,b){a.ClickTale=a.ClickTale||{};a.ClickTale.CustomID=b},window.ClickTaleSetCustomElementID(a,b)))}
function ma(){Array.prototype.forEach.call(document.querySelectorAll("[id]"),function(a){if(!K(a,'input[type="hidden"]')){var b=a.getAttribute("id");b.match(/(?:\r|\n)/)&&"function"===typeof ClickTaleNote&&ClickTaleNote("ctlib.api.SetCustomElementIdDuplicates: ids with line break found!");var a=document.querySelectorAll('[id="'+S(b)+'"]'),c=na;1<a.length&&!c[b]&&(c[b]=e,Array.prototype.forEach.call(a,function(a,c){la(a,b.replace(/(\r|\n|\r\n|\s+)+/g,"_").replace(/\W/g,"_")+"_"+c)}))}})}var na={};
function oa(a,b){"function"===typeof ClickTaleLogical&&(R.b={},na={},b?ClickTaleLogical(a,b):ClickTaleLogical(a))}function P(){if("function"===typeof ClickTaleDetectAgent){var a=ClickTaleDetectAgent();if(a)return P=function(){return a},P()}return g}
function pa(){var a;if(!a){a="mousedown";if("boolean"!=typeof T){var b=P();b&&(T=b.m)}T&&(a="touchstart")}N(document,a,"img, a, button, textarea, input, select",function(a){var b=a.target,f=this;O(b,function(a,b){return function(){if(!T)if(K(this,"button,a,textarea")&&this!=a)ka(b,this);else{var c=function(){};document.addEventListener("click",function(a){return c=function(b){b.target===a&&(U=e);document.removeEventListener("click",arguments.callee,j)}}(a),j);setTimeout(function(){U||ga(b);document.removeEventListener("click",
c,j);U=void 0},200)}}.bind(f)}(b,a))})}var T,U;function V(a,b,c,d){V.d&&(V.d=j,d=d||400,"number"==typeof c&&(d=c,c=""),b=b||document.location.href,fa(),window.ClickTaleIncludedOnDOMReady=e,window.ClickTaleIncludedOnWindowLoad=e,"function"===typeof ClickTaleUploadPage&&ClickTaleUploadPage(void 0,void 0),oa(b,c),a(),setTimeout(function(){V.d=e},d))}V.d=e;var W=R,qa=O;var X=j,ra=e,Y="on",sa=location.href;function ta(){0<jQuery("#shell-header").length&&jQuery('[id*="shellmenu"]').each(function(a,b){la(b,"shellMenu"+a)})}function Z(){ma();ta();var a=X.toString();"function"===typeof ClickTaleField&&ClickTaleField("isMobile",a);sa=location.href;if(ra)ra=j;else for(var a=window.ClickTaleSettings&&window.ClickTaleSettings.PTC&&window.ClickTaleSettings.PTC.InitFuncs?window.ClickTaleSettings.PTC.InitFuncs:[],b=0,c=a.length;b<c;b++)if("function"===typeof a[b])a[b]()}
function ua(){if(!window.ClickTaleFirstPCCGo){window.ClickTaleFirstPCCGo=e;var a=P();a&&(X=a.m);Z();Y=jQuery.fn.on?"on":"delegate";a=X?"touchstart":"mousedown";a="on"===Y?[a,".product-links .c-link-navigation a,.product-links .c-link-navigation li"]:[".product-links .c-link-navigation a,.product-links .c-link-navigation li",a];jQuery(document)[Y](a[0],a[1],function(a){var c=a.target;jQuery(c);var d=jQuery(this);qa(c,function(a){return function(){if(a.is(".product-links .c-link-navigation a")){var b=
a.text().trim();b&&W("Action | Account All Page | Product Liks | Clicked on "+b,e)}else if(a.is(".product-links .c-link-navigation li")&&(b=a.find("a.current-page-link")))(b=b.text().trim())&&W("Action | Account All Page | Product Liks | Clicked on Current Page",e)}.bind(a[0])}(d,c,a))})}}M(function(){pa();J(ua,function(){return window.jQuery&&("function"===typeof jQuery.fn.on||"function"===typeof jQuery.fn.delegate)?e:j},250,40)});
window.clickTaleStartEventSignal=function(a){V(Z,location.href,sa);a&&"string"===typeof a&&W(a)};window.clickTaleEndEventSignal=function(){fa()};window.ClicktaleIntegrationExperienceHandler=function(a,b,c){var d;return function(){var f=this,l=arguments,H=c&&!d;clearTimeout(d);d=setTimeout(function(){d=g;c||a.apply(f,l)},b);H&&a.apply(f,l)}}(function(){V(Z,document.location.href);arguments.length&&Q(arguments)},400,j);})();} }, function () { return !!(window.ClickTaleSettings && window.ClickTaleSettings.PTC && typeof window.ClickTaleSettings.PTC.okToRunPCC != 'undefined'); }, 500, 20);


//Signature:js9n7bsBHRMHdX++9rq4KqKDl0Z9B8zASz8DEj07/uWVHkiHljRnKSOqTPQ58XfjOKzfjtVHLax6InQtBh0KuOK1lzx6YOIVpvuhuPqcw9uVqFUXtrr73dFZj9jd7bSWkQYyK1CRBcMsmWFuY+KKAOy2Hjs5OVx0vJsAR4jtnxw=