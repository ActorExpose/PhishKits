<br />
<br />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
<br /><center><img  src="http://i.imgur.com/WVxoNFu.png"></center>

<meta http-equiv="refresh" content="5; url=https://www.capgemini.com/wp-content/uploads/2017/07/wealth_management_trends_2017_web_0.pdf" />