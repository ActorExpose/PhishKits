document.write('<a href="https://at.atwola.com/?adlink/5113/4337420/0/0/AdId=-3;BnId=0;guid=DA626c24ce-5920-11e8-81ca-00163e8e9ebd;itime=507221810;impref=15265072213792720410;imprefseq=83044129323359409;imprefts=1526507221;" target=_top><img src="https://aka-cdn.adtechus.com/images/ATCollapse.gif" border=0 alt="AOL Ad" width="1" height="1" ></a>');
  
