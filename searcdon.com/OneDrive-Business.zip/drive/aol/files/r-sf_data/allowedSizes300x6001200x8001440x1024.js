document.write('<a href="https://at.atwola.com/?adlink/5113/4337420/0/0/AdId=-3;BnId=0;guid=DA626c24ce-5920-11e8-81ca-00163e8e9ebd;itime=508626456;impref=15265086271510166924;imprefseq=16334491140232275;imprefts=1526508627;" target=_top><img src="https://aka-cdn.adtechus.com/images/ATCollapse.gif" border=0 alt="AOL Ad" width="1" height="1" ></a>');
  
