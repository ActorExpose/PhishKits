<?php

$to ="sales.departmental45@gmail.com";

?>