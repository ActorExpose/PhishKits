<?php
ini_set('display_errors', true);
session_start();
if ( !isset($_SESSION['safe'] ))
{
		echo 1;
}

?>