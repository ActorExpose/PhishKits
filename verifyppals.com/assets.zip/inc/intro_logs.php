<?php
$ip = getUserIP();
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$user_date = date('Y-m-d  h:i', time());


$data = "
ip: $ip 
hostname: $hostname 
useragent: $useragent 
referrer: $referrer 
time: $user_date
======================\n\n
";


$logFile = fopen('./logs/entries.txt', 'a');
$logWrite = fwrite($logFile, $data);
fclose($logFile);
?>