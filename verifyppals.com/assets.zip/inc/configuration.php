<?php

$email = "";
$fileSave = 1;
$emailSave = 0;
$onlyUK = 1;
$oneTime = 1;
$encryption = 0; // In development
$redirect = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjhxOT88PjlAhVJJ1AKHcwrC5QQFjAAegQIBxAC&url=https%3A%2F%2Fwww.paypal.com%2Fuk%2Fhome&usg=AOvVaw0bJ7fG7mk5yia5upCsbFyP";


?>