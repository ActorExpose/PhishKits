function numbersonly(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8 && unicode!=9  ){ 


if (unicode<48||unicode>57){ 

return false 
}

}
}




function phone(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8 && unicode!=9  ){ 


if (unicode<48||unicode>57){ 

if (unicode==43)
{
return true;
}
else
{
return false ;
}

}

}
}





function sorte(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8 && unicode!=9  ){ 


if (unicode<48||unicode>57){ 

if (unicode==45)
{
return true;
}
else
{
return false ;
}

}

}
}







function onKeyPressBlockNumbers(e)
{
	var key = window.event ? e.keyCode : e.which;
	var keychar = String.fromCharCode(key);
	reg = /\d/;
	return !reg.test(keychar);
}

