<?PHP 

/*
	// When this is enabled the code will generate no errors to the user even if there was one.
	// This is used to prevent sensitive data to be shown to a user who found an error. 
	// The following line should be uncommented only on releases. 
	error_reporting(0);


*/

require_once('functions.php');
require_once('database.php');

// Check if forms exists and if they're not null

	if(!isset($_POST['user'], $_POST['password']) || // Check if they exists
		empty(input($_POST['user'])) || empty(input($_POST['password'])))   // Check if they contains something 	
			die("There was an error. Please retry."); 						// Stop execution if something miss


	// Check with regular expression the validation of the forms content
	// Regular expressions must be defined by the Developer regarding their needs.


	if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['user']))) 
		$POSTusername = input($_POST['user']);
	else 
		die("There was an error. Please retry.");
	

	if(preg_match("/^[A-Za-z0-9\.\_\-]{1,32}/", input($_POST['password']))) 
		$POSTpassword = input($_POST['password']);		
	 else 
		die("There was an error. Please retry.");

	// After the check prepare for the query to verify password

	//Prepared statement

	try {

    // set the PDO error mode to exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // CHECK USERNAME

    $stmt = $db->prepare("SELECT user FROM ".TAB_ACCOUNTS." WHERE `user`=:fuser");
    
    $stmt->execute(array("fuser" => "$POSTusername"));

    $Username_Count = $stmt->rowCount();

    if($Username_Count == 0)
    	die("Username does not exists.");

    // Find the Account ID
    $stmt = $db->prepare("SELECT id FROM ".TAB_ACCOUNTS." WHERE `user`=:fuser");
    
    $stmt->execute(array("fuser" => "$POSTusername"));

    $row = $stmt->fetch();
    $AccountID = $row['id']; 


        // Take the password from the database of the current user
    $stmt = $db->prepare("SELECT password FROM ".TAB_ACCOUNTS." WHERE `user`=:fuser");
    
    $stmt->execute(array("fuser" => "$POSTusername"));

    $row = $stmt->fetch();

    $dbPassword = $row['password'];      


        // Take the "active" state from the database
    $stmt = $db->prepare("SELECT active FROM ".TAB_ACCOUNTS." WHERE `user`=:fuser");
    
    $stmt->execute(array("fuser" => "$POSTusername"));

    $row = $stmt->fetch();

    $active = $row['active'];        


        // Take the "isBanned" state from the database
    $stmt = $db->prepare("SELECT isBanned FROM ".TAB_ACCOUNTS." WHERE `user`=:fuser");
    
    $stmt->execute(array("fuser" => "$POSTusername"));

    $row = $stmt->fetch();

    $isBanned = $row['isBanned'];

    // Check if password was correct
    if(password_verify($POSTpassword, $dbPassword)) 
    {

    	if($isBanned == 1) 
    		die("Your account has been banned.");

    	// Password and username correct, proceed with login.
		die("Successfully logged in! \n Loading..."); //Die with this message. This will be processed by Unity for continue.	
    } 
    else 
    {
		die("Password does not match \n");
    }


    }
	catch(PDOException $e)
    {
    // echo "Error: " . $e->getMessage();
    die("An error occurred, please retry.");
    }
	

?>