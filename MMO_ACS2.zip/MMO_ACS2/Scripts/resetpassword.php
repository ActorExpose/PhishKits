<!DOCTYPE html>
 
<html>
<head>
    <title>MMO ACS 2 > Reset your password</title>
    <link href="css/style.css" type="text/css" rel="stylesheet" />
</head>
<body style="background-image: url('MMOACS2_WebBg.png');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center top; ">    <!-- start header div --> 
    <div id="header">
    </div>
    <!-- end header div -->   
     
    <!-- start wrap div -->   
    <div id="wrap">


<style>

@font-face {
font-family: "immortal";
src: url("IMMORTAL.ttf");
src:
url("IMMORTAL.ttf") format("ttf"),
}

.container {
  height: 230px;
  position: relative;
}

.center {
  margin: 0;
  position: absolute;
  top: 200%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-55%, -50%);
}

.section {
  height: 380px;
  width:  420px;
  position: relative;
  border: 2px solid #006187;
  background:#000000
}

.responseMessage {
	height: 250px;
  position: relative;
  margin: 0;
  position: absolute;
  top: 0%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-55%, +325%);
  height: 80px;
  width:  380px;
  position: relative;
  border: 2px solid black;
  background:#000000
}
</style>
	
	<!-- Page and button -->
	
		
	<div class="container">
  <div class="center">
  	  <div class="section">

					<center>
<h1 style="font-family:immortal; color: white"> RECOVER PASSWORD</h1>
		
		<form method="POST">
					<h3 style="font-family:immortal; color: white"> New Password:</h3>

		<p><input style="font-family:immortal;" type="password" name="password" value="" /></p>
				<h3 style="font-family:immortal; color: white">Confirm Password:</h3>
		<p><input style="font-family:immortal;" type="password" name="confirmpassword" value="" /></p>

		<input style="font-family:immortal;" type="submit" id="btnSubmit" name="btnSubmit" value="Save Changes" />
		</form>
			</center>
		</form>  </div> </div>
</div> 
		
	
        <!-- start PHP code -->
        <?PHP
		
		/*
		// When this is enabled the code will generate no errors to the user even if there was one.
		// This is used to prevent sensitive data to be shown to a user who found an error. 
		// The following line should be uncommented only on releases. 

		error_reporting(0);

		*/

		require_once('functions.php');
		require_once('database.php');
	
		$email = "";
		
		// Verify data
		if(isset($_GET['email']) && !empty($_GET['email']) AND isset($_GET['passhash']) && !empty($_GET['passhash'])){
			
		$email = input($_GET['email']);
		$PasswordHash = input($_GET['passhash']);

		
		}

	
		
		if (isset($_POST['btnSubmit'])) //If we press "Continue"
		{
	
			$newpass = input($_POST['password']); //newpass is equal at what we wrote in the first field
			$confirmnewpass = input($_POST['confirmpassword']); //confirmnewpass is equal to what we wrote in the secodn field
						
			if($newpass != $confirmnewpass)  
			{
				die('<div class="responseMessage"><p style="color:yellow;">Password does not match.</p></div>');

			} else  {			
				
				try {
 				// set the PDO error mode to exception
			    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    
			    // CHECK FOR EXISTING EMAIL

				$stmt = $db->prepare("SELECT email, ResetPasswordHash FROM ".TAB_ACCOUNTS." WHERE email=:femail AND ResetPasswordHash=:fpasshash");
			    
			    $stmt->execute(array("femail" => "$email",
									 "fpasshash" => "$PasswordHash"));


	    	    $match = $stmt->rowCount();


				if($match > 0) { //if there is a match

				// Crypt the password
				$newpass = c_hash_password($newpass);	//set the password


		    	$stmt = $db->prepare("UPDATE ".TAB_ACCOUNTS." SET password ='".$newpass."' WHERE email = :femail AND ResetPasswordHash=:fpasshash");

				$stmt->execute(array(
						    "femail" => "$email",
							"fpasshash" => $PasswordHash));

		    	$stmt = $db->prepare("UPDATE ".TAB_ACCOUNTS." SET ResetPasswordHash =null WHERE email = :femail AND ResetPasswordHash=:fpasshash");

				$stmt->execute(array(
						    "femail" => "$email",
							"fpasshash" => $PasswordHash));

				die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">Password has been updated. You can now login with your new password.</p></div>');


				} else {
					die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">The link has expired, please request a new link.</p></div>');

				}

			} catch(PDOException $e)
		    {
		    // echo "Error: " . $e->getMessage();
				die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">An error occurred, please retry.</p></div>');
		    }	
		}
			
	}

			
		?>.		
        <!-- stop PHP Code -->
 
         
    </div>
    <!-- end wrap div --> 
</body>
</html>