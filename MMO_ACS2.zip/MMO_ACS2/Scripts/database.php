<?php
/*
	// When this is enabled the code will generate no errors to the user even if there was one.
	// This is used to prevent sensitive data to be shown to a user who found an error. 
	// The following line should be uncommented only on releases. 

	error_reporting(0);

*/


// This file will create a connection to the database based on the defined values
// It must be included in every PHP script that must access to the database
// In the script we will access to the database using $db


define('SERVER_NAME', 'localhost');
define('DB_NAME', 'mmoacs2_db');
define('DB_USER', 'root');
define('DB_PASS','');

define('TAB_ACCOUNTS', 'accounts');
define('TAB_PLAYERS',  'characters');

define('SUPPORT_EMAIL_ADDRESS',  'yourmail@yourdomain.com'); // The mail address that will send the mails to users.


// Create connection

$db = new PDO("mysql:host=".SERVER_NAME."; dbname=".DB_NAME, DB_USER, DB_PASS);



?>