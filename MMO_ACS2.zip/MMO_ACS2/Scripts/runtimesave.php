<?PHP

/*
	// When this is enabled the code will generate no errors to the user even if there was one.
	// This is used to prevent sensitive data to be shown to a user who found an error. 
	// The following line should be uncommented only on releases. 
	error_reporting(0);


*/

	require_once('functions.php');
	require_once('database.php');

	// Check for every values before assign or use them
   if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Username']))) 
        $Username = input($_POST['Username']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Name']))) 
        $Name = input($_POST['Name']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Gender']))) 
        $Gender = input($_POST['Gender']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Level']))) 
        $Level = input($_POST['Level']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Race']))) 
        $Race = input($_POST['Race']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Class']))) 
        $Class = input($_POST['Class']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Skin']))) 
        $Skin = input($_POST['Skin']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Hair']))) 
        $HairType = input($_POST['Hair']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['HairColor']))) 
        $HairColor = input($_POST['HairColor']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['HeadEquipped']))) 
        $HeadEquipped = input($_POST['HeadEquipped']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['ChestEquipped']))) 
        $ChestEquipped = input($_POST['ChestEquipped']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['HandsEquipped']))) 
        $HandsEquipped = input($_POST['HandsEquipped']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['LegsEquipped']))) 
        $LegsEquipped = input($_POST['LegsEquipped']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['FeetsEquipped']))) 
        $FeetsEquipped = input($_POST['FeetsEquipped']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['RHandEquipped']))) 
        $RHandEquipped = input($_POST['RHandEquipped']);
    else 
        die("There was an error. Please retry.");



    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Strenght']))) 
        $Strenght = input($_POST['Strenght']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Agility']))) 
        $Agility = input($_POST['Agility']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Intellect']))) 
        $Intellect = input($_POST['Intellect']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Spirit']))) 
        $Spirit = input($_POST['Spirit']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['Armour']))) 
        $Armour = input($_POST['Armour']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['CriticalChance']))) 
        $CriticalChance = input($_POST['CriticalChance']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['MeleeDamage']))) 
        $MeleeDamage = input($_POST['MeleeDamage']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['SpellDamage']))) 
        $SpellDamage = input($_POST['SpellDamage']);
    else 
        die("There was an error. Please retry.");

    if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['CharID']))) 
        $CharID = input($_POST['CharID']);
    else 
        die("There was an error. Please retry.");


    try {

	    // set the PDO error mode to exception
	    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    
	    // CHECK USERNAME

	    $stmt = $db->prepare("SELECT id FROM ".TAB_ACCOUNTS." WHERE user=:fuser");
	    
	    $stmt->execute(array("fuser" => "$Username"));

    	$row = $stmt->fetch();

    	$AccountID = $row['id'];  

    	$stmt = $db->prepare("UPDATE ".TAB_PLAYERS." SET
    		Name = :fName, 
    		Gender = :fGender, 
    		Level = :fLevel, 
    		Race = :fRace, 
    		Class = :fClass,
    		Skin = :fSkin,
    		HairType = :fHairType,
    		HairColor = :fHairColor,
    		HeadEquipped = :fHeadEquipped,
    		ChestEquipped = :fChestEquipped,
    		HandsEquipped = :fHandsEquipped,
    		LegsEquipped = :fLegsEquipped,
    		FeetsEquipped = :fFeetsEquipped,
    		RHandEquipped = :fRHandEquipped,
    		Strenght = :fStrenght,
    		Agility = :fAgility,
    		Intellect = :fIntellect,
    		Spirit = :fSpirit,
    		Armour = :fArmour,
    		CriticalChance = :fCriticalChance,
    		MeleeDamage = :fMeleeDamage,
    		SpellDamage = :fSpellDamage
    					
    		WHERE
    		ID = :fCharID");

		$stmt->execute(array(
				    "fName" => "$Name",
                    "fGender" => "$Gender",
                    "fLevel" => "$Level",
                	"fRace" => "$Race",
                	"fClass" => "$Class",
                	"fSkin" => "$Skin",
                	"fHairType" => "$HairType",
                	"fHairColor" => "$HairColor",
                	"fHeadEquipped" => "$HeadEquipped",
                	"fChestEquipped" => "$ChestEquipped",
                	"fHandsEquipped" => "$HandsEquipped",
                	"fLegsEquipped" => "$LegsEquipped",
                	"fFeetsEquipped" => "$FeetsEquipped",
                	"fRHandEquipped" => "$RHandEquipped",
                	"fStrenght" => "$Strenght",
                	"fAgility" => "$Agility",
                	"fIntellect" => "$Intellect",
                	"fSpirit" => "$Spirit",
                	"fArmour" => "$Armour",
                	"fCriticalChance" => "$CriticalChance",
                	"fMeleeDamage" => "$MeleeDamage",
                	"fSpellDamage" => "$SpellDamage",
                	"fCharID" => "$CharID"));

		die("Saved Successfully!"); //Otherwise say that everything went ok!


	} 
	catch(PDOException $e)
    {
	    echo "Error: " . $e->getMessage();
	    die("An error occurred, please retry.");
    }



?>