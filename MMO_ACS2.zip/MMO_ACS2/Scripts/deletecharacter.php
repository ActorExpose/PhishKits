<?PHP
/*
	// When this is enabled the code will generate no errors to the user even if there was one.
	// This is used to prevent sensitive data to be shown to a user who found an error. 
	// The following line should be uncommented only on releases. 

	error_reporting(0);

*/


	require_once('functions.php');
	require_once('database.php');

   if(preg_match("/^[0-9]{1,24}/", input($_POST['PlayerID']))) 
        $PlayerID = input($_POST['PlayerID']);
    else 
        die("There was an error. Please retry.");


    try {

	    // set the PDO error mode to exception
	    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    
	    // CHECK USERNAME

	    $stmt = $db->prepare("DELETE FROM ".TAB_PLAYERS." WHERE ID=:fplayerid");
	    
	    $stmt->execute(array("fplayerid" => "$PlayerID"));

	    die("Character deleted!"); 
	} 
	catch(PDOException $e)
    {
	    // echo "Error: " . $e->getMessage();
	    die("An error occurred, please retry.");
    }
	
	

?>