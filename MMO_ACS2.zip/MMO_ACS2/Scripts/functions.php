<?PHP 

/*
	// When this is enabled the code will generate no errors to the user even if there was one.
	// This is used to prevent sensitive data to be shown to a user who found an error. 
	// The following line should be uncommented only on releases. 


*/

	error_reporting(0);


// Validate input and avoid disasters caused by XSS attacks.
function input($value) {

 	$value = trim($value);
 	$value = stripslashes($value);
 	$value = htmlspecialchars($value);
 	return $value;
}

// Bycript the password wiht custom options
function c_hash_password($password) {

	$options = [
	    'cost' => 12,
	];
	return password_hash($password, PASSWORD_BCRYPT, $options);

}


?>