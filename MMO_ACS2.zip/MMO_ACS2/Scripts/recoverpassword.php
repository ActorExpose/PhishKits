<!DOCTYPE html>
<html>
<head>
    <title>MMO ACS 2 > Recover your password</title>
    <link href="css/style.css" type="text/css" rel="stylesheet" />
</head>
<body style="background-image: url('MMOACS2_WebBg.png');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center top; ">    <!-- start header div --> 
    <div id="header">
    </div>
    <!-- end header div -->   
     
    <!-- start wrap div -->   
    <div id="wrap">
	
	<!-- Page and button -->
	
<style>

@font-face {
font-family: "immortal";
src: url("IMMORTAL.ttf");
src:
url("IMMORTAL.ttf") format("ttf"),
}

.container {
  height: 200px;
  position: relative;
}

.center {
  margin: 0;
  position: absolute;
  top: 200%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-55%, -50%);
}

.section {
  height: 350px;
  width:  420px;
  position: relative;
  border: 2px solid #006187;
  background:#000000
}

.responseMessage {
	height: 200px;
  position: relative;
  margin: 0;
  position: absolute;
  top: 0%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-55%, +290%);
  height: 80px;
  width:  380px;
  position: relative;
  border: 2px solid black;
  background:#000000
}
</style>

<div class="container">
  <div class="center">
  	  <div class="section">

					<center>

<h1 style="font-family:immortal; color: white"> RECOVER PASSWORD</h1>
		<h3 style="font-family:immortal; color: white"> Please Enter Your E-Mail</h3>

		<form action="recoverpassword.php" method="POST">

		<p><input style="font-family:immortal" type="email" name="name" value="" /></p>
		
		<p><input style="font-family:immortal" name = "Button" value="Submit" type="submit"></p>
	</center>
		</form>  </div> </div>
</div> 

		
		

        <!-- start PHP code -->
        <?PHP
		//This is the page showed when we click on "Forgot Your Password?"
		//This will allow us to send an email with data. The data is the Passwordhash and the email of the user. They are setted in the URL.
		
		
		/*
		// When this is enabled the code will generate no errors to the user even if there was one.
		// This is used to prevent sensitive data to be shown to a user who found an error. 
		// The following line should be uncommented only on releases. 

		error_reporting(0);

		*/

		require_once('functions.php');
		require_once('database.php');
	

		if (isset($_POST['Button'])) 
		{ 
			$to      = input($_POST['name']); // Say that the email must be sendt to our user
		


			try {

			    // set the PDO error mode to exception
			    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    
			    // CHECK FOR EXISTING EMAIL

				$stmt = $db->prepare("SELECT email, active FROM ".TAB_ACCOUNTS." WHERE email=:femail AND active='1'");
			    
			    $stmt->execute(array("femail" => "$to"));


	    	    $match = $stmt->rowCount();

	    	    if($match > 0) {
	    		$Passwordhash = md5( rand(0,1000) );

		    	$stmt = $db->prepare("UPDATE ".TAB_ACCOUNTS." SET ResetPasswordHash ='".$Passwordhash."'  WHERE email = :femail");

				$stmt->execute(array(
						    "femail" => "$to"));

			   

			
				$subject = 'MMO Accounts & Characters System 2 | Recover your account password.'; // Give the email a subject 
				$message = '
				
				This is an automatic email, please do not reply. 
				 
				Hi!
				We have recived a request of resetting your password.
				If you havent done that just ignore this email, otherwise click on the link below to reset your password.

				--------------------------------------------------------------------
				 
				Please click this link to reset your password:
				http://localhost/MMO_ACS2/Scripts/resetpassword.php?email='.$to.'&passhash='.$Passwordhash.'

				 
				'; // Our message above including the link
	                     
				$headers = "From:".SUPPORT_EMAIL_ADDRESS.""."\r\n"; // Set the email address that gonna send the email

				mail($to, $subject, $message, $headers); // Send our email

			    die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">We have successfully recived your request and sent you a link to reset your password. Please check your emails.</p></div>');


			} else 
			{
				die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">The email is no associated to any account or the account is not active.</p></div>');
			}
					
		} catch(PDOException $e)
		    {
		    // echo "Error: " . $e->getMessage();
		    die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">An error occurred, please retry.</p></div>');

		    }
			
		}

	
	

	  		
		?>.		
        <!-- stop PHP Code -->
 
         
    </div>
    <!-- end wrap div --> 
</body>
</html>