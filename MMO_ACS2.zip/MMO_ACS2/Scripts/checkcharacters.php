
<?PHP

/*
	// When this is enabled the code will generate no errors to the user even if there was one.
	// This is used to prevent sensitive data to be shown to a user who found an error. 
	// The following line should be uncommented only on releases. 
*/
error_reporting(0);



	require_once('functions.php');
	require_once('database.php');


   if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['username']))) 
        $POSTusername = input($_POST['username']);
    else 
        die("There was an error. Please retry.");



	try {

    // set the PDO error mode to exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // CHECK USERNAME

    $stmt = $db->prepare("SELECT id FROM ".TAB_ACCOUNTS." WHERE `user`=:fuser");
    
    $stmt->execute(array("fuser" => "$POSTusername"));

	$row = $stmt->fetch();

    $AccountID = $row['id'];    


	$stmt = $db->prepare("SELECT ID, Name, Gender, Level, Race, Class, Skin, HairType, HairColor, Strenght, Agility, Intellect, Spirit, Armour, CriticalChance, MeleeDamage, SpellDamage, HeadEquipped, ChestEquipped, HandsEquipped, LegsEquipped, FeetsEquipped, RHandEquipped FROM ".TAB_PLAYERS." WHERE AccountID=:faccountid ORDER BY ID ASC");
    
    $stmt->execute(array("faccountid" => "$AccountID"));

    $characters = $stmt->rowCount();

    if($characters > 0) {
        while($row = $stmt->fetch(PDO::FETCH_ASSOC))
        {        
            //PLEASE NOTE: Look how the sttring is formatted. An IMPORTANT thing to understand is the ";" that we put at the end of 
            //Return all the characthers datas.
			echo("ID:".$row['ID'].
				"|NAME:".$row['Name'].
				"|GENDER:".$row['Gender'].
				"|LEVEL:".$row['Level'].
				"|RACE:".$row['Race'].
				"|CLASS:".$row['Class'].
				"|SKIN:".$row['Skin'].
				"|HAIRTYPE:".$row['HairType'].
				"|HAIRCOLOR:".$row['HairColor'].
				"|STRENGHT:".$row['Strenght'].
				"|AGILITY:".$row['Agility'].
				"|INTELLECT:".$row['Intellect'].
				"|SPIRIT:".$row['Spirit'].
				"|ARMOUR:".$row['Armour'].
				"|CRITICALCHANCE:".$row['CriticalChance'].
				"|MELEEDAMAGE:".$row['MeleeDamage'].
				"|SPELLDAMAGE:".$row['SpellDamage'].
				"|HEADEQUIPPED:".$row['HeadEquipped'].
				"|CHESTEQUIPPED:".$row['ChestEquipped'].
				"|HANDSEQUIPPED:".$row['HandsEquipped'].
				"|LEGSEQUIPPED:".$row['LegsEquipped'].
				"|FEETSEQUIPPED:".$row['FeetsEquipped'].
				"|RHANDEQUIPPED:".$row['RHandEquipped'].
				 ";");
        }
        die();
    } else {
		die("NULL"); //This will return just 0, an int that we can parse into Unity.
    }

    }
    catch(PDOException $e)
    {
    	// echo "Error: " . $e->getMessage();
    	die("An error occurred, please retry. $e");
    }
	

?>