
<!DOCTYPE html>
 
<html>
<head>
    <title>MMO ACS 2 > Sign up</title>
    <link href="css/style.css" type="text/css" rel="stylesheet" />
</head>
<body style="background-image: url('MMOACS2_WebBg.png');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center top; ">    <!-- start header div --> 
    <div id="header">
    </div>
    <!-- end header div -->   



     
    <!-- start wrap div -->   
    <div id="wrap">

    <style>
    
    
@font-face {
font-family: "immortal";
src: url("IMMORTAL.ttf");
src:
url("IMMORTAL.ttf") format("ttf"),
}

.container {
  height: 200px;
  position: relative;
}

.center {
  margin: 0;
  position: absolute;
  top: 200%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-55%, -50%);
}

.section {
  height: 280px;
  width:  420px;
  position: relative;
  border: 2px solid #006187;
  background:#000000
}

.responseMessage {
	height: 200px;
  position: relative;
  margin: 0;
  position: absolute;
  top: 0%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-55%, +155%);
  height: 80px;
  width:  380px;
  position: relative;
  border: 2px solid black;
  background:#000000
}
</style>


<div class="container">
  <div class="center">
  	  <div class="section">

					<center>

<h1 style="font-family:immortal; color: white">VERIFY ACCOUNT</h1>


		
	</center>
		 </div> </div>
</div> 


        <!-- start PHP code -->
        <?PHP

		/*
			// When this is enabled the code will generate no errors to the user even if there was one.
			// This is used to prevent sensitive data to be shown to a user who found an error. 
			// The following line should be uncommented only on releases. 

			error_reporting(0);

		*/

		require_once('functions.php');
		require_once('database.php');


		if(!isset($_GET['email'], $_GET['hash']) || // Check if they exists
			empty(input($_GET['email'])) || empty(input($_GET['hash'])))   // Check if they contains something 	
    		die('<div class="responseMessage"><p style="color:yellow;">An error occurred, the link may be expired. Please request another and retry.</p></div>');

		
			if(filter_var(input($_GET['email']), FILTER_VALIDATE_EMAIL))
				$email = input($_GET['email']);
	 		else 
    		die('<div class="responseMessage"><p style="color:yellow;">An error occurred, the link may be expired. Please request another and retry.</p></div>');

			$hash = input($_GET['hash']);

			try {

			    // set the PDO error mode to exception
			    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    
			    // CHECKS AND TAKES OF VALUES

			    $stmt = $db->prepare("SELECT email, hash, active FROM ".TAB_ACCOUNTS." WHERE email=:femail AND hash=:fhash AND active='0'");
			    
			    $stmt->execute(array("femail" => "$email",
									 "fhash" => "$hash"));


	    	    $match = $stmt->rowCount();

		
				if($match > 0){

				// We have a match, activate the account
		    	$stmt = $db->prepare("UPDATE ".TAB_ACCOUNTS." SET active = '1' WHERE email = :femail AND hash = :fhash");

				$stmt->execute(array(
						    "femail" => "$email",
						    "fhash"  => "$hash"));
				

		    	die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">Your account has been activated, you can now login in game.</p></div>');

				}
				else
    		die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">An error occurred, the link may be expired. Please request another and retry.</p></div>');

			}
			catch(PDOException $e)
		    {
		    // echo "Error: " . $e->getMessage();
    		die('<div class="responseMessage"><p style="font-family:immortal; color:yellow;">An error occurred, the link may be expired. Please request another and retry.</p></div>');
		    }	

		?>.
        <!-- stop PHP Code -->
 
         
    </div>
    <!-- end wrap div --> 
</body>
</html>