<?PHP


/*
	// When this is enabled the code will generate no errors to the user even if there was one.
	// This is used to prevent sensitive data to be shown to a user who found an error. 
	// The following line should be uncommented only on releases. 

	error_reporting(0);

*/

require_once('functions.php');
require_once('database.php');


// Check if forms exists and if they're not null

	if(!isset($_POST['user'], $_POST['email'], $_POST['password']) || 										 // Check if they exists
		empty(input($_POST['user'])) || empty(input($_POST['email'])) || empty(input($_POST['password'])))   // Check if they contains something 	
			die("There was an error. Please retry."); 														 // Stop execution if something miss


// Check with regular expression the validation of the forms content
// Regular expressions must be defined by the Developer regarding their needs.


	if(preg_match("/^[A-Za-z0-9\.\_\-]{1,22}/", input($_POST['user']))) 
		$POSTusername = input($_POST['user']);
	else 
		die("There was an error. Please retry.");

	
	if(filter_var(input($_POST['email']), FILTER_VALIDATE_EMAIL))
		$POSTemail = input($_POST['email']);
	 else 
		die("Email is invalid.");
	

	if(preg_match("/^[A-Za-z0-9\.\_\-]{1,32}/", input($_POST['password']))) 
		$POSTpassword = input($_POST['password']);		
	 else 
		die("There was an error. Please retry.");
 

	// Prepared statement

	try {

    // set the PDO error mode to exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // CHECK USERNAME

    $stmt = $db->prepare("SELECT user FROM ".TAB_ACCOUNTS." WHERE `user`=:fuser");
    
    $stmt->execute(array("fuser" => "$POSTusername"));

    $Username_Count = $stmt->rowCount();

    // CHECK EMAIL

    $stmt = $db->prepare("SELECT email FROM ".TAB_ACCOUNTS." WHERE `email`=:femail");
    
    $stmt->execute(array("femail" => "$POSTemail"));

    $Email_Count = $stmt->rowCount();

	
	// Chek for errors

	if($Username_Count > 0 && $Email_Count > 0)
		die("Username and Email are already in use.");
	else 
		if($Username_Count > 0 && $Email_Count == 0)
			die("Username is already in use.");
	else
		if($Username_Count == 0 && $Email_Count > 0)
			die("Email is already in use.");
	else
		if($Username_Count == 0 && $Email_Count == 0) 
		{
			// Valid username and email!

			// Crypt the password
			$newPass = c_hash_password($POSTpassword);

			// Create Hash for activation
			$hash = md5( rand(0,1000) ); //set the hash for activation link

	    	$stmt = $db->prepare("INSERT INTO ".TAB_ACCOUNTS." (user, email, password, hash)
    								  VALUES(:fuser, :femail, :fpassword, :fhash)");

			$stmt->execute(array(
					    "fuser" => "$POSTusername",
					    "femail" => "$POSTemail",
	                    "fpassword" => "$newPass",
	                    "fhash" => "$hash"));

	    	
	    	$to      = $POSTemail; // Select the Recipient
			$subject = 'Welcome to MMO Accounts & Characters System 2! | Verify your email.'; // Give the email a subject 

			//Write the message
			$message = '
	
			This is an automatic email, please do not reply. 
			 
			Welcome to MMO-ACS2, '.$POSTusername.'!
			Your account has been created, you can login with the credentials that you have inserted in the registration after you have activated your account by pressing the url below.

			--------------------------------------------------------------------
			 
			Please click this link to activate your account:
			http://localhost/MMO_ACS2/Scripts/verify.php?email='.$POSTemail.'&hash='.$hash.' 
			 
			'; // Our message above include the link
			                     
			$headers = "From:".SUPPORT_EMAIL_ADDRESS.""."\r\n"; // Set the email address that gonna send the email

			mail($to, $subject, $message, $headers); // Function that send the email
			
			die ("Registration completed! Check your email for validate your account.");		//Return that everything worked, this string gonna appear in unity as Message.

			}	
		}
		catch(PDOException $e)
		    {
		    // echo "Error: " . $e->getMessage();
		    die("An error occurred, please retry.");

		    }	



?>
