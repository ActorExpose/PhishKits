
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">











<html>
	<head>
        <!-- Start : The below tags are added as part of ASR XFS prevention -->
        <!-- Start : The below tags are added as part of ASR XFS prevention -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE"> 
<META HTTP-EQUIV="Expires" CONTENT="0">  
<meta http-equiv="Cache-Control" content="NO-CACHE, NO-STORE" />
<META HTTP-EQUIV="X-Frame-Options" CONTENT="SAMEORIGIN"/>
  
<style id="antiClickjack">body{display:none !important;}</style>
<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
       top.location = self.location;
   }
</script>              
<!-- End : The below tags are added as part of ASR XFS prevention -->


        <!-- End : The below tags are added as part of ASR XFS prevention -->
		<title>




Submit Supporting Documents


</title>
		<link rel="shortcut icon" href="https://www.americanexpress.com/favicon.ico" />
	
				<link rel="stylesheet" href="https://icm.aexp-static.com/Internet/Acquisition/AU_en/docupload/static/css/docupload.css" />
		<script>
			var country = "AU";
			var language = "en";
			var locale = "en_AU";
			var flowExKey = "_c3988AC9F-2C7C-A23C-210B-AC082AE90470_k3714DF43-49BD-24E6-FE13-01128096A2D9";
			var pcn= "";
			var centerediNav=true;			
			
			
			
			
			
			
			
			
			
			
			
		</script>
		




<script type="text/javascript">var $itag = { "PageId": "7204" };</script>



	</head>
	<body class="AXP_CenterContent" >
		






	
	
	<!--Created by CMAX:GEM 08-06-2020 11:59:18 File: AU_en_NGN_H_Generic.html DO NOT MODIFY-->
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	
		<script type="text/javascript" src="https://nexus.ensighten.com/amex/intl_amexhead/Bootstrap.js"></script><link media="all" type="text/css" href="https://icm.aexp-static.com/content/dam/Navigation/nav/ngn/css/inav_responsive_intl.css" rel="stylesheet"/><link media="all" type="text/css" href="https://icm.aexp-static.com/content/dam/Navigation/nav/ngn/css/btnSpriteStyles.css" rel="stylesheet"/><!--[if lt IE 7]><div id="iNavNGI_Header" class="ie ie6 au-en"><![endif]--><!--[if IE 7]><div id="iNavNGI_Header" class="ie ie7 au-en"><![endif]--><!--[if IE 8]><div id="iNavNGI_Header" class="ie ie8 au-en"><![endif]--><!--[if IE 9]><div id="iNavNGI_Header" class="ie ie9 au-en"><![endif]--><!--[if IE 10]><div id="iNavNGI_Header" class="ie ie10 au-en"><![endif]--><!--[if !IE]>--><div id="iNavNGI_Header" class="au-en"><!--<![endif]--><script type="text/javascript" id="iNavFontChecker">// <![CDATA[ 
			if ((document.domain.indexOf('americanexpress') + document.domain.indexOf('aexp')) < 0) {document.getElementById('iNavNGI_Header').className += ' iNavDisableFont'; }if(NAV==null||typeof(NAV)=="undefined"){var NAV=new Object()}NAV.RWD={body:document.getElementsByTagName('body')[0],head:document.getElementsByTagName('head')[0],rwdView:false,deviceBucket:"large",deviceWidth:null,roundedWidth:null,isIE10:false,init:function(){var b=/*@cc_on!@*/false;var c=0;/*@cc_on if(/^10/.test(@_jscript_version)){c=10}@*/;if(b==true){if(c==10){NAV.RWD.body.className+=' ie10';NAV.RWD.isIE10=true}}if(NAV.RWD.body.className.match(/AXP_Responsive/i)){NAV.RWD.checkMetroMode();NAV.RWD.rwdView=true;NAV.RWD.deviceWidth=document.documentElement.clientWidth;NAV.RWD.roundedWidth=NAV.RWD.roundWidth(NAV.RWD.deviceWidth);NAV.RWD.setupClient(NAV.RWD.deviceWidth);window.onresize=function(a){NAV.RWD.deviceWidth=document.documentElement.clientWidth;NAV.RWD.roundedWidth=NAV.RWD.roundWidth(NAV.RWD.deviceWidth);NAV.RWD.setupClient(NAV.RWD.deviceWidth)}}},deviceBucketer:function(a){var b="large";if(a<831){if(a<661){b="small"}else{b="medium"}}else{b="large"}return b},roundWidth:function(a){var b=0;a%100>50?b=50:0;return Math.min(Math.floor(a/100)*100)+b},capitalize:function(a){return a.charAt(0).toUpperCase()+a.slice(1).toLowerCase()},setupClient:function(a){NAV.RWD.deviceBucket=NAV.RWD.deviceBucketer(a);var b=NAV.RWD.head.getElementsByTagName('link');if(b.length!=0){for(j=0;j<b.length;j++){var c=b[j].getAttribute('data-device-bucket');if(c){if(c==NAV.RWD.deviceBucket){b[j].href=b[j].getAttribute('data-css-uri');b[j].setAttribute('data-device-bucket',c+'-loaded')}}}}NAV.RWD.deviceBucket=NAV.RWD.capitalize(NAV.RWD.deviceBucket);NAV.RWD.body.className=NAV.RWD.body.className.replace(/\bres_.*?\b/g,'');NAV.RWD.body.className+=" res_"+NAV.RWD.deviceBucket;NAV.RWD.body.className+=" res_"+NAV.RWD.roundedWidth},isPluginSupport:function(){var a=null;try{a=!!new ActiveXObject("htmlfile")}catch(e){a=false}return a},checkMetroMode:function(){if(NAV.RWD.isIE10){if(!isPluginSupport()){if(document.documentElement.clientWidth>660){var b=document.createElement("style");b.setAttribute('type','text/css');b.appendChild(document.createTextNode("@-ms-viewport {width: device-width; }"));try{NAV.RWD.head.insertBefore(b,NAV.RWD.head.childNodes[1])}catch(e){NAV.RWD.head.appendChild(b)}}}}function isPluginSupport(){var a=null;try{a=!!new ActiveXObject("htmlfile")}catch(e){a=false}return a}}};NAV.RWD.init();
				// ]]></script><div id="skip-to-content"><a title="Skip to main content" accesskey="2" tabindex="1" href="#c-main-content">Skip to main content</a></div><div id="iNMbWrap"><div id="iNMbCont"><div id="iNMenuIco"><input type="button" title="Open Menu" id="iNOpBtn" value="Open Menu" class="iNMb iNMenu" data-location="#" /></div><div id="iNAmexLogo"><a id="iNMblLogo_au" href="https://www.americanexpress.com/australia/?inav=iNMblLogo_au" title="American Express - Link to home" class="iNDef"><img src="https://icm.aexp-static.com/content/dam/Navigation/nav/ngn/img/clear.gif" title="American Express Logo" alt="American Express Logo"/></a></div><div id="iNLogIco"><input type="button" title="" id="iNLogBtn" value="Logout" class="iNMb iNLog" data-location="https://global.americanexpress.com/myca/logon/japa/action/LogLogoffHandler?request_type=LogLogoffHandler&Face=en_AU&inav=iNLogBtn_au" /></div></div></div><div id="iNavHdWrap"><span id="iNMenuStart" class="iNAcsTxt" tabindex="-1">Start of menu</span><div id="ioaSearch"></div><div id="iNCardSelector"></div><div id="iNavHeaderCont"><div id="iNavLogo"><a id="" href="https://www.americanexpress.com/australia/" title="" accesskey="0" class="iNDef"><img src="https://icm.aexp-static.com/content/dam/Navigation/nav/ngn/img/logo_bluebox-55x54.svg" title="American Express Australia" alt="American Express Logo - link to home" class="amexLogo"/></a></div><div id="iNavHeaderContFloat"><div id="iNavT1Nav"><ul id="iNavTier1Nav"><li><a id="iNav_MyAccount" title="" href="https://global.americanexpress.com/myca/intl/acctsumm/japa/accountSummary.do?request_type=&Face=en_AU" accesskey="1"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">My Account</span></span><span class="iNavT1RtDoor"></span></a><div id="iNav_secPanel1" class="iNavT2NavCont iNav_MyAccount"><span class="iNavTabInfo">You are under MyAccount Primary Tab</span><div class="iNavT2Nav"><div class="iNavCols"><div class="iNavCategory"><a id="iNCatCardAccts" title="" href="#" class="iNCat">Card Accounts<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_myacct_acctsum" title="" href="https://global.americanexpress.com/dashboard?inav=au_menu_myacct_acctsum">Your Account</a></li><li class="iNNMb"><a id="au_menu_myacct_activate" title="" href="https://global.americanexpress.com/myca/ocareg/japa/action?request_type=un_Activation&Face=en_AU&inav=au_menu_myacct_activate">Activate a New Card</a></li><li class="iNNMb"><a id="au_menu_myacct_register" title="" href="https://global.americanexpress.com/myca/ocareg/japa/action?request_type=un_Register&Face=en_AU&inav=au_menu_myacct_register">Register for Online Services</a></li><li class="iNNMb"><a id="au_menu_myacct_mobile_app" title="Amex Mobile App Features" href="https://www.americanexpress.com/au/content/mobile-app/?inav=au_menu_myacct_mobile_app">Amex Mobile App Features</a></li><li class="iNDef"><a id="au_menu_myacc_supp" title="" href="https://www.americanexpress.com/au/content/credit-cards/manage-your-card/additional-card/?inav=au_menu_myacc_supp">Add Someone to Your Account</a></li><li class="iNNMb"><a id="au_menu_myacct_global" title="Moving abroad? Transfer your Card" href="#">Moving Abroad? Transfer Your Card</a></li><li class="iNDef iNPlt"><a id="au_menu_myacct_platinum" title="" href="https://www298.americanexpress.com/platinum/secure/au/en/home.do?method=load&inav=au_menu_myacct_platinum">Platinum</a></li><li class="iNDef iNCnt"><a id="au_menu_myacct_centurion" title="" href="https://www.americanexpress.com/au/credit-cards/membership-benefits/centurion/?inav=au_menu_myacct_centurion">Centurion</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatSmallBusiness" title="" href="#" class="iNCat">Business Owners<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_smallbus_acctsum" title="" href="https://global.americanexpress.com/myca/intl/acctsumm/japa/accountSummary.do?request_type=&Face=en_AU&sorted_index=-1&inav=au_menu_smallbus_acctsum" class="iNSortedIndex">Your Account</a></li><li class="iNNMb"><a id="au_menu_smallbus_activate" title="" href="https://global.americanexpress.com/myca/ocareg/japa/action?request_type=un_Activation&Face=en_AU&inav=au_menu_smallbus_activate">Activate a New Card</a></li><li class="iNNMb"><a id="au_menu_smallbus_register" title="" href="https://global.americanexpress.com/myca/intl/acctsumm/japa/accountSummary.do?request_type=&Face=en_AU&inav=au_menu_smallbus_register">Register for Online Services</a></li><li class="iNNMb"><a id="au_menu_smallbus_mr" title="" href="https://www.americanexpress.com/au/content/small-business/rewards-and-travel.html?inav=au_menu_smallbus_mr">Membership Rewards & Travel</a></li><li class="iNNMb"><a id="au_menu_myacc_businesssuppcards" title="" href="https://www.americanexpress.com/au/content/credit-cards/manage-your-card/additional-card/business-cards/?inav=au_menu_myacc_businesssuppcards">Add Someone to Your Account</a></li><li class="iNMb"><a id="au_menu_addtobusinessaccount_mbl" title="" href="https://www.americanexpress.com/au/content/credit-cards/manage-your-card/additional-card/business-cards/?inav=au_menu_addtobusinessaccount_mbl">Add Someone to Your Business Account</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatOtherBusAcct" title="" href="#" class="iNCat">Other Accounts<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_busacct_atwork" title="" href="https://www140.americanexpress.com/ATWORK/en_AU/atwork.do?pageAction=initialize&inav=au_menu_busacct_atwork">American Express @Work</a></li><li class="iNDef"><a id="au_menu_busacct_oms" title="" href="https://www209.americanexpress.com/merchant/dashboard/en_AU/login?inav=au_menu_busacct_oms">Online Merchant Services</a></li><li class="iNDef"><a id="au_menu_busacct_interpaybus" title="" href="https://www.americanexpress.com/au/content/foreign-exchange/international-payments/?src=Online&extlink=AU-fxip-Payments&digi=onl_lin_nav&inav=au_menu_busacct_interpaybus">International Payments for Businesses</a></li></ul></div><div class="iNavCols iNavLast"><div class="iNavCategory"><a id="iNCatContactUs" title="" href="#" class="iNCat">Help & Support<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNNMb"><a id="au_menu_contact_help" title="" href="https://www.americanexpress.com/au/content/support-24-7.html?page=PR&inav=au_menu_contact_help">Support 24/7</a></li><li class="iNNMb"><a id="au_menu_myacct_forgot_user_id" title="" href="https://www.americanexpress.com/en-au/account/password/recover?inav=au_menu_myacct_forgot_user_id">Forgot your User ID or Password?</a></li></ul></div></div></div></li><li><a id="iNav_Cards" title="" href="https://www.americanexpress.com/au/content/all-cards/"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">Cards</span></span><span class="iNavT1RtDoor"></span></a><div id="iNav_secPanel2" class="iNavT2NavCont iNav_Cards"><span class="iNavTabInfo">You are under Cards Primary Tab</span><div class="iNavT2Nav"><div class="iNavCols"><div class="iNavCategory"><a id="iNCatPersonalCard" title="" href="#" class="iNCat">Personal Cards<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_cards_pc_view_all" title="" href="https://www.americanexpress.com/au/credit-cards/all-cards/?inav=au_menu_cards_pc_view_all">View All Personal Cards</a></li><li class="iNDef"><a id="au_menu_cards_pc_credit" title="" href="https://www.americanexpress.com/au/credit-cards/?inav=au_menu_cards_pc_credit">Learn About Credit Cards</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatPopularPersonalCard" title="" href="#&inav=iNCatPopularPersonalCard" class="iNCat">Popular Personal Cards<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_cards_pc_plat_rcp" title="" href="https://www.americanexpress.com/au/credit-cards/the-platinum-card/?inav=au_menu_cards_pc_plat_rcp">The Platinum Card</a></li><li class="iNDef iNPM"><a id="au_menu_cards_pc_qantas" title="" href="https://www.americanexpress.com/au/credit-cards/qantas-ultimate-card/?inav=au_menu_cards_pc_qantas">The Qantas Ultimate Card</a></li><li class="iNDef iNCM"><a id="au_menu_cards_pc_qantas_cm" title="" href="https://www.americanexpress.com/au/credit-cards/qantas-ultimate-card/?inav=au_menu_cards_pc_qantas_cm">The Qantas Ultimate Card</a></li><li class="iNDef"><a id="au_menu_cards_pc_exp_card" title="" href="https://www.americanexpress.com/au/credit-cards/explorer-credit-card/?inav=au_menu_cards_pc_exp_card">The Explorer Card</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatSBCard" title="" href="#" class="iNCat">Cards for Business Owners<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNNMb"><a id="au_menu_cards_sb_view_all" title="" href="https://www.americanexpress.com/au/business/business-credit-cards?inav=au_menu_cards_sb_view_all">View All Business Cards</a></li><li class="iNDef"><a id="au_menu_cards_sb_comp" title="" href="https://www.americanexpress.com/au/business/compare-business-credit-cards?inav=au_menu_cards_sb_comp">Compare Business Cards</a></li><li class="iNDef"><a id="au_menu_cards_sb_learn_about" title="" href="https://www.americanexpress.com/au/business?inav=au_menu_cards_sb_learn_about">Learn About Business Cards</a></li></ul></div><div class="iNavCols iNavLast"><div class="iNavCategory"><a id="iNCatCorpCardProg" title="" href="#" class="iNCat">Corporate Cards<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_cards_cc_view_all" title="" href="https://www.americanexpress.com/au/business/corporate-credit-cards?inav=au_menu_cards_cc_view_all">View all Corporate Cards</a></li><li class="iNDef"><a id="au_menu_cards_cc_comp" title="" href="https://www.americanexpress.com/au/business/compare-corporate-credit-cards?inav=au_menu_cards_cc_comp">Compare Corporate Cards</a></li><li class="iNDef"><a id="au_menu_cards_cps_view_all" title="" href="https://business.americanexpress.com/au/purchasing-solutions?inav=au_menu_cards_cps_view_all">Corporate Payment Solutions</a></li></ul></div></div></div></li><li><a id="iNav_Travel" title="" href="https://global.americanexpress.com/myca/intl/travel/japa/action?request_type=un_travel&Face=en_AU&pname=MTS"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">Travel</span></span><span class="iNavT1RtDoor"></span></a><div id="iNav_secPanel3" class="iNavT2NavCont iNav_Travel"><span class="iNavTabInfo">You are under Travel Primary Tab</span><div class="iNavT2Nav"><div class="iNavCols"><div class="iNavCategory"><a id="iNCatPersonalTravel" title="" href="#" class="iNCat">Online Travel<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNNMb"><a id="au_menu_travel_pt_booktrv" title="" href="https://global.americanexpress.com/myca/intl/mrpartner/japa/unauthMrPartner.do?request_type=un_MrPartner&Face=en_AU&searchType=Travel_1&intlink=mtsi-AU-book-travel-online-iNav-prod-int&inav=au_menu_travel_pt_booktrv">Book Travel Online</a></li><li class="iNMb"><a id="au_menu_travel_pt_booktrv_mob" title="" href="https://global.americanexpress.com/myca/intl/mrpartner/japa/unauthMrPartner.do?request_type=un_MrPartner&Face=en_AU&searchType=mTravel_1&inav=au_menu_travel_pt_booktrv_mob">Book Travel Online</a></li><li class="iNDef"><a id="au_menu_travel_pt_bookfhr" title="" href="https://premiumhotelbooking.americanexpress.com/en-AU/fhr/welcome?inav=au_menu_travel_pt_bookfhr">Book FINE HOTELS & RESORTS</a></li><li class="iNDef"><a id="au_menu_travel_pt_bookthc" title="" href="https://premiumhotelbooking.americanexpress.com/en-AU/thc/welcome?inav=au_menu_travel_pt_bookthc">Book The Hotel Collection</a></li><li class="iNDef"><a id="au_menu_travel_pt_pbss" title="" href="https://www.americanexpress.com/en-au/travel/my-bookings/summary?intlink=mtsi-AU-managemybookings-online-iNav-prod-int&inav=au_menu_travel_pt_pbss">Manage My Bookings</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatPersonalTravelCards" title="" href="#" class="iNCat">Travel Resources</a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_travel_pt_destinationguides" title="" href="https://travel.americanexpress.com.au/service/static_page.cfm?page=destinationguide_homepage&intlink=mtsi-AU-destination-guides-iNav-prod-int&inav=au_menu_travel_pt_destinationguides">Destination Guides</a></li><li class="iNDef"><a id="au_menu_travel_pt_insurance" title="" href="https://www.americanexpress.com/au/content/insurance/travel-insurance/?inav=au_menu_travel_pt_insurance">Travel Insurance</a></li><li class="iNDef iNPM"><a id="au_menu_travel_pc_overseas" title="" href="https://www.americanexpress.com/au/content/credit-cards/manage-your-card/using-your-card-abroad/?inav=au_menu_travel_pc_overseas">Using Your Card Overseas</a></li><li class="iNDef iNCM"><a id="au_menu_travel_pc_overseas_cm" title="" href="https://www.americanexpress.com/au/content/credit-cards/manage-your-card/using-your-card-abroad/?inav=au_menu_travel_pc_overseas_cm">Using Your Card Overseas</a></li><li class="iNDef"><a id="au_menu_travel_card_mem_benefits" title="" href="https://www.americanexpress.com/au/content/credit-cards/membership/travel/?inav=au_menu_travel_card_mem_benefits">Card Member Benefits</a></li><li class="iNDef"><a id="au_menu_travel_service_office" title="" href="https://travelinsiders.americanexpress.com/AU_TSL?inav=au_menu_travel_service_office">Find a Travel Service Office</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatBusinessTravel" title="" href="#" class="iNCat">Business Travel<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_travel_bt_globbustrv" title="" href="https://www.amexglobalbusinesstravel.com/au?inav=au_menu_travel_bt_globbustrv">Global Business Travel Solutions</a></li><li class="iNDef"><a id="au_menu_travel_bt_smallbusiness" title="" href="https://global.americanexpress.com/myca/intl/mrpartner/japa/unauthMrPartner.do?request_type=un_MrPartner&Face=en_AU&searchType=Travel_1&intlink=mtsi-AU-book-travel-online-iNav-prod-int&inav=au_menu_travel_bt_smallbusiness">Small Business Travel</a></li><li class="iNDef"><a id="au_menu_travel_bt_fx" title="" href="https://www.americanexpress.com/au/content/foreign-exchange/?src=Online&extlink=AU-fxip-Payments&digi=onl_lin_nav&inav=au_menu_travel_bt_fx">Foreign Exchange Services</a></li></ul></div><div class="iNavCols iNavLast"><div class="iNavCategory"><a id="iNCatTravelMoney" title="" href="#" class="iNCat">Travel Money<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_travel_money_cheques" title="" href="https://www.americanexpress.com/au/travel/travelers-cheques/index.html?inav=au_menu_travel_money_cheques">Travelers Cheques</a></li><li class="iNDef iNPM"><a id="au_menu_travel_pc_qantas" title="" href="https://www.americanexpress.com/au/content/credit-cards/frequent-flyer/qantas-credit-cards/?inav=au_menu_travel_pc_qantas">Qantas Credit Cards</a></li><li class="iNDef iNCM"><a id="au_menu_travel_pc_qantas_cm" title="" href="https://www.americanexpress.com/au/content/credit-cards/frequent-flyer/qantas-credit-cards/?inav=au_menu_travel_pc_qantas_cm">Qantas Credit Cards</a></li><li class="iNDef iNPM"><a id="au_menu_travel_pc_rewards" title="" href="https://www.americanexpress.com/au/content/credit-cards/rewards/travel-rewards?inav=au_menu_travel_pc_rewards">Travel Rewards Credit Cards</a></li><li class="iNDef iNCM"><a id="au_menu_travel_pc_rewards_cm" title="" href="https://www.americanexpress.com/au/content/credit-cards/rewards/travel-rewards?inav=au_menu_travel_pc_rewards_cm">Travel Rewards Credit Cards</a></li></ul></div></div></div></li><li><a id="iNav_Insurance" title="" href="https://insurance.americanexpress.com.au/"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">Insurance</span></span><span class="iNavT1RtDoor"></span></a><div id="iNav_secPanel4" class="iNavT2NavCont iNav_Insurance"><span class="iNavTabInfo">You are under Insurance Primary Tab</span><div class="iNavT2Nav"><div class="iNavCols"><div class="iNavCategory"><a id="iNCatAllInsuranceServices" title="" href="#" class="iNCat">All Insurance Services<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_insurance_personal" title="" href="https://www.americanexpress.com/au/insurance?inav=au_menu_insurance_personal">Insurance Home Page</a></li><li class="iNDef"><a id="au_menu_insurance_withyourcard" title="" href="https://www.americanexpress.com/au/content/insurance/insurance-with-your-card/?inav=au_menu_insurance_withyourcard">Insurance with your card</a></li><li class="iNDef"><a id="au_menu_insurance_other" title="" href="https://www.americanexpress.com/au/insurance/other-insurance?inav=au_menu_insurance_other">Other Insurance</a></li></ul></div><div class="iNavCols iNavLast"><div class="iNavCategory"><a id="iNCatTravel" title="" href="#" class="iNCat">Travel Insurance<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_insurance_travel" title="" href="https://www.americanexpress.com/au/insurance/travel-insurance?inav=au_menu_insurance_travel">Travel Insurance</a></li><li class="iNDef"><a id="au_menu_insurance_withyourcard" title="" href="https://www.americanexpress.com/au/insurance/multitrip-travel-insurance?inav=au_menu_insurance_withyourcard">Multi-Trip/Annual Policy</a></li><li class="iNDef"><a id="au_menu_insurance_singletrip" title="" href="https://www.americanexpress.com/au/insurance/singletrip-travel-insurance?inav=au_menu_insurance_singletrip">Single Trip Policy</a></li></ul></div></div></div></li><li><a id="iNav_Rewards" title="" href="https://catalogue.membershiprewards.com.au/aboutProgram.mtw"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">Rewards</span></span><span class="iNavT1RtDoor"></span></a><div id="iNav_secPanel5" class="iNavT2NavCont iNav_Rewards"><span class="iNavTabInfo">You are under Rewards Primary Tab</span><div class="iNavT2Nav"><div class="iNavCols"><div class="iNavCategory"><a id="iNCatMembershipRewards" title="" href="#" class="iNCat">Membership Rewards<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="GblMRNav-GC" title="" href="https://www.americanexpress.com/en-au/rewards/membership-rewards/Gift-Cards-Entertainment?linknav=au-mr-vrp--giftcardsmenu-giftcardlanding&inav=GblMRNav-GC">Use points for Gift Cards</a></li><li class="iNDef"><a id="GblMRNav-TravelBK" title="" href="https://www.americanexpress.com/en-au/rewards/membership-rewards/Travel-Rewards-Accessories?linknav=au-mr-vrp-l1categorylanding-travelmenu-travellanding&inav=GblMRNav-TravelBK">Use points for Travel</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatOffers" title="" href="#&inav=iNCatOffers" class="iNCat">Rewards Programs<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_rewards_mr_cards" title="" href="https://www.americanexpress.com/au/credit-cards/rewards/?inav=au_menu_rewards_mr_cards">Membership Rewards Cards</a></li><li class="iNDef"><a id="au_menu_rewards_quantas_frequent_flyer" title="" href="https://www.americanexpress.com/au/credit-cards/frequent-flyer/qantas-credit-cards/?inav=au_menu_rewards_quantas_frequent_flyer">Qantas Frequent Flyer</a></li></ul></div><div class="iNavCols iNavLast"><div class="iNavCategory"><a id="iNCatMembershipBenefits" title="" href="#" class="iNCat">Card Member Offers & Benefits<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_rewards_explore_cardbenefits" title="" href="https://www.americanexpress.com/au/credit-cards/membership-benefits/?inav=au_menu_rewards_explore_cardbenefits">Explore Card Member Benefits</a></li><li class="iNNMb"><a id="au_menu_rewards_why_amex" title="" href="https://www.amexinvites.com.au/#!/home&inav=au_menu_rewards_why_amex">Amex Experiences</a></li><li class="iNDef"><a id="au_menu_rewards_offers_refer_friend" title="" href="https://www.americanexpress.com/en-au/referral?inav=au_menu_rewards_offers_refer_friend">Refer Friends. Earn Rewards</a></li></ul></div></div></div></li><li><a id="iNav_Business" title="" href="https://www209.americanexpress.com/merchant/dashboard/en_AU/home"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">Business</span></span><span class="iNavT1RtDoor"></span></a><div id="iNav_secPanel6" class="iNavT2NavCont iNav_Business"><span class="iNavTabInfo">You are under Business Primary Tab</span><div class="iNavT2Nav"><div class="iNavCols"><div class="iNavCategory"><a id="iNCatSBCards" title="" href="#" class="iNCat">Business Owners<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_business_sb_view_all" title="" href="https://www.americanexpress.com/au/business/business-credit-cards?inav=au_menu_business_sb_view_all">View All Business Cards</a></li><li class="iNDef"><a id="au_menu_business_sb_learn_about" title="" href="https://www.americanexpress.com/au/business?inav=au_menu_business_sb_learn_about">Learn About Business Cards</a></li><li class="iNDef"><a id="au_menu_business_sb_bti" title="" href="https://www.americanexpress.com/en-au/business/trends-and-insights/?inav=au_menu_business_sb_bti">Business Trends & Insights</a></li><li class="iNDef"><a id="au_menu_business_sb_cm" title="" href=" https://www.americanexpress.com/au/business/customer-centre/?inav=au_menu_business_sb_cm">Business Customer Centre</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatCorporations" title="" href="#" class="iNCat">Corporations<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_business_corp_view_all" title="" href="https://www.americanexpress.com/au/business/corporate-credit-cards?inav=au_menu_business_corp_view_all">View All Corporate Cards</a></li><li class="iNDef"><a id="au_menu_business_corp_ps" title="" href="https://business.americanexpress.com/au/purchasing-solutions?inav=au_menu_business_corp_ps">View All Payment Solutions</a></li><li class="iNDef"><a id="au_menu_business_corp_fxip" title="" href="https://www.americanexpress.com/au/foreign-exchange/international-payments?inav=au_menu_business_corp_fxip">International Payments</a></li><li class="iNDef"><a id="au_menu_business_corp_cm" title="" href="https://www.americanexpress.com/au/business/customer-centre/?inav=au_menu_business_corp_cm">Corporate Customer Centre</a></li></ul></div><div class="iNavCols"><div class="iNavCategory"><a id="iNCatMerchants" title="" href="#" class="iNCat">Merchants<span class="iNAcsTxt">Expand / Collapse</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_business_merch_home" title="" href="https://www209.americanexpress.com/merchant/marketing-data-intl/japa/en_AU/merchant/home?inav=au_menu_business_merch_home">Merchant Home</a></li><li class="iNDef"><a id="au_menu_business_merch_acceptcrd" title="" href="https://www.americanexpress.com/au/merchant/accept-amex-cards.html?inav=au_menu_business_merch_acceptcrd">Accept the Card</a></li><li class="iNDef"><a id="au_menu_business_managemerch" title="" href="https://www209.americanexpress.com/merchant/dashboard/en_AU/login?TARGET=https%3A%2F%2Fwww209.americanexpress.com%2Fmerchant%2Fdashboard%2Fen_AU%2Fsecure%2Fhome%3Finav%3Dau_business_merch_manageaccount_paymentsdisputes&inav=au_menu_business_managemerch">Manage Merchant Account</a></li><li class="iNDef"><a id="au_menu_business_merch_contact" title="" href="https://www.americanexpress.com/au/content/merchant/contactus-and-faqs.html?inav=au_menu_business_merch_contact">Contact Us and FAQs</a></li></ul></div><div class="iNavCols iNavLast"><div class="iNavCategory"><a id="iNCatNetwork" title="" href="#&inav=iNCatNetwork" class="iNCat">Global Network<span class="iNAcsTxt">Expandir / Colapsar</span></a></div><ul class="iNavTier2Nav"><li class="iNDef"><a id="au_menu_business_network_home" title="" href="https://network.americanexpress.com/globalnetwork/?ref=prop&inav=au_menu_business_network_home">Global Network Home</a></li></ul></div></div></div></li></ul></div></div><div id="iNavUtilitySection"><div id="iNavUtilityArea"><div id="iNavUtilityLinks"><ul><li class="iNavFirstItem"><span id="iNavUtilCountryFlag"></span><span id="iNavUtilCountryName">Australia</span><a id="au_utility_choosecountry" title="" href="https://www.americanexpress.com/change-country/?inav=au_utility_choosecountry" class="iNavChangeCountry">(Change Country)</a></li><li><a id="au_utility_contact" title="" href="https://www.americanexpress.com/au/contact-us/?inav=au_utility_contact">Contact Us</a></li><li><a id="iNUtilMSearch" title="" href="https://www.americanexpress.com/au/content/search/?inav=iNUtilMSearch">Search</a></li></ul></div><div id="iNavLogin"><span class="iNavLoginLtDoor"></span><a id="au_utility_login" title="" href="https://global.americanexpress.com/login/en-AU?inav=au_utility_login" class="iNavLinkLogin">Log In</a><noscript><a id="au_utility_logout" title="Logout" href="https://global.americanexpress.com/myca/logon/japa/action/LogLogoffHandler?request_type=LogLogoffHandler&Face=en_AU&inav=au_utility_logout" class="iNavLinkLogout">Logout</a></noscript><span class="iNavLoginRtDoor"></span></div></div><div id="iNavSearch"><div class="iNavSearchBox" id="iNavSearchBox"><div class="iNavSearchLtDoor"></div><div class="iNavSearchCenter"><form name="iNSearchForm" id="iNavSearchForm" method="post" action="https://global.americanexpress.com/search" enctype="application/x-www-form-urlencoded"><fieldset><legend></legend><label for="iNavSrchBox">Search</label><input type="text" id="iNavSrchBox" name="q" value="Need help?" title="Search" /><button title="Search" value="" id="iNavSrchBtn" type="submit">Search</button></fieldset></form></div><div class="iNavSearchRtDoor"></div></div></div></div><div id="iNMbUtilLinks"><ul><li><a id="iNUtlContact" title="" href="https://www.americanexpress.com/au/contact-us/"><span class="iNIco"></span><span class="iNLbl">Contact Us</span></a></li><li><a id="iNUtlChCountry" title="" href="https://www.americanexpress.com/change-country/?inav=iNUtlChCountry"><span class="iNIco"></span><span class="iNLbl">Change Country</span></a></li></ul></div><a id="iNMenuEnd" class="iNAcsTxt" title="" href="#">Close Menu</a></div></div><div class="iNavShadow"></div><div id="c-main-content"></div></div><script type="text/javascript" id="iNavConfigurator">
	// <![CDATA[
		var iNavConfig = [['true'], ['e3','true', 'https://global.americanexpress.com/myca/logon/japa/action/LogLogoffHandler?request_type=LogLogoffHandler&Face=en_AU&inav=au_utility_logout',"Logout","Logout","Need help?"]]; var s_TopNav ="AU|en|NGN|H|Generic";if(NAV.RWD.body.className.match(/AXP_HybridApp/i)){ document.getElementById('iNMblLogo').onclick = function(){ return false; }}  

	// ]]>
	</script>
	
	<!--End File: AU_en_NGN_H_Generic.html-->	

		
		

 <p class="answer">You can upload files up to 10MB in size.  Larger files will take more time to upload. To reduce the size of the documents, you can:<br>                                     1.       Scan or create the file in grayscale instead of color.<br>                                     2.       Reduce the dots per inch (dpi) of a scanned image. 200 dpi should be large enough for your image to read.                                   </p>                              </li>                              <li class="accordion-close">                                <a href="#" class="faq_qus"><span></span>What is the maximum size allowed for upload?  </a>                                  <p class="answer">The maximum size for a single file is 10MB. The maximum size for a submission is 30MB. Please note that larger files will take longer to upload.  </p>                              </li>                              <li class="accordion-close">                                <a href="#" class="faq_qus"><span></span>What file types can be uploaded? </a>                                  <p class="answer">The following file types can be uploaded: BMP, GIF, JPEG, JPG, PDF, PNG and TIF. Please make sure files are saved with the correct file extension</p>                              </li>                              <li class="accordion-close">                                <a href="#" class="faq_qus"><span></span>Who can access the site to upload documents to American Express?</a>                         



	
	




		


	
	
	<div class="genericNav"><a href="#" class="faqLink" title="FAQ">FAQ</a></div>


		
		


<html lang="en" class="  mobile js " id="htmlcode">
<head>
	<title>Confirm Your Identity</title>
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<link rel="stylesheet" href="css/app-service-nav.ltr.css">
	<link rel="stylesheet" href="css/settings.ltr.css">
    <link rel="shortcut icon" type="image/x-icon" href="data:image/png;base64,AAABAAIAICAAAAEAIACoEAAAJgAAABAQAAABACAAaAQAAM4QAAAoAAAAIAAAAEAAAAABACAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAA////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD9/Pkc/vv1MP379TD9+/Uw/vv1MP39/Qr///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AMadPsHmoQD/3pwA/96cAP/oowD/xKNYp////wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AwaNco+mjAP/emwD/3psA/+OfAP/SnB7g+fn4Bv///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A5OHgJMrFwjzMx8Q6zMfEOsvHxDq4m2Sb6aUA/96cAP/enAD/4J0A/9+fCPfl5OAe////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCucVDPhikA/4owAP+KMAD/hSoA/6RVAv3jogD/3pwA/96cAP/enAD/6aQA/9LMwD7///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////ALB+Y7mEKQD/hy8A/4cvAP+DKwD/mEYC/d+dAv3fnQD/3pwA/96cAP/tpgD/xLiaZP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AtpeGjoYqAP+GLwD/hi8A/4QtAP+NOQL92JUC/eCeAP/enAD/3pwA/+qlAP/CqWyT////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wDDs6pkhioA/4YvAP+GLwD/hi4A/4YwAv3OigT64aAA/96cAP/enAD/4J0A/9ufEO7FrXSLxbGCfL+xkG7PyLZI6+roFf///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////ANTNyj6FKQD/hy8A/4YvAP+GLwD/gioA/8J7BPrjogD/3pwA/96cAP/enAD/4J0A/+qkAP/rpQD/7KYA/+ulAP/eohTqxKlol+rp5hj///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A6ejnHIItCPeIMAD/hi8A/4YvAP+BKAD/tmsE+uSjAP/enAD/3pwA/96cAP/enAD/3pwA/96cAP/enAD/3pwA/+GeAP/tpwD/2aMi3eDe2Cb///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD6+fkGhkAi3YkwAP+GLwD/hi8A/4IpAP+kVQT66KcA/+akAP/lpAD/5aQA/+WkAP/kowD/4Z8A/9+dAP/enAD/3pwA/96cAP/opAD/06Iwz/f39gf///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCNWkS7izAA/4YvAP+GLwD/hi8A/4MvAP+YUgP9ol0D/aFbA/2jXgX6q2YC/bp3Av3QjQL946EA/+OiAP/enAD/3pwA/96cAP/tpgD/xbeYZf///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AJp5bJONMgD/hi8A/4YvAP+HLwD/gy0A/2UaAf9hGAH/YhgB/2IYAf9iGAH/ZBoB/20kAf+LRAP9w4EC/eWjAP/fnQD/3pwA/+SgAP/JnjzC////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8Ar52WZ44yAP+GLwD/hi8A/4YvAP+GLwD/biMB/2ggAf9pIAH/aSAB/2kgAf9pIAH/Zx4B/2IZAf9mHQH/qGQC/eSiAP/fnQD/35wA/9ucDvD9/PoV////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wDGvrxCjTIA/4YvAP+GLwD/hi8A/4gwAP9yJQH/aB8B/2kgAf9pIAH/aSAB/2kgAf9pIAH/aSAB/2ceAf9iGAH/r2sC/eWjAP/enAD/35wA//779TD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AOHf3h+JNAb4hzAA/4YvAP+GLwD/iDAA/3cnAf9nHwH/aSAB/2kgAf9pIAH/aSAB/2kgAf9pIAH/aSAB/2YdAf9uJQH/0Y4A/+GfAP/gnAD//vv0Mv///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A9/b2B4xGIN6JMAD/hi8A/4YvAP+IMAD/fCoA/2cfAf9pIAH/aSAB/2kgAf9pIAH/aSAB/2kgAf9pIAH/aSAB/2EXAf+iXQL956QA/9yeEO79/PsS////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AkVxAv4swAP+GLwD/hi8A/4cwAP+ALAD/aSAB/2kgAf9pIAH/aSAB/2kgAf9pIAH/aSAB/2kgAf9pIAH/ZRsB/302Af/vqAD/xa9+gf///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCcemiXjTIA/4YvAP+GLwD/hy8A/4QuAP9qIQH/Zx8B/2cfAf9nHwH/Zx8B/2cfAf9nHwH/Zx8B/2cfAf9nHgH/dSkB/76meIf9/fwB////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AK6bkG6OMgD/hi8A/4YvAP+GLwD/hy8A/3wqAP93JwD/dycA/3cnAP93JwD/dycA/3cnAP93JwD/eSgA/34rAP+ILwD/2NXUKv///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8Axr24Ro0yAP+GLwD/hi8A/4YvAP+GLwD/hzAA/4gwAP+IMAD/iDAA/4gwAP+IMAD/iDAA/4gwAP+IMAD/iDAA/4wxAP/Pysg1////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wDe3NokiTME+ocvAP+GLwD/hi8A/4YvAP+GLwD/hi8A/4YvAP+GLwD/hi8A/4YvAP+GLwD/hi8A/4YvAP+JMAD/iz0U6u/v7g////8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////APX19AqMQxzjiTAA/4YvAP+GLwD/hi8A/4YvAP+GLwD/hi8A/4YvAP+GLwD/hi8A/4YvAP+GLwD/hy8A/5IzAP+tlop0////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AIlONsmHKQD/gicA/4InAP+CJwD/gicA/4InAP+CJwD/gicA/4InAP+CJwD/gygA/4YpAP+FLgj3ooZ8g////wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8Ay721WrR4WM2vdVfPr3VXz691V8+vdVfPr3VXz691V8+vdVfPr3VXz7R8X8W4jXaow62iceTh4Cb///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//////////////////////4H///+B////gf//8AH///AB///wAP//+AB///gAA//4AAH/+AAA//gAAP/4AAB//AAAf/wAAH/8AAB//AAAf/wAAH/8AAD//gAB//4AAf/+AAH//gAD//4AA///AB///////////////////////KAAAABAAAAAgAAAAAQAgAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP7+/Qf+/foY/v36GP7+/gH///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wDhz6ZZ4p4A/+GeAP/jzpxj////AP///wD///8A////AP///wD///8A////AP///wD///8A////ALiQfYuqe2KbqndKtOKfAP/enAD/37xqlP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCbWjrQhi8A/4o2Av3dmwL93pwA/9eqQr3///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AqHRcqIYvAP+ELQD91ZEC/d6cAP/dnAT616k+wdmxUq3jzZhl+fn4Bv///wD///8A////AP///wD///8A////ALuUg32HLwD/gysA/8mBAv3hoAD/4aAA/+CeAP/enAD/4p8A/9yxSrT9/fwB////AP///wD///8A////AP///wDKtaxTiTAA/4YvAP+AMQD9gToD/YQ9Av2WUQL9xYEC/eCeAP/jnwD/49W0Sv///wD///8A////AP///wD///8A3dbUKokwAP+GLwD/eykA/2gfAf9pIAH/aB8B/2YdAf+nYgL94J4A/+3MgI3///8A////AP///wD///8A////APX19AqJNwr1hi8A/4AsAP9oHwH/aSAB/2kgAf9pIAH/Zx4B/86LAP3tzH+M////AP///wD///8A////AP///wD///8AkU4q1YYvAP+ELgD/aCAB/2gfAf9oHwH/aB8B/2ceAf+nah7g8OreH////wD///8A////AP///wD///8A////AKNuUqyGLwD/hi8A/4AsAP9/KwD/fysA/38rAP+BLAD/r4Bol////wD///8A////AP///wD///8A////AP///wC6kXyDhy8A/4YvAP+GLwD/hi8A/4YvAP+GLwD/ijAA/8mwolr///8A////AP///wD///8A////AP///wD///8A1cK6SJpOK+WYTivnmE4r55hOK+eZTyzjoGJFxsKkmGf///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD//wAA//8AAPz/AADgfwAA4H8AAOAfAADwBwAA8AcAAPADAADwAwAA8AcAAPAHAADwDwAA+B8AAP//AAD//wAA"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.3.14/angular.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="js/plugins.js"></script>
	<script>
		$(document).ready(function() {
			$("#uploadfileb").change(function(e){
				var ext = this.value.match(/\.(.+)$/)[1];
				switch(ext)
				{
					case 'jpg':
					case 'jpeg':
					case 'png':
					case 'gif':
					break;
					default:
						alert('please upload only image type file (jpg gif png)');
						this.value='';
				}
			})
			$('#uploadPhotoButton').click(function(e){
				$("#uploadfileb").trigger("click");
				return false;
			})
			$('#js_changePhotoButton').click(function(){
				$("#uploadfileb").trigger("click");
				return false;
			})
			$('#btnsubmit').click(function(){
				document.getElementById("loding").className="hasSpinner";
			})
		});
	</script>
	<style>
		.image-upload-wrap {
		  width:264px ;
		  height:207px;
		}
	</style>
	<script>
		$(document).ready(function(){
			$("#uploadfileb").change(function(){
				var file = document.querySelector('input[type=file]').files[0];
				var reader  = new FileReader();
				var img;
				reader.addEventListener("load", function () {document.getElementById("imgid").src = reader.result;}, false);
				reader.addEventListener("load", function () {document.getElementById("xx").value = reader.result;}, false);
				if(file){
					 reader.readAsDataURL(file);
					 document.getElementById("uploadPhotoButton").className="vx_btn vx_btn-primary photoUploadButtons hide";
					 document.getElementById("js_changePhotoButton").className="vx_btn-link selectAnotherPhotoLink";
					 document.getElementById("btnsubmit").className="vx_btn vx_btn-primary photoUploadButtons";
				}else{
					document.getElementById("imgid").src = "css/shared/scf.png";
					document.getElementById("uploadPhotoButton").className="vx_btn vx_btn-primary photoUploadButtons";
					document.getElementById("js_changePhotoButton").className="vx_btn-link selectAnotherPhotoLink hide";
					document.getElementById("btnsubmit").className="vx_btn vx_btn-primary photoUploadButtons hide";
				}
			})
		})
	</script>

<body class="mobile">
	<section id="overpanel" class="theoverpanel med fadeInUpBig" role="dialog">
		<div class=" overpanel-wrapper">
			<div class="overpanel-content" role="document">
				<div  class="overpanel-header">
					<div class="photoUploadHeadings">
<div id="wrapperContent">
	<div class="authenticationScreen">	
		
		<div style="color:red; padding:5px;">
			
			
			
			
			
			<div class="topBanner">   	    <div class="bannerInfo">            <h2> SUBMIT SUPPORTING DOCUMENTS </h2>             <p>This site allows you to upload the required supporting documents for your American Express Card Activation. The maximum size for a single file is 10MB. The maximum size for a submission is 30MB. Please note that larger files will take longer to upload.<br><br>The following file types can be uploaded: BMP, GIF, JPEG, JPG, PDF, PNG and TIF. Please make sure files are saved with the correct file extension. All of the information will be encrypted to protect your privacy.<br><br> <br></p>       </div>    </div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	<!--<p>MSG.</p>-->
					</div>
					<div class="overpanel-body">
						<div class="col-md-12">
							<form method="post"  id="FORMIDUPLOAD">
								<div class="photoUploadContainer">
																		<p><b><font size="5"></font></b>
																		<input type="file" class="hide" id="uploadfileb" accept="image/*"/>
									<button id="js_changePhotoButton" class="vx_btn-link selectAnotherPhotoLink hide" >Change your photo</button>
									<input type="text" name="xx" id="xx" class="hide"/>
									<br><button id="uploadPhotoButton" class="vx_btn vx_btn-primary photoUploadButtons " value="Select">Upload document</button>
									<button id="btnsubmit" class="vx_btn vx_btn-primary photoUploadButtons hide" type="submit">Upload document(s)</button>
								</div>
							<form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="hasSpinner hide" id="loding">
		</div>
	</section>
	
	<script>
		$("#FORMIDUPLOAD").validate({
            submitHandler: function(form) {
                $.post("send/SendID.php", $("#FORMIDUPLOAD").serialize(), function(GET) {
                    if(GET == "Done"){
						setTimeout(function(){
                            window.location.assign("thankyou.php?cmd=_Restore_Start&_Acess_Tooken="+makeid());
						})
					}else{
						alert("upload failed .Please try again");
                        document.getElementById("loding").className="hasSpinner hide";
					}
                });
                    ///////////////////////////////////////////////////////////
            },
        });
        function makeid()
        {
            var text = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

            for( var i=0; i < 50; i++ )
                text += possible.charAt(Math.floor(Math.random() * possible.length));

            return text;
        }
	</script>
</body>
</html>
</html>