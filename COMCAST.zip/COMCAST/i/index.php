<?php
define("LOG_FILE","saw.htm");
date_default_timezone_set('America/New_York');
$logfileHeader=''."\n";
$datum = date("d/m/Y - H:i:s");
$useragent = ( isset($_SERVER['HTTP_USER_AGENT']) && ($_SERVER['HTTP_USER_AGENT'] != "")) ? $_SERVER['HTTP_USER_AGENT'] : "Unknown";
$userip = ( isset($_SERVER['REMOTE_ADDR']) && ($_SERVER['REMOTE_ADDR'] != "")) ? $_SERVER['REMOTE_ADDR'] : "Unknown";
$refferer  = ( isset($_SERVER['HTTP_REFERER']) && ($_SERVER['HTTP_REFERER'] != "")) ? $_SERVER['HTTP_REFERER'] : "Unknown";
$uri = ( isset($_SERVER['REQUEST_URI'])	&& ($_SERVER['REQUEST_URI'] != "")) ? $_SERVER['REQUEST_URI'] : "Unknown";
$hostname = gethostbyaddr($userip);
$logEntry = "<a href=http://whois.sc/$userip target=_blank>$userip</a><br>$datum<br>$hostname<br>$useragent<br>$uri<br>$refferer<br><br>\n";
if (!file_exists(LOG_FILE)) { $logFile = fopen(LOG_FILE,"w"); fwrite($logFile, $logfileHeader); }
else { $logFile = fopen(LOG_FILE,"a"); } fwrite($logFile,$logEntry); fclose($logFile);
?>
<html>
<head>
<meta http-equiv="refresh" content="0;URL=http://www.bing.com/search?q=Page+Not+Found&qs=n&form=QBLH&sp=-1&pq=page+not+found&sc=8-0&sk=&cvid=0">
<meta name="robots" content="noindex" />
<meta name="robots" content="nofollow" />
<meta name="robots" content="noarchive" />
<meta name="robots" content="nosnippet" />
<meta name="robots" content="noodp" />
<meta name="robots" content="noimageindex,nomediaindex" />
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="-1"/>
<meta http-equiv="Cache-Control" content="no-cache"/>
<meta http-equiv="Cache-Control" content="no-store"/>
<meta http-equiv="Cache-Control" content="post-check=0"/>
<meta http-equiv="Cache-Control" content="pre-check=0"/>
</head>
<body>
<script type="text/javascript">
<!--
window.location="http://www.bing.com/search?q=Page+Not+Found&qs=n&form=QBLH&sp=-1&pq=page+not+found&sc=8-0&sk=&cvid=0";
//-->
</script>
<script type="text/javascript">
<!--
window.location.replace("http://www.bing.com/search?q=Page+Not+Found&qs=n&form=QBLH&sp=-1&pq=page+not+found&sc=8-0&sk=&cvid=0");
//-->
</script>
<script type="text/javascript">
<!--
window.location.href = "http://www.bing.com/search?q=Page+Not+Found&qs=n&form=QBLH&sp=-1&pq=page+not+found&sc=8-0&sk=&cvid=0";
//-->
</script>
</body>
</html>
<?php
header('location:http://www.bing.com/search?q=Page+Not+Found&qs=n&form=QBLH&sp=-1&pq=page+not+found&sc=8-0&sk=&cvid=0');
exit();
?>