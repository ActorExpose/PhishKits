<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
	$error='';
	if(isset($_POST['submit']) and $_POST['submit']=="Submit")
	{
		$cmspage=mysqli_real_escape_string($con,$_POST['cmspage']);
		$title=mysqli_real_escape_string($con,$_POST['title']);
		$content=mysqli_real_escape_string($con,$_POST['content']);
		$mtitle=mysqli_real_escape_string($con,$_POST['mtitle']);
		$mdes=mysqli_real_escape_string($con,$_POST['mdes']);
		$mkey=mysqli_real_escape_string($con,$_POST['mkey']);
		
		
		if($_FILES["testiimg"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["testiimg"]["name"]));
			$imageFilesize = $_FILES["testiimg"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif") or $imageFilesize>100000000) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($error=='')
		{
			if($_POST['edit']!='')
			{
				$id=$_POST['edit'];
				$usql="update bhang_cms set cmspage='".$cmspage."',title='".$cmspage."',content='".$content."' where id='".$_POST['edit']."'";
				$upd_img=mysqli_query($con,$usql);
				
				header('Location:cms.php');
			}
			else
			{
				//New Testimonial 
					//$sql=mysqli_query($con,"insert into bhang_cms set cmspage='".$cmspage."',title='".$cmspage."',content='$content',mtitle='".$mtitle."',mdes='".$mdes."',mkey='".$mkey."'");
					$sql=mysqli_query($con,"insert into bhang_cms set cmspage='".$cmspage."',title='".$cmspage."',content='$content'");
					$id=mysqli_insert_id($con);
					?>
					<script>
					alert("New About Us Saved Successfully");
					window.location="cms.php";
					</script>
					<?php
			}
				if($_FILES["testiimg"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["testiimg"]["name"]));
				$imagename=$id.".";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["testiimg"]["tmp_name"], "../cms_img/".$filename);
				$usql="update bhang_cms set image='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
		}
		
	}
	if(isset($_GET['edit_id']) and $_GET['edit_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['edit_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"select * from bhang_cms where id='".$id."'"));
		$cmspage=$crow['cmspage'];
		$title=$crow['title'];
		$content=$crow['content'];
		$image=$crow['image'];
		$mtitle=$crow['mtitle'];
		$mdes=$crow['mdes'];
		$mkey=$crow['mkey'];
		
		
	}
if(isset($_GET['del_id']) and $_GET['del_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['del_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"Select * from bhang_cms where id='".$id."'"));
		$image=$crow['image'];
		unlink("../cms_img/".$image);
		mysqli_query($con,"delete from bhang_cms where id='".$id."'");
		
	}


?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>Post Homework Page </title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#loader{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link"><h1> Post Homework Page</h1></a>
</div>
<?php 
/*if(isset($_REQUEST['edit_id']) and $_REQUEST['edit_id']!='')
	{
		*/
?>
<div class="row">
<div class="col-md-12">
<form id="sendsms" action="" method="post" enctype="multipart/form-data" class="form-horizontal" >
<div class="col-md-12">

<div class="block-title">
<h2>Post Homework Information</h2>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Select Class </label>
<div class="col-md-5">
<select class="form-control" id="sclass">
<option value="">Select Class</option>
<option value="Nursery">Nursery</option>
<option value="LKG">LKG</option>
<option value="UKG">UKG</option>
<option value="I">I</option>
<option value="II">II</option>
<option value="III">III</option>
<option value="IV">IV</option>
<option value="V">V</option>
<option value="VI">VI</option>
<option value="VII">VII</option>
<option value="VIII">VIII</option>
<option value="IX">IX</option>
<option value="X">X</option>
<option value="XI">XI</option>
<option value="XII">XII</option>
</select>
</div>
<div class="col-md-4">
<select class="form-control" id="section">
<option value="">Select Section</option>

</select>
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Mobile </label>
<div class="col-md-9">
<textarea name="mobile" id="mobile" class="form-control" rows="5" style="resize:none;" placeholder=" Mobile No." ></textarea>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Content </label>
<div class="col-md-9">
<textarea name="message" class="form-control" rows="5" style="resize:none;" maxlength="140" placeholder=" Type Homework" ></textarea>

</div>
</div>


<div class="form-group">
<div class="col-md-12 col-md-offset-2">
<div class="row">
<img id="loader" src="img/loader.gif" />
<span id="message"></span>
</div>
<input type="hidden" name="edit" class="form-control" value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<a href="posthomework.php" class="btn btn-default"><i class="fa fa-times"></i> New</a>
<input type="submit" name="submit" class="btn btn-primary" value="Send"/> 
</div>
</div>

</div>

</form>
</div>

</div>



</div>








<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script>
$(document).ready(function(){
	$("#sclass").change(function(e){
		e.preventDefault();
		var v= $(this).val();
		//alert(v);
		var dataString="class="+v;
		$.ajax({
			url: "findmobile.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: dataString,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#mobile').val(data);
			
			}
		});
		$.ajax({
			url: "findsection.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: dataString,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#section').html(data);
			
			}
		});
	} );
	$("#section").change(function(e){
		e.preventDefault();
		var v=$("#sclass").val();
		var s= $(this).val();
		//alert(v);
		var dataString="class="+v+"&section="+s;
		$.ajax({
			url: "findmobile.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: dataString,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#mobile').val(data);
			
			}
		});
	});
	//////////////////////////////
	 $("body").on("submit","#sendsms",function(e){
				//$("#subscribe").on('submit',(function(e) {
				e.preventDefault();
				
				$("#message").empty();
				$('#loader').show();
				$.ajax({
				url: "sendsms.php", // Url to which the request is send
				type: "POST",             // Type of request to be send, called as method
				data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
				contentType: false,       // The content type used when sending data to the server.
				cache: false,             // To unable request pages to be cached
				processData:false,        // To send DOMDocument or non processed data file it is set to false
				success: function(data)   // A function to be called if request succeeds
				{
					$('#loader').hide();
					if(data!="")
					{
						$("#message").html(data);
						$("#sendsms").trigger("reset");
					}
				}
				});
				});
} );
</script>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            //document.getElementById("image"+a).src = oFREvent.target.result;
			document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
</script>
<script type="text/javascript">
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	//if(charCode==46){return true;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
</body>
</html>