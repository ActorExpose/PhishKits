<?php
if($_SESSION['lmsadmin']!='Admin')
{
	header('Location:login.php');
}
?>
