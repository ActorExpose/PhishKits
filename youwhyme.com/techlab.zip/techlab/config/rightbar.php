<div id="sidebar-right">
<div class="sidebar-content">
<div class="user-info">
<div class="user-details"><a href="page_special_user_profile.php"><?php echo $_SESSION['uname'];?></a><br><em>Employee</em></div>
<?php
if(file_exists("empimg/".$_SESSION['image']))
	{
		echo '<img src="empimg/'.$_SESSION['image'].'" alt="Avatar" style="height:35px;width:35px;">
		
		';
	
	}
	else
	{
		echo '<img src="img/template/avatar.png" alt="Avatar">';
	}
	?>

</div>
<div class="sidebar-right-scroll">
<div class="sidebar-section">
<h2 class="sidebar-header">Color Themes</h2>
<ul class="theme-colors clearfix">
<li class="active">
<a href="javascript:void(0)" class="themed-background-default themed-border-default" data-theme="default" data-toggle="tooltip" title="Default"></a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-river themed-border-river" data-theme="css/themes/river-2.1.css" data-toggle="tooltip" title="River"></a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-amethyst themed-border-amethyst" data-theme="css/themes/amethyst-2.1.css" data-toggle="tooltip" title="Amethyst"></a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-dragon themed-border-dragon" data-theme="css/themes/dragon-2.1.css" data-toggle="tooltip" title="Dragon"></a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-emerald themed-border-emerald" data-theme="css/themes/emerald-2.1.css" data-toggle="tooltip" title="Emerald"></a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-grass themed-border-grass" data-theme="css/themes/grass-2.1.css" data-toggle="tooltip" title="Grass"></a>
</li>
</ul>
</div>
<ul class="sidebar-nav">
<li>
<h2 class="sidebar-header">Explore</h2>
</li>
<li>
<a href="page_special_timeline.php"><i class="fa fa-clock-o"></i> Updates</a>
</li>
<li>
<a href="page_special_user_profile.php"><i class="fa fa-pencil-square"></i> Profile</a>
</li>
<li>
<a href="page_special_message_center.php"><i class="fa fa-envelope-o"></i> Messages</a>
</li>
<li>
<a href="javascript:void(0)"><i class="fa fa-cog"></i> Settings</a>
</li>
<li>
<a href="page_special_login.php"><i class="fa fa-power-off"></i> Logout</a>
</li>
</ul>
<div class="sidebar-section">
<h2 class="sidebar-header">Notifications</h2>
<div class="alert alert-success alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<small><em>2 hours ago</em></small><br>
PHP version updated successfully on <a href="javascript:void(0)">Server #5</a>
</div>
<div class="alert alert-danger alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<small><em>3 hours ago</em></small><br>
<a href="javascript:void(0)">Game Server</a> crashed but restored!
</div>
<div class="alert alert-warning alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<small><em>5 hours ago</em></small><br>
<a href="javascript:void(0)">FTP Server</a> went down for maintenance!
</div>
</div>
<div class="sidebar-section">
<h2 class="sidebar-header">Messages</h2>
<div class="alert alert-info">
<small><a href="page_special_user_profile.php">Claire</a>, 2 minutes ago</small><br>
Hi John, I just wanted to let you know that.. <a href="page_special_message_center.php">more</a>
</div>
<div class="alert alert-info">
<small><a href="page_special_user_profile.php">Michael</a>, 5 minutes ago</small><br>
The project is moving along just fine and we.. <a href="page_special_message_center.php">more</a>
</div>
</div>
</div>
</div>
</div>