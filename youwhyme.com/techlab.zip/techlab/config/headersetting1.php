<header class="navbar navbar-default navbar-fixed-top">
<div class="col-md-12" style="background:#fff;">
<div class="" id="nav">

              <ul class="collapse navbar-collapse nav navbar-nav navbar-right uppercase" style="height:62px;padding:16px 0px; opacity:1!important;margin-right:2%;">
               
                <li><a href="./" style="border-right:1px dashed #fff;padding-top:5px;padding-bottom:5px;"> Techlab  </a></li>
				
              </ul>
		<ul class="nav header-nav pull-left">
			<li>
			<a href="javascript:void(0)" id="sidebar-left-toggle">
			<i class="fa fa-bars"></i>
			
			
			Hello! <!--<?php echo $_SESSION['ownername'];?> -->
			</a>
			</li>
			</ul>	
</div>

			
</div>

</header>