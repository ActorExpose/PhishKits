<?php
$host="localhost";
$username="exportuser";
$password="export)(*&^";
$dbname="techlab";
//$dbname="letsexpo_export";
//$con=mysql_connect($host,$username,$password) or die (mysql_error());
//mysql_select_db($dbname,$con) or die(mysql_error());
//$con=mysqli_connect($host,$username,$password,$dbname);
$con=mysqli_connect($host,"root",'',$dbname);

?>