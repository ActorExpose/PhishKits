<?php
if($_SESSION['ownerID']=='')
{
	header('Location:usr-login.php');
}
?>
