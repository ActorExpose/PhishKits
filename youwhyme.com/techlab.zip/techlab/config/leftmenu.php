<?php 
$sql=mysqli_fetch_array(mysqli_query($con,"select * from arshlogin where ownerID='".$_SESSION['ownerID']."'"));
$usertype=$sql['usertype'];
$_SESSION['usertype']=$usertype;
$_SESSION['uname']=$sql['onnerName'];
$valid=explode(",",$sql['authority']);
?>
<div id="sidebar-left" class="enable-hover">
<div class="sidebar-content">

<div class="sidebar-left-scroll">
<ul class="sidebar-nav">
<li>
<h2 class="sidebar-header">Welcome</h2>
</li>




<!--<li>
<a href="editprofile.php" ><i class="fa fa-user"></i>Edit Profile</a>
</li>
<li>
<a href="#" ><i class="fa fa-lock"></i>Message</a>
</li>-->


				
<li>
<a href="changepassword.php" ><i class="fa fa-lock"></i>Change Password</a>
</li>
<li>
<a href="logout.php" ><i class="fa fa-sign-out"></i>logout</a>
</li>

</ul>
</div>
</div>
</div>