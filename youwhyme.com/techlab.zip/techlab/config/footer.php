<footer class="clearfix">
<div class="pull-right">
Powered  <i class="fa fa-heart text-danger"></i> by <a href="" target="_blank"></a>
</div>
<div class="pull-left">
<span id=""></span>2020 &copy; <a href="" target="_blank"></a>
</div>
</footer>
<script src="js/jquery-1.11.0.min.js"></script>
<script>!window.jQuery && document.write(decodeURI('%3Cscript src="js/vendor/jquery-1.11.1.min.js"%3E%3C/script%3E'));</script>
<script src="js/vendor/bootstrap.min-2.1.js"></script>
<script src="js/plugins-2.1.js"></script>
<script src="js/main-2.1.js"></script>
<script>$(function(){webApp.datatables(),$("#example-datatable").dataTable({columnDefs:[{orderable:!1,targets:[2]}],pageLength:15,lengthMenu:[[15,30,50,100,-1],[15,30,50,100,"All"]]}),$(".dataTables_filter input").attr("placeholder","Search")});</script>
