<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
//include 'config/admin_login_check.php';
date_default_timezone_set("Asia/Kolkata");
if(isset($_SESSION['studioadmin']) and $_SESSION['studioadmin']!='')
{
	$nemail=$_SESSION['studioadmin'];
}
if(isset($_SESSION['ownername']) and $_SESSION['ownername']!='')
{
	$nemail=$_SESSION['ownername'];
}
if(isset($_POST['submit']) && $_POST['submit']=="Change Password")
{
    $email=mysqli_real_escape_string($con, $_POST['email']);
    $pwd=mysqli_real_escape_string($con, trim($_POST['oldpwd']));
    $npwd=mysqli_real_escape_string($con, trim($_POST['newpwd']));
    $cpwd=mysqli_real_escape_string($con, trim($_POST['cnfpwd']));
	
    if(isset($_SESSION['ownername']) and $_SESSION['ownername']!='')
	{
		$sql="SELECT * FROM ownerlogin WHERE onnerName='".$email."' AND onPassword='".$pwd."' AND admin_active='yes'";
		$search=mysqli_num_rows(mysqli_query($con,$sql));
		if($search>0)
		{
			if(preg_match('/[A-Za-z]+[0-9]+/', $npwd) and strlen($npwd)>5 and $npwd==$cpwd)
			{
				$ok=mysqli_query($con,"update ownerlogin set onPassword='".$npwd."' where onnerName='".$email."' AND admin_active='yes'");
				if($ok)
				{
					$error="Password Successfully Changed";
				}
				else
				{
					$error="Some Internal Error in Updation";
				}
			}
			else
			{
				$error="Error: Password must be 6 character long with 1 letter and 1 alphabet";
			}
		}
		else
		{
			$error="Invalid Credential";
		}
	}
	/*if(isset($_SESSION['studioadmin']) and $_SESSION['studioadmin']!='')
	{
		$sql="SELECT onnerName, onPassword FROM studiologin WHERE onnerName='".$email."' AND onPassword='".$pwd."' AND usertype='admin'";
		$search=mysqli_num_rows(mysqli_query($con,$sql));
		if($search>0)
		{
			if(preg_match('/[A-Za-z]+[0-9]+/', $npwd) and strlen($npwd)>5 and $npwd==$cpwd)
			{
				$ok=mysqli_query($con,"update arshlogin set onPassword='".$npwd."' where onnerName='".$email."' ");
				if($ok)
				{
					$error="Password Successfully Changed";
				}
				else
				{
					$error="Some Internal Error in Updation";
				}
			}
			else
			{
				$error="Error: Password must be 6 character long with 1 letter and 1 alphabet";
			}
		}
		else
		{
			$error="Invalid Credential";
		}
	}*/
	
}
?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>Change Password </title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">

<?php 

	include 'config/headersetting1.php';

?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>Change Password Page  </h1>
</a>
</div>

<form action="changepassword.php" method="post" enctype="multipart/form-data" class="form-horizontal">
<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="block-title">
<h2>Change Password Information</h2>
</div>
<div style="color:red;"><?php echo $error;?></div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">User </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="email" class="form-control" placeholder="Enter User Name" readonly="true" maxlength="50" value="<?php echo $nemail;?>">
</div>
</div>



<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Old Password  </label>
<div class="col-md-9">
<input type="password" id="example-text-input" name="oldpwd" class="form-control" placeholder="Your Old Password" maxlength="50">
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">New Password  </label>
<div class="col-md-9">
<input type="password" id="example-text-input" name="newpwd" class="form-control" placeholder=" New Password" maxlength="50">

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Confirm Password  </label>
<div class="col-md-9">
<input type="password" id="example-text-input" name="cnfpwd" class="form-control" placeholder=" Confirm Password" maxlength="50">

</div>
</div>

</div>
<!----------------next step ---------->



</div>
<div class="form-group">
<div class="col-md-12 col-md-offset-2">
<input type="hidden" name="edit" class="form-control"value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Change Password"/> 
</div>
</div>
</div>
</form>






</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>

</body>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	
	function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	if(charCode==46){return true;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
	}
</script>
</html>