<?php
session_start();
include 'config/configuration.php';
error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
$dop=Date('Y-m-d');

$otp=isset($_POST['otp'])?mysqli_real_escape_string($con,$_POST['otp']):'';
$mobile=$_SESSION['mobile'];


if($otp==$_SESSION['otp'])
{
  $row=mysqli_fetch_array(mysqli_query($con,"select * from arsh_new_usr where usr_mobile='".$mobile."' and mob_active='1' and admin_active='yes'"));
  $_SESSION['auditionname']=$row['usr_name'];
  $_SESSION['usermail']=$row['usr_email'];
  $_SESSION['otp']='';
  $_SESSION['mobile']='';
  echo "Success";
 
}
else
{
	echo "Your OTP code is invalid";
}
		
?>