<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$today=date("Y-m-d");

$url=explode("?",basename($_SERVER['REQUEST_URI']));
$url1= explode("=",urldecode(base64_decode($url[1])));
$id=mysqli_real_escape_string($con,$url1[1]);
$row=mysqli_fetch_array(mysqli_query($con,"select * from studio_candi as a, studio_candi_info as b where a.id='".$id."' and b.candiid='".$id."'"));
?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
<meta charset="utf-8">
<title>Profile</title>
<meta name="author" content="pixelcave">
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
</head>
<body class="header-fixed-top">

<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>
<div id="fx-container" class="fx-opacity"><div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>
<i class="gi gi-comments animation-expandUp"></i><?php echo $row['cname'];?><br><small><?php echo $row['city'].', '.$row['state'].', '.$row['country'];?></small>
</h1>
</a>
</div>
<ul class="breadcrumb breadcrumb-top">
<li><i class=" fa fa-file-o"></i></li>
<li>Pages</li>
<li><a href=""><?php echo $row['cname'];?></a></li>
</ul>
<div class="row gutter30">
<div class="col-md-6">
<div class="row gutter30">
<div class="col-sm-12 col-md-12">
<div class="block full">
<div class="block-title">
<h2><?php echo $row['cname'];?> Galleries</h2>
</div>
<?php 
$img=explode(",",$row['image']);
$l=sizeof($img);
?>
<div id="example-carousel" class="carousel slide">
<ol class="carousel-indicators">
<?php 
$i=0;
for($n=0;$n<$l;$n++)
{
	if($n==0)
	{
		echo '<li data-target="#example-carousel" data-slide-to="'.$n.'" class="active"></li>';
	}
	else
	{
		echo '<li data-target="#example-carousel" data-slide-to="'.$n.'" ></li>';
	}
}
?>
<!----<li data-target="#example-carousel" data-slide-to="0" class="active"></li>
<li data-target="#example-carousel" data-slide-to="1"></li>
<li data-target="#example-carousel" data-slide-to="2"></li>
<li data-target="#example-carousel" data-slide-to="3"></li>
<li data-target="#example-carousel" data-slide-to="4"></li>
<li data-target="#example-carousel" data-slide-to="5"></li>---->
</ol>
<div class="carousel-inner">
<?php 
for($n=0;$n<$l;$n++)
{
	if($n==0)
	{
		echo '<div class="active item">
			<img src="../candidateimg/'.$img[$n].'" alt="'.$row['cname'].'" style="height:400px;width:100%;">
			</div>';
	}
	else
	{
		echo '<div class="item">
			<img src="../candidateimg/'.$img[$n].'" alt="'.$row['cname'].'" style="height:400px;width:100%;">
			</div>';
	}
}
?>
<!---
<div class="active item">
<img src="img/placeholders/image_1680x1050_dark.png" alt="fakeimg">

</div>
<div class="item">
<img src="img/placeholders/image_1680x1050_light.png" alt="fakeimg">

</div>
<div class="item">
<img src="img/placeholders/image_1680x1050_dark.png" alt="fakeimg">

</div>
<div class="item">
<img src="img/placeholders/image_1680x1050_light.png" alt="fakeimg">

</div>
<div class="item">
<img src="img/placeholders/image_1680x1050_dark.png" alt="fakeimg">

</div>
<div class="item">
<img src="img/placeholders/image_1680x1050_light.png" alt="fakeimg">

</div>-->
</div>
<a class="left carousel-control" href="#example-carousel" data-slide="prev">
<span><i class="fa fa-chevron-left"></i></span>
</a>
<a class="right carousel-control" href="#example-carousel" data-slide="next">
<span><i class="fa fa-chevron-right"></i></span>
</a>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-6">
<ul class="nav nav-tabs push" data-toggle="tabs">
<li class="active"><a href="#forum-cats">Profile</a></li>
<li><a href="#forum-topics">Audio</a></li>
<li><a href="#forum-discussion">Video</a></li>
</ul>
<div class="tab-content">
<div class="tab-pane active" id="forum-cats">

<div class="ms-message-list list-group">
<a href="javascript:void(0)" class="list-group-item">
<h4 class="list-group-item-heading" style="font-weight:bold;margin-bottom:10px;">Age</h4>
<p class="list-group-item-text"><?php echo date_diff(date_create($row['dob']), date_create($today))->y; ?> Years.</p>

</a>
<a href="javascript:void(0)" class="list-group-item">
<h4 class="list-group-item-heading" style="font-weight:bold;margin-bottom:10px;">Height</h4>
<p class="list-group-item-text"><?php echo $row['height'];?></p>

</a>
<a href="javascript:void(0)" class="list-group-item">
<h4 class="list-group-item-heading" style="font-weight:bold;margin-bottom:10px;">Attributes</h4>
<p class="list-group-item-text"><?php echo $row['gender'].' (Gender), '.$row['eyecolor'].', '.$row['facecolor'].', '.$row['haircolor'];?></p>

</a>

<a href="javascript:void(0)" class="list-group-item">
<h4 class="list-group-item-heading" style="font-weight:bold;margin-bottom:10px;">Category</h4>
<p class="list-group-item-text"><?php echo $row['category'];?></p>

</a>

<a href="javascript:void(0)" class="list-group-item">
<h4 class="list-group-item-heading" style="font-weight:bold;margin-bottom:10px;">About</h4>
<p class="list-group-item-text"><?php echo $row['description'];?></p>

</a>



</div>

<!--<source src="../candidateaudio/intro1	.ogg" type="audio/ogg">-->
</div>
<div class="tab-pane" id="forum-topics">

<?php 
/*$vurl=explode(",",$row['vurl']);
$vl=sizeof($vurl);
for($i=0;$i<$vl;$i++)
{
	echo '<iframe src="'.$vurl[$i].'" frameborder="0" height="400" width="550"></iframe>';
}*/
$vurl=explode(",",$row['caudio']);
$vl=sizeof($vurl);
for($i=0;$i<$vl;$i++)
{
	echo '
	<audio autoplay controls>
	<source src="../candidateaudio/'.$vurl[$i].'" type="audio/mp3">
	</audio>'
	
	;
}


?>
  
  

</div>
<div class="tab-pane" id="forum-discussion">
<?php 
/*$vurl=explode(",",$row['vurl']);
$vl=sizeof($vurl);
for($i=0;$i<$vl;$i++)
{
	echo '<iframe src="'.$vurl[$i].'" frameborder="0" height="400" width="550"></iframe>';
}*/
$vurl=explode(",",$row['cvideo']);
$vl=sizeof($vurl);
for($i=0;$i<$vl;$i++)
{
	echo '
	
	<video width="320" height="240" controls>
  <source src="../cvideofile/'.$vurl[$i].'" type="video/mp4">
  
Your browser does not support the video tag.
</video>'
	
	;
}


?>


</div>
</div>
</div>
</div>
</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>

</body>
</html>