<?php
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$mb='';
$class=isset($_POST['class'])?mysqli_real_escape_string($con,$_POST['class']):'';
$section=isset($_POST['section'])?mysqli_real_escape_string($con,$_POST['section']):'';
if($section!='')
{
	$query=mysqli_query($con,"select * from student where sclass='".$class."' and section='".$section."'");
}
else
{
	$query=mysqli_query($con,"select * from student where sclass='".$class."'");
}

while($row=mysqli_fetch_array($query) )
{
	$mb.=$row['contact'].",";
}
$mb=rtrim($mb,",");
echo $mb;
?>