<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/admin_login_check.php';
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
	$error='';
	if(isset($_POST['submit']) and $_POST['submit']=="Submit")
	{
		$title=mysqli_real_escape_string($con,$_POST['title']);
		$blink=mysqli_real_escape_string($con,$_POST['blink']);
		$active=isset($_POST['active'])?mysqli_real_escape_string($con,$_POST['active']):'no';
		
		if($_FILES["regimg"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["regimg"]["name"]));
			$imageFilesize = $_FILES["regimg"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif") or $imageFilesize>100000000) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($error=='')
		{
			if($_POST['edit']!='')
			{
				$id=$_POST['edit'];
				$usql="update studio_regi set title='".$title."',blink='".$blink."', active='$active' where id='".$_POST['edit']."'";
				$upd_img=mysqli_query($con,$usql);
				?>
				<script>
				alert("Register For Updated Successfully");
				</script>
				<?php
				header('Location:regi.php');
			}
			else
			{
				//New Register For 
					$sql=mysqli_query($con,"insert into studio_regi set title='".$title."',blink='".$blink."', active='$active'");
					$id=mysqli_insert_id($con);
					?>
					<script>
					alert("New Register For Saved Successfully");
					window.location="regi.php";
					</script>
					<?php
			}
				if($_FILES["regimg"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["regimg"]["name"]));
				$imagename=$id.".";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["regimg"]["tmp_name"], "../regimg/".$filename);
				$usql="update studio_regi set title='".$title."',blink='".$blink."', image='$filename', active='$active' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
		}
		
	}
	if(isset($_GET['edit_id']) and $_GET['edit_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['edit_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"select * from studio_regi where id='".$id."'"));
		$title=$crow['title'];
		$blink=$crow['blink'];
		$image=$crow['image'];
		$active=$crow['active'];
		
		
		
	}
if(isset($_GET['del_id']) and $_GET['del_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['del_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"Select * from studio_regi where id='".$id."'"));
		$image=$crow['image'];
		unlink("../regimg/".$image);
		mysqli_query($con,"delete from studio_regi where id='".$id."'");
		
	}

?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Register For </title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>
<i class="fa fa-camera-retro animation-expandUp"></i>Register For<br><small>Main Page Register For Editable Form</small>
</h1>
</a>
</div>
<ul class="breadcrumb breadcrumb-top">
<li><i class="fa fa-cog"></i></li>
<li><a href="regi.php">Register For</a></li>
</ul>

<div class="block full">
<div class="block-title">
<h2><i class="fa fa-cloud-upload"></i> Register For Image Upload </h2>
</div>
<form action="regi.php" method="post" enctype="multipart/form-data" class="form-horizontal">

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Register For Title</label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="title" class="form-control" placeholder="Title" maxlength="100" value="<?php echo $title;?>">

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Link</label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="blink" class="form-control" placeholder="Link" maxlength="250" value="<?php echo $blink;?>">

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Register For Image</label>
<div class="col-md-4">
<input type="file" name="regimg" id="uploadinput1" onchange="uploadimg(1);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image!='' and file_exists("../regimg/".$image))
{
	echo '<img src="../regimg/'.$image.'" style="height:100px;width:200px;" id="upload1"/>';
}
else
{
	echo '<img src="../img/noimage.png" style="height:100px;width:200px;" id="upload1"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Active on Home</label>
<div class="col-md-9">
<input type="checkbox" value="yes" name="active" <?php if($active=='yes'){echo 'checked';}?> /> Check For Active
<span class="help-block"></span>
</div>
</div>
<div class="form-group">
<div class="col-md-12 col-md-offset-5">
<input type="hidden" name="edit" class="form-control"value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>
</form>
</div>


<div class="row gutter30">
<div class="col-md-12">
<div class="block">
<div class="block-title">
<h2><i class="fa fa-camera-retro"></i> All Register For Editable </h2>
</div>
<div class="gallery" data-toggle="lightbox-gallery">
<div class="row">
<?php 
$slidesql=mysqli_query($con,"select * from studio_regi");
while($sliderow=mysqli_fetch_array($slidesql))
{
	if($sliderow['image']!='' and file_exists("../regimg/".$sliderow['image']))
	{
		echo '
		<div class="col-sm-3 gallery-image">
		<img src="../regimg/'.$sliderow['image'].'" title="'.$sliderow['title'].'" height="200">
		<div class="gallery-image-options text-center">
		<div class="btn-group btn-group-sm">
		<a href="../regimg/'.$sliderow['image'].'" class="gallery-link btn btn-primary" title="'.$sliderow['title'].'">View</a>
		<a href="regi.php?edit_id='.$sliderow['id'].'" class="btn btn-primary" data-toggle="tooltip" title="Edit"><i class="fa fa-pencil"></i></a>';
		?>
		<a href="regi.php?del_id=<?php echo $sliderow['id'];?>" class="btn btn-primary" data-toggle="tooltip" title="Remove" onclick="return confirm('Are You want To Remove this Slide');"><i class="fa fa-times"></i> </a>
		<?php     echo '</div>
		</div>
		</div>
		
		';
	}
}
?>


<!--
<div class="col-sm-4 gallery-image">
<img src="img/placeholders/image_720x450_light.png" alt="image">
<div class="gallery-image-options text-center">
<div class="btn-group btn-group-sm">
<a href="img/placeholders/image_720x450_light.png" class="gallery-link btn btn-primary" title="Image Info">View</a>
<a href="javascript:void(0)" class="btn btn-primary" data-toggle="tooltip" title="Edit"><i class="fa fa-pencil"></i></a>
<a href="javascript:void(0)" class="btn btn-primary" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></a>
</div>
</div>
</div>
-->



</div>
</div>
</div>
</div>
</div>

</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	</script>
</body>
</html>