<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
	if(isset($_POST['submit']) and $_POST['submit']=="Submit")
	{
		$cname=mysqli_real_escape_string($con,$_POST['cname']);
		$email=mysqli_real_escape_string($con,$_POST['email']);
		$mobile=mysqli_real_escape_string($con,$_POST['mobile']);
		$gender=mysqli_real_escape_string($con,$_POST['gender']);
		$street=mysqli_real_escape_string($con,$_POST['street']);
		$city=mysqli_real_escape_string($con,$_POST['city']);
		$state=mysqli_real_escape_string($con,$_POST['state']);
		$zip=mysqli_real_escape_string($con,$_POST['zip']);
		$country=mysqli_real_escape_string($con,$_POST['country']);
		
		$csql=mysqli_query($con,"select * from bhang_usr_profile where email='".$email."'");
		$cnum=mysqli_num_rows($csql);
		if($cnum<1)
		{
			mysqli_query($con,"insert into bhang_usr_profile set cname='".$cname."',mobile='".$mobile."',email='".$email."',gender='".$gender."',street='".$street."',city='".$city."',state='".$state."',zip='".$zip."',country='".$country."'");
			$id=mysqli_insert_id($con);
			
			if($_FILES["image"]["name"]!='')
			{
				$imageFileType = end(explode(".", $_FILES["image"]["name"]));
				$imageFilesize = $_FILES["image"]["size"];
				if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif") or $imageFilesize>10000000) {
					echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
					$error = "Error: Image Type or Size Not Supported";
				}
				else
				{
					$extension = end(explode(".", $_FILES["image"]["name"]));
					$imagename=$id.".";
					$filename=$imagename.$extension;
					move_uploaded_file($_FILES["image"]["tmp_name"], "userimg/".$filename);
					$usql="update bhang_usr_profile set image='$filename' where id='".$id."'";
					$upd_img=mysqli_query($con,$usql);
				}
			}
			$error="Profile Successfully Updated";
		}
		else
		{
			$cidrow=mysqli_fetch_array($csql);
			$id=$cidrow['id'];
			
			mysqli_query($con,"update bhang_usr_profile set cname='".$cname."',mobile='".$mobile."',email='".$email."',gender='".$gender."',street='".$street."',city='".$city."',state='".$state."',zip='".$zip."',country='".$country."' where id='".$id."'");
			
			if($_FILES["image"]["name"]!='')
			{
				$imageFileType = end(explode(".", $_FILES["image"]["name"]));
				$imageFilesize = $_FILES["image"]["size"];
				if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif") or $imageFilesize>10000000) {
					echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
					$error = "Error: Image Type or Size Not Supported";
				}
				else
				{
					$extension = end(explode(".", $_FILES["image"]["name"]));
					$imagename=$id.".";
					$filename=$imagename.$extension;
					move_uploaded_file($_FILES["image"]["tmp_name"], "userimg/".$filename);
					$usql="update bhang_usr_profile set image='$filename' where id='".$id."'";
					$upd_img=mysqli_query($con,$usql);
				}
			}
			$error="Profile Successfully Updated";
		}
	
	}
	
		
		$crow=mysqli_fetch_array(mysqli_query($con,"Select * from bhang_new_usr where usr_email='".$_SESSION['usermail']."'"));
		$cname=$crow['usr_name'];
		$mobile=$crow['usr_mobile'];
		$email=$crow['usr_email'];
		$crow=mysqli_fetch_array(mysqli_query($con,"Select * from bhang_usr_profile where email='".$_SESSION['usermail']."'"));
		$gender=$crow['gender'];
		$street=$crow['street'];
		$city=$crow['city'];
		$state=$crow['state'];
		$zip=$crow['zip'];
		$country=$crow['country'];
		$image=$crow['image'];
		
	


?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>Edit Profile </title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#candidateform,#studioform,#modelling{display:block;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php //include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>
<i class="fa fa-anchor animation-expandUp"></i>Update Profile </h1>
</a>
</div>

<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" id="studioform">
<div class="row">
<div class="col-md-12" style="margin-top:30px;margin-bottom:40px;">
<div class="col-md-6">
<div class="block-title">
<h2> Personal Information</h2>
</div>

<div class="form-group"><div style="color:red;"><?php echo $error;?></div>
<label class="col-md-3 control-label" for="example-text-input">Name </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="cname" class="form-control" placeholder="Enter Name" maxlength="50" value="<?php echo $_SESSION['auditionname'];?>" readonly>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Contact No.  </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="mobile" value="<?php echo $mobile;?>" class="form-control" placeholder="Your Mobile No." readonly>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Email </label>
<div class="col-md-9">
<input type="email" id="example-text-input" name="email" class="form-control" value="<?php echo $_SESSION['usermail'];?>" placeholder="Enter Email" readonly maxlength="50">

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Gender </label>
<div class="col-md-9">
<select name="gender" class="form-control" >
<option value="">--Select--</option>
<?php 
if($gender!='')
{
	echo '<option value="'.$gender.'" selected>'.$gender.'</option>';
}
?>
<option value="Male">Male</option>
<option value="Female">Female</option>

</select>
</div>
</div>




</div>
<!----------------next step ---------->
<div class="col-md-6">
<div class="block-title">
<h2>Locality Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Street Name.</label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="street" value="<?php echo $street;?>" class="form-control" placeholder="Your Street Name" maxlength="100">

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">City.  </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="city" value="<?php echo $city;?>" class="form-control" placeholder="Your City." maxlength="50">

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">State  </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="state" value="<?php echo $state;?>"  class="form-control" placeholder="Your State." maxlength="50">

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Zip Code </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="zip" value="<?php echo $zip;?>"  class="form-control" placeholder="Your Zip." maxlength="50">

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Country </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="country" value="<?php echo $country;?>"  class="form-control" placeholder="Your Country." maxlength="50">

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-file-input"> Photo</label>
<div class="col-md-9">
<input type="file" id="uploadinput6" onchange="uploadimg(6);" name="image" style="width:60%;display:inline;">
<?php 
if($image!='' and file_exists('userimg/'.$image))
{
	echo '<img src="userimg/'.$image.'" id="upload6" style="height:100px;width:100px;display:inline;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload6" style="height:100px;width:100px;display:inline;" />';
}
?>

<span class="help-block">Image less than 100KB (.jpg,.png,.gif) Only </span>
</div>
</div>

</div>


<div class="form-group" style="margin-top:30px;">
<div class="col-md-12 col-md-offset-5">

<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>

</div>


</div>
</form>







</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>

</body>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	
	function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	if(charCode==46){return true;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
	}
</script>
<script>
$(document).ready(function(){
	$("#cand").click(function(e){
		//e.preventDefault();
		$("#candidateform").show("slow");
		$("#studioform").hide();
	} );
	$("#studio").click(function(e){
		//e.preventDefault();
		$("#candidateform").hide();
		$("#studioform").show("slow");
	} );
	$(".cato").change(function(){
		var c=$(this).val();
		if(c=="Modelling")
		{
			$("#modelling").show("slow");
		}
		else
		{
			$("#modelling").hide();
		}
	} );
});
</script>
</html>