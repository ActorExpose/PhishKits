<?php 
	//error_reporting(0);
	session_start();
	$_SESSION['auditionname']='';
	session_destroy();
	header('Location:./');
?>

	
	 