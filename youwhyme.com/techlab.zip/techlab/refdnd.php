<?php
error_reporting(0);
session_start();
include 'config/configuration.php';
include'config/login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$date=date("Y-m-d");

	  $ref=isset($_REQUEST['reference'])?mysqli_real_escape_string($con,$_REQUEST['reference']):'';
		//$fromdate = isset($_REQUEST['fromdate'])?mysqli_real_escape_string($con,$_REQUEST['fromdate']):'';
		//$todate = isset($_REQUEST['todate'])?mysqli_real_escape_string($con,$_REQUEST['todate']):'';
		
		
		
		$fromdate=Date('Y-m-d',strtotime($fromdate));
		$todate=Date('Y-m-d',strtotime($todate));
		
		$sql="select * from lms_data where reference='".$ref."' order by dname asc";
		
			
			$sql1=mysqli_query($con,$sql);
			
			 $setMainHeader = "Name \t Email \t Mobile \t Location \t Project \t Reference \t Assign Date \t Ringing \t Callback \t Callback Date \t Site Visit \t Visit Date \t More Details \n ";
			 $rowLine='';
			while($row=mysqli_fetch_array($sql1))
			{
				$drow=mysqli_fetch_array(mysqli_query($con,"select * from lms_emp_data where dataid='".$row['id']."'") );
				if($drow['callbackdate']=="0000-00-00" or $drow['callbackdate']=="1970-01-01" or $drow['callbackdate']==""){ $callbackdate='';}else{ $callbackdate=date("d M Y", strtotime($drow['callbackdate']));}
				
				if($drow['visitdate']=="0000-00-00" or $drow['visitdate']=="1970-01-01" or $drow['visitdate']==""){ $visitdate='';}else{ $visitdate=date("d M Y", strtotime($drow['visitdate']));}	
				
				if($drow['datefor']=="0000-00-00" or $drow['datefor']=="1970-01-01" or $drow['datefor']==""){ $assigndate='';}else{ $assigndate=date("d M Y", strtotime($drow['datefor']));}	
				
				$rowLine.= $row['dname']." \t ".$row['email']." \t ".$row['mobile']." \t ".$row['location']." \t ".$row['project']." \t ".$row['reference']." \t ".$assigndate." \t ".$drow['ringing']." \t ".$drow['callback']." \t ".$callbackdate." \t ". $drow['sitevisit']." \t ".$visitdate." \t ".$drow['about']." \n ";
			}
			//echo $rowLine;
			
			 $setData = str_replace("\r", "", $rowLine);

			if ($setData == "") {
			  $setData = "\n select * from tab_ro where rdate>='".$fromdate."' and rdate<='".$todate."' and status='Ok' order by rdate desc\n";
			}

			//$setCounter = mysql_num_fields($setRec);



			//This Header is used to make data download instead of display the data
			 header("Content-type: application/octet-stream");

			header("Content-Disposition: attachment; filename=Referencestatus.xls");

			header("Pragma: no-cache");
			header("Expires: 0");

			//It will print all the Table row as Excel file row with selected column name as header.
			echo ucwords($setMainHeader)."\n".$setData."\n";
						
			
			
			
		
	
?>