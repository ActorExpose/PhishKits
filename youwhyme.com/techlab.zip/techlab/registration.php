<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
//include'config/login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>Registration </title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#candidateform,#studioform,#modelling,.studiomore{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php //include 'config/leftmenu.php'; ?>
<?php //include 'config/rightbar.php'; ?>

<div id="page-container">
<?php //include 'config/headersetting.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>
<i class="fa fa-anchor animation-expandUp"></i>Registration Form </h1>
</a>
</div>

<div class="row">
<div class="col-md-12">
<div class="block-title">
<h2> Select Category</h2>
</div>


<div class="form-group">

<label class="col-md-3 control-label" for="example-text-input"> </label>
<div class="col-md-3"> <input type="radio" name="cat" id="studio" /> Post Job </div>
<div class="col-md-3"> <input type="radio" name="cat" id="cand" /> Post Talent </div>


</div>


</div>
</div>

<div class="row" id="studioform">
<form id="studioinfo" method="post" enctype="multipart/form-data" class="form-horizontal">
<div class="col-md-12" style="margin-top:30px;margin-bottom:40px;">

<div class="col-md-6">
<div class="block-title">
<h2> Personal Information</h2>
</div>

<div class="form-group"><div style="color:red;"><?php echo $error;?></div>
<label class="col-md-3 control-label" for="example-text-input">Name </label>
<div class="col-md-9">
<input type="text" id="sname" name="sname" class="form-control" placeholder="Enter Name" maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Contact No.  </label>
<div class="col-md-9">
<input type="text" id="mobile" name="mobile" class="form-control" placeholder="Your Mobile No." maxlength="10" onkeypress="return isNumber(event);" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Email </label>
<div class="col-md-9">
<input type="email" id="email" name="email" class="form-control" placeholder="Enter Email" maxlength="50" required>

</div>
</div>




</div>

<div class="col-md-6">
<div class="block-title">
<h2>Locality Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Street Name.</label>
<div class="col-md-9">
<input type="text" name="street" class="form-control" placeholder="Your Street Name" maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">City.  </label>
<div class="col-md-9">
<input type="text"  name="city" class="form-control" placeholder="Your City." maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">State  </label>
<div class="col-md-9">
<input type="text"  name="state" class="form-control" placeholder="Your State." maxlength="50" required>

</div>
</div>


<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Country </label>
<div class="col-md-9">
<input type="text"  name="country" class="form-control" placeholder="Your Country." required maxlength="50">

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Pin Code </label>
<div class="col-md-9">
<input type="text"  name="zip" class="form-control" placeholder="Your Pin." onkeypress="return isNumber(event);" required maxlength="6">

</div>
</div>
<div class="form-group" style="margin-top:30px;">
<div class="col-md-12 col-md-offset-5">
<button type="button" id="studionext" class="btn btn-default"><i class="fa fa-arrow-right"></i> Next Step</button>

</div>
</div>

</div>

</div>

<div class="col-md-12 studiomore" id="studiomore"  style="margin-top:20px;margin-bottom:20px;">


<div class="col-md-6">


<div class="block-title">
<h2 style="text-align:center;">Category Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Category </label>
<div class="col-md-9">
<select name="category1" class="form-control cat" data-id="scat1" >
<option value="">--- Select One ---</option>
<?php 
$q=mysqli_query($con,"select * from studio_category");
while($qrow=mysqli_fetch_array($q))
{
	echo '<option value="'.$qrow['catname'].'">'.$qrow['catname'].'</option>';
}
?>

</select>
<span class="help-block"><strong id="scat1"> </strong></span>


</div>
</div>


</div>

<div class="col-md-6"  style="margin-bottom:30px;">
<div class="block-title">
<h2 style="text-align:center;">Describe Yourself </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Job Title </label>
<div class="col-md-9">
<input type="text" name="jtitle1" class="form-control" maxlength="50" />

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Company Name </label>
<div class="col-md-9">
<input type="text" name="cname1" class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Description </label>
<div class="col-md-9">
<textarea name="description1" class="form-control"></textarea>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">No. of Vaccancy</label>
<div class="col-md-9">
<input type="text" name="nov1" class="form-control" maxlength="5" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">City</label>
<div class="col-md-9">
<input type="text" name="city1" required class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Street Address</label>
<div class="col-md-9">
<input type="text" name="street1" class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Phone No.</label>
<div class="col-md-9">
<input type="text" name="mobile1" class="form-control" maxlength="10" onkeypress="return isNumber(event);" required />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">State</label>
<div class="col-md-9">
<input type="text" name="state1" required class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Country</label>
<div class="col-md-9">
<input type="text" name="country1" class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-9 control-label" for="example-text-input">  </label>
<div class="col-md-3">
<a href="#" id="addmore">+ Add More Category</a>

</div>
</div>

</div>
<div id="morecat" style="margin-top:20px;">
<div class="col-md-6">
<div class="block-title">
<h2 style="text-align:center;">Category Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Category </label>
<div class="col-md-9">
<select name="category2" class="form-control cat" data-id="scat2" >
<option value="">--- Select One ---</option>
<?php 
$q=mysqli_query($con,"select * from studio_category");
while($qrow=mysqli_fetch_array($q))
{
	echo '<option value="'.$qrow['catname'].'">'.$qrow['catname'].'</option>';
}
?>

</select>
<span class="help-block"><strong id="scat2"> </strong></span>


</div>
</div>


</div>

<div class="col-md-6">
<div class="block-title">
<h2 style="text-align:center;">Describe Yourself </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Job Title </label>
<div class="col-md-9">
<input type="text" name="jtitle2" class="form-control" maxlength="50" />

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Company Name </label>
<div class="col-md-9">
<input type="text" name="cname2" class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Description </label>
<div class="col-md-9">
<textarea name="description2" class="form-control" ></textarea>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">No. of Vaccancy</label>
<div class="col-md-9">
<input type="text" name="nov2" class="form-control" maxlength="5" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">City</label>
<div class="col-md-9">
<input type="text" name="city2"  class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Street Address</label>
<div class="col-md-9">
<input type="text" name="street2" class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Phone No.</label>
<div class="col-md-9">
<input type="text" name="mobile2" class="form-control" maxlength="10" onkeypress="return isNumber(event);"  />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">State</label>
<div class="col-md-9">
<input type="text" name="state2"  class="form-control" />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Country</label>
<div class="col-md-9">
<input type="text" name="country2" class="form-control" maxlength="50" />

</div>
</div>

<div class="form-group">
<label class="col-md-9 control-label" for="example-text-input">  </label>
<div class="col-md-3">


</div>
</div>

</div>
</div>


<div class="col-md-12" style="margin-top:20px;">
<div class="block-title">
<h2 style="color:#f2b149;">Payment Details </h2>
</div>

<div class="col-md-3"></div>
<div class="col-md-3"><h3 style="color:#f2b149;">Category</h3></div>
<div class="col-md-6"><h3 style="color:#f2b149;">Payment Details </h3></div>

<div class="col-md-3"></div>
<div class="col-md-3"><h4 id="studiocat1"> </h4></div>
<div class="col-md-6"><h4>&#8377; <span id="sprice1">  0.00 </span></h4></div>
<div class="col-md-3"></div>
<div class="col-md-3"><h4 id="studiocat2"> </h4></div>
<div class="col-md-6"><h4>&#8377; <span id="sprice2"> 0.00 </span> </h4></div>
</div>
<div class="col-md-12" style="margin-top:20px;padding-top:10px;">
<div class="col-md-3"></div>
<div class="col-md-3" style="border-top:1px solid gray;"><h4 style="color:#f2b149;" >Total</h4></div>
<div class="col-md-2" style="border-top:1px solid gray;"><h4  style="color:#f2b149;">&#8377; <span id="tprice"> 0.00 </span></h4></div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"></label>
<div class="col-md-9">
<input type="checkbox" required /> I Agree with Terms & Conditions

</div>
</div>
<div class="form-group" style="margin-top:30px;">
<div class="col-md-12 col-md-offset-5">
<img src="img/loader.gif" id="sinfoloader" />
<div id="studioformmessage"></div>
<input type="hidden" name="edit" class="form-control"value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>

</div>
</form>

</div>




<div class="row">

<div class="col-md-12" style="margin-top:30px;margin-bottom:40px;">
<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" id="candidateform">
<div class="col-md-6">

<div class="block-title">
<h2>Personal Information</h2>
</div>

<div class="form-group"><div style="color:red;"></div>
<label class="col-md-3 control-label" for="example-text-input">Name </label>
<div class="col-md-9">
<input type="text" id="cnname" name="cname" class="form-control" placeholder="Enter Name" maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Contact No.  </label>
<div class="col-md-9">
<input type="text" id="cnmobile" name="mobile" class="form-control" placeholder="Your Mobile No." maxlength="10" onkeypress="return isNumber(event);" required />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Email </label>
<div class="col-md-9">
<input type="email" id="cnemail" name="email" class="form-control" placeholder="Enter Email" maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Gender </label>
<div class="col-md-9">
<select name="gender" class="form-control" required>
<option value=""></option>
<option value="Male">Male</option>
<option value="Female">Female</option>

</select>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3" for="example-datepicker3">Date of Birth</label>
<div class="col-md-9">
<input type="text" name="dob" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy" required>
</div>
</div>




</div>
<!----------------next step ---------->
<div class="col-md-6">
<div class="block-title">
<h2>Locality Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Street Name.</label>
<div class="col-md-9">
<input type="text" name="street" class="form-control" placeholder="Your Street Name" maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">City.  </label>
<div class="col-md-9">
<input type="text" name="city" class="form-control" placeholder="Your City." maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">State  </label>
<div class="col-md-9">
<input type="text" name="state" class="form-control" placeholder="Your State." maxlength="50" required>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Pin Code </label>
<div class="col-md-9">
<input type="text" name="zip" value=""  class="form-control" placeholder="Your Pin Code." onkeypress="return isNumber(event);" maxlength="6" required />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Country </label>
<div class="col-md-9">
<input type="text" name="country" value=""  class="form-control" placeholder="Your Country." maxlength="50" required>

</div>
</div>
<div class="form-group" style="margin-top:30px;">
<div class="col-md-12 col-md-offset-5">
<button type="button" id="cannext" class="btn btn-default"><i class="fa fa-arrow-right"></i> Next Step</button>

</div>
</div>

</div>
<div class="col-md-12" id="canmore" style="margin-top:20px;">

<div class="col-md-12" style="margin:40px 0px;text-align:center;line-height:20px;">
<div class="block-title">
<h2 style="text-align:center;">Our Plan </h2>
</div>
<div class="row" style="height:40px;">
<div class="col-md-2 col-md-offset-2"></div><div class="col-md-2"><a href="#" style="font-size:28px">Basic</a></div><div class="col-md-2"><a href="#" style="font-size:28px">Standard</a></div><div class="col-md-2"><a href="#" style="font-size:28px">Premium</a></div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Category</a></div><div class="col-md-2">1</div><div class="col-md-2">2</div><div class="col-md-2">Unlimited</div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Video</a></div><div class="col-md-2">1</div><div class="col-md-2">2</div><div class="col-md-2">Unlimited</div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Audio</a></div><div class="col-md-2">1</div><div class="col-md-2">2</div><div class="col-md-2">Unlimited</div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Your Words</a></div><div class="col-md-2">250</div><div class="col-md-2">500</div><div class="col-md-2">1200</div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Profile Highlights</a></div><div class="col-md-2">Once in a Week</div><div class="col-md-2">Twice in a Week</div><div class="col-md-2">Every Day</div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Recent Talent</a></div><div class="col-md-2"><i class="fa fa-times"></i></div><div class="col-md-2"><i class="fa fa-times"></i></div><div class="col-md-2"><i class="fa fa-check"></i></div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Photo</a></div><div class="col-md-2">1</div><div class="col-md-2">3</div><div class="col-md-2">10</div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"></div><div class="col-md-2"><input type="radio" class="plan" name="plan" value="basic" /> Add</div><div class="col-md-2"><input type="radio" name="plan" class="plan" value="standard" /> Add</div><div class="col-md-2"><input type="radio" class="plan" name="plan" value="premium" /> Add</div>
</div>
<div class="row" style="height:30px;">
<div class="col-md-2 col-md-offset-2" style="text-align:left;"></div><div class="col-md-2"> <i class="fa fa-rupee"></i> 349 </div><div class="col-md-2"> <i class="fa fa-rupee"></i> 499 </div><div class="col-md-2"> <i class="fa fa-rupee"></i> 999 </div>
</div>


</div>



<div class="col-md-6">
<div class="block-title">
<h2 style="text-align:center;">Category Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Category </label>
<div class="col-md-9">
<select name="category1" class="form-control cat cato" data-id="scat3" required>
<option value="">--- Select One ---</option>
<?php 
$q=mysqli_query($con,"select * from studio_category");
while($qrow=mysqli_fetch_array($q))
{
	echo '<option value="'.$qrow['catname'].'">'.$qrow['catname'].'</option>';
}
?>

</select>
<span class="help-block"><strong id="scat3"> </strong></span>


</div>
</div>

<div class="form-group" id="addcan">
<label class="col-md-3 control-label" for="example-text-input">Category </label>
<div class="col-md-9">
<select name="category2" class="form-control cat cato" data-id="scat4" >
<option value="">--- Select One ---</option>
<?php 
$q=mysqli_query($con,"select * from studio_category");
while($qrow=mysqli_fetch_array($q))
{
	echo '<option value="'.$qrow['catname'].'">'.$qrow['catname'].'</option>';
}
?>

</select>
<span class="help-block"><strong id="scat4"> </strong></span>


</div>
</div>


<div class="form-group">
<label class="col-md-9 control-label" for="example-text-input">  </label>
<div class="col-md-3">
<a href="#" id="addcanmore">+ Add More Category</a>

</div>
</div>


</div>

<div class="col-md-6">
<div class="block-title">
<h2 style="text-align:center;">Describe Yourself </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Description </label>
<div class="col-md-9">
<textarea name="description" class="form-control"></textarea>

</div>
</div>

<div id="modelling">

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Eye Color</label>
<div class="col-md-9">
<input type="text" name="eyecolor" maxlength="50" class="form-control"/>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Face Color</label>
<div class="col-md-9">
<input type="radio" name="facecolor" value="Complexion" /> Complexion 
<input type="radio" name="facecolor" value="Fair" /> Fair
 <input type="radio" name="facecolor" value="Very Fair" /> Very Fair
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Hair Color</label>
<div class="col-md-9">
<input type="text" name="haircolor" maxlength="50" class="form-control"/>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Height</label>
<div class="col-md-9">
<input type="text" name="height" maxlength="20" class="form-control"/>

</div>
</div>

</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Video URL </label>
<div class="col-md-9">
<input type="text" class="form-control" name="vurl" maxlength="200"/>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Upload Audio </label>
<div class="col-md-9">
<input type="file" name="caudio" maxlength="100" class="form-control" />
<span class="help-block">Audio Not more than 5MB (.mp3,.wav) Only </span>
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Passion For Life</label>
<div class="col-md-9">
<input type="text" name="passion" class="form-control" maxlength="100"/>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-file-input"> Photo</label>
<div class="col-md-9">
<input type="file" id="uploadinput6" class="form-control" onchange="uploadimg(6);" name="file" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload6" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload6" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>

</div>


<div class="col-md-12">
<div class="block-title">
<h2>Payment Details </h2>
</div>

<div class="col-md-3"></div>
<div class="col-md-3"><h3 style="color:#647AB3;">Plan</h3></div>
<div class="col-md-6"><h3 style="color:#647AB3;">Payment Details </h3></div>

<div class="col-md-3"></div>
<div class="col-md-3"><h4 id="studiocat3"> </h4></div>
<div class="col-md-6"><h4>&#8377; <span id="sprice3">  0.00 </span></h4></div>
<div class="col-md-3"></div>

</div>
<div class="col-md-12" style="margin-top:20px;padding-top:10px;">
<div class="col-md-3"></div>
<div class="col-md-3" style="border-top:1px solid gray;"><h4 style="color:#647AB3;" >Total</h4></div>
<div class="col-md-2" style="border-top:1px solid gray;"><h4  style="color:#647AB3;">&#8377; <span id="tprice1"> 0.00 </span> </h4></div>
</div>


<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"></label>
<div class="col-md-9">
<input type="checkbox" checked required /> I Agree with Terms & Conditions

</div>
</div>
<div class="form-group" style="margin-top:30px;">
<div class="col-md-12 col-md-offset-5">
<img src="img/loader.gif" id="cinfoloader" />
<div id="cformmessage"></div>
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>



</div>
</form>
</div>

</div>





</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>

</body>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	
	function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	if(charCode==46){return false;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
	}
</script>
<script>
$(document).ready(function(){
	$("#morecat").hide();
	$("#addcan").hide();
	$("#canmore").hide();
	$("#cand").click(function(e){
		//e.preventDefault();
		$("#candidateform").show("slow");
		$("#studioform").hide();
	} );
	
	$("#studionext").click(function(e){
		e.preventDefault();
		var sname=$("#sname").val();
		var mobile=$("#mobile").val();
		var email=$("#email").val();
		var password=$("#password").val();
		if(sname=='' || mobile=='' || email=='' || password=='')
		{ alert("Some Important information missing"); }
		else {
			
			$("#studiomore").show("slow");
			$(window).scrollTop(800);
		}
	} );
	////////////////////
	$("#cannext").click(function(e){
		e.preventDefault();
		var sname=$("#cnname").val();
		var mobile=$("#cnmobile").val();
		var email=$("#cnemail").val();
		var password=$("#cnpassword").val();
		if(sname=='' || mobile=='' || email=='' || password=='')
		{ alert("Some Important information missing"); }
		else {
			
			$("#canmore").show("slow");
			$(window).scrollTop(800);
		}
	} );
	
	///////////////////
	$("#studio").click(function(e){
		//e.preventDefault();
		$("#candidateform").hide();
		$("#studioform").show("slow");
	} );
	$("#addmore").click(function(e){
		e.preventDefault();
		var t=$(this).text();
		$(window).scrollTop(1200);
		$("#morecat").toggle("slow");
		if(t=="+ Add More Category"){$(this).text("- Remove Category");}else{$(this).text("+ Add More Category");}
	} );
	$("#addcanmore").click(function(e){
		e.preventDefault();
		var t=$(this).text();
		//$(window).scrollTop(1200);
		$("#addcan").toggle("slow");
		if(t=="+ Add More Category"){$(this).text("- Remove Category");}else{$(this).text("+ Add More Category");}
	} );
	$(".cato").change(function(){
		var c=$(this).val();
		if(c=="Modelling" || c=="Anchoring")
		{
			$("#modelling").show("slow");
		}
		else
		{
			$("#modelling").hide();
		}
	} );
	/*$(".cat").change(function(){
		var c=$(this).val();
		var datastr="cat="+c;
		var i= $(this).attr("data-id");
		var n=i.charAt(i.length-1);
		$.ajax({
			url: "searchcat.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: datastr,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#'+i).html(data);
			var res=data.split(" ");
			var pr=res[(res.length)-1].substring(0,res[(res.length)-1].length-1);
			pr=parseInt(pr).toFixed(2);
			$("#studiocat"+n).html(res[0])
			$("#sprice"+n).html(pr);
			var t1=$("#sprice1").text();
			var t2=$("#sprice2").text();
			var t3=$("#sprice3").text();
			var t4=$("#sprice4").text();
			var total=parseInt(t1)+parseInt(t2);
			var total1=parseInt(t3)+parseInt(t4);
			$("#tprice").text(parseInt(total).toFixed(2));
			$("#tprice1").text(parseInt(total1).toFixed(2));
			
			//alert(pr);
			//$(window).scrollTop(250);
			//$('html, body').animate({scrollTop:150}, 'slow');
			//window.location="dataedit.php";
			//alert(data);
			}
		});
		
	});*/
	$(".plan").click(function(e) {
		
		var p=$(this).val();
		if(p=="basic")
		{
			$("#studiocat3").html("Basic");
			$("#sprice3").html("349.00");
			$("#tprice1").html("349.00");
		}
		else if(p=="standard")
		{
			$("#studiocat3").html("Standard");
			$("#sprice3").html("499.00");
			$("#tprice1").html("499.00");
		}
		else if(p=="premium")
		{
			$("#studiocat3").html("Premium");
			$("#sprice3").html("999.00");
			$("#tprice1").html("999.00");
		}
		
	});
	
	////////////////////studio info form///////////////////////////
	$('#sinfoloader').hide();
	$("body").on("submit","#studioinfo",function(e){
		//$("#subscribe").on('submit',(function(e) {
		e.preventDefault();
	//alert("formpost");
		$("#sinfomessage").empty();
		$('#sinfoloader').show();
		$.ajax({
		url: "studioinfo.php", // Url to which the request is send
		type: "POST",             // Type of request to be send, called as method
		data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,        // To send DOMDocument or non processed data file it is set to false
		success: function(data)   // A function to be called if request succeeds
		{
			$('#sinfoloader').hide();
			if(data=="success")
			{
				$("#studioformmessage").html("Registration Successfull");
				$(this).trigger("reset");
			}
			else
			{
				$("#studioformmessage").html(data);
			}
		}
		});
		});
	////////////////////candidate form///////////////////////////
	$('#cinfoloader').hide();
	$("body").on("submit","#candidateform",function(e){
		//$("#subscribe").on('submit',(function(e) {
		e.preventDefault();
		//alert("formpost");
		$("#cinfomessage").empty();
		$('#cinfoloader').show();
		$.ajax({
		url: "candiinfo.php", // Url to which the request is send
		type: "POST",             // Type of request to be send, called as method
		data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,        // To send DOMDocument or non processed data file it is set to false
		success: function(data)   // A function to be called if request succeeds
			{
				$('#cinfoloader').hide();
				if(data=="success")
				{
					$("#cformmessage").html("Registration Successfull Completed");
					$(this).trigger("reset");
				}
				else
				{
					$("#cformmessage").html(data);
				}
			}
			});
		});
});
</script>
</html>