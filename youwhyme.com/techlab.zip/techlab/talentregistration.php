<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$row=mysqli_fetch_array(mysqli_query($con,"select * from studio_new_usr where usr_email='".$_SESSION['usermail']."'"));
//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>Talent Registration </title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#modelling,.studiomore,.stcat,.a2,.v2{display:none;}
.more{font-size:26px;display:none;}
.remove{font-size:18px;color:red;}
</style>
</head>
<body class="header-fixed-top">
<?php //include 'config/leftmenu.php'; ?>
<?php //include 'config/rightbar.php'; ?>

<div id="page-container">
<?php //include 'config/headersetting.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1> Talent Registration Form </h1>
</a>
</div>







<div class="row">

<div class="col-md-12" style="margin-top:30px;margin-bottom:40px;">
<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" id="candidateform">
<div class="col-md-6">

<div class="block-title">
<h2>Personal Information</h2>
</div>

<div class="form-group"><div style="color:red;"></div>
<label class="col-md-3 control-label" for="example-text-input">Name </label>
<div class="col-md-9">
<input type="text" id="cnname" name="cname" class="form-control" placeholder="Enter Name" maxlength="50" value="<?php echo $row['usr_name'];?>" readonly required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Contact No.  </label>
<div class="col-md-9">
<input type="text" id="cnmobile" name="mobile" class="form-control" placeholder="Your Mobile No." value="<?php echo $row['usr_mobile'];?>" readonly maxlength="10" onkeypress="return isNumber(event);" required />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Email </label>
<div class="col-md-9">
<input type="email" id="cnemail" name="email" class="form-control" placeholder="Enter Email" maxlength="50" value="<?php echo $row['usr_email'];?>" readonly required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Gender </label>
<div class="col-md-9">
<select name="gender" class="form-control" required>
<option value="">--Select--</option>
<option value="Male">Male</option>
<option value="Female">Female</option>

</select>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3" for="example-datepicker3">Date of Birth</label>
<div class="col-md-9">
<input type="text" name="dob" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy" required>
</div>
</div>




</div>
<!----------------next step ---------->
<div class="col-md-6">
<div class="block-title">
<h2>Locality Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Street Name.</label>
<div class="col-md-9">
<input type="text" name="street" class="form-control" placeholder="Your Street Name" maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">City.  </label>
<div class="col-md-9">
<input type="text" name="city" class="form-control" placeholder="Your City." maxlength="50" required>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">State  </label>
<div class="col-md-9">
<input type="text" name="state" class="form-control" placeholder="Your State." maxlength="50" required>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Pin Code </label>
<div class="col-md-9">
<input type="text" name="zip" value=""  class="form-control" placeholder="Your Pin Code." onkeypress="return isNumber(event);" maxlength="6" required />

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Country </label>
<div class="col-md-9">
<input type="text" name="country" value=""  class="form-control" placeholder="Your Country." maxlength="50" required>

</div>
</div>
<div class="form-group" style="margin-top:30px;">
<div class="col-md-12 col-md-offset-5">
<button type="button" id="cannext" class="btn btn-default"><i class="fa fa-arrow-right"></i> Next Step</button>

</div>
</div>

</div>
<div class="col-md-12" id="canmore" style="margin-top:20px;">

<div class="col-md-12" style="margin:40px 0px;text-align:center;line-height:20px;">
<div class="block-title">
<h2 style="text-align:center;">Our Plan </h2>
</div>
<div class="row" style="height:40px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2"></div><div class="col-md-2 col-xs-3"><a href="#" style="font-size:24px">Basic</a></div><div class="col-md-2 col-xs-3"><a href="#" style="font-size:24px">Standard</a></div><div class="col-md-2 col-xs-3"><a href="#" style="font-size:24px">Premium</a></div>
</div>
<div class="row" style="height:30px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Category</a></div><div class="col-xs-3 col-md-2">1</div><div class="col-xs-3 col-md-2">2</div><div class="col-xs-3 col-md-2">Unlimited</div>
</div>
<div class="row" style="height:30px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Video</a></div><div class="col-xs-3 col-md-2">1</div><div class="col-xs-3 col-md-2">2</div><div class="col-xs-3 col-md-2">Unlimited</div>
</div>
<div class="row" style="height:30px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Audio</a></div><div class="col-xs-3 col-md-2">1</div><div class="col-xs-3 col-md-2">2</div><div class="col-xs-3 col-md-2">Unlimited</div>
</div>
<div class="row" style="height:30px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Your Words</a></div><div class="col-xs-3 col-md-2">250</div><div class="col-xs-3 col-md-2">500</div><div class="col-xs-3 col-md-2">1200</div>
</div>
<div class="row" style="height:50px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Profile Highlights</a></div><div class="col-xs-3 col-md-2">Once in a Week</div><div class="col-xs-3 col-md-2">Twice in a Week</div><div class="col-xs-3 col-md-2">Every Day</div>
</div>
<div class="row" style="height:50px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Recent Talent</a></div><div class="col-xs-3 col-md-2"><i class="fa fa-times"></i></div><div class="col-xs-3 col-md-2"><i class="fa fa-times"></i></div><div class="col-xs-3 col-md-2"><i class="fa fa-check"></i></div>
</div>
<div class="row" style="height:30px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"><a href="#">Photo</a></div><div class="col-xs-3 col-md-2">1</div><div class="col-xs-3 col-md-2">3</div><div class="col-xs-3 col-md-2">10</div>
</div>
<div class="row" style="height:30px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"></div><div class="col-xs-3 col-md-2"><input type="radio" class="plan" name="plan" value="basic" required /> Add</div><div class="col-xs-3 col-md-2"><input type="radio" name="plan" class="plan" value="standard" required /> Add</div><div class="col-xs-3 col-md-2"><input type="radio" class="plan" name="plan" value="premium" required /> Add</div>
</div>
<div class="row" style="height:30px;">
<div class="col-xs-3 col-xs-offset-0 col-md-2 col-md-offset-2" style="text-align:left;"></div><div class="col-xs-3 col-md-2"> <i class="fa fa-rupee"></i> 349 </div><div class="col-xs-3 col-md-2"> <i class="fa fa-rupee"></i> 499 </div><div class="col-xs-3 col-md-2"> <i class="fa fa-rupee"></i> 999 </div>
</div>


</div>



<div class="col-md-6">
<div class="block-title">
<h2 style="text-align:center;">Category Information </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Category </label>
<div class="col-md-8">
<select name="cat[]" class="form-control cat cato" data-id="scat3" required>
<option value="">--- Select One ---</option>
<?php 
$q=mysqli_query($con,"select * from studio_category");
while($qrow=mysqli_fetch_array($q))
{
	echo '<option value="'.$qrow['catname'].'">'.$qrow['catname'].'</option>';
}
?>

</select>
</div>
<div class="col-md-1"><a href="#" class="more" id="addcat">+</a></div>
</div>
<div id="morecat">

</div>


<div class="form-group" id="addcan">
<label class="col-md-3 control-label" for="example-text-input">Category </label>
<div class="col-md-8">
<select name="cat[]" class="form-control cat cato" data-id="scat4" >
<option value="">--- Select One ---</option>
<?php 
$q=mysqli_query($con,"select * from studio_category");
while($qrow=mysqli_fetch_array($q))
{
	echo '<option value="'.$qrow['catname'].'">'.$qrow['catname'].'</option>';
}
?>

</select>
</div>

</div>


<div class="form-group stcat" >
<label class="col-md-9 control-label" for="example-text-input">  </label>
<div class="col-md-3">
<a href="#" id="addcanmore">+ Add More Category</a>

</div>
</div>


</div>

<div class="col-md-6">
<div class="block-title">
<h2 style="text-align:center;">Describe Yourself </h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Description </label>
<div class="col-md-9">
<textarea name="description" class="form-control ywords" maxlength="5"></textarea>

</div>
</div>

<div id="modelling">

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Eye Color</label>
<div class="col-md-9">
<input type="text" name="eyecolor" maxlength="50" class="form-control"/>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Face Color</label>
<div class="col-md-9">
<input type="radio" name="facecolor" value="Complexion" /> Complexion 
<input type="radio" name="facecolor" value="Fair" /> Fair
 <input type="radio" name="facecolor" value="Very Fair" /> Very Fair
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Hair Color</label>
<div class="col-md-9">
<input type="text" name="haircolor" maxlength="50" class="form-control"/>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Height</label>
<div class="col-md-9">
<input type="text" name="height" maxlength="20" class="form-control"/>

</div>
</div>

</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Video URL </label>
<div class="col-md-8">
<input type="file" name="cvideo[]" class="form-control" />
<!--<input type="text" class="form-control" name="vurl[]" maxlength="200"/>-->
</div>
<div class="col-md-1"><a href="#" class="more" id="addv">+</a></div>
</div>
<div id="morev">

</div>
<!----<div class="form-group v2">
<label class="col-md-3 control-label" for="example-text-input"> Video URL 2</label>
<div class="col-md-9">
<input type="text" class="form-control" name="vurl[]" maxlength="200"/>

</div>
</div>--->
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Upload Audio </label>
<div class="col-md-8">
<input type="file" name="caudio[]" class="form-control" />
<span class="help-block">Audio Not more than 5MB (.mp3,.wav) Only </span>
</div>
<div class="col-md-1"><a href="#" class="more" id="adda">+</a></div>
</div>
<div id="morea">
</div>
<!--
<div class="form-group a2">
<label class="col-md-3 control-label" for="example-text-input">Upload Audio 2</label>
<div class="col-md-9">
<input type="file" name="caudio[]" maxlength="100" class="form-control" />
<span class="help-block">Audio Not more than 5MB (.mp3,.wav) Only </span>
</div>
</div>
-->
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Passion For Life</label>
<div class="col-md-9">
<input type="text" name="passion" class="form-control" maxlength="100"/>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-file-input"> Photo 1</label>
<div class="col-md-8">
<input type="file" id="uploadinput1" class="form-control" onchange="uploadimg(1);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload1" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="../img/noimage.png" id="upload1" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
<div class="col-md-1"><a href="#" class="more" id="addi">+</a></div>
</div>
<div id="moreimage"></div>

<!--
<div class="form-group 3photo 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 02</label>
<div class="col-md-9">
<input type="file" id="uploadinput2" class="form-control" onchange="uploadimg(2);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload2" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload2" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>

<div class="form-group 3photo 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 03</label>
<div class="col-md-9">
<input type="file" id="uploadinput3" class="form-control" onchange="uploadimg(3);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload3" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload3" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>

<div class="form-group 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 04</label>
<div class="col-md-9">
<input type="file" id="uploadinput4" class="form-control" onchange="uploadimg(4);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload4" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload4" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>
<div class="form-group 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 05</label>
<div class="col-md-9">
<input type="file" id="uploadinput5" class="form-control" onchange="uploadimg(5);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload5" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload5" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>
<div class="form-group 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 06</label>
<div class="col-md-9">
<input type="file" id="uploadinput6" class="form-control" onchange="uploadimg(6);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload6" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload6" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>
<div class="form-group 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 07</label>
<div class="col-md-9">
<input type="file" id="uploadinput7" class="form-control" onchange="uploadimg(7);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload7" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload7" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>
<div class="form-group 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 08</label>
<div class="col-md-9">
<input type="file" id="uploadinput8" class="form-control" onchange="uploadimg(8);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload8" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload8" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>
<div class="form-group 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 09</label>
<div class="col-md-9">
<input type="file" id="uploadinput9" class="form-control" onchange="uploadimg(9);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload9" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload9" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>
<div class="form-group 10photo">
<label class="col-md-3 control-label" for="example-file-input"> Photo 10 </label>
<div class="col-md-9">
<input type="file" id="uploadinput10" class="form-control" onchange="uploadimg(10);" name="file[]" style="width:60%;display:inline;">
<span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span>
<?php 
if($image!='' and file_exists('../candidateimg/'.$image))
{
	echo '<img src="../candidateimg/'.$image.'" id="upload10" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
else
{
	echo '<img src="img/nophoto.png" id="upload10" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" />';
}
?>


</div>
</div>
-->
</div>


<div class="col-md-12">
<div class="block-title">
<h2>Payment Details </h2>
</div>

<div class="col-md-3"></div>
<div class="col-md-3"><h3 style="color:#647AB3;">Plan</h3></div>
<div class="col-md-6"><h3 style="color:#647AB3;">Payment Details </h3></div>

<div class="col-md-3"></div>
<div class="col-md-3"><h4 id="studiocat3"> </h4></div>
<div class="col-md-6"><h4>&#8377; <span id="sprice3">  0.00 </span></h4></div>
<div class="col-md-3"></div>

</div>
<div class="col-md-12" style="margin-top:20px;padding-top:10px;">
<div class="col-md-3"></div>
<div class="col-md-3" style="border-top:1px solid gray;"><h4 style="color:#647AB3;" >Total</h4></div>
<div class="col-md-2" style="border-top:1px solid gray;"><h4  style="color:#647AB3;">&#8377; <span id="tprice1"> 0.00 </span> </h4></div>
</div>


<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"></label>
<div class="col-md-9">
<input type="checkbox" checked required /> I Agree with Terms & Conditions

</div>
</div>
<div class="form-group" style="margin-top:30px;">
<div class="col-md-12 col-md-offset-5">
<img src="img/loader.gif" id="cinfoloader" />
<div id="cformmessage"></div>
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" id="submit" name="submit" class="btn btn-primary" value="Submit"/> <span id="paybutton"></span>
</div>
</div>



</div>
</form>
</div>

</div>





</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>

</body>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	
	function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	if(charCode==46){return false;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
	}
</script>
<script>
$(document).ready(function(){
	$("#paybutton").hide();
	$("#addcan").hide();
	$("#canmore").hide();
	$("#cand").click(function(e){
		//e.preventDefault();
		$("#candidateform").show("slow");
		$("#studioform").hide();
	} );
	
	$("#studionext").click(function(e){
		e.preventDefault();
		var sname=$("#sname").val();
		var mobile=$("#mobile").val();
		var email=$("#email").val();
		var password=$("#password").val();
		if(sname=='' || mobile=='' || email=='' || password=='')
		{ alert("Some Important information missing"); }
		else {
			
			$("#studiomore").show("slow");
			$(window).scrollTop(800);
		}
	} );
	////////////////////
	$("#cannext").click(function(e){
		e.preventDefault();
		var sname=$("#cnname").val();
		var mobile=$("#cnmobile").val();
		var email=$("#cnemail").val();
		var password=$("#cnpassword").val();
		if(sname=='' || mobile=='' || email=='' || password=='')
		{ alert("Some Important information missing"); }
		else {
			
			$("#canmore").show("slow");
			$(window).scrollTop(800);
		}
	} );
	
	///////////////////
	$("#studio").click(function(e){
		//e.preventDefault();
		$("#candidateform").hide();
		$("#studioform").show("slow");
	} );
	
	$("#addcanmore").click(function(e){
		e.preventDefault();
		var t=$(this).text();
		//$(window).scrollTop(1200);
		$("#addcan").toggle("slow");
		if(t=="+ Add More Category"){$(this).text("- Remove Category");}else{$(this).text("+ Add More Category");}
	} );
	//////////////////////////
	$("#modelling").hide();
	//$(".cato").change(function(){
	$("body").on("change",".cato",function(){
		var c=$(this).val();
		if(c=="Modelling" || c=="Anchoring")
		{
			$("#modelling").show("slow");
		}
		
	} );
	/*$(".cat").change(function(){
		var c=$(this).val();
		var datastr="cat="+c;
		var i= $(this).attr("data-id");
		var n=i.charAt(i.length-1);
		$.ajax({
			url: "searchcat.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: datastr,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#'+i).html(data);
			var res=data.split(" ");
			var pr=res[(res.length)-1].substring(0,res[(res.length)-1].length-1);
			pr=parseInt(pr).toFixed(2);
			$("#studiocat"+n).html(res[0])
			$("#sprice"+n).html(pr);
			var t1=$("#sprice1").text();
			var t2=$("#sprice2").text();
			var t3=$("#sprice3").text();
			var t4=$("#sprice4").text();
			var total=parseInt(t1)+parseInt(t2);
			var total1=parseInt(t3)+parseInt(t4);
			$("#tprice").text(parseInt(total).toFixed(2));
			$("#tprice1").text(parseInt(total1).toFixed(2));
			
			//alert(pr);
			//$(window).scrollTop(250);
			//$('html, body').animate({scrollTop:150}, 'slow');
			//window.location="dataedit.php";
			//alert(data);
			}
		});
		
	});*/
	$(".3photo").hide();
	$(".10photo").hide();
	$(".plan").click(function(e) {
	
		var p=$(this).val();
		if(p=="basic")
		{
			$("#morea").hide();
			$("#morev").hide();
			$("#morecat").hide();
			$("#addcan").hide();
			$(".stcat").hide();
			$(".3photo").hide();
			$(".10photo").hide();
			$(".v2").hide();
			$(".a2").hide();
			$(".more").hide();
			$(".ywords").prop("maxlength","250");
			$("#studiocat3").html("Basic");
			$("#sprice3").html("349.00");
			$("#tprice1").html("349.00");
			$("#paybutton").html('<div class="pm-button"><a href="https://www.payumoney.com/paybypayumoney/#/686BFA92A8F082CB87E2BC16FDDFA52A"><img src="https://www.payumoney.com//media/images/payby_payumoney/buttons/212.png" /></a></div>');
		}
		else if(p=="standard")
		{
			$("#morea").show();
			$("#morea").html("");
			$("#morev").show();
			$("#morev").html("");
			$("#morecat").hide();
			$(".10photo").hide();
			$(".stcat").show("slow");
			$(".3photo").show("slow");
			$(".more").hide();
			$("#addi").show();
			$("#adda").show();
			$("#addv").show();
			//$(".v2").show("slow");
			//$(".a2").show("slow");
			$(".ywords").prop("maxlength","500");
			$("#studiocat3").html("Standard");
			$("#sprice3").html("499.00");
			$("#tprice1").html("499.00");
			$("#paybutton").html('<div class="pm-button"><a href="https://www.payumoney.com/paybypayumoney/#/0B4AEFEFDC5854CC9AF82472AA2F3451"><img src="https://www.payumoney.com//media/images/payby_payumoney/buttons/212.png" /></a></div>');
		}
		else if(p=="premium")
		{	
			$("#morea").show();
			$("#morev").show();
			$("#morecat").show();
			//$(".v2").hide();
			$("#adda").show();
			//$(".a2").hide();
			$("#addcan").hide();
			$(".more").show("slow");
			$(".3photo").hide();
			$(".10photo").show("slow");
			$(".stcat").hide();
			$(".ywords").prop("maxlength","1200");
			$("#studiocat3").html("Premium");
			$("#sprice3").html("999.00");
			$("#tprice1").html("999.00");
			$("#paybutton").html('<div class="pm-button"><a href="https://www.payumoney.com/paybypayumoney/#/96ECDA8197E3BFA1B593599FC7246EF8"><img src="https://www.payumoney.com//media/images/payby_payumoney/buttons/212.png" /></a></div>');
		}
		
	});
	
	////////////////////studio info form///////////////////////////
	$('#sinfoloader').hide();
	$("body").on("submit","#studioinfo",function(e){
		//$("#subscribe").on('submit',(function(e) {
		e.preventDefault();
	//alert("formpost");
		$("#sinfomessage").empty();
		$('#sinfoloader').show();
		$.ajax({
		url: "studioinfo.php", // Url to which the request is send
		type: "POST",             // Type of request to be send, called as method
		data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,        // To send DOMDocument or non processed data file it is set to false
		success: function(data)   // A function to be called if request succeeds
		{
			$('#sinfoloader').hide();
			if(data=="success")
			{
				$("#studioformmessage").html("Registration Successfull");
				$(this).trigger("reset");
			}
			else
			{
				$("#studioformmessage").html(data);
			}
		}
		});
		});
		//////////more category////////////
		var c=2;
		$("#addcat").click(function(e){
			e.preventDefault();
			$("#morecat").append('<div class="form-group" id="morecat'+c+'"><label class="col-md-3 control-label" for="example-text-input">Category </label><div class="col-md-8"><select name="cat[]" class="form-control cat cato" data-id="scat3" required><option value="">--- Select One ---</option><?php $q=mysqli_query($con,"select * from studio_category");while($qrow=mysqli_fetch_array($q)){echo '<option value="'.$qrow['catname'].'">'.$qrow['catname'].'</option>';}?></select></div><div class="col-md-1"><a href="#" class="remove remcat" data-val="'+c+'" >x</a></div></div>');
			c++;
		});
		$("body").on("click",".remcat",function(e){ 
			e.preventDefault();
			var d=$(this).attr("data-val");
			$("#morecat").children("#morecat"+d).remove();
		});
	////////////more video///////////////////
		var v=2;
		$("#addv").click(function(e){
			e.preventDefault();
			var mi=$("input:radio.plan:checked").val();
			var hi=(mi=="basic")?0:(mi=="standard")?2:50;
			//alert(mi);
			if(v>hi)
			{
				alert("Your Video Limit is Over");
				return false;
			}
			$("#morev").append('<div class="form-group" id="morev'+v+'"><label class="col-md-3 control-label" for="example-text-input"> Video URL </label><div class="col-md-8"><input type="file" name="cvideo[]" class="form-control" /></div><div class="col-md-1"><a href="#" data-val="'+v+'" class="remove remvideo">x</a></div></div>');
			v++;
		});
		$("body").on("click",".remvideo",function(e){
			e.preventDefault();
			var v=$(this).attr("data-val");
			$("#morev").children("#morev"+v).remove();
		});
	////////////more audio///////////////////
		var au=2;
		$("#adda").click(function(e){
			e.preventDefault();
			var mi=$("input:radio.plan:checked").val();
			var hi=(mi=="basic")?0:(mi=="standard")?2:50;
			//alert(mi);
			if(au>hi)
			{
				alert("Your Audio Limit is Over");
				return false;
			}
			$("#morea").append('<div class="form-group" id="morea'+au+'"><label class="col-md-3 control-label" for="example-text-input"> Audio </label><div class="col-md-8"><input type="file" name="caudio[]" class="form-control" /><span class="help-block">Audio Not more than 5MB (.mp3,.wav) Only </span></div><div class="col-md-1"><a href="#" data-val="'+au+'" class="remove remaudio">x</a></div></div>');
			au++;
		});
		$("body").on("click",".remaudio",function(e){
			e.preventDefault();
			var v=$(this).attr("data-val");
			$("#morea").children("#morea"+v).remove();
		});
	////////////more image///////////////////
		var ai=2;
		
		
		$("#addi").click(function(e){
			e.preventDefault();
			var mi=$("input:radio.plan:checked").val();
			var hi=(mi=="standard")?3:(mi=="premium")?10:0;
			//alert(mi);
			if(ai>hi)
			{
				alert("Your Image Limit is Over");
				return false;
			}
			$("#moreimage").append('<div class="form-group" id="morei'+ai+'"><label class="col-md-3 control-label" for="example-file-input"> Photo '+ai+'</label><div class="col-md-8"><input type="file" id="uploadinput'+ai+'" class="form-control" onchange="uploadimg('+ai+');" name="file[]" style="width:60%;display:inline;"><span class="help-block">Image less than 50KB (.jpg,.png,.gif) Only </span> <img src="../img/noimage.png" id="upload'+ai+'" style="height:100px;width:100px;float:right;margin-top:-63px; margin-bottom:10px;" /></div><div class="col-md-1"><a href="#" data-val="'+ai+'" class="remove remimage">x</a></div></div>');
			
			ai++;
		});
		$("body").on("click",".remimage",function(e){
			e.preventDefault();
			var v=$(this).attr("data-val");
			$("#moreimage").children("#morei"+v).remove();
		});
	////////////////////candidate form///////////////////////////
	$('#cinfoloader').hide();
	$("body").on("submit","#candidateform",function(e){
		//$("#subscribe").on('submit',(function(e) {
		e.preventDefault();
		//alert("formpost");
		$("#cinfomessage").empty();
		$('#cinfoloader').show();
		$.ajax({
		url: "candiinfo.php", // Url to which the request is send
		type: "POST",             // Type of request to be send, called as method
		data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,        // To send DOMDocument or non processed data file it is set to false
		success: function(data)   // A function to be called if request succeeds
			{
				$('#cinfoloader').hide();
				if(data=="success")
				{
					$("#cformmessage").html("Registration Successfull Completed");
					$("#paybutton").show();
					$("#submit").hide("slow");
				}
				else
				{
					$("#cformmessage").html(data);
				}
				//$("#candidateform").trigger("reset");
			}
			});
		});
});
</script>
</html>