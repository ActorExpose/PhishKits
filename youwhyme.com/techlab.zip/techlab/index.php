<?php 
error_reporting(0);
session_start();
include 'config/candidate_login_check.php';
include 'config/configuration.php';

?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Dashboard </title>

<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php';?>


<?php include 'config/rightbar.php';?>
<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div class="cotainer">


<?php
$i=1;
$cmssql=mysqli_query($con,"select * from faculty");
while($cmsrow=mysqli_fetch_array($cmssql) )
{
	?>
	
	
	<div class="col-md-3">
	<div style="    text-align: center;
    padding: 30px 30px;">
	<h6><?php echo $cmsrow['fname'];?></h6>
	<a href="<?php echo $cmsrow['father'];?>" type="button" class="btn btn-primary">Click</a>
	</div>
	</div>
	
	
	
	
	<?php 
}
?>

</div>







</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>


</body>
</html>