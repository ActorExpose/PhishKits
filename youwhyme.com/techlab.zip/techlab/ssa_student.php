<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

$bdate=Date('Y-m-d');
	//$bdate=Date('Y-m-d H:i:s');
	$error='';
	if(isset($_POST['submit']) and $_POST['submit']=="Submit")
	{
		$rollno=mysqli_real_escape_string($con,$_POST['rollno']);
		$sname=mysqli_real_escape_string($con,$_POST['sname']);
		$father=mysqli_real_escape_string($con,$_POST['father']);
		$contact=mysqli_real_escape_string($con,$_POST['contact']);
		$sclass=mysqli_real_escape_string($con,$_POST['sclass']);
		$section=mysqli_real_escape_string($con,$_POST['section']);
		$gender=mysqli_real_escape_string($con,$_POST['gender']);
		$dob=mysqli_real_escape_string($con,$_POST['dob']);
		$dob=date("Y-m-d",strtotime($dob));
		$gender=mysqli_real_escape_string($con,$_POST['gender']);
		$address=mysqli_real_escape_string($con,$_POST['address']);
		
		
		if($_FILES["testiimg"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["testiimg"]["name"]));
			$imageFilesize = $_FILES["testiimg"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif") or $imageFilesize>100000000) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($error=='')
		{
			if($_POST['edit']!='')
			{
				$id=$_POST['edit'];
				$usql="update ssa_student set rollno='".$rollno."',sname='".$sname."',father='".$father."',contact='".$contact."',section='".$section."',dob='".$dob."',sclass='".$sclass."',gender='".$gender."',address='".$address."' where id='".$_POST['edit']."'";
				$upd_img=mysqli_query($con,$usql);
				
				header('Location:ssa_student.php');
			}
			else
			{
				//New Student 
					$sql=mysqli_query($con,"insert into ssa_student set rollno='".$rollno."',sname='".$sname."',father='".$father."',contact='".$contact."',section='".$section."',dob='".$dob."',sclass='".$sclass."',gender='".$gender."',address='".$address."'");
					$id=mysqli_insert_id($con);
					?>
					<script>
					alert("New Student Saved Successfully");
					window.location="ssa_student.php";
					</script>
					<?php
			}
				if($_FILES["testiimg"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["testiimg"]["name"]));
				$imagename=$id.".";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["testiimg"]["tmp_name"], "../facultiimg/".$filename);
				$usql="update ssa_student set image='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
		}
		
	}
	if(isset($_GET['edit_id']) and $_GET['edit_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['edit_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"select * from ssa_student where id='".$id."'"));
		$rollno=$crow['rollno'];
		$sname=$crow['sname'];
		$father=$crow['father'];
		$section=$crow['section'];
		$sclass=$crow['sclass'];
		$contact=$crow['contact'];
		$address=$crow['address'];
		$gender=$crow['gender'];
		$dob=$crow['dob'];
		
		
		$image=$crow['image'];
		
		
		
	}
if(isset($_GET['del_id']) and $_GET['del_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['del_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"Select * from ssa_student where id='".$id."'"));
		$image=$crow['image'];
		unlink("../facultiimg/".$image);
		mysqli_query($con,"delete from ssa_student where id='".$id."'");
		
	}


?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>Student Page Edit</title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#loader{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link"><h1> S.S.Arya Student Page</h1></a>
</div>
<div class="row" style="height:60px;">
<div class="btn-group">
<a href="#excelform" data-toggle="modal" class="btn btn-default btn-sm ">Upload Student by Excel (.csv) File</a>
</div>
</div>
<div class="row">
<div class="col-md-12">
<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" >
<div class="col-md-12">

<div class="block-title">
<h2>Student Information Entry</h2>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Roll No. </label>
<div class="col-md-9">
<input type="text"  name="rollno" class="form-control" placeholder=" Rollno" maxlength="50" value="<?php echo $rollno;?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Student Name </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="sname" class="form-control" placeholder=" Name" maxlength="50" value="<?php echo $sname; ?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Father's Name </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="father" class="form-control" placeholder=" Father's name" maxlength="50" value="<?php echo $father; ?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Contact No. </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="contact" class="form-control" placeholder=" Mobile No." maxlength="10" value="<?php echo $contact; ?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Class. </label>
<div class="col-md-6">
<select id="sclasss" class="form-control" >
<option value="">Select Class</option>
<option value="Nursery">Nursery</option>
<option value="LKG">LKG</option>
<option value="UKG">UKG</option>
<option value="I">I</option>
<option value="II">II</option>
<option value="III"> III</option>
<option value="IV">IV</option>
<option value="V">V</option>
<option value="VI">VI</option>
<option value="VII">VII</option>
<option value="VIII">VIII</option>
<option value="IX">IX</option>
<option value="X"> X</option>
<option value="XI"> XI</option>
<option value="XII">XII</option>
</select>
</div>
<div class="col-md-3">
<input type="text" id="sclass" name="sclass" class="form-control" placeholder=" Class" maxlength="20" value="<?php echo $sclass; ?>" readonly>
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Section. </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="section" class="form-control" placeholder=" Section" maxlength="50" value="<?php echo $section; ?>" >
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Date of Birth. </label>
<div class="col-md-9">
<input type="text" id="example-datepicker3" name="dob" value="<?php if($dob!=''){echo date("m/d/Y",strtotime($dob));}?>" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy">
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Gender </label>
<div class="col-md-9">
<select  name="gender" class="form-control">
<option value="">--Select--</option>
<?php
if($gender!='')
{
	echo '<option value="'.$gender.'" selected>'.$gender.'</option>';
}
?>
<option value="Male">Male</option>
<option value="Female">Female</option>

</select>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Address </label>
<div class="col-md-9">
<textarea name="address" class="form-control" rows="2" style="resize:none;" placeholder=" Address"><?php echo $address; ?></textarea>

</div>
</div>
<!---
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Image</label>
<div class="col-md-4">
<input type="file" name="testiimg" id="uploadinput1" onchange="uploadimg(1);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image!='' and file_exists("../facultiimg/".$image))
{
	echo '<img src="../facultiimg/'.$image.'" style="height:100px;width:200px;" id="upload1"/>';
}
else
{
	echo '<img src="img/noimage.png" style="height:100px;width:200px;" id="upload1"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Meta Title </label>
<div class="col-md-9">
<textarea name="mtitle" class="form-control" rows="2" style="resize:none;" placeholder=" Meta Title" ><?php echo $mtitle;?></textarea>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Meta Description </label>
<div class="col-md-9">
<textarea name="mdes" class="form-control" rows="2" style="resize:none;" placeholder=" Meta description" ><?php echo $mdes;?></textarea>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Meta Keyword </label>
<div class="col-md-9">
<textarea name="mkey" class="form-control" rows="2" style="resize:none;" placeholder=" Meta Keyword" ><?php echo $mkey;?></textarea>

</div>
</div>
--->

<div class="form-group">
<div class="col-md-12 col-md-offset-2">
<input type="hidden" name="edit" class="form-control" value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<a href="ssa_student.php" class="btn btn-default"><i class="fa fa-times"></i> New</a>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>

</div>

</form>
</div>

</div>

All Students  are :
<div class="table-responsive">
<table id="example-datatable" class="table table-bordered table-hover">
<thead>
<tr>
<th>Sr. No.</th>
<th> Roll No</th>
<th> Name</th>
<th>Father's name</th>
<th>Class</th>
<th>DOB</th>
<th>Post</th>
<th>Contact</th>



<th class="text-center">Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
$cmssql=mysqli_query($con,"select * from ssa_student");
while($cmsrow=mysqli_fetch_array($cmssql) )
{
	?>
	<tr>
<td><?php echo $i; $i++;?></td>	
<td><?php echo $cmsrow['rollno'];?></td>
<td><?php echo $cmsrow['sname'];?></td>
<td><?php echo $cmsrow['father'];?></td>
<td><?php echo $cmsrow['sclass'];?></td>
<td><?php echo date("d-M-Y",strtotime($cmsrow['dob']));?></td>
<td><?php echo $cmsrow['section'];?></td>
<td><?php echo $cmsrow['contact'];?></td>



<!---
<td><?php echo $cmsrow['mtitle'];?></td>
<td><?php echo $cmsrow['mdes'];?></td>
<td><?php echo $cmsrow['mkey'];?></td>-->
<td class="text-center">
<a href="ssa_student.php?edit_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>

<a href="ssa_student.php?del_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Delete" class="btn btn-xs btn-default" onclick="return confirm('Are you want to Delete this member');"><i class="fa fa-times"></i></a>



</td>
</tr>
	
	<?php 
}
?>


</tbody>
</table>
</div>



</div>








<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script>
$(document).ready(function(){
	$("#sclasss").change(function(){
		var v= $(this).val();
		$("#sclass").val(v);
	} );
} );
</script>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            //document.getElementById("image"+a).src = oFREvent.target.result;
			document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
</script>
<script type="text/javascript">
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	//if(charCode==46){return true;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
</body>
</html>

<div id="excelform" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Select File to Upload Student  </h4>
      </div>
	  <div class="modal-body" style="height:150px">
	  <div class="row">
		<form id="csvform" action="" method="post" enctype="multipart/form-data" class="form-horizontal">
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Select File (.csv) </label>
		<div class="col-md-9">
		<input type="file" name="csvfile"  class="form-control" >
		<span>Only select .csv file in Proper Format</span>
		</div>
		</div>
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<input type="submit" name="submit" class="btn btn-primary" value="Send"/> 
		<img src="img/loader.gif" id="loader" />
		<span id="message"></span>
		</div>
		</div>
		
		</form>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<script>
$("#csvform").on("submit",function(e){
				e.preventDefault();
				$('#loader').show();
				$.ajax({
					url: "ssa_studentcsvform.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false,        // To send DOMDocument or non processed data file it is set to false
					success: function(data)   // A function to be called if request succeeds
					{
					$('#loader').hide();
					//$(window).scrollTop(250);
					//$('html, body').animate({scrollTop:150}, 'slow');
					//window.location="addrecord.php";
					$("#message").text(data);
					$("#csvform").trigger("reset");
					}
				});
			});
</script>