<?php
session_start();
include 'config/configuration.php';
error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
$dop=Date('Y-m-d');


$email=isset($_POST['email'])?mysqli_real_escape_string($con,$_POST['email']):'';

$hash = md5( rand(1000000,99999999) );
$fsql=mysqli_query($con,"select * from bhang_new_usr where usr_email='".$email."' and mob_active=1");
$csql=mysqli_num_rows($fsql);
if($csql>0)
{
	$row=mysqli_fetch_array($fsql);
	
	$to      = $email; // Send email to our user
	$subject = 'Forgot Password | Change Password'; // Give the email a subject 
	$message = '
	 
	Thanks for Using forgot Password At Bhangalias!
	
	 
	Please click this link to Change your Password at Bhangalias.com:
	http://www.bhangalias.com/change_password.php?email='.$row['usr_email'].'&hash='.$row['usr_hash'].'
	 
	'; // Our message above including the link
						 
	$headers = 'From:info@bhangalias.com' . "\r\n"; // Set from headers
	//mail($to, $subject, $message, $headers); // Send our email.

	echo 'Check Mail to Change Password';

}
else
{
	echo "Email-id Not Registered at Aryavarttpublicschool";
}

?>