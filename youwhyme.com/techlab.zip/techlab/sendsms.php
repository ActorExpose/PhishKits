<?php
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$mobile=isset($_POST['mobile'])?mysqli_real_escape_string($con,$_POST['mobile']):'';
$message=isset($_POST['message'])?mysqli_real_escape_string($con,$_POST['message']):'';

//echo $mobile.$message;

		if($mobile!="" and $message!='')
		{
	
			
			$data="key=259E6211FB19BE&routeid=230&type=text&contacts=".$mobile."&senderid=AVPSGN&msg=".$message;
			
			/*$data="mobile=9867777284&pass=KEXLV&senderid=MANZIL&to=8898205658&msg=Dear Ashwani Kumar Gupta, ".$username." expressed interest on your property ad on Manzildeal.com Call +91-".$mobile." to get in touch.";
			
			$data1="mobile=9867777284&pass=KEXLV&senderid=MANZIL&to=".$mobile."&msg=Dear ".$username.", thanks for expressing interest on Manzildeal.com you can contact advertiser Ashwani on 8898205658.";*/
			$url="http://www.shinenetcor.com/app/smsapi/index.php?";
			
			  function postdata($url,$data)
				{
					$objURL = curl_init($url);
					curl_setopt($objURL, CURLOPT_RETURNTRANSFER, 1); 
					curl_setopt($objURL,CURLOPT_POST,1);
					curl_setopt($objURL, CURLOPT_POSTFIELDS,$data);
					$retval = trim(curl_exec($objURL));
					curl_close($objURL);
					//echo $retval;
					
				}
			/*function postdata1($url,$data)
				{
					$objURL = curl_init($url);
					curl_setopt($objURL, CURLOPT_RETURNTRANSFER, 1); 
					curl_setopt($objURL,CURLOPT_POST,1);
					curl_setopt($objURL, CURLOPT_POSTFIELDS,$data);
					$retval = trim(curl_exec($objURL));
					curl_close($objURL);
					//echo $retval;
					
				}*/
				postdata($url,$data);
				//postdata1($url,$data1);
			
			//Sender ID Does not Exist or Pending or Route Invalid!
			
			//sms gateway.................

		}
		else
		{
			echo "Invalid Send, Please enter Mobile no and Message";
		}
		
	

?>