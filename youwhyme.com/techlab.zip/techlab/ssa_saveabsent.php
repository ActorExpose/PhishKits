<?php
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$class=isset($_POST['sclass'])?mysqli_real_escape_string($con,$_POST['sclass']):'';
$sid=isset($_POST['stuid'])?mysqli_real_escape_string($con,$_POST['stuid']):'';
$sdate=isset($_POST['dos'])?mysqli_real_escape_string($con,$_POST['dos']):'';
$sdate=date("Y-m-d",strtotime($sdate) );

if($sid=='' or $class=='' or $sdate=='')
{
	echo "Some Important Information Missing";
}
else
{
	$n=mysqli_num_rows(mysqli_query($con,"select * from ssa_absent where sdate='".$sdate."' and sclass='".$class."'"));
	if($n>0)
	{
		$query="update ssa_absent set stid='".$sid."' where sdate='".$sdate."' and sclass='".$class."'";
		mysqli_query($con,$query);
		echo "Absent Student Saved";
	}
	else
	{
		$query="insert into ssa_absent set stid='".$sid."' , sdate='".$sdate."' , sclass='".$class."'";
		mysqli_query($con,$query);
		echo "Absent Student Saved";
	}
	
	$id=explode(",",$sid);
	foreach($id as $value)
	{
		$row=mysqli_fetch_array(mysqli_query($con,"select * from ssa_student where id='".$value."'" ) );
		$name=$row['sname'];
		$mobile=$row['contact'];
		$message="Your ward ".$name." is ssa_absent today. Principal- Aryavartt Public School Palla, Greater Noida";
		$data="key=358F899D62E89F&routeid=16&type=text&contacts=".$mobile."&senderid=AVPSGN&msg=".$message;
		$url="http://www.shinenetcor.com/app/smsapi/index.php?";
			
			  function postdata($url,$data)
				{
					$objURL = curl_init($url);
					curl_setopt($objURL, CURLOPT_RETURNTRANSFER, 1); 
					curl_setopt($objURL,CURLOPT_POST,1);
					curl_setopt($objURL, CURLOPT_POSTFIELDS,$data);
					$retval = trim(curl_exec($objURL));
					curl_close($objURL);
					//echo $retval;
					
				}
			
				postdata($url,$data);
	}
}


?>