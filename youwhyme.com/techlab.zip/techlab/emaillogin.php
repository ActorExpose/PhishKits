<?php
session_start();
include 'config/configuration.php';
error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
$dop=Date('Y-m-d');
$_SESSION['otp'] = rand(1000,5000);


$email=isset($_POST['email'])?mysqli_real_escape_string($con,$_POST['email']):'';
$password=isset($_POST['password'])?mysqli_real_escape_string($con,$_POST['password']):'';
$sql=mysqli_query($con,"select * from ownerlogin where (onnerName='".$email."') and onPassword='".$password."' and admin_active='yes'");
$nsql=mysqli_num_rows($sql);
if($nsql>0)
{
		$row=mysqli_fetch_array($sql);
		$_SESSION['ownerID']=$row['ownerID'];
		$_SESSION['ownername']="Admin";
			
	echo "Success";
}
else{
	echo "Invalid Credentials";
}

?>