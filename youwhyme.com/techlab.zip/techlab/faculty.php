<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

$bdate=Date('Y-m-d');
	//$bdate=Date('Y-m-d H:i:s');
	$error='';
	if(isset($_POST['submit']) and $_POST['submit']=="Submit")
	{
		
		$fname=mysqli_real_escape_string($con,$_POST['fname']);
		$father=mysqli_real_escape_string($con,$_POST['father']);
		$contact=mysqli_real_escape_string($con,$_POST['contact']);
		$quali=mysqli_real_escape_string($con,$_POST['quali']);
		$post=mysqli_real_escape_string($con,$_POST['post']);
		$gender=mysqli_real_escape_string($con,$_POST['gender']);
		$dob=mysqli_real_escape_string($con,$_POST['dob']);
		$dob=date("Y-m-d",strtotime($dob));
		$gender=mysqli_real_escape_string($con,$_POST['gender']);
		$address=mysqli_real_escape_string($con,$_POST['address']);
		
		
		if($_FILES["testiimg"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["testiimg"]["name"]));
			$imageFilesize = $_FILES["testiimg"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif") or $imageFilesize>100000000) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($error=='')
		{
			if($_POST['edit']!='')
			{
				$id=$_POST['edit'];
				$usql="update faculty set fname='".$fname."',father='".$father."',contact='".$contact."',post='".$post."',dob='".$dob."',quali='".$quali."',gender='".$gender."',address='".$address."' where id='".$_POST['edit']."'";
				$upd_img=mysqli_query($con,$usql);
				
				header('Location:faculty.php');
			}
			else
			{
				//New Faculty 
					$sql=mysqli_query($con,"insert into faculty set fname='".$fname."',father='".$father."',contact='".$contact."',post='".$post."',dob='".$dob."',quali='".$quali."',gender='".$gender."',address='".$address."'");
					$id=mysqli_insert_id($con);
					?>
					<script>
					alert("New Faculty Saved Successfully");
					window.location="faculty.php";
					</script>
					<?php
			}
				if($_FILES["testiimg"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["testiimg"]["name"]));
				$imagename=$id.".";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["testiimg"]["tmp_name"], "../facultiimg/".$filename);
				$usql="update faculty set image='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
		}
		
	}
	if(isset($_GET['edit_id']) and $_GET['edit_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['edit_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"select * from faculty where id='".$id."'"));
		
		$fname=$crow['fname'];
		$father=$crow['father'];
		$post=$crow['post'];
		$quali=$crow['quali'];
		$contact=$crow['contact'];
		$address=$crow['address'];
		$gender=$crow['gender'];
		$dob=$crow['dob'];
		
		
		$image=$crow['image'];
		
		
		
	}
if(isset($_GET['del_id']) and $_GET['del_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['del_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"Select * from faculty where id='".$id."'"));
		$image=$crow['image'];
		unlink("../facultiimg/".$image);
		mysqli_query($con,"delete from faculty where id='".$id."'");
		
	}


?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>Faculty Page Edit</title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#loader{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link"><h1> Faculty Page</h1></a>
</div>
<?php 
/*if(isset($_REQUEST['edit_id']) and $_REQUEST['edit_id']!='')
	{
		*/
?>
<div class="row">
<div class="col-md-12">
<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" >
<div class="col-md-12">

<div class="block-title">
<h2>Faculty Information Entry</h2>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Faculty Name </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="fname" class="form-control" placeholder=" Name" maxlength="50" value="<?php echo $fname?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Father's Name </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="father" class="form-control" placeholder=" Father's name" maxlength="50" value="<?php echo $father?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Contact No. </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="contact" class="form-control" placeholder=" Mobile No." maxlength="10" value="<?php echo $contact?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Post. </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="post" class="form-control" placeholder=" Post" maxlength="50" value="<?php echo $post?>" >
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Qualification. </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="quali" class="form-control" placeholder=" Qualification" maxlength="50" value="<?php echo $quali?>" >
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Date of Birth. </label>
<div class="col-md-9">
<input type="text" id="example-datepicker3" name="dob" value="<?php if($dob!=''){echo date("m/d/Y",strtotime($dob));}?>" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy">
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Gender </label>
<div class="col-md-9">
<select  name="gender" class="form-control">
<option value="">--Select--</option>
<?php
if($gender!='')
{
	echo '<option value="'.$gender.'" selected>'.$gender.'</option>';
}
?>
<option value="Male">Male</option>
<option value="Female">Female</option>

</select>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Address </label>
<div class="col-md-9">
<textarea name="address" class="form-control" rows="2" style="resize:none;" placeholder=" Address"><?php echo $address?></textarea>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Image</label>
<div class="col-md-4">
<input type="file" name="testiimg" id="uploadinput1" onchange="uploadimg(1);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image!='' and file_exists("../facultiimg/".$image))
{
	echo '<img src="../facultiimg/'.$image.'" style="height:100px;width:200px;" id="upload1"/>';
}
else
{
	echo '<img src="img/noimage.png" style="height:100px;width:200px;" id="upload1"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>
<!---
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Meta Title </label>
<div class="col-md-9">
<textarea name="mtitle" class="form-control" rows="2" style="resize:none;" placeholder=" Meta Title" ><?php echo $mtitle;?></textarea>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Meta Description </label>
<div class="col-md-9">
<textarea name="mdes" class="form-control" rows="2" style="resize:none;" placeholder=" Meta description" ><?php echo $mdes;?></textarea>

</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Meta Keyword </label>
<div class="col-md-9">
<textarea name="mkey" class="form-control" rows="2" style="resize:none;" placeholder=" Meta Keyword" ><?php echo $mkey;?></textarea>

</div>
</div>
--->

<div class="form-group">
<div class="col-md-12 col-md-offset-2">
<input type="hidden" name="edit" class="form-control" value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<a href="faculty.php" class="btn btn-default"><i class="fa fa-times"></i> New</a>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>

</div>

</form>
</div>

</div>

All Faculties  are :
<div class="table-responsive">
<table id="example-datatable" class="table table-bordered table-hover">
<thead>
<tr>
<th>Sr. No.</th>
<th> Name</th>
<th>Father's name</th>
<th>DOB</th>
<th>Post</th>
<th>Contact</th>

<th>IMAGE</th>

<th class="text-center">Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
$cmssql=mysqli_query($con,"select * from faculty");
while($cmsrow=mysqli_fetch_array($cmssql) )
{
	?>
	<tr>
<td><?php echo $i; $i++;?></td>	

<td><?php echo $cmsrow['fname'];?></td>
<td><?php echo $cmsrow['father'];?></td>
<td><?php echo date("d-M-Y",strtotime($cmsrow['dob']));?></td>
<td><?php echo $cmsrow['post'];?></td>
<td><?php echo $cmsrow['contact'];?></td>


<td><?php 
if($cmsrow['image']!='' and file_exists("../facultiimg/".$cmsrow['image']) )
{
	echo '<img src="../facultiimg/'.$cmsrow['image'].'"j height="60" width="50" />';
}


?></td>
<!---
<td><?php echo $cmsrow['mtitle'];?></td>
<td><?php echo $cmsrow['mdes'];?></td>
<td><?php echo $cmsrow['mkey'];?></td>-->
<td class="text-center">
<a href="faculty.php?edit_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>

<a href="faculty.php?del_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Delete" class="btn btn-xs btn-default" onclick="return confirm('Are you want to Delete this member');"><i class="fa fa-times"></i></a>



</td>
</tr>
	
	<?php 
}
?>


</tbody>
</table>
</div>



</div>








<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script>
$(document).ready(function(){
	$("#faculty").change(function(){
		var v= $(this).val();
		$("#cmspage").val(v);
	} );
} );
</script>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            //document.getElementById("image"+a).src = oFREvent.target.result;
			document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
</script>
<script type="text/javascript">
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	//if(charCode==46){return true;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
</body>
</html>