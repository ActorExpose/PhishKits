<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php';
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Absent Student </title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#loader1,#loader{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>
<i class="fa fa-camera-retro animation-expandUp"></i>Absent S.S. Arya Student<br><small>Main Page Notice Editable Form</small>
</h1>
</a>
</div>
<ul class="breadcrumb breadcrumb-top">
<li><i class="fa fa-cog"></i></li>
<li><a href="ssa_absent.php">Absent SSA Student</a></li>
</ul>
<input type="button" class="btn btn-success" data-toggle="modal" data-target="#dnldModal" value="Download"/> 

<div class="block full">
<div class="block-title">
<h2><i class="fa fa-cloud-upload"></i> Select Class for Absent Student </h2>
</div>
<form action="ssa_absent.php" method="post" enctype="multipart/form-data" class="form-horizontal">
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Select Class </label>
<div class="col-md-5">
<select class="form-control" id="sclass" name="sclass">
<option value="">Select Class</option>
<?php 
if($_POST['sclass']!='')
{
	echo '<option value="'.$_POST['sclass'].'" selected>'.$_POST['sclass'].'</option>';
}
?>
<option value="Nursery">Nursery</option>
<option value="LKG">LKG</option>
<option value="UKG">UKG</option>
<option value="I">I</option>
<option value="II">II</option>
<option value="III">III</option>
<option value="IV">IV</option>
<option value="V">V</option>
<option value="VI">VI</option>
<option value="VII">VII</option>
<option value="VIII">VIII</option>
<option value="IX">IX</option>
<option value="X">X</option>
<option value="XI">XI</option>
<option value="XII">XII</option>
</select>
</div>
<div class="col-md-4">
<select class="form-control" id="section" name="section">
<option value="">Select Section</option>
<?php 
if($_POST['section']!='')
{
	echo '<option value="'.$_POST['section'].'" selected>'.$_POST['section'].'</option>';
}
?>
</select>
</div>
</div>


<div class="form-group">
<div class="col-md-12 col-md-offset-5">
<input type="hidden" name="edit" class="form-control" value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Find Student"/> 

</div>
</div>
</form>

</div>


<div class="row gutter30">
<div class="col-md-12">
<div class="block">
<div class="block-title">
<h2><i class="fa fa-camera-retro"></i> All Students of Selected Class</h2>
</div>

<div class="table-responsive">
<table id="example-datatable" class="table table-bordered table-hover">
<thead>
<tr>
<th class="text-center"><input type="checkbox" name="" id="allsms" value="" /> All</th>
<th>Roll No</th>
<th>Name</th>
<th>Contact</th>
<th>DOB</th>
<th>Class</th>
<th>Section</th>
<th>Address</th>

<th class="text-center">Post</th>
</tr>
</thead>
<tbody>
<?php 
if(isset($_POST['submit']) and $_POST['submit']="Find Student")
{
	if($_POST['section']!='')
	{
		$sql=mysqli_query($con,"select * from ssa_student where sclass='".mysqli_real_escape_string($con,$_POST['sclass'])."' and section='".mysqli_real_escape_string($con,$_POST['section'])."' order by rollno");
	}
	else
	{
		$sql=mysqli_query($con,"select * from ssa_student where sclass='".mysqli_real_escape_string($con,$_POST['sclass'])."' order by rollno");
	}
}
$i=1;
while($student=mysqli_fetch_array($sql))
{
?>
<tr>
<td class="text-center">
<input type="checkbox" class="thissms" name="" data-val="<?php echo $student['id'];?>" id="check<?php echo $student['id'];?>" value="" /> &nbsp; <?php echo $i;?></td>
<td><?php echo $student['rollno'];?></td>
<td><a href="student.php?edit_id=<?php echo $student['id'];?>"><?php echo $student['sname'];?></a></td>
<td><?php echo $student['contact'];?></td>
<td><?php echo date("d-M-Y",strtotime($student['dob']));?></td>
<td><?php echo $student['sclass'];?></td>
<td><?php echo $student['section'];?></td>
<td><?php echo $student['address'];?></td>
<td class="text-center">
<div class="btn-group">
<a href="javascript:void(0)" data-toggle="modal" data-target="#myModal"  title="Send SMS" class="btn btn-xs btn-default sendsms"><i class="fa fa-pencil"></i></a>
</div>
</td>

</tr>
<?php 
$i++;
} 
?>

</table>
</div>
</div>
</div>
</div>

</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	</script>
	<script>
$(document).ready(function(){
	$("#sclass").change(function(e){
		e.preventDefault();
		var v= $(this).val();
		//alert(v);
		var dataString="class="+v;
		$.ajax({
			url: "ssa_findsection.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: dataString,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#section').html(data);
			
			}
		});
	} );
	//////////////////////////////////////////
	$("#sclass1").change(function(e){
		e.preventDefault();
		var v= $(this).val();
		//alert(v);
		var dataString="class="+v;
		$.ajax({
			url: "ssa_findsection.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: dataString,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#section1').html(data);
			
			}
		});
	} );
	

} );
</script>
<script>
$(document).ready(function() {
	
	 $("#allsms").click(function(){
		 
		  if($(this).prop("checked"))
		  {
			  $(".thissms").prop("checked",true);
		  }
		  else
		  {
			  $(".thissms").prop("checked",false);
		  }
		 var sendmob = new Array();
		 sendmob=[];
		$.each($("input[class='thissms']:checked"), function(){
			sendmob.push($(this).attr("data-val"));
		});
		//alert(sendmob);
		$("#mob").val(sendmob);
		  
	   });
	   
	
	
	//var sendmob = new Array();
	
	
	$(".thissms").click(function() {
			sendmob=[];
			
		$.each($("input[class='thissms']:checked"), function(){
			sendmob.push($(this).attr("data-val"));
		});
		//var totmob='';
			
		//$.each(sendmob,function(){totmob+=(this)+"," || '';});
		
		
		$("#mob").val(sendmob);
		
	});
	///////////////upload Absent ////////
	 $("body").on("submit","#ssa_absent",function(e){
				//$("#subscribe").on('submit',(function(e) {
				e.preventDefault();
				
				$("#message").empty();
				$('#loader').show();
				$.ajax({
				url: "ssa_saveabsent.php", // Url to which the request is send
				type: "POST",             // Type of request to be send, called as method
				data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
				contentType: false,       // The content type used when sending data to the server.
				cache: false,             // To unable request pages to be cached
				processData:false,        // To send DOMDocument or non processed data file it is set to false
				success: function(data)   // A function to be called if request succeeds
				{
					$('#loader').hide();
					if(data!="")
					{
						$("#message").html(data);
						$("#ssa_absent").trigger("reset");
					}
				}
				});
				});
	///////////////Download Absent ////////
	 $("body").on("submit","#absentdnld",function(e){
				//$("#subscribe").on('submit',(function(e) {
				e.preventDefault();
				
				$("#message1").empty();
				$('#loader1').show();
				$.ajax({
				url: "ssa_exceldnd.php", // Url to which the request is send
				type: "POST",             // Type of request to be send, called as method
				data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
				contentType: false,       // The content type used when sending data to the server.
				cache: false,             // To unable request pages to be cached
				processData:false,        // To send DOMDocument or non processed data file it is set to false
				success: function(data)   // A function to be called if request succeeds
				{
					$('#loader1').hide();
					if(data!="")
					{
						$("#message1").html(data);
						$("#absentdnld").trigger("reset");
					}
				}
				});
				});
});
</script>
</body>
</html>
<!---Downlaod Modal ----------------------------------------->
<div id="dnldModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">All Absent Students Download : </h4>
      </div>
      <div class="modal-body">
	  <div class="row">
	  <form id="absentdnldfddf" method="post" action="exceldnd.php" enctype="multipart/form-data" class="form-horizontal" >
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Date :  </label>
		<div class="col-md-3">
		<input type="text" id="example-datepicker3" name="dos" value="<?php echo date("m/d/Y");?>" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy">
		</div>
		<label class="col-md-3 control-label" for="example-text-input">Download By : </label>
		<div class="col-md-3">
		<select name="dnldby" class="form-control ">
		<option value="bydate">Bydate</option>
		<option value="bymonth">ByMonth</option>
		<option value="byyear">ByYear</option>
		
		</select>
		</div>
		</div>
		
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Class : </label>
		<div class="col-md-9">
		<select class="form-control " id="sclass1" name="sclass" required >
			<option value="">Select Class</option>
			<option value="Nursery">Nursery</option>
			<option value="LKG">LKG</option>
			<option value="UKG">UKG</option>
			<option value="I">I</option>
			<option value="II">II</option>
			<option value="III">III</option>
			<option value="IV">IV</option>
			<option value="V">V</option>
			<option value="VI">VI</option>
			<option value="VII">VII</option>
			<option value="VIII">VIII</option>
			<option value="IX">IX</option>
			<option value="X">X</option>
			<option value="XI">XI</option>
			<option value="XII">XII</option>
			</select>
		</div>
		</div>
		
	<!---	<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Section :</label>
		<div class="col-md-9">
		<select class="form-control" id="section1" name="section">
		<option value="">Select Section</option>
		
		</select>
		</div>
		</div>
	  -->
       
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<input type="submit" name="submit" class="btn btn-primary" value="Download"/> 
		</div>
		</div>
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<img id="loader1" src="img/loader.gif" />
		<span id="message1"></span>
		</div>
		</div>
		
		</form>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!---Upload Absent Modal ----------------------------------------->

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">All Absent Students are : </h4>
      </div>
      <div class="modal-body">
	  <div class="row">
	  <form id="ssa_absent" method="post" enctype="multipart/form-data" class="form-horizontal" >
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Date :  </label>
		<div class="col-md-9">
		<input type="text" id="example-datepicker3" name="dos" value="<?php echo date("m/d/Y");?>" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy">
		
		</div>
		</div>
		
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Class : </label>
		<div class="col-md-9">
		<input type="text" name="sclass" class="form-control" value="<?php echo $_POST['sclass'];?>" readonly />
		</div>
		</div>
		
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Absent student ID :</label>
		<div class="col-md-9">
		<textarea id="mob" name="stuid" class="form-control" rows="5" style="resize:none;"></textarea>
		</div>
		</div>
	  
       
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<input type="submit" name="submit" class="btn btn-primary" value="Post Absent"/> 
		</div>
		</div>
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<img id="loader" src="img/loader.gif" />
		<span id="message"></span>
		</div>
		</div>
		
		</form>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>