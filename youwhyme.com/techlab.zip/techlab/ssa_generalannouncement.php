<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>All S.S.Arya Students </title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#loader{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>Our S.S.Arya Students Page <small>Every student is important for us.</small>
</h1>
</a>
</div>
All <input type="checkbox" name="" id="allsms" value="" />
<div class="table-responsive">
<table id="example-datatable" class="table table-bordered table-hover">
<thead>
<tr>
<th class="text-center">Sr. No. </th>
<th>Student</th>
<th>Father</th>
<th>Class</th>
<th>Contact</th>
<th>DOB.</th>
<th>Address.</th>

<th class="text-center">Actions</th>
</tr>
</thead>
<tbody>
<?php 
$i=1;
$sql=mysqli_query($con,"select * from ssa_student");
while($student=mysqli_fetch_array($sql))
{
	
?>
<tr>
<td class="text-center"><?php echo $i;?><br>
<input type="checkbox" class="thissms" name="" data-val="<?php echo $student['contact'];?>" id="check<?php echo $student['id'];?>" value="" />
</td>
<td><a href="ssa_student.php?edit_id=<?php echo $student['id'];?>"><?php echo $student['sname'];?></a></td>
<td><?php echo $student['father'];?></td>
<td><?php echo str_replace(",","<br>",$student['sclass']);?></td>
<td><?php echo str_replace(",","<br>",$student['contact']);?></td>
<td><?php echo date("d-M-Y",strtotime($student['dob']));?></td>
<td><?php echo $student['address'];?></td>

<td class="text-center">
<div class="btn-group">

<a href="ssa_student.php?edit_id=<?php echo $student['id'];?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
<a href="javascript:void(0)" data-toggle="modal" data-target="#myModal"  title="Send SMS" class="btn btn-xs btn-default sendsms"><i class="fa fa-envelope"></i></a>
<!--<a href="editclient.php?del_id=<?php echo $student['id'];?>" data-toggle="tooltip" title="Delete" class="btn btn-xs btn-default" onclick="return confirm('Are you want to Delete this Client');"><i class="fa fa-times"></i></a>
-->
</div>
</td>

</tr>
<?php 
$i++;
} 
?>

</table>
</div>




</div>
<?php include 'config/footer.php';?>

</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>

</body>
</html>
<script>
$(document).ready(function() {
	
	 $("body").on("click","#allsms",function(){
	 //$("#allsms").click(function(){
		 
		  if($(this).prop("checked"))
		  {
			  $(".thissms").prop("checked",true);
		  }
		  else
		  {
			  $(".thissms").prop("checked",false);
		  }
		 var sendmob = new Array();
		 sendmob=[];
		$.each($("input[class='thissms']:checked"), function(){
			sendmob.push($(this).attr("data-val"));
		});
		//alert(sendmob);
		$("#mob").val(sendmob);
		  
	   });
	   
	
	
	//var sendmob = new Array();
	
	$("body").on("click",".thissms",function() {
	//$(".thissms").click(function() {
			sendmob=[];
			
		$.each($("input[class='thissms']:checked"), function(){
			sendmob.push($(this).attr("data-val"));
		});
		//var totmob='';
			
		//$.each(sendmob,function(){totmob+=(this)+"," || '';});
		
		
		$("#mob").val(sendmob);
		
	});
	///////////////Send SMS////////
	 $("body").on("submit","#sendsms",function(e){
				//$("#subscribe").on('submit',(function(e) {
				e.preventDefault();
				
				$("#message").empty();
				$('#loader').show();
				$.ajax({
				url: "sendsms.php", // Url to which the request is send
				type: "POST",             // Type of request to be send, called as method
				data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
				contentType: false,       // The content type used when sending data to the server.
				cache: false,             // To unable request pages to be cached
				processData:false,        // To send DOMDocument or non processed data file it is set to false
				success: function(data)   // A function to be called if request succeeds
				{
					$('#loader').hide();
					if(data!="")
					{
						$("#message").html(data);
						$("#sendsms").trigger("reset");
					}
				}
				});
				});
});
</script>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Send SMS</h4>
      </div>
      <div class="modal-body">
	  <div class="row">
	  <form id="sendsms" method="post" enctype="multipart/form-data" class="form-horizontal" >
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Mobile No. </label>
		<div class="col-md-9">
		<input type="text" id="mob" name="mobile" value="" class="form-control" placeholder="Mobile No.">
		</div>
		</div>
	  
       <div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea">Message</label>
		<div class="col-md-9">
		<textarea id="small-textarea" name="message" rows="5" maxlength="140" class="form-control" placeholder="Write Message in maximum 140 characters"></textarea>
		</div>
		</div>
		 <div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<input type="submit" name="submit" class="btn btn-primary" value="Send"/> 
		</div>
		</div>
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<img id="loader" src="img/loader.gif" />
		<span id="message"></span>
		</div>
		</div>
		
		</form>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>