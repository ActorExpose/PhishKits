<?php
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$mb='<option value="">Select Section</option>';
$class=isset($_POST['class'])?mysqli_real_escape_string($con,$_POST['class']):'';
$query=mysqli_query($con,"select distinct(section) from ssa_student where sclass='".$class."' order by section");
while($row=mysqli_fetch_array($query) )
{
	$mb.='<option value="'.$row['section'].'">'.$row['section'].'</option>';
}
echo $mb;
?>