<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php';
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
	if(isset($_POST['submit']) && $_POST['submit']=="Save Homework")
	{
	$pdate=Date('Y-m-d h:i:s');
	$class=mysqli_real_escape_string($con,$_POST['sclass']);
	
	
	
	if($class!="" or $_FILES["hwfile"]["name"]!='')
	{
		if(isset($_REQUEST['hid']) and $_REQUEST['hid']!='')
		{
			$fsql=mysqli_fetch_array(mysqli_query($con,"select * from homework where class='$class'"));
			unlink("../hwfile/".$fsql['hwfile']);
			$sql="update homework set class='$class' where id='".$_REQUEST['hid']."'";
			$res=mysqli_query($con,$sql);
			$id=$_REQUEST['hid'];
		}
		else
		{
			$nsql=mysqli_num_rows(mysqli_query($con,"select * from homework where class='".$class."'"));
			if($nsql<1)
			{
				$sql="insert into homework set class='$class'";
				$res=mysqli_query($con,$sql);
				$id=mysqli_insert_id($con);
			}
			else
			{
				exit();
			}
			
		}
		//echo $sql;
		if($_FILES["hwfile"]["name"]!='')
		{
			$extension = end(explode(".", $_FILES["hwfile"]["name"]));
			$imagename=$id.".";
			if($extension=='doc' or $extension=='docx' or $extension=='pdf' or $extension=='jpg' or $extension=='JPG' or $extension=='jpeg' or $extension=='JPEG' or $extension=='png' or $extension=='PNG')
			{
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["hwfile"]["tmp_name"], "../hwfile/".$filename);
				$usql="update homework set hwfile='$filename' where id='$id'";
				$upd_img=mysqli_query($con,$usql);
			}
			
			
		}
		
		header('Location:homework.php');
	}
		
	}
	if(isset($_REQUEST['edit_id']))
	{
		$edit_info=mysqli_query($con,"select * from homework where id='".mysqli_real_escape_string($con, $_REQUEST['edit_id'])."'");	
		$row=mysqli_fetch_array($edit_info);
		$sclass=$row['class'];
	}
	if(isset($_REQUEST['del_id']))
	{
		$ss=mysqli_fetch_array(mysqli_query($con,"select * from homework where id='".mysqli_real_escape_string($con, $_REQUEST['del_id'])."'"));
		unlink("../hwfile/".$ss['hwfile']);
		mysqli_query($con,"delete from homework where id='".mysqli_real_escape_string($con, $_REQUEST['del_id'])."'");	
		header('Location:homework.php');
		
	}
?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Holiday Homework </title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#loader1,#loader{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>
<i class="fa fa-camera-retro animation-expandUp"></i>Holiday Homework<br><small>Main Page Notice Editable Form</small>
</h1>
</a>
</div>
<ul class="breadcrumb breadcrumb-top">
<li><i class="fa fa-cog"></i></li>
<li><a href="homework.php">Holiday Homework</a></li>
</ul>
<!--<input type="button" class="btn btn-success" data-toggle="modal" data-target="#dnldModal" value="Download"/> -->

<div class="block full">
<div class="block-title">
<h2><i class="fa fa-cloud-upload"></i> Select Class for Holiday Homework </h2>
</div>
<form action="homework.php" method="post" enctype="multipart/form-data" class="form-horizontal">
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Select Class </label>
<div class="col-md-5">
<select class="form-control" id="sclass" name="sclass">
<option value="">Select Class</option>
<?php 
if($sclass!='')
{
	echo '<option value="'.$sclass.'" selected>'.$sclass.'</option>';
}
?>
<option value="Nursery">Nursery</option>
<option value="LKG">LKG</option>
<option value="UKG">UKG</option>
<option value="I">I</option>
<option value="II">II</option>
<option value="III">III</option>
<option value="IV">IV</option>
<option value="V">V</option>
<option value="VI">VI</option>
<option value="VII">VII</option>
<option value="VIII">VIII</option>
<option value="IX">IX</option>
<option value="X">X</option>
<option value="XI">XI</option>
<option value="XII">XII</option>
</select>
</div>

</div>
<div class="form-group">
<div class="col-md-12 col-md-offset-0">
<label class="col-md-3 control-label" for="example-text-input">Upload Homework </label>
<div class="col-md-4">
<input type="file" name="hwfile" class="form-control" />
</div>
</div>
</div>

<div class="form-group">
<div class="col-md-12 col-md-offset-5">
<input type="hidden" name="hid" class="form-control" value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Save Homework"/> 

</div>
</div>
</form>

</div>


<div class="row gutter30">
<div class="col-md-12">
<div class="block">
<div class="block-title">
<h2><i class="fa fa-camera-retro"></i> All Homeworks are :</h2>
</div>

<div class="table-responsive">
<table id="example-datatable" class="table table-bordered table-hover">
<thead>
<tr>
<th class="text-center"> All</th>
<th>Class</th>
<th>Homework</th>

<th class="text-center">Action</th>
</tr>
</thead>
<tbody>
<?php 
$sql=mysqli_query($con,"select * from homework order by class");
$i=1;
while($student=mysqli_fetch_array($sql))
{
	
?>
<tr>
<td class="text-center">
 <?php echo $i;?></td>
<td><?php echo $student['class'];?></td>

<td><a href="../hwfile/<?php echo $student['hwfile'];?>" download="homework">Click to Download </a></td>

<td class="text-center">
<div class="btn-group33">
<a href="homework.php?edit_id=<?php echo $student['id'];?>"   title="Edit Homework" class="btn btn-xs btn-default "><i class="fa fa-pencil"></i></a> &nbsp;
<a href="homework.php?del_id=<?php echo $student['id'];?>" onclick="return confirm('Are You want to Delete this Homework');"  title="Delete Homework" class="btn btn-xs btn-danger "><i class="fa fa-trash"></i></a>
</div>
</td>

</tr>
<?php 
$i++;
} 
?>

</table>
</div>
</div>
</div>
</div>

</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	</script>
	<script>
$(document).ready(function(){
	$("#sclass").change(function(e){
		e.preventDefault();
		var v= $(this).val();
		//alert(v);
		var dataString="class="+v;
		$.ajax({
			url: "findsection.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: dataString,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#section').html(data);
			
			}
		});
	} );
	//////////////////////////////////////////
	$("#sclass1").change(function(e){
		e.preventDefault();
		var v= $(this).val();
		//alert(v);
		var dataString="class="+v;
		$.ajax({
			url: "findsection.php", // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: dataString,//new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			//contentType: false,       // The content type used when sending data to the server.
			//cache: false,             // To unable request pages to be cached
			//processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
			$('#section1').html(data);
			
			}
		});
	} );
	

} );
</script>
<script>
$(document).ready(function() {
	
	 $("#allsms").click(function(){
		 
		  if($(this).prop("checked"))
		  {
			  $(".thissms").prop("checked",true);
		  }
		  else
		  {
			  $(".thissms").prop("checked",false);
		  }
		 var sendmob = new Array();
		 sendmob=[];
		$.each($("input[class='thissms']:checked"), function(){
			sendmob.push($(this).attr("data-val"));
		});
		//alert(sendmob);
		$("#mob").val(sendmob);
		  
	   });
	   
	
	
	//var sendmob = new Array();
	
	
	$(".thissms").click(function() {
			sendmob=[];
			
		$.each($("input[class='thissms']:checked"), function(){
			sendmob.push($(this).attr("data-val"));
		});
		//var totmob='';
			
		//$.each(sendmob,function(){totmob+=(this)+"," || '';});
		
		
		$("#mob").val(sendmob);
		
	});
	///////////////upload Absent ////////
	 $("body").on("submit","#homework",function(e){
				//$("#subscribe").on('submit',(function(e) {
				e.preventDefault();
				
				$("#message").empty();
				$('#loader').show();
				$.ajax({
				url: "saveabsent.php", // Url to which the request is send
				type: "POST",             // Type of request to be send, called as method
				data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
				contentType: false,       // The content type used when sending data to the server.
				cache: false,             // To unable request pages to be cached
				processData:false,        // To send DOMDocument or non processed data file it is set to false
				success: function(data)   // A function to be called if request succeeds
				{
					$('#loader').hide();
					if(data!="")
					{
						$("#message").html(data);
						$("#homework").trigger("reset");
					}
				}
				});
				});
	///////////////Download Absent ////////
	 $("body").on("submit","#absentdnld",function(e){
				//$("#subscribe").on('submit',(function(e) {
				e.preventDefault();
				
				$("#message1").empty();
				$('#loader1').show();
				$.ajax({
				url: "exceldnd.php", // Url to which the request is send
				type: "POST",             // Type of request to be send, called as method
				data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
				contentType: false,       // The content type used when sending data to the server.
				cache: false,             // To unable request pages to be cached
				processData:false,        // To send DOMDocument or non processed data file it is set to false
				success: function(data)   // A function to be called if request succeeds
				{
					$('#loader1').hide();
					if(data!="")
					{
						$("#message1").html(data);
						$("#absentdnld").trigger("reset");
					}
				}
				});
				});
});
</script>
</body>
</html>
<!---Downlaod Modal ----------------------------------------->
<div id="dnldModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">All Holiday Homeworks Download : </h4>
      </div>
      <div class="modal-body">
	  <div class="row">
	  <form id="absentdnldfddf" method="post" action="exceldnd.php" enctype="multipart/form-data" class="form-horizontal" >
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Date :  </label>
		<div class="col-md-3">
		<input type="text" id="example-datepicker3" name="dos" value="<?php echo date("m/d/Y");?>" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy">
		</div>
		<label class="col-md-3 control-label" for="example-text-input">Download By : </label>
		<div class="col-md-3">
		<select name="dnldby" class="form-control ">
		<option value="bydate">Bydate</option>
		<option value="bymonth">ByMonth</option>
		<option value="byyear">ByYear</option>
		
		</select>
		</div>
		</div>
		
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Class : </label>
		<div class="col-md-9">
		<select class="form-control " id="sclass1" name="sclass" required >
			<option value="">Select Class</option>
			<option value="Nursery">Nursery</option>
			<option value="LKG">LKG</option>
			<option value="UKG">UKG</option>
			<option value="I">I</option>
			<option value="II">II</option>
			<option value="III">III</option>
			<option value="IV">IV</option>
			<option value="V">V</option>
			<option value="VI">VI</option>
			<option value="VII">VII</option>
			<option value="VIII">VIII</option>
			<option value="IX">IX</option>
			<option value="X">X</option>
			<option value="XI">XI</option>
			<option value="XII">XII</option>
			</select>
		</div>
		</div>
		
	<!---	<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Section :</label>
		<div class="col-md-9">
		<select class="form-control" id="section1" name="section">
		<option value="">Select Section</option>
		
		</select>
		</div>
		</div>
	  -->
       
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<input type="submit" name="submit" class="btn btn-primary" value="Download"/> 
		</div>
		</div>
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<img id="loader1" src="img/loader.gif" />
		<span id="message1"></span>
		</div>
		</div>
		
		</form>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!---Upload Absent Modal ----------------------------------------->

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">All Holiday Homeworks are : </h4>
      </div>
      <div class="modal-body">
	  <div class="row">
	  <form id="homework" method="post" enctype="multipart/form-data" class="form-horizontal" >
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Date :  </label>
		<div class="col-md-9">
		<input type="text" id="example-datepicker3" name="dos" value="<?php echo date("m/d/Y");?>" class="form-control input-datepicker-close text-left" data-date-format="mm/dd/yyyy" placeholder="mm/dd/yyyy">
		
		</div>
		</div>
		
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Class : </label>
		<div class="col-md-9">
		<input type="text" name="sclass" class="form-control" value="<?php echo $_POST['sclass'];?>" readonly />
		</div>
		</div>
		
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Absent student ID :</label>
		<div class="col-md-9">
		<textarea id="mob" name="stuid" class="form-control" rows="5" style="resize:none;"></textarea>
		</div>
		</div>
	  
       
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<input type="submit" name="submit" class="btn btn-primary" value="Post Absent"/> 
		</div>
		</div>
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<img id="loader" src="img/loader.gif" />
		<span id="message"></span>
		</div>
		</div>
		
		</form>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>