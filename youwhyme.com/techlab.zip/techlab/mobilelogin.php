<?php
session_start();
include 'config/configuration.php';
error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
$dop=Date('Y-m-d');
$_SESSION['otp'] = rand(1000,5000);
$otpmsg="Your Arsh Optical Login verfication OTP is ".$_SESSION['otp'];

$mobile=isset($_POST['mobile'])?mysqli_real_escape_string($con,$_POST['mobile']):'';
$nsql=mysqli_num_rows(mysqli_query($con,"select * from arsh_new_usr where usr_mobile='".$mobile."' and mob_active='1' and admin_active='yes'"));
if($nsql>0)
{
	$_SESSION['mobile']=$mobile;
	
	// sms gateway.................
			$data="key=35878B4953A805&routeid=230&type=text&contacts=".$mobile."&senderid=ARSOPT&msg=".$otpmsg;
						
			$url="http://www.shinenetcor.com/app/smsapi/index.php?";
			
			 function postdata($url,$data)
				{
					$objURL = curl_init($url);
					curl_setopt($objURL, CURLOPT_RETURNTRANSFER, 1); 
					curl_setopt($objURL,CURLOPT_POST,1);
					curl_setopt($objURL, CURLOPT_POSTFIELDS,$data);
					$retval = trim(curl_exec($objURL));
					curl_close($objURL);
					//echo $retval;
					
				}
				postdata($url,$data);
				
			//sms gateway.................
			
	echo "Success";
}
else{
	echo "Mobile Number Not registered or Not Verified by Arsh Optical";
}

?>