<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
	$error='';
	if(isset($_POST['submit']) and $_POST['submit']=="Submit")
	{
		$pname=mysqli_real_escape_string($con,$_POST['pname']);
		$title=mysqli_real_escape_string($con,$_POST['title']);
		$content=mysqli_real_escape_string($con,$_POST['content']);
		$mtitle=mysqli_real_escape_string($con,$_POST['mtitle']);
		$mdes=mysqli_real_escape_string($con,$_POST['mdes']);
		$mkey=mysqli_real_escape_string($con,$_POST['mkey']);
		
		
		if($_FILES["image1"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["image1"]["name"]));
			$imageFilesize = $_FILES["image1"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif")) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($_FILES["image2"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["image2"]["name"]));
			$imageFilesize = $_FILES["image2"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif")) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($_FILES["image3"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["image3"]["name"]));
			$imageFilesize = $_FILES["image3"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif")) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($_FILES["image4"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["image4"]["name"]));
			$imageFilesize = $_FILES["image4"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif")) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($_FILES["image5"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["image5"]["name"]));
			$imageFilesize = $_FILES["image5"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif")) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		
		
		if($error=='')
		{
			if($_POST['edit']!='')
			{
				$id=$_POST['edit'];
				$usql="update page set pname='".$pname."',content='".$content."' where id='".$_POST['edit']."'";
				$upd_img=mysqli_query($con,$usql);
				
				header('Location:cms.php');
			}
			else
			{
				//New Testimonial 
					//$sql=mysqli_query($con,"insert into page set pname='".$pname."',title='".$pname."',content='$content',mtitle='".$mtitle."',mdes='".$mdes."',mkey='".$mkey."'");
					$sql=mysqli_query($con,"insert into page set pname='".$pname."',content='$content'");
					$id=mysqli_insert_id($con);
					?>
					<script>
					alert("New About Us Saved Successfully");
					window.location="cms.php";
					</script>
					<?php
			}
				if($_FILES["image1"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["image1"]["name"]));
				$imagename=$id."1.";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["image1"]["tmp_name"], "../pageimg/".$filename);
				$usql="update page set image1='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
				if($_FILES["image2"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["image2"]["name"]));
				$imagename=$id."2.";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["image2"]["tmp_name"], "../pageimg/".$filename);
				$usql="update page set image2='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
				if($_FILES["image3"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["image3"]["name"]));
				$imagename=$id."3.";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["image3"]["tmp_name"], "../pageimg/".$filename);
				$usql="update page set image3='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
				if($_FILES["image4"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["image4"]["name"]));
				$imagename=$id."4.";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["image4"]["tmp_name"], "../pageimg/".$filename);
				$usql="update page set image4='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
				if($_FILES["image5"]["name"]!='')
				{
				$extension = end(explode(".", $_FILES["image5"]["name"]));
				$imagename=$id."5.";
				$filename=$imagename.$extension;
				move_uploaded_file($_FILES["image5"]["tmp_name"], "../pageimg/".$filename);
				$usql="update page set image5='$filename' where id='".$id."'";
				$upd_img=mysqli_query($con,$usql);
				}
				
		}
		
	}
	if(isset($_GET['edit_id']) and $_GET['edit_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['edit_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"select * from page where id='".$id."'"));
		$pname=$crow['pname'];
		$content=$crow['content'];
		$image1=$crow['image1'];
		$image2=$crow['image2'];
		$image3=$crow['image3'];
		$image4=$crow['image4'];
		$image5=$crow['image5'];
		
	}
if(isset($_GET['del_id']) and $_GET['del_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['del_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"Select * from page where id='".$id."'"));
		$image=$crow['image'];
		unlink("../pageimg/".$image);
		mysqli_query($con,"delete from page where id='".$id."'");
		
	}


?>
<!DOCTYPE html>
<html class="no-js"> 
<head>
<meta charset="utf-8">
<title>CMS Page Edit</title>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#loader{display:none;}
</style>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link"><h1> CMS Page</h1></a>
</div>
<?php 
/*if(isset($_REQUEST['edit_id']) and $_REQUEST['edit_id']!='')
	{
		*/
?>
<div class="row">
<div class="col-md-12">
<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" >
<div class="col-md-12">

<div class="block-title">
<h2>CMS Information</h2>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Select Page </label>
<div class="col-md-5">
<select class="form-control" id="cms">
<option value="">Select Page</option>
<option value="About">About</option>
<option value="Admission">Admission</option>
<option value="Mission">Mission</option>
<option value="Vision">Vision</option>
<option value="Principal">Principal</option>
<option value="Manager">Manager</option>
<option value="Founder">Founder</option>

<option value="Transport">Transport</option>
<option value="Medical">Medical</option>
<option value="Games">Games</option>
<option value="Computer">Computer</option>
<option value="Art">Art</option>
</select>
</div>
<div class="col-md-4">
<input type="text" id="pname" name="pname" class="form-control" readonly value="<?php echo $pname; ?>">
</div>
</div>
<!--
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Title </label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="title" class="form-control" placeholder=" Title" maxlength="50" value="<?php echo $title;?>" >

</div>
</div>
-->
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Content </label>
<div class="col-md-9">
<textarea name="content" class="form-control textarea-editor" rows="15" style="resize:none;" placeholder=" Content" ><?php echo $content;?></textarea>

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Image1 </label>
<div class="col-md-4">
<input type="file" name="image1" id="uploadinput1" onchange="uploadimg(1);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image1!='' and file_exists("../pageimg/".$image1))
{
	echo '<img src="../pageimg/'.$image1.'" style="height:100px;width:200px;" id="upload1"/>';
}
else
{
	echo '<img src="img/noimage.png" style="height:100px;width:200px;" id="upload1"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Image2 </label>
<div class="col-md-4">
<input type="file" name="image2" id="uploadinput2" onchange="uploadimg(2);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image2!='' and file_exists("../pageimg/".$image2))
{
	echo '<img src="../pageimg/'.$image2.'" style="height:100px;width:200px;" id="upload2"/>';
}
else
{
	echo '<img src="img/noimage.png" style="height:100px;width:200px;" id="upload2"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Image3 </label>
<div class="col-md-4">
<input type="file" name="image3" id="uploadinput3" onchange="uploadimg(3);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image3!='' and file_exists("../pageimg/".$image3))
{
	echo '<img src="../pageimg/'.$image3.'" style="height:100px;width:200px;" id="upload3"/>';
}
else
{
	echo '<img src="img/noimage.png" style="height:100px;width:200px;" id="upload3"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Image4 </label>
<div class="col-md-4">
<input type="file" name="image4" id="uploadinput4" onchange="uploadimg(4);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image4!='' and file_exists("../pageimg/".$image4))
{
	echo '<img src="../pageimg/'.$image4.'" style="height:100px;width:200px;" id="upload4"/>';
}
else
{
	echo '<img src="img/noimage.png" style="height:100px;width:200px;" id="upload4"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Image5 </label>
<div class="col-md-4">
<input type="file" name="image5" id="uploadinput5" onchange="uploadimg(5);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image5!='' and file_exists("../pageimg/".$image5))
{
	echo '<img src="../pageimg/'.$image5.'" style="height:100px;width:200px;" id="upload5"/>';
}
else
{
	echo '<img src="img/noimage.png" style="height:100px;width:200px;" id="upload5"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>


<div class="form-group">
<div class="col-md-12 col-md-offset-2">
<input type="hidden" name="edit" class="form-control" value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<a href="cms.php" class="btn btn-default"><i class="fa fa-times"></i> New</a>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>

</div>

</form>
</div>

</div>

All CMS Pages are :
<div class="table-responsive">
<table id="example-datatable" class="table table-bordered table-hover">
<thead>
<tr>
<th>Sr. No.</th>
<th>Page</th>
<th>Content</th>
<th>Image1</th>
<th>Image2</th>


<th class="text-center">Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
$cmssql=mysqli_query($con,"select * from page");
while($cmsrow=mysqli_fetch_array($cmssql) )
{
	?>
	<tr>
<td><?php echo $i; $i++;?></td>	

<td><?php echo $cmsrow['pname'];?></td>
<td style="width:500px;"><?php echo substr(strip_tags($cmsrow['content']),0,200);?></td>
<td><?php 
if($cmsrow['image1']!='' and file_exists("../pageimg/".$cmsrow['image1']) )
{
	echo '<img src="../pageimg/'.$cmsrow['image1'].'"j height="60" width="50" />';
}


?></td>
<td><?php 
if($cmsrow['image2']!='' and file_exists("../pageimg/".$cmsrow['image2']) )
{
	echo '<img src="../pageimg/'.$cmsrow['image2'].'"j height="60" width="50" />';
}


?></td>

<td class="text-center">
<a href="cms.php?edit_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>

<a href="cms.php?del_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Delete" class="btn btn-xs btn-default" onclick="return confirm('Are you want to Delete this member');"><i class="fa fa-times"></i></a>



</td>
</tr>
	
	<?php 
}
?>


</tbody>
</table>
</div>



</div>








<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script>
$(document).ready(function(){
	$("#cms").change(function(){
		var v= $(this).val();
		$("#pname").val(v);
	} );
} );
</script>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            //document.getElementById("image"+a).src = oFREvent.target.result;
			document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
</script>
<script type="text/javascript">
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	//if(charCode==46){return true;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
</body>
</html>