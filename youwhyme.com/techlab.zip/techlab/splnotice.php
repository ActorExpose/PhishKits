<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include 'config/candidate_login_check.php';
date_default_timezone_set("Asia/Kolkata");

//$n=Date('Y-m-d');
	//$pdate=Date('Y-m-d H:i:s');
	$error='';
	if(isset($_POST['submit']) and $_POST['submit']=="Submit")
	{
		$notice=mysqli_real_escape_string($con,$_POST['notice']);
		
		$active=isset($_POST['active'])?mysqli_real_escape_string($con,$_POST['active']):'no';
		
		if($_FILES["bannerimg"]["name"]!='')
		{
			$imageFileType = end(explode(".", $_FILES["bannerimg"]["name"]));
			$imageFilesize = $_FILES["bannerimg"]["size"];
			//echo $imageFileType;
			if(($imageFileType != "jpg" and $imageFileType != "png" and $imageFileType != "jpeg" and $imageFileType != "gif") or $imageFilesize>100000000) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$error = "Error: Image Type or Size Not Supported";
			}
		}
		if($error=='')
		{
			if($_POST['edit']!='')
			{
				$id=$_POST['edit'];
				$usql="update splnotice set notice='".$notice."',onhome='".$active."' where id='".$_POST['edit']."'";
				$upd_img=mysqli_query($con,$usql);
				?>
				<script>
				alert("Notice Updated Successfully");
				</script>
				<?php
				header('Location:splnotice.php');
			}
			else
			{
				//New Notice 
					$sql=mysqli_query($con,"insert into splnotice set notice='".$notice."',onhome='".$active."'");
					$id=mysqli_insert_id($con);
					?>
					<script>
					alert("New Notice Saved Successfully");
					window.location="splnotice.php";
					</script>
					<?php
			}
				
		}
		
	}
	if(isset($_GET['edit_id']) and $_GET['edit_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['edit_id']);
		$crow=mysqli_fetch_array(mysqli_query($con,"select * from splnotice where id='".$id."'"));
		$notice=$crow['notice'];
		//$vlink=$crow['vlink'];
		//$image=$crow['image'];
		$active=$crow['onhome'];
		
		
	}
if(isset($_GET['del_id']) and $_GET['del_id']!='')
	{
		$id=mysqli_real_escape_string($con,$_GET['del_id']);
		//$crow=mysqli_fetch_array(mysqli_query($con,"Select * from splnotice where id='".$id."'"));
		//$image=$crow['image'];
		//unlink("bannerimg/".$image);
		mysqli_query($con,"delete from splnotice where id='".$id."'");
		
	}

?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Special Notice </title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
</head>
<body class="header-fixed-top">
<?php include 'config/leftmenu.php'; ?>
<?php include 'config/rightbar.php'; ?>

<div id="page-container">
<?php include 'config/headersetting1.php';?>

<div id="fx-container" class="fx-opacity">
<div id="page-content" class="block">
<div class="block-header">
<a href="" class="header-title-link">
<h1>
<i class="fa fa-camera-retro animation-expandUp"></i>Special Notice<br><small>Main Page Notice Editable Form</small>
</h1>
</a>
</div>
<ul class="breadcrumb breadcrumb-top">
<li><i class="fa fa-cog"></i></li>
<li><a href="splnotice.php">Special Notice</a></li>
</ul>

<div class="block full">
<div class="block-title">
<h2><i class="fa fa-cloud-upload"></i> Notice Upload </h2>
</div>
<form action="splnotice.php" method="post" enctype="multipart/form-data" class="form-horizontal">

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Notice</label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="notice" class="form-control" placeholder="Title" maxlength="240" value="<?php echo $notice?>">

</div>
</div>
<!-----
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Link</label>
<div class="col-md-9">
<input type="text" id="example-text-input" name="vlink" class="form-control" placeholder="Link" maxlength="350" value="<?php echo $vlink;?>">

</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input">Notice Link</label>
<div class="col-md-4">
<input type="file" name="bannerimg" id="uploadinput1" onchange="uploadimg(1);">
</div>
<div class="col-md-5">
<?php 
if($_REQUEST['edit_id']!='' and $image!='' and file_exists("bannerimg/".$image))
{
	echo '<img src="bannerimg/'.$image.'" style="height:100px;width:200px;" id="upload1"/>';
}
else
{
	echo '<img src="../img/noimage.png" style="height:100px;width:200px;" id="upload1"/>';
}
?>
<span class="help-block">Upload minimum 450 x 200 resolution jpg Image</span>
</div>
</div>---->
<div class="form-group">
<label class="col-md-3 control-label" for="example-text-input"> Active on Home</label>
<div class="col-md-9">
<input type="checkbox" value="yes" name="active" <?php if($active=='yes'){echo 'checked';}?> /> Check For Active
<span class="help-block"></span>
</div>
</div>
<div class="form-group">
<div class="col-md-12 col-md-offset-5">
<input type="hidden" name="edit" class="form-control" value="<?php echo mysqli_real_escape_string($con,$_GET['edit_id']);?>">
<button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Reset</button>
<input type="submit" name="submit" class="btn btn-primary" value="Submit"/> 
</div>
</div>
</form>
</div>


<div class="row gutter30">
<div class="col-md-12">
<div class="block">
<div class="block-title">
<h2><i class="fa fa-camera-retro"></i> All Notice Editable </h2>
</div>

<div class="table-responsive">
<table id="example-datatable" class="table table-bordered table-hover">
<thead>
<tr>
<th>Sr. No.</th>
<th> Notice</th>
<th> On Home</th>



<th class="text-center">Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
$cmssql=mysqli_query($con,"select * from splnotice");
while($cmsrow=mysqli_fetch_array($cmssql) )
{
	?>
	<tr>
<td><?php echo $i; $i++;?></td>	
<td><?php echo $cmsrow['notice'];?></td>
<td><?php echo $cmsrow['onhome'];?></td>



<td class="text-center">
<a href="splnotice.php?edit_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>

<a href="splnotice.php?del_id=<?php echo $cmsrow['id'];?>" data-toggle="tooltip" title="Delete" class="btn btn-xs btn-default" onclick="return confirm('Are you want to Delete this member');"><i class="fa fa-times"></i></a>



</td>
</tr>
	
	<?php 
}
?>


</tbody>
</table>
</div>
</div>
</div>
</div>

</div>
<?php include 'config/footer.php';?>
</div>
</div>
<a href="javascript:void(0)" id="to-top"><i class="fa fa-angle-up"></i></a>
<script type="text/javascript">
    function uploadimg(a) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadinput"+a).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("upload"+a).src = oFREvent.target.result;
        };
    }
	</script>
</body>
</html>