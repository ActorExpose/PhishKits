<?php
error_reporting(0);
session_start();
include 'config/configuration.php';
include'config/login_check.php'; 
date_default_timezone_set("Asia/Kolkata");
$date=date("Y-m-d");
		$by = isset($_REQUEST['dnldby'])?mysqli_real_escape_string($con,$_REQUEST['dnldby']):'';
		$sclass=isset($_REQUEST['sclass'])?mysqli_real_escape_string($con,$_REQUEST['sclass']):'';
		$todate = isset($_REQUEST['dos'])?mysqli_real_escape_string($con,$_REQUEST['dos']):'';
		$todate=Date('Y-m-d',strtotime($todate));
	
		if($by=='bydate')
		{
			$date=$todate;
			$sql=mysqli_query($con,"select * from ssa_absent where sdate='".$todate."' and sclass='".$sclass."'");
		}
		else if($by=='bymonth')
		{
			
			$mm=date("m",strtotime($todate));
			$sql=mysqli_query($con,"select * from ssa_absent where month(sdate)='".$mm."' and sclass='".$sclass."'");
		}
		else if($by=='byyear')
		{
			$date=date("Y",strtotime($todate));
			$yy=date("Y",strtotime($todate));
			$sql=mysqli_query($con,"select * from ssa_absent where year(sdate)='".$yy."' and sclass='".$sclass."'");
		}
		//echo $sql;
		
		
			 $setMainHeader = "ABSENT STUDENT LIST \n Date \t RollNo \t Name \t Father's Name \t Contact No \n ";
			 $rowLine='';
			while($row1=mysqli_fetch_array($sql))
			{
					
					$id=explode(",",$row1['stid']);
					foreach ($id as $value)
					{
						
						$row=mysqli_fetch_array(mysqli_query($con,"select * from ssa_student where id='".$value."'" ) );
					
					$rowLine.= date("d-M-Y",strtotime($row1['sdate']))." \t ".$row['rollno']."\t ".$row['sname']." \t ".$row['father']." \t ".$row['contact']." \n ";
				
					
					}
				
			}
			
			//echo $rowLine;
			
			 $setData = str_replace("\r", "", $rowLine);

			if ($setData == "") {
			  $setData = "\n  \n";
			}

			//$setCounter = mysql_num_fields($setRec);



			//This Header is used to make data download instead of display the data
			 header("Content-type: application/octet-stream");

			header("Content-Disposition: attachment; filename=AbsentStudent_".$date.".xls");

			header("Pragma: no-cache");
			header("Expires: 0");

			//It will print all the Table row as Excel file row with selected column name as header.
			echo ucwords($setMainHeader)."\n".$setData."\n";

?>