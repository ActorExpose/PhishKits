<?php
session_start();
include 'config/configuration.php';
error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
$dop=Date('Y-m-d');
$_SESSION['otp'] = rand(1000,5000);
$otpmsg="Your Arsh Optical Sign UP verfication OTP is ".$_SESSION['otp'];

$uname=isset($_POST['username'])?mysqli_real_escape_string($con,$_POST['username']):'';
$company=isset($_POST['company'])?mysqli_real_escape_string($con,$_POST['company']):'';
$tin=isset($_POST['tin'])?mysqli_real_escape_string($con,$_POST['tin']):'';
$address=isset($_POST['tin'])?mysqli_real_escape_string($con,$_POST['address']):'';
$mobile=isset($_POST['mobile'])?mysqli_real_escape_string($con,$_POST['mobile']):'';
$email=isset($_POST['email'])?mysqli_real_escape_string($con,$_POST['email']):'';
$pwd=isset($_POST['password'])?mysqli_real_escape_string($con,$_POST['password']):'';
if (preg_match('/[A-Za-z]+[0-9]+/', $pwd) and strlen($pwd)>5)
{
$hash = md5( rand(1000000,99999999) );
$_SESSION['mobile']=$mobile;
$csql=mysqli_num_rows(mysqli_query($con,"select * from arsh_new_usr where usr_email='".$email."' or usr_mobile='".$mobile."'"));
if($csql<1)
{
	$sql="insert into arsh_new_usr set usr_name='".$uname."',company='".$company."',address='".$address."', usr_mobile='".$mobile."', usr_pwd='".md5($pwd)."',tin='".$tin."', usr_email='".$email."', usr_hash='".$hash."'";
	mysqli_query($con,$sql);


	$to      = $email; // Send email to our user
	$subject = 'Signup | Verification'; // Give the email a subject 
	/*$message = '<!doctype html>				<head><title>Notification From Arsh Optical</title></head>
				<body style="padding:15px;background:url("http://www.goforaudition.com/gofor/img/bg.jpg");">
				<div style="background:#fff;border:1px solid #e5e5e5;box-shadow:0px 0px 5px #e5e5e5;padding:15px;" >
				<div style="height:60px;width:100%;background:#383431;">
				<a href="http://www.goforaudition.com" target="_blank"><img src="http://www.goforaudition.com/img/logo.png" style="height:50px;margin:15px;" /></a>
				</div>
				<div style="background:#e5e5e5; padding:10px;">
				<p style="margin:2px;font-weight:bold;color:#2196f3;">SignUp Details</p>
				Thanks for signing up!
				Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.
				<table style="width:100%;">
				<tr><td style="font-weight:bold">User Name :</td><td>'.$email.'</td></tr>
				<tr><td style="font-weight:bold">Password :</td><td>'.$pwd.'</td></tr>
				
				</table>
				
					
				</div>
				<p style="">Please click this link to activate your email-id at Arsh Optical: <a href="http://www.goforaudition.com/verify.php?email='.$email.'&hash='.$hash.'" target="_blank" >Verify Email </a></p>
				<p style="margin-bottom:0px;">Thank You</p>
				<p style="margin-top:0px;font-weight:bold;font-size:19px;">Team Arsh Optical</p>
				</div>
				<ul style="padding:0px;list-style:none;color:#2196f3;font-weight:bold">
				<li style="width:32%;text-align:center;float:left;">16000+ Job Listing</li>
				<li style="width:32%;text-align:center;float:left;border-left:1px solid silver;border-right:1px solid silver;">126000+ Talent Applied</li>
				<li style="width:32%;text-align:center;float:left;">3000+ Audition Appeared</li>
				</ul>
				<div style="margin:30px auto;text-align:center;margin-top:50px;">
				<a href="http://www.facebook.com" target="_blank"><img src="http://www.goforaudition.com/gofor/img/fb.png" style="height:38px;"/></a>
				<a href="http://www.twitter.com" target="_blank"><img src="http://www.goforaudition.com/gofor/img/tw.png" style="height:40px;"/></a>
				<a href="http://www.google.com" target="_blank"><img src="http://www.goforaudition.com/gofor/img/gp.png" style="height:40px;"/></a>
				<a href="http://www.linkedin.com" target="_blank"><img src="http://www.goforaudition.com/gofor/img/lin.png" style="height:40px;"/></a>
				<a href="http://www.youtube.com" target="_blank"><img src="http://www.goforaudition.com/gofor/img/ytb.png" style="height:40px;"/></a>

				</div>
				<p style="text-align:center;margin:0px;font-size:16px;">You are receiving this mail from Arsh Optical</p>
				<p style="text-align:center;margin:0px;font-size:16px;">For any assistance, Visit our website or write to us at <br> <a href="mailto:info@goforaudition.com">info@goforaudition.com</a><br> &copy; <a href="http://www.goforaudition.com" target="_blank"> goforaudition.com</a> </p>

				</body>
				</html>
	 	 
	'; // Our message above including the link
						 
	$headers = 'From:info@goforaudition.com' . "\r\n"; // Set from headers
	mail($to, $subject, $message, $headers); // Send our email.
*/
	// sms gateway.................
			
			
			$data="key=35878B4953A805&routeid=230&type=text&contacts=".$mobile."&senderid=ARSOPT&msg=".$otpmsg;
			
			/*$data="mobile=9867777284&pass=KEXLV&senderid=MANZIL&to=8898205658&msg=Dear Ashwani Kumar Gupta, ".$username." expressed interest on your property ad on Manzildeal.com Call +91-".$mobile." to get in touch.";
			
			$data1="mobile=9867777284&pass=KEXLV&senderid=MANZIL&to=".$mobile."&msg=Dear ".$username.", thanks for expressing interest on Manzildeal.com you can contact advertiser Ashwani on 8898205658.";*/
			$url="http://www.shinenetcor.com/app/smsapi/index.php?";
			
			 function postdata($url,$data)
				{
					$objURL = curl_init($url);
					curl_setopt($objURL, CURLOPT_RETURNTRANSFER, 1); 
					curl_setopt($objURL,CURLOPT_POST,1);
					curl_setopt($objURL, CURLOPT_POSTFIELDS,$data);
					$retval = trim(curl_exec($objURL));
					curl_close($objURL);
					//echo $retval;
					
				}
			 /*function postdata1($url,$data)
				{
					$objURL = curl_init($url);
					curl_setopt($objURL, CURLOPT_RETURNTRANSFER, 1); 
					curl_setopt($objURL,CURLOPT_POST,1);
					curl_setopt($objURL, CURLOPT_POSTFIELDS,$data);
					$retval = trim(curl_exec($objURL));
					curl_close($objURL);
					//echo $retval;
					
				}*/
				postdata($url,$data);
				//postdata1($url,$data1);
			
			//Sender ID Does not Exist or Pending or Route Invalid!
			
			//sms gateway.................
	
	echo 'Success';

}
else
{
	echo "You are already Registered at Arsh Optical";
}
}
else
{
	echo "Password Must a letter and a number with minimum 6 characters long";
}
?>