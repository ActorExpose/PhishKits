<?php 
error_reporting(0);
session_start();

include 'config/configuration.php';
if(isset($_POST['username']) && !empty($_POST['username']) AND isset($_POST['password']) && !empty($_POST['password']))
{
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    // $sql="SELECT usr_name, usr_email, usr_pwd, usr_active FROM arsh_new_usr WHERE usr_name='".$username."' AND usr_pwd='".$password."' AND usr_active='1'";
	
    $search = mysqli_query($con,"SELECT usr_name, usr_email, usr_pwd, usr_active FROM bhang_new_usr WHERE (usr_mobile='".$username."' or usr_email='".$username."') AND usr_pwd='".$password."' AND (usr_active='1' or mob_active='1')"); 
    $match = mysqli_num_rows($search);
	if($match>0)
	{
		$row=mysqli_fetch_array($search);
		$_SESSION['auditionname']=$row['usr_name'];
		$_SESSION['usermail']=$row['usr_email'];
		header('Location:index.php');
	}
	else
	{
		$error="Invalid Credential";
	}
}

?>
<!DOCTYPE html>
 <head>
<meta charset="utf-8">
<title>Login Here</title>
<meta name="description" content="">
<meta name="author" content="">
<meta name="robots" content="">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

<link rel="stylesheet" href="css/bootstrap-2.1.css">
<link rel="stylesheet" href="css/plugins-2.1.css">
<link rel="stylesheet" href="css/main-2.1.css">
<link rel="stylesheet" href="css/themes-2.0.css">
<script src="js/vendor/modernizr-respond.min.js"></script>
<style>
#otp,#loginotp,#mobile-login,#loader1,#loader2,#loader3,#loader5{display:none;}
.lgbt{padding:10px;text-align:center;border:2px solid #2196f3;border-radius:10px; color: #2196f3; cursor:pointer;}
#message,#message3,#message4{color:red;}
</style>
</head>
<body>

<div id="login-container">
<div id="page-content" class="block remove-margin" style="border:1px solid #647AB3;box-shadow:0px 0px 5px #647AB3;">
<div class="block-header">
<div class="header-section">

<h3 class="text-center"><!-- <img src="img/logo.png" class="img-responsive" style="height:80px;float:left;margin-top:-30px"/>--> Welcome to AVPS Panel</h3>
</div>
</div>

<form action="" id="mobile-login" method="post" class="form-horizontal">
<div class="form-group">
	<div class="col-xs-12">
	<div class="input-group">
	<span class="input-group-addon"><i class="fa fa-phone fa-fw"></i></span>
	<input type="text" id="login-email" onkeypress="return isNumber(event);" maxlength="10" name="mobile" class="form-control input-lg" placeholder="Enter Registered Mobile No." autocomplete="off" >
	</div>
	</div>
</div>

<div class="form-group">
<div class="col-xs-8">
<img src="img/loader.gif" id="loader1"/>
<span id="message"></span>
</div>
<div class="col-xs-4 text-right">
<button type="submit" name="submit" class="btn btn-sm btn-primary"><i class="fa fa-angle-right"></i> Login</button>
</div>
</div>

<div class="form-group">
<div class="col-xs-6 col-xs-offset-3">
<div class="lgbt" id="maillogin">
Login with Email-Id
</div>
</div>
</div>

<div class="form-group">
<div class="col-xs-12">
<p class="text-center remove-margin"><small>Don't have an account?</small> <a href="javascript:void(0)" id="link-login0"><small>Create one for free!</small></a></p>
</div>
</div>

</form>

<form action="" method="post" id="loginotp" class="form-horizontal">

<div class="form-group">
	<div class="col-xs-12">
	<div class="input-group">
	<span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
	<input type="text" id="login-email" onkeypress="return isNumber(event);" maxlength="6" name="otp" class="form-control input-lg" placeholder="OTP" autocomplete="off" >
	</div>
	</div>
</div>

<div class="form-group">
<div class="col-xs-8">
<img src="img/loader.gif" id="loader2"/>
<span id="message2"></span>
</div>
<div class="col-xs-4 text-right">
<button type="submit" name="submit" class="btn btn-sm btn-primary"><i class="fa fa-angle-right"></i> Submit</button>
</div>
</div>

</form>


<form action="" method="post" id="form-login" class="form-horizontal">

<div class="form-group">
	<div class="col-xs-12">
	<div class="input-group">
	<span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
	<input type="text" id="login-email" name="email" class="form-control input-lg" placeholder="Enter Email or Registered Mobile" autocomplete="off" required>
	</div>
	</div>
</div>

<div class="form-group">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-asterisk fa-fw"></i></span>
<input type="password" id="login-password" name="password" class="form-control input-lg" placeholder="Password">
<input type="checkbox" id="login-remember" name="login-remember" hidden>
</div></div>
</div>



<div class="form-group">
<div class="col-xs-12">

<a href="#myForgot" data-toggle="modal" id=""><small>Forgot Password?</small></a>


</div>
</div>
<div class="form-group">
<div class="col-xs-6">
<div class="btn-group">
<button type="button" class="btn btn-sm btn-default disabled">Remember me?</button>
<button type="button" class="btn btn-sm btn-default" data-toggle="button" id="btn-remember"><i class="fa fa-check"></i>
</button>
</div>
</div>
<div class="col-xs-6 text-right">
<button type="submit" name="submit" class="btn btn-sm btn-primary"><i class="fa fa-angle-right"></i> Login</button>
<img src="img/loader.gif" id="loader3"/>
<div id="message3"></div>
</div>
</div>
<!--
<div class="form-group">
<div class="col-xs-6 col-xs-offset-3">
<div class="lgbt" id="moblogin">
Login with Mobile
</div>
</div>
</div>

<div class="form-group">
<div class="col-xs-12">
<p class="text-center remove-margin"><small>Don't have an account?</small> <a href="javascript:void(0)" id="link-login"><small>Create one for free!</small></a></p>
</div>
</div>-->
</form>

<form action="" method="post" id="form-register" class="form-horizontal display-none" >

<div class="form-group signup">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
<input type="text" id="register-username" name="username" class="form-control input-md" autocomplete="off"  maxlength="50" placeholder="Username" required />
</div>
</div>
</div>
<div class="form-group signup">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
<input type="text" id="" name="company" class="form-control input-md" autocomplete="off" placeholder="Company Name" maxlength="60" required />
</div>
</div>
</div>
<div class="form-group signup">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-map-marker fa-fw"></i></span>
<input type="text" name="address"  class="form-control input-md" autocomplete="off" placeholder="Address" maxlength="100"  required />
</div>

</div>
</div>
<div class="form-group signup">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-phone fa-fw"></i></span>
<input type="text" name="mobile"  class="form-control input-md" autocomplete="off" placeholder="Mobile Number" maxlength="10" onkeypress="return isNumber(event);" required />
</div>

</div>
</div>
<div class="form-group signup">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
<input type="text" name="tin"  class="form-control input-md" autocomplete="off" placeholder="Tin Number" maxlength="12" onkeypress="return isNumber(event);" required />
</div>

</div>
</div>

<div class="form-group signup">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
<input type="text" id="register-email" name="email" class="form-control input-md" autocomplete="off" placeholder="Email" required />
</div>
</div>
</div>

<div class="form-group signup">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-asterisk fa-fw"></i></span>
<input type="password" id="register-password" name="password" class="form-control input-md" autocomplete="off" placeholder="Password" required />
</div>
<div id="message4"></div>


</div>
</div>

<div class="form-group" id="otp">
<div class="col-md-12">
<div class="col-md-6">
<input type="text" id="otpvalue" class="form-control input-lg" autocomplete="off" maxlength="6" placeholder="OTP"  />
</div>
<div class="col-md-6">
<input type="submit" id="otpsubmit" class="btn btn-sm btn-default" value="Submit" />
</div>
</div>
</div>

<div class="form-group signup">
<div class="col-xs-6">
<div class="btn-group">
<a href="#modal-terms" class="btn btn-sm btn-primary" data-toggle="modal">Terms</a>
<button type="button" class="btn btn-sm btn-default" data-toggle="button" id="btn-terms"><i class="fa fa-check"></i> Agree</button>
</div>
</div>
<div class="col-xs-6 text-right">
<button type="submit" id="submit" name="submit" class="btn btn-sm btn-success"><i class="fa fa-angle-right"></i> Register</button>
<img src="img/loader.gif" id="loader"/>

</div>
</div>
<div class="form-group">
<div class="col-xs-12">
<p class="text-center remove-margin"><small>Oops, you have an account?</small> <a href="javascript:void(0)" id="link-register"><small>Login!</small></a></p>
</div>
</div>
</form>

<div id="modal-terms" class="modal" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">Terms &amp; Conditions</h4>
</div>

</div>
</div>
</div>
</div>
</div>
<script src="js/jquery-1.11.0.min.js"></script>
<script>!window.jQuery && document.write(decodeURI('%3Cscript src="js/vendor/jquery-1.11.1.min.js"%3E%3C/script%3E'));</script>
<script src="js/vendor/bootstrap.min-2.1.js"></script>
<script src="js/plugins-2.1.js"></script>
<script src="js/main-2.1.js"></script>
<script>$(function(){var e=$("#login-remember"),c=$("#register-terms"),i=$("#btn-remember"),r=$("#btn-terms");e.prop("checked")&&i.addClass("active"),c.prop("checked")&&r.addClass("active"),i.on("click",function(){e.prop("checked",!e.prop("checked"))}),r.on("click",function(){c.prop("checked",!c.prop("checked"))});var n=$("#form-login"),o=$("#form-register");$("#link-login").click(function(){n.slideUp(250),o.slideDown(250)}),$("#link-register").click(function(){o.slideUp(250),n.slideDown(250)})});</script>
</body>
</html>
<script>
$(document).ready(function(){
	
	$("#register").on("click",function(e){
		e.preventDefault();
		$("#form-login1").hide();
		$("#form-register1").show("slow");
	} );
	
	$("#link-login0").on("click",function(e){
		e.preventDefault();
		$("#form-register").show("slow");
		$("#mobile-login").hide();
	} );
	$("#login").on("click",function(e){
		e.preventDefault();
		$("#form-register1").hide();
		$("#form-login1").show("slow");
	} );
	$("#maillogin").on("click",function(e){
		e.preventDefault();
		$("#mobile-login").hide();
		$("#form-login").show("slow");
	} );
	$("#moblogin").on("click",function(e){
		e.preventDefault();
		$("#mobile-login").show("slow");
		$("#form-login").hide();
	} );
	
	
} );
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	if(charCode==46){return false;}
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
	}
</script>
<!-- Modal -->
<div id="myForgot" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Forgot Password</h4>
      </div>
      <div class="modal-body" style="height:130px;">
	  <div class="row">
	 <form action="" method="post" id="forgotform" enctype="multipart/form-data" class="form-horizontal" >
		<div class="form-group">
		<label class="col-md-3 control-label" for="example-text-input">Email </label>
		<div class="col-md-9">
		<input type="email" id="email" name="email" value="" class="form-control" placeholder="Your Email">
		</div>
		</div>
	  
       
		<div class="form-group">
		<label class="col-md-3 control-label" for="small-textarea"></label>
		<div class="col-md-9">
		<input type="submit" name="submit" class="btn btn-primary" value="Send"/> 
		<img src="img/loader.gif" id="loader5"/>
		<div id="message5"></div>
		</div>
		</div>
		
		
	 </form>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<script>
$(document).ready(function(){
	$('#loader').hide();
		$("#form-register").on("submit",function(e){
				e.preventDefault();
				$('#loader').show();
				$.ajax({
					url: "register.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false,        // To send DOMDocument or non processed data file it is set to false
					success: function(data)   // A function to be called if request succeeds
					{
					$('#loader').hide();
					if(data=="Success")
					{
						$('#otp').show();
						$(".signup").hide();
					}
					else
					{
						$("#message4").html(data);
					}
					//$(window).scrollTop(250);
					//$('html, body').animate({scrollTop:150}, 'slow');
					//window.location="dataedit.php";
					///alert(data);
					
					//location.reload();
					//$(this).trigger("reset");
					}
				});
			});
			//////////////Email Login///////////////////
			
			$("#form-login").on("submit",function(e){
				e.preventDefault();
				$('#loader3').show();
				$.ajax({
					url: "emaillogin.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false,        // To send DOMDocument or non processed data file it is set to false
					success: function(data)   // A function to be called if request succeeds
					{
					$('#loader3').hide();
					if(data=="Success")
					{
						$("#message3").html("");
						window.location="index.php";
					}
					else
					{
						$("#message3").html(data);
					}
					//$(".signup").hide();
					//location.reload();
					//$(this).trigger("reset");
					}
				});
			});
			//////////////Mobile Login///////////////////
			
			$("#mobile-login").on("submit",function(e){
				e.preventDefault();
				$('#loader1').show();
				$.ajax({
					url: "mobilelogin.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false,        // To send DOMDocument or non processed data file it is set to false
					success: function(data)   // A function to be called if request succeeds
					{
					$('#loader1').hide();
					if(data=="Success")
					{
						$("#mobile-login").hide();
						$('#loginotp').show();
					}
					else
					{
						$("#message").html(data);
					}
					//$(".signup").hide();
					//location.reload();
					//$(this).trigger("reset");
					}
				});
			});
			////////Mobile Login check through OTP /////////////////////
			
			$("body").on("submit","#loginotp",function(e){
				e.preventDefault();
				$('#loader2').show();
				$.ajax({
					url: "otplogin.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false,        // To send DOMDocument or non processed data file it is set to false
					success: function(data)   // A function to be called if request succeeds
					{
					$('#loader2').hide();
					 if(data=="Success")
					 {
						  $("#message2").html("");
						  window.location="index.php";
					 }
					 else
					 {
						 $("#message2").html(data);
					 }
						
					
					}
				});
			});
			
			//////////////signup OTP//////////////
		$("#otpsubmit").on("click",function(e){
				e.preventDefault();
				var o=$("#otpvalue").val();
				if(o==''){return false;}
				var datastr="otp="+o;
				$('#loader').show();
				$.ajax({
					url: "otpchk.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: datastr, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					success: function(data)   // A function to be called if request succeeds
					{
						
					 if(data=="Success")
					 {
						 $('#loader').hide();
						 alert("Mobile Verification successfull");
						 window.location="index.php";
					 }
					 else{
						 alert("Invalid OTP KEY");
					 }
					
					//$(window).scrollTop(250);
					//$('html, body').animate({scrollTop:150}, 'slow');
					//window.location="dataedit.php";
					
					//$('#otp').show();
					
					//$(this).trigger("reset");
					}
				});
			});	
			////////Forgot Password /////////////////////
			
			$("body").on("submit","#forgotform",function(e){
				e.preventDefault();
				$('#loader5').show();
				$.ajax({
					url: "forgotpassword.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false,        // To send DOMDocument or non processed data file it is set to false
					success: function(data)   // A function to be called if request succeeds
					{
					$('#loader5').hide();
					 if(data=="Success")
					 {
						  alert(data);
						  window.location="../";
					 }
					 else
					 {
						 $("#message5").html(data);
					 }
						
					
					}
				});
			});
			
});
</script>