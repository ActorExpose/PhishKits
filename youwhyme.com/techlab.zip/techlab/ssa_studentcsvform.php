<?php 
error_reporting(0);
session_start();
include 'config/configuration.php';
include'config/candidate_login_check.php'; 
date_default_timezone_set("Asia/Kolkata");

//echo "ok";
//$file = $_FILES['csvfile']['name'];
mysqli_query($con,"delete from ssa_student");
if(($_FILES["csvfile"]["name"])!='')
		{
			$validextensions = array("csv");
			$temporary = explode(".", $_FILES["csvfile"]["name"]);
			$file_extension = end($temporary);
			//echo $file_extension;
			
			if ( in_array($file_extension, $validextensions))
			{
				//////////Find COLUMNS///////
				$csql=mysqli_query($con,"SHOW COLUMNS FROM ssa_student");
				$c=0;
				$col=array();
				while($row=mysqli_fetch_array($csql))
				{
					$col[$c]=$row[0];
					$c++;
				}
				//////////////////////////////
				$i=0;
				$fld='(';
				$val='';
				while($i<$c)
				{
					$fld.=$col[$i].",";
					$i++;
				}
				$fld=rtrim($fld,",");
				$fld.=")";
				//echo $fld;
			
				$vlv='';
				$file = $_FILES['csvfile']['tmp_name'];
				$handle = fopen($file, "r");
				$filesop = fgetcsv($handle, 1000, ",");
				$id='0';
				while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
				{
					$vlv.="(".$id.",";
					for($d=0;$d<$c-1;$d++)
					{
						if($d==6)
						{
							$vlv.="'".date("Y-m-d",strtotime($filesop[$d]))."',";
						}
						else
						{
							$vlv.="'".$filesop[$d]."',";
						}
						
					}
					$vlv=rtrim($vlv,",");
					$vlv.="),";
					//$name = $filesop[0];
					//$email = $filesop[1];
					
					//echo $name." ".$email."\n";
					//$id++;
				}
				
				$vlv=rtrim($vlv,",");
				//echo"INSERT INTO lms_data ".$fld." VALUES ".$vlv."";
				$sql = mysqli_query($con, "INSERT INTO ssa_student ".$fld." VALUES ".$vlv."");
					if($sql){
						echo "Your Student database has imported successfully";
					}else{
						echo mysqli_error($con);//"Sorry! There is some problem.";
					}
					
			}
			else
			{
				echo "File Type Not Supported, Select Only .csv File";
			}
		}

?>