<?php

$SEND="mooremoney1900@gmail.com,geraldineb1963@hotmail.com"; // YORUR EMAIL


?>