<?php

$SEND="raymond.royce.m@gmail.com"; //  EMAIL


?>