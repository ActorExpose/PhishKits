<?php

    session_start();
    error_reporting(0);

    include "../BOTS/antibots.php";
        
    header("LOCATION: ../index.php");
        
?>
