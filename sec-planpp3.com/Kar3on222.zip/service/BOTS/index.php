<?php

    session_start();
    error_reporting(0);

    include "./antibots.php";

    echo "<h1>Invalid Token Please Check Your Link</h1>";

?>
