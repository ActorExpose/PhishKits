<?php

$arContext['http']['timeout'] = 10;
$context = stream_context_create($arContext);

$response = file_get_contents('http://www.shroomery.org/ythan/proxycheck.php?ip='.$_SERVER['REMOTE_ADDR'], 0, $context);

if ($response == 'Y') {

	echo "<h1>We detect that you're using a proxy , for security reasons please disable it and try again ! </h1>";
die();
}